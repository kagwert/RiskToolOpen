function [S_raw, S_smooth, position, S_discrete] = aggregate_signals( ...
        s_mom, s_macro, s_policy, alpha, beta, threshold, smooth_win, pre_score)
% AGGREGATE_SIGNALS  Module 4: combine sub-signals → regime-filtered position.
%
%   Linear path (default):
%   [S_raw, S_smooth, position, S_discrete] = aggregate_signals(
%       s_mom, s_macro, s_policy, alpha, beta, threshold)
%   [S_raw, S_smooth, position, S_discrete] = aggregate_signals(
%       s_mom, s_macro, s_policy, alpha, beta, threshold, smooth_win)
%
%   Decision-tree path (pre_score bypasses the weighted sum):
%   [S_raw, S_smooth, position, S_discrete] = aggregate_signals(
%       [], [], [], [], [], threshold, smooth_win, pre_score)
%     pre_score - T×1 external score in [-1,+1] (e.g. from train_duration_tree)
%
%   Inputs:
%     s_mom, s_macro, s_policy - T×1 module signals ∈ [-1,+1]
%     alpha      - Weight on s_mom        (scalar, 0–1)
%     beta       - Weight on s_macro      (scalar, 0–1; gamma = 1-alpha-beta)
%     threshold  - Entry threshold for position switch (scalar, 0–1)
%     smooth_win - Trailing-mean window applied to S_raw before thresholding
%                  (integer days, default 63 ≈ 3 months)
%
%   Outputs:
%     S_raw      - T×1 daily composite signal ∈ [-1,+1]  (unsmoothed)
%     S_smooth   - T×1 causal trailing-mean of S_raw over smooth_win days
%     position   - T×1 discrete duration (years): 2, 4, or 6
%     S_discrete - T×1 mapped to {-1, 0, +1}
%
%   Position logic (hysteresis):
%     gamma = 1 - alpha - beta
%     S_raw   = alpha·s_mom + beta·s_macro + gamma·s_policy
%     S_smooth = trailing mean of S_raw over smooth_win days
%
%     Entry threshold  : thr_enter = threshold
%     Exit  threshold  : thr_exit  = threshold × 0.5
%       (requires signal to decay well below entry before reversing)
%
%     From NEUTRAL (4y):
%       S_smooth >  thr_enter  → go LONG  (6y)
%       S_smooth < -thr_enter  → go SHORT (2y)
%     From LONG (6y):
%       S_smooth <  thr_exit   → revert to NEUTRAL (4y)
%     From SHORT (2y):
%       S_smooth > -thr_exit   → revert to NEUTRAL (4y)
%
%   Notes:
%     A 1-day signal lag is applied in run_backtest, not here.
%     All NaN S_smooth dates carry forward the last valid position.

%% === Defaults & validation ===============================================
if nargin < 7, smooth_win = 63; end
if nargin < 8, pre_score  = []; end

use_tree = ~isempty(pre_score);

if use_tree
    % Decision-tree path: validate pre_score only
    assert(threshold > 0 && threshold < 1, 'threshold must be in (0,1)');
    assert(smooth_win >= 1,                'smooth_win must be ≥ 1');
    T = numel(pre_score);
else
    % Linear path: validate all weights and signals
    assert(alpha >= 0 && alpha <= 1,  'alpha must be in [0,1]');
    assert(beta  >= 0 && beta  <= 1,  'beta must be in [0,1]');
    assert(alpha + beta <= 1,          'alpha + beta must be ≤ 1');
    assert(threshold > 0 && threshold < 1, 'threshold must be in (0,1)');
    assert(smooth_win >= 1,            'smooth_win must be ≥ 1');
    T = numel(s_mom);
    assert(numel(s_macro)  == T, 'All signals must have the same length');
    assert(numel(s_policy) == T, 'All signals must have the same length');
end

%% === Composite signal ====================================================
if use_tree
    S_raw = max(-1, min(1, pre_score(:)));   % decision-tree path: score is pre-computed
else
    gamma = 1 - alpha - beta;
    S_raw = alpha * s_mom(:) + beta * s_macro(:) + gamma * s_policy(:);
    S_raw = max(-1, min(1, S_raw));
end

%% === Causal smoothing ====================================================
% movmean(..., [smooth_win-1, 0]) uses only past and current values.
S_smooth = movmean(S_raw, [smooth_win - 1, 0], 'omitnan');
S_smooth = max(-1, min(1, S_smooth));

%% === Hysteresis position logic ===========================================
thr_enter = threshold;
thr_exit  = threshold * 0.5;   % must decay to 50% of entry to exit

position   = 4 * ones(T, 1);   % start neutral
S_discrete = zeros(T, 1);

for t = 2:T
    s    = S_smooth(t);
    prev = position(t-1);

    if isnan(s)
        position(t) = prev;     % hold last position through missing data
        continue
    end

    switch prev
        case 4   % currently NEUTRAL — enter on threshold breach
            if    s >  thr_enter,  position(t) = 6;
            elseif s < -thr_enter, position(t) = 2;
            else,                  position(t) = 4;
            end

        case 6   % currently LONG — stay until signal decays past exit
            if s < thr_exit,  position(t) = 4;
            else,             position(t) = 6;
            end

        case 2   % currently SHORT — stay until signal recovers past exit
            if s > -thr_exit, position(t) = 4;
            else,             position(t) = 2;
            end

        otherwise
            position(t) = 4;
    end
end

%% === Discrete signal map =================================================
S_discrete(position == 6) =  1;
S_discrete(position == 2) = -1;
end
