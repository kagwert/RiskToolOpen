function [X, feat_names, feat_groups] = build_feature_matrix(yield_tt, macro_tt, policy_tt, market_tt, mom_sub)
% BUILD_FEATURE_MATRIX  Assemble a T×p raw-feature matrix for the duration decision tree.
%
%   [X, feat_names, feat_groups] = build_feature_matrix(yield_tt, macro_tt, policy_tt, market_tt, mom_sub)
%
%   Inputs:
%     yield_tt   - Daily timetable: DGS2/3MO/5/7/10/20/30, DFII2/5/10, T5YIE/T10YIE/T5YIFR
%     macro_tt   - Daily timetable (LOCF from monthly/weekly): CPI, CoreCPI, INDPRO, Payrolls,
%                  PMI, LEI, CFNAI, InitialClaims, AHE, GDP, RetailSales, UNRATE, NROU,
%                  Breakeven5y5y, Breakeven10y
%     policy_tt  - Daily timetable (LOCF): FEDFUNDS, DFII10, CorePCE_level, CorePCE, UNRATE, NROU
%     market_tt  - Daily timetable: VIX, Gold, Copper, HY_OAS, IG_OAS, NFCI,
%                  Mortgage30y, HousingStarts, BAA, AAA
%     mom_sub    - Struct from compute_momentum_signal: s_short, s_medium, s_long, s_slope, adx_scale
%
%   Outputs:
%     X           - T×p double matrix (raw, no z-score except where noted)
%     feat_names  - 1×p cell array of feature name strings
%     feat_groups - 1×p cell array of group labels (A–L)
%
%   Design:
%     ~91 features; raw levels + momentum/change companions.
%     Trees are scale-invariant — z-scores only where historical context matters.
%     All computations strictly causal (no lookahead).
%     NaN columns are OK — fitctree uses surrogate splits.

%% === Determine T ==========================================================
T = 0;
candidates = {yield_tt, macro_tt, policy_tt, market_tt};
for ci = 1:numel(candidates)
    if ~isempty(candidates{ci}) && istimetable(candidates{ci})
        T = height(candidates{ci});
        break;
    end
end
if T == 0 && isstruct(mom_sub) && isfield(mom_sub, 's_short')
    T = numel(mom_sub.s_short);
end
if T == 0
    error('build_feature_matrix: cannot determine T from inputs.');
end

%% === Extract raw series ===================================================
% Yield series
r2   = gc(yield_tt, 'DGS2');
r3mo = gc(yield_tt, 'DGS3MO');
r5   = gc(yield_tt, 'DGS5');
r10  = gc(yield_tt, 'DGS10');
r30  = gc(yield_tt, 'DGS30');

% Real rates: try yield_tt first, then policy_tt
dfii2  = gc(yield_tt, 'DFII2');
dfii5  = gc(yield_tt, 'DFII5');
dfii10 = gc(yield_tt, 'DFII10');
if all(isnan(dfii10))
    dfii10 = gc(policy_tt, 'DFII10');
end

% Breakevens
be5y   = gc(yield_tt, 'T5YIE');
be10y  = gc(yield_tt, 'T10YIE');
if all(isnan(be10y))
    be10y = gc(macro_tt, 'Breakeven10y');
end
be5y5y = gc(yield_tt, 'T5YIFR');
if all(isnan(be5y5y))
    be5y5y = gc(macro_tt, 'Breakeven5y5y');
end

% Macro series
cpi         = gc(macro_tt, 'CPI');
core_cpi    = gc(macro_tt, 'CoreCPI');
indpro      = gc(macro_tt, 'INDPRO');
payrolls    = gc(macro_tt, 'Payrolls');
pmi         = gc(macro_tt, 'PMI');
lei         = gc(macro_tt, 'LEI');
cfnai       = gc(macro_tt, 'CFNAI');
init_claims = gc(macro_tt, 'InitialClaims');
ahe         = gc(macro_tt, 'AHE');
gdp         = gc(macro_tt, 'GDP');
retail      = gc(macro_tt, 'RetailSales');
unrate      = gc(macro_tt, 'UNRATE');
nrou        = gc(macro_tt, 'NROU');

% Policy series
fedfunds       = gc(policy_tt, 'FEDFUNDS');
core_pce_yoy   = gc(policy_tt, 'CorePCE');
core_pce_level = gc(policy_tt, 'CorePCE_level');
% Fallback: compute CorePCE YoY from level if column is all NaN
if all(isnan(core_pce_yoy))
    pce_lag = lag_k(core_pce_level, 252);
    core_pce_yoy = 100 * (core_pce_level ./ pce_lag - 1);
    core_pce_yoy(pce_lag <= 0) = NaN;
end

% Market series
vix          = gc(market_tt, 'VIX');
gold         = gc(market_tt, 'Gold');
copper       = gc(market_tt, 'Copper');
hy_oas       = gc(market_tt, 'HY_OAS');
ig_oas       = gc(market_tt, 'IG_OAS');
nfci         = gc(market_tt, 'NFCI');
mortgage30y  = gc(market_tt, 'Mortgage30y');
houst        = gc(market_tt, 'HousingStarts');
baa          = gc(market_tt, 'BAA');
aaa          = gc(market_tt, 'AAA');

%% === Accumulators =========================================================
names_acc  = {};
groups_acc = {};
vals_acc   = {};

%% =========================================================================
%% GROUP A — Yield Levels (4)
%% =========================================================================
grp = 'A_YieldLevels';
names_acc{end+1} = 'r_2y';   groups_acc{end+1} = grp; vals_acc{end+1} = r2;
names_acc{end+1} = 'r_5y';   groups_acc{end+1} = grp; vals_acc{end+1} = r5;
names_acc{end+1} = 'r_10y';  groups_acc{end+1} = grp; vals_acc{end+1} = r10;
names_acc{end+1} = 'r_30y';  groups_acc{end+1} = grp; vals_acc{end+1} = r30;

%% =========================================================================
%% GROUP B — Rate Changes (10)
%% =========================================================================
grp = 'B_RateChanges';
names_acc{end+1} = 'dr_2y_1m';     groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(r2,  21);
names_acc{end+1} = 'dr_2y_3m';     groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(r2,  63);
names_acc{end+1} = 'dr_5y_3m';     groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(r5,  63);
names_acc{end+1} = 'dr_10y_1m';    groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(r10, 21);
names_acc{end+1} = 'dr_10y_3m';    groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(r10, 63);
names_acc{end+1} = 'dr_10y_12m';   groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(r10, 252);
names_acc{end+1} = 'dr_30y_3m';    groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(r30, 63);
names_acc{end+1} = 'dr_30y_12m';   groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(r30, 252);
spr_2s10s_raw = r10 - r2;
names_acc{end+1} = 'dr_2s10s_1m';  groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(spr_2s10s_raw, 21);
names_acc{end+1} = 'dr_2s10s_3m';  groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(spr_2s10s_raw, 63);

%% =========================================================================
%% GROUP C — Curve Shape (8)
%% =========================================================================
grp = 'C_CurveShape';
names_acc{end+1} = 'spr_2s10s';    groups_acc{end+1} = grp; vals_acc{end+1} = r10 - r2;
names_acc{end+1} = 'spr_3m10y';    groups_acc{end+1} = grp; vals_acc{end+1} = r10 - r3mo;
names_acc{end+1} = 'spr_5s30s';    groups_acc{end+1} = grp; vals_acc{end+1} = r30 - r5;
names_acc{end+1} = 'spr_2s30s';    groups_acc{end+1} = grp; vals_acc{end+1} = r30 - r2;
names_acc{end+1} = 'butterfly_5y'; groups_acc{end+1} = grp; vals_acc{end+1} = r5 - 0.5*(r2 + r10);
r_level_avg_val = (r2 + r5 + r10) / 3;
names_acc{end+1} = 'r_level_avg';  groups_acc{end+1} = grp; vals_acc{end+1} = r_level_avg_val;
inv_2s10s_val = double(r2 > r10);   inv_2s10s_val(isnan(r2) | isnan(r10)) = NaN;
names_acc{end+1} = 'inv_2s10s';    groups_acc{end+1} = grp; vals_acc{end+1} = inv_2s10s_val;
inv_3m10y_val = double(r3mo > r10); inv_3m10y_val(isnan(r3mo) | isnan(r10)) = NaN;
names_acc{end+1} = 'inv_3m10y';    groups_acc{end+1} = grp; vals_acc{end+1} = inv_3m10y_val;

%% =========================================================================
%% GROUP D — Real Rates & Breakevens (8)
%% =========================================================================
grp = 'D_RealBreakeven';
names_acc{end+1} = 'real_2y';      groups_acc{end+1} = grp; vals_acc{end+1} = dfii2;
names_acc{end+1} = 'real_5y';      groups_acc{end+1} = grp; vals_acc{end+1} = dfii5;
names_acc{end+1} = 'real_10y';     groups_acc{end+1} = grp; vals_acc{end+1} = dfii10;
names_acc{end+1} = 'be_5y';        groups_acc{end+1} = grp; vals_acc{end+1} = be5y;
names_acc{end+1} = 'be_10y';       groups_acc{end+1} = grp; vals_acc{end+1} = be10y;
names_acc{end+1} = 'be_5y5y';      groups_acc{end+1} = grp; vals_acc{end+1} = be5y5y;
names_acc{end+1} = 'dreal_10y_3m'; groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(dfii10, 63);
names_acc{end+1} = 'dbe_10y_3m';   groups_acc{end+1} = grp; vals_acc{end+1} = roll_chg(be10y,  63);

%% =========================================================================
%% GROUP E — Inflation (9)
%% =========================================================================
grp = 'E_Inflation';
cpi_yoy_val      = pct_chg(cpi,      252);
core_cpi_yoy_val = pct_chg(core_cpi, 252);
cpi_3m_ann_val   = ann_chg(cpi,      63);
cpi_6m_ann_val   = ann_chg(cpi,      126);
core_3m_ann_val  = ann_chg(core_cpi, 63);
infl_mom_val     = cpi_3m_ann_val - cpi_6m_ann_val;
infl_vs_tgt_val  = core_pce_yoy - 2.0;
z_cpi_yoy_val    = rolling_zscore(cpi_yoy_val, 756);

names_acc{end+1} = 'cpi_yoy';       groups_acc{end+1} = grp; vals_acc{end+1} = cpi_yoy_val;
names_acc{end+1} = 'core_cpi_yoy';  groups_acc{end+1} = grp; vals_acc{end+1} = core_cpi_yoy_val;
names_acc{end+1} = 'core_pce_yoy';  groups_acc{end+1} = grp; vals_acc{end+1} = core_pce_yoy;
names_acc{end+1} = 'cpi_3m_ann';    groups_acc{end+1} = grp; vals_acc{end+1} = cpi_3m_ann_val;
names_acc{end+1} = 'cpi_6m_ann';    groups_acc{end+1} = grp; vals_acc{end+1} = cpi_6m_ann_val;
names_acc{end+1} = 'core_3m_ann';   groups_acc{end+1} = grp; vals_acc{end+1} = core_3m_ann_val;
names_acc{end+1} = 'infl_mom';      groups_acc{end+1} = grp; vals_acc{end+1} = infl_mom_val;
names_acc{end+1} = 'infl_vs_target';groups_acc{end+1} = grp; vals_acc{end+1} = infl_vs_tgt_val;
names_acc{end+1} = 'z_cpi_yoy';     groups_acc{end+1} = grp; vals_acc{end+1} = z_cpi_yoy_val;

%% =========================================================================
%% GROUP F — Growth (11)
%% =========================================================================
grp = 'F_Growth';
indpro_yoy_val     = pct_chg(indpro, 252);
indpro_3m_ann_val  = ann_chg(indpro, 63);
indpro_6m_ann_val  = ann_chg(indpro, 126);
indpro_mom_val     = indpro_3m_ann_val - indpro_6m_ann_val;
pmi_vs50_val       = pmi - 50;
pmi_3m_chg_val     = roll_chg(pmi, 63);
lei_3m_pct_val     = pct_chg(lei, 63);
lei_6m_pct_val     = pct_chg(lei, 126);
cfnai_3m_val       = roll_mean(cfnai, 63);
retail_3m_ann_val  = ann_chg(retail, 63);
gdp_yoy_val        = pct_chg(gdp, 252);

names_acc{end+1} = 'indpro_yoy';    groups_acc{end+1} = grp; vals_acc{end+1} = indpro_yoy_val;
names_acc{end+1} = 'indpro_3m_ann'; groups_acc{end+1} = grp; vals_acc{end+1} = indpro_3m_ann_val;
names_acc{end+1} = 'indpro_mom';    groups_acc{end+1} = grp; vals_acc{end+1} = indpro_mom_val;
names_acc{end+1} = 'pmi_level';     groups_acc{end+1} = grp; vals_acc{end+1} = pmi;
names_acc{end+1} = 'pmi_vs50';      groups_acc{end+1} = grp; vals_acc{end+1} = pmi_vs50_val;
names_acc{end+1} = 'pmi_3m_chg';    groups_acc{end+1} = grp; vals_acc{end+1} = pmi_3m_chg_val;
names_acc{end+1} = 'lei_3m_pct';    groups_acc{end+1} = grp; vals_acc{end+1} = lei_3m_pct_val;
names_acc{end+1} = 'lei_6m_pct';    groups_acc{end+1} = grp; vals_acc{end+1} = lei_6m_pct_val;
names_acc{end+1} = 'cfnai_3m';      groups_acc{end+1} = grp; vals_acc{end+1} = cfnai_3m_val;
names_acc{end+1} = 'retail_3m_ann'; groups_acc{end+1} = grp; vals_acc{end+1} = retail_3m_ann_val;
names_acc{end+1} = 'gdp_yoy';       groups_acc{end+1} = grp; vals_acc{end+1} = gdp_yoy_val;

%% =========================================================================
%% GROUP G — Labor Market (9)
%% =========================================================================
grp = 'G_Labor';
ue_gap_val     = nrou - unrate;
ue_chg3m_val   = roll_chg(unrate, 63);
ue_chg12m_val  = roll_chg(unrate, 252);
nfp_3m_val     = roll_chg(payrolls, 63)  / 3;
nfp_6m_val     = roll_chg(payrolls, 126) / 6;
nfp_mom_val    = nfp_3m_val - nfp_6m_val;
claims_4w_val  = roll_mean(init_claims, 20);
ahe_yoy_val    = pct_chg(ahe, 252);

names_acc{end+1} = 'unrate';      groups_acc{end+1} = grp; vals_acc{end+1} = unrate;
names_acc{end+1} = 'ue_gap';      groups_acc{end+1} = grp; vals_acc{end+1} = ue_gap_val;
names_acc{end+1} = 'ue_chg_3m';   groups_acc{end+1} = grp; vals_acc{end+1} = ue_chg3m_val;
names_acc{end+1} = 'ue_chg_12m';  groups_acc{end+1} = grp; vals_acc{end+1} = ue_chg12m_val;
names_acc{end+1} = 'nfp_3m_avg';  groups_acc{end+1} = grp; vals_acc{end+1} = nfp_3m_val;
names_acc{end+1} = 'nfp_6m_avg';  groups_acc{end+1} = grp; vals_acc{end+1} = nfp_6m_val;
names_acc{end+1} = 'nfp_mom';     groups_acc{end+1} = grp; vals_acc{end+1} = nfp_mom_val;
names_acc{end+1} = 'claims_4w';   groups_acc{end+1} = grp; vals_acc{end+1} = claims_4w_val;
names_acc{end+1} = 'ahe_yoy';     groups_acc{end+1} = grp; vals_acc{end+1} = ahe_yoy_val;

%% =========================================================================
%% GROUP H — Fed Policy (7)
%% =========================================================================
grp = 'H_FedPolicy';
ff_3m_chg_val  = roll_chg(fedfunds, 63);
ff_12m_chg_val = roll_chg(fedfunds, 252);
real_ff_val    = fedfunds - core_pce_yoy;
% Taylor rule: neutral_rate + core_pce + 0.5*(core_pce - 2) + 0.5*(ue_gap * 2)
% Simplified: 0.5 + core_pce_yoy + 0.5*(core_pce_yoy - 2) + 1.0*ue_gap
taylor_rule    = 0.5 + core_pce_yoy + 0.5*(core_pce_yoy - 2.0) + 0.5*(ue_gap_val * 2.0);
taylor_gap_val = fedfunds - taylor_rule;
ff_vs_2y_val   = r2 - fedfunds;
z_real_ff_val  = rolling_zscore(real_ff_val, 1260);

names_acc{end+1} = 'ff_level';    groups_acc{end+1} = grp; vals_acc{end+1} = fedfunds;
names_acc{end+1} = 'ff_3m_chg';   groups_acc{end+1} = grp; vals_acc{end+1} = ff_3m_chg_val;
names_acc{end+1} = 'ff_12m_chg';  groups_acc{end+1} = grp; vals_acc{end+1} = ff_12m_chg_val;
names_acc{end+1} = 'real_ff';     groups_acc{end+1} = grp; vals_acc{end+1} = real_ff_val;
names_acc{end+1} = 'taylor_gap';  groups_acc{end+1} = grp; vals_acc{end+1} = taylor_gap_val;
names_acc{end+1} = 'ff_vs_2y';    groups_acc{end+1} = grp; vals_acc{end+1} = ff_vs_2y_val;
names_acc{end+1} = 'z_real_ff';   groups_acc{end+1} = grp; vals_acc{end+1} = z_real_ff_val;

%% =========================================================================
%% GROUP I — Credit & Financial Conditions (8)
%% =========================================================================
grp = 'I_Credit';
hy_oas_3m_val  = roll_chg(hy_oas, 63);
ig_oas_3m_val  = roll_chg(ig_oas, 63);
nfci_3m_val    = roll_chg(nfci,   63);
z_hy_oas_val   = rolling_zscore(hy_oas, 756);
baa_aaa_spr    = baa - aaa;

names_acc{end+1} = 'hy_oas';      groups_acc{end+1} = grp; vals_acc{end+1} = hy_oas;
names_acc{end+1} = 'hy_oas_3m';   groups_acc{end+1} = grp; vals_acc{end+1} = hy_oas_3m_val;
names_acc{end+1} = 'ig_oas';      groups_acc{end+1} = grp; vals_acc{end+1} = ig_oas;
names_acc{end+1} = 'ig_oas_3m';   groups_acc{end+1} = grp; vals_acc{end+1} = ig_oas_3m_val;
names_acc{end+1} = 'nfci';        groups_acc{end+1} = grp; vals_acc{end+1} = nfci;
names_acc{end+1} = 'nfci_3m';     groups_acc{end+1} = grp; vals_acc{end+1} = nfci_3m_val;
names_acc{end+1} = 'z_hy_oas';    groups_acc{end+1} = grp; vals_acc{end+1} = z_hy_oas_val;
names_acc{end+1} = 'baa_aaa_spr'; groups_acc{end+1} = grp; vals_acc{end+1} = baa_aaa_spr;

%% =========================================================================
%% GROUP J — Market Risk & Commodities (8)
%% =========================================================================
grp = 'J_MarketRisk';
vix_1m_chg_val  = roll_chg(vix, 21);
vix_3m_ma_val   = roll_mean(vix, 63);
gold_3m_ret_val  = pct_chg(gold,   63);
gold_12m_ret_val = pct_chg(gold,  252);
copper_3m_ret_val= pct_chg(copper, 63);
cu_au            = safe_div(copper, gold);
cu_au_3m_ret_val = pct_chg(cu_au, 63);
cu_au_12m_ret_val= pct_chg(cu_au, 252);

names_acc{end+1} = 'vix';           groups_acc{end+1} = grp; vals_acc{end+1} = vix;
names_acc{end+1} = 'vix_1m_chg';    groups_acc{end+1} = grp; vals_acc{end+1} = vix_1m_chg_val;
names_acc{end+1} = 'vix_3m_ma';     groups_acc{end+1} = grp; vals_acc{end+1} = vix_3m_ma_val;
names_acc{end+1} = 'gold_3m_ret';   groups_acc{end+1} = grp; vals_acc{end+1} = gold_3m_ret_val;
names_acc{end+1} = 'gold_12m_ret';  groups_acc{end+1} = grp; vals_acc{end+1} = gold_12m_ret_val;
names_acc{end+1} = 'copper_3m_ret'; groups_acc{end+1} = grp; vals_acc{end+1} = copper_3m_ret_val;
names_acc{end+1} = 'cu_au_3m_ret';  groups_acc{end+1} = grp; vals_acc{end+1} = cu_au_3m_ret_val;
names_acc{end+1} = 'cu_au_12m_ret'; groups_acc{end+1} = grp; vals_acc{end+1} = cu_au_12m_ret_val;

%% =========================================================================
%% GROUP K — Housing & Mortgage (4)
%% =========================================================================
grp = 'K_Housing';
mortgage_vs10y_val = mortgage30y - r10;
houst_yoy_val      = pct_chg(houst, 252);
houst_3m_chg_val   = roll_chg(houst, 63);

names_acc{end+1} = 'mortgage_level';  groups_acc{end+1} = grp; vals_acc{end+1} = mortgage30y;
names_acc{end+1} = 'mortgage_vs10y';  groups_acc{end+1} = grp; vals_acc{end+1} = mortgage_vs10y_val;
names_acc{end+1} = 'houst_yoy';       groups_acc{end+1} = grp; vals_acc{end+1} = houst_yoy_val;
names_acc{end+1} = 'houst_3m_chg';    groups_acc{end+1} = grp; vals_acc{end+1} = houst_3m_chg_val;

%% =========================================================================
%% GROUP L — Rate Momentum from mom_sub (5)
%% =========================================================================
grp = 'L_Momentum';
mom_short_val  = mom_field(mom_sub, 's_short',   T);
mom_medium_val = mom_field(mom_sub, 's_medium',  T);
mom_long_val   = mom_field(mom_sub, 's_long',    T);
mom_slope_val  = mom_field(mom_sub, 's_slope',   T);
adx_scale_val  = mom_field(mom_sub, 'adx_scale', T);

names_acc{end+1} = 'mom_short';   groups_acc{end+1} = grp; vals_acc{end+1} = mom_short_val;
names_acc{end+1} = 'mom_medium';  groups_acc{end+1} = grp; vals_acc{end+1} = mom_medium_val;
names_acc{end+1} = 'mom_long';    groups_acc{end+1} = grp; vals_acc{end+1} = mom_long_val;
names_acc{end+1} = 'mom_slope';   groups_acc{end+1} = grp; vals_acc{end+1} = mom_slope_val;
names_acc{end+1} = 'adx_scale';   groups_acc{end+1} = grp; vals_acc{end+1} = adx_scale_val;

%% =========================================================================
%% ASSEMBLE X
%% =========================================================================
p = numel(names_acc);
X = nan(T, p);
for k = 1:p
    v = vals_acc{k};
    if numel(v) == T
        X(:, k) = v(:);
    end
end

% Clip extreme outliers (numerical guard — does not z-score)
X = max(-1e6, min(1e6, X));

feat_names  = names_acc;
feat_groups = groups_acc;

end % main function

%% =========================================================================
%% HELPER SUBFUNCTIONS
%% =========================================================================

function v = gc(tt, nm)
% GC  Get column from timetable by name; return NaN column if absent.
if isempty(tt) || ~istimetable(tt)
    % Cannot determine T from this input alone; return scalar NaN sentinel
    v = NaN;
    return;
end
n = height(tt);
if ismember(nm, tt.Properties.VariableNames)
    v = double(tt.(nm));
    v = v(:);
else
    v = nan(n, 1);
end
end

function v = lag_k(x, k)
% LAG_K  Shift x forward k periods (k leading NaNs).
n = numel(x);
v = nan(n, 1);
if k < n
    v(k+1:end) = x(1:end-k);
end
end

function v = roll_chg(x, k)
% ROLL_CHG  Absolute change: x(t) - x(t-k).
v = x - lag_k(x, k);
end

function v = pct_chg(x, k)
% PCT_CHG  Percent return: 100*(x(t)/x(t-k) - 1).
xlag = lag_k(x, k);
v = 100 * (x ./ xlag - 1);
v(xlag == 0 | isnan(xlag)) = NaN;
end

function v = ann_chg(x, k)
% ANN_CHG  Annualised compound return: 100*((x(t)/x(t-k))^(252/k) - 1).
%   Handles zero/negative lag values safely.
xlag = lag_k(x, k);
denom = max(abs(xlag), 1e-10);
v = 100 * ((x ./ denom) .^ (252/k) - 1);
v(xlag <= 0 | isnan(xlag)) = NaN;
end

function v = roll_mean(x, k)
% ROLL_MEAN  Causal k-period trailing mean (movmean with [k-1, 0]).
x = x(:);
v = movmean(x, [k-1, 0], 'omitnan');
% Set leading rows with fewer than 2 valid obs to NaN to avoid misleading values
for t = 1:min(k-1, numel(v))
    window_vals = x(max(1, t-k+1):t);
    if sum(~isnan(window_vals)) < 2
        v(t) = NaN;
    end
end
end

function v = safe_div(a, b)
% SAFE_DIV  Element-wise a./b with 0/0 → NaN guard.
v = a ./ b;
v(b == 0 | isnan(b)) = NaN;
end

function v = mom_field(s, fname, T)
% MOM_FIELD  Extract field from mom_sub struct; return NaN column if missing.
if isstruct(s) && isfield(s, fname)
    v = s.(fname)(:);
    if numel(v) ~= T
        v = nan(T, 1);
    end
else
    v = nan(T, 1);
end
end
