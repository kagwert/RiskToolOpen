%% DURATION_SIGNAL_MAIN  USD Fixed Income Duration Signal — Main Orchestrator
%
%  Generates a systematic duration positioning signal for USD fixed income,
%  targeting ±1 year around a neutral 4-year duration benchmark (2y/4y/6y).
%
%  Modules:
%    1. Momentum & Trend (compute_momentum_signal)
%    2. Macro Fundamentals (compute_macro_signal)
%    3. Level & Policy Attractiveness (compute_policy_signal)
%    4. Signal Aggregation & Walk-forward Optimization (optimize_parameters)
%    5. Backtest Engine & Performance Attribution (run_backtest)
%
%  Output:
%    - Summary performance table printed to console
%    - 8-panel dashboard saved to duration_signal_dashboard.pdf
%
%  Dependencies:
%    fetch_fred_data.m, interp_to_daily.m, rolling_zscore.m
%    compute_momentum_signal.m, compute_macro_signal.m, compute_policy_signal.m
%    build_feature_matrix.m, train_duration_tree.m  (tree path)
%    aggregate_signals.m, run_backtest.m, optimize_parameters.m, plot_dashboard.m
%
%  Requirements: MATLAB R2019b or later (timetable, webread, jsondecode).
%                No additional toolboxes required (Financial Toolbox optional).
%
%  Usage:
%    Edit FRED_API_KEY below, then press Run (F5) or type:
%      >> duration_signal_main
%
%  Author: Quant Research
%  Date  : 2026-04

clear; clc; close all;

%% =========================================================================
%% USER CONFIGURATION — edit these before running
%% =========================================================================
FRED_API_KEY   = '8bf43d6978221c9897d819ded36bab05';       % <-- REPLACE with your FRED API key
START_DATE     = '1994-01-01';          % Data start (earliest gives more history)
END_DATE       = datestr(today, 'yyyy-mm-dd');  % Latest available
FORCE_REFRESH  = false;                 % true = bypass cache, re-download FRED
RUN_OPTIMISE   = false;                 % false = use DEFAULT_PARAMS below
USE_TREE       = true;                  % true = decision-tree path (bypasses weighted sum)
OUTPUT_PDF     = 'duration_signal_dashboard.pdf';

% --- Market/risk data series (decision tree features) ---
% These are fetched alongside macro/policy but stored in market_tt

% Default parameters (used when RUN_OPTIMISE = false OR USE_TREE = true)
% In tree mode alpha/beta/gamma are unused; only threshold and smooth_win matter.
DEFAULT_PARAMS.alpha      = 0.35;  % momentum weight  (linear path only)
DEFAULT_PARAMS.beta       = 0.35;  % macro weight     (linear path only)
DEFAULT_PARAMS.gamma      = 0.30;  % policy weight    (linear path only)
DEFAULT_PARAMS.threshold  = 0.20;  % entry threshold for position switch
DEFAULT_PARAMS.smooth_win = 63;    % trailing-mean window for S_raw (≈3 months)

% Decision-tree hyperparameters (ignored when USE_TREE = false)
TREE_PARAMS.label_horizon  = 63;    % 3-month forward-return label window
TREE_PARAMS.tree_depth     = 4;     % max depth (15 splits, 16 leaves)
TREE_PARAMS.min_leaf       = 63;    % minimum observations per leaf
TREE_PARAMS.train_window   = 1260;  % rolling IS window (5 years)
TREE_PARAMS.min_train_size = 756;   % minimum training size (3 years)
TREE_PARAMS.retrain_freq   = 21;    % retrain monthly
TREE_PARAMS.bench_dur      = 4;     % neutral benchmark duration
TREE_PARAMS.neutral_eps    = 0.25;  % min cumulative excess return (over label horizon) for non-neutral label
%   0.25% over 63 days ≈ 1% annualised edge; prevents noisy labels when
%   6y beats 4y by just 1–2bps.  Set to 0 to label every marginal winner.

% Backtest settings
BT_PARAMS.tc_bps_per_yr   = 0.50;  % transaction cost (bps per yr of duration shifted)
BT_PARAMS.benchmark_dur   = 4;     % neutral benchmark duration (years)
%% =========================================================================

fprintf('=== USD Fixed Income Duration Signal ===\n');
fprintf('Start: %s   End: %s\n\n', START_DATE, END_DATE);

%% =========================================================================
%% STEP 1: DATA INGESTION
%% =========================================================================
fprintf('[1/6] Fetching FRED data ...\n');

% --- Treasury yields (daily) ---
% DGS20 is optional — the curve can be interpolated without it.
% Any series that fails after retries is silently dropped; a warning lists gaps.
fred_yield_tickers = {'DGS1','DGS2','DGS3','DGS5','DGS7','DGS10','DGS20','DGS30', ...
                      'DGS3MO','DFII2','DFII5','T5YIE','T10YIE'};
yield_data    = struct();
yield_missing = cell(0, 1);   % pre-allocated empty, grows only on failure
for i = 1:numel(fred_yield_tickers)
    tk = fred_yield_tickers{i};
    fprintf('  %s ', tk);
    try
        yield_data.(tk) = fetch_fred_data(tk, START_DATE, END_DATE, FRED_API_KEY, FORCE_REFRESH);
        fprintf('OK\n');
    catch ME
        fprintf('SKIPPED (%s)\n', strtrim(ME.message(1:min(80, end))));
        yield_missing = [yield_missing, {tk}]; %#ok<AGROW>
    end
end
if ~isempty(yield_missing)
    warning('duration_signal_main: Missing yield tickers: %s — will interpolate from remaining curve.', ...
            strjoin(yield_missing, ', '));
end

% --- Macro series (monthly → will be interpolated to daily) ---
fred_macro_tickers = {
    'CPIAUCSL',  'CPI';
    'CPILFESL',  'CoreCPI';
    'T5YIFR',    'Breakeven5y5y';
    'T10YIE',    'Breakeven10y';
    'INDPRO',    'INDPRO';
    'PAYEMS',    'Payrolls';
    'NAPM',      'PMI';          % ISM Manufacturing PMI (try NAPM)
    'USSLIND',   'LEI';
    'RSXFS',     'RetailSales';
    'UNRATE',    'UNRATE';
    'NROU',      'NROU';
    'BAA',       'BAA';
    'AAA',       'AAA';
    'CFNAI',     'CFNAI';
    'ICSA',      'InitialClaims';
    'AHETPI',    'AHE';
    'GDPC1',     'GDP';
};
macro_raw = struct();
for i = 1:size(fred_macro_tickers, 1)
    tk     = fred_macro_tickers{i, 1};
    alias  = fred_macro_tickers{i, 2};
    fprintf('  %s (%s) ', tk, alias);
    try
        macro_raw.(alias) = fetch_fred_data(tk, START_DATE, END_DATE, FRED_API_KEY, FORCE_REFRESH);
        fprintf('OK\n');
    catch ME
        fprintf('FAILED (%s) — using NaN placeholder\n', ME.message);
        macro_raw.(alias) = [];
    end
end

% --- Policy series ---
fred_policy_tickers = {
    'DFII10',   'DFII10';
    'DFII2',    'DFII2';
    'FEDFUNDS', 'FEDFUNDS';
    'PCEPILFE', 'CorePCE_level';  % level, YoY computed below
    'UNRATE',   'UNRATE';
    'NROU',     'NROU';
};
policy_raw = struct();
for i = 1:size(fred_policy_tickers, 1)
    tk    = fred_policy_tickers{i, 1};
    alias = fred_policy_tickers{i, 2};
    fprintf('  %s (%s) ', tk, alias);
    if isfield(macro_raw, alias)
        policy_raw.(alias) = macro_raw.(alias);
        fprintf('(reused)\n');
        continue
    end
    try
        policy_raw.(alias) = fetch_fred_data(tk, START_DATE, END_DATE, FRED_API_KEY, FORCE_REFRESH);
        fprintf('OK\n');
    catch ME
        fprintf('FAILED (%s) — using NaN placeholder\n', ME.message);
        policy_raw.(alias) = [];
    end
end

% --- Market / risk / commodity series ---
fred_market_tickers = {
    'VIXCLS',           'VIX';
    'GOLDAMGBD228NLBM', 'Gold';
    'PCOPPUSDM',        'Copper';
    'BAMLH0A0HYM2',     'HY_OAS';
    'BAMLC0A0CM',       'IG_OAS';
    'NFCI',             'NFCI';
    'MORTGAGE30US',     'Mortgage30y';
    'HOUST',            'HousingStarts';
};
market_raw = struct();
for i = 1:size(fred_market_tickers, 1)
    tk    = fred_market_tickers{i, 1};
    alias = fred_market_tickers{i, 2};
    fprintf('  %s (%s) ', tk, alias);
    try
        market_raw.(alias) = fetch_fred_data(tk, START_DATE, END_DATE, FRED_API_KEY, FORCE_REFRESH);
        fprintf('OK\n');
    catch ME
        fprintf('FAILED (%s) — using NaN placeholder\n', ME.message);
        market_raw.(alias) = [];
    end
end

%% =========================================================================
%% STEP 2: ALIGN ALL DATA TO COMMON BUSINESS-DAY CALENDAR
%% =========================================================================
fprintf('\n[2/6] Aligning data to business-day calendar ...\n');

% Only use tickers that were successfully fetched
loaded_yield_tickers = fred_yield_tickers(~ismember(fred_yield_tickers, yield_missing));

% Build business day grid from earliest yield data
all_dates = cell(numel(loaded_yield_tickers), 1);
for i = 1:numel(loaded_yield_tickers)
    tk = loaded_yield_tickers{i};
    all_dates{i} = yield_data.(tk).Properties.RowTimes;
end
all_dates  = vertcat(all_dates{~cellfun(@isempty, all_dates)});
all_dates  = unique(all_dates);
% Filter to weekdays only
dow        = weekday(all_dates);            % 1=Sun, 7=Sat
biz_dates  = all_dates(dow >= 2 & dow <= 6);
T          = numel(biz_dates);
fprintf('  %d business days from %s to %s\n', T, ...
        datestr(biz_dates(1), 'yyyy-mm-dd'), datestr(biz_dates(end), 'yyyy-mm-dd'));

% --- Align yield timetable (daily series: forward-fill ≤5 bd) ---
% Only include loaded tickers; missing tenors become all-NaN and are skipped
% by the pchip interpolation in run_backtest and compute_policy_signal.
yield_mat = nan(T, numel(loaded_yield_tickers));
for i = 1:numel(loaded_yield_tickers)
    tk  = loaded_yield_tickers{i};
    src = yield_data.(tk);
    src_dates = src.Properties.RowTimes;
    src_vals  = src.Value;
    aligned = align_to_calendar(src_dates, src_vals, biz_dates, 5);
    yield_mat(:, i) = aligned;
end
yield_tt = array2timetable(yield_mat, 'RowTimes', biz_dates, ...
    'VariableNames', loaded_yield_tickers);
yield_tt.Properties.DimensionNames{1} = 'Date';

% --- Build macro daily timetable (monthly series: LOCF without limit) ---
macro_series_names = fieldnames(macro_raw);
macro_mat  = nan(T, numel(macro_series_names));
for i = 1:numel(macro_series_names)
    nm  = macro_series_names{i};
    src = macro_raw.(nm);
    if isempty(src), continue, end
    src_dates = src.Properties.RowTimes;
    src_vals  = src.Value;
    % For monthly series: unlimited LOCF (released once/month)
    macro_mat(:, i) = align_to_calendar(src_dates, src_vals, biz_dates, Inf);
end
macro_daily_tt = array2timetable(macro_mat, 'RowTimes', biz_dates, ...
    'VariableNames', macro_series_names);
macro_daily_tt.Properties.DimensionNames{1} = 'Date';

% --- Build policy daily timetable ---
policy_series_names = fieldnames(policy_raw);
policy_mat  = nan(T, numel(policy_series_names));
for i = 1:numel(policy_series_names)
    nm  = policy_series_names{i};
    src = policy_raw.(nm);
    if isempty(src), continue, end
    src_dates = src.Properties.RowTimes;
    src_vals  = src.Value;
    policy_mat(:, i) = align_to_calendar(src_dates, src_vals, biz_dates, Inf);
end
policy_tt = array2timetable(policy_mat, 'RowTimes', biz_dates, ...
    'VariableNames', policy_series_names);
policy_tt.Properties.DimensionNames{1} = 'Date';

% --- Build market daily timetable ---
market_series_names = fieldnames(market_raw);
if isempty(market_series_names)
    % All market fetches failed — create an empty timetable (GC helper returns NaN cols)
    market_tt = timetable('RowTimes', biz_dates);
else
    market_mat = nan(T, numel(market_series_names));
    for i = 1:numel(market_series_names)
        nm  = market_series_names{i};
        src = market_raw.(nm);
        if isempty(src), continue, end
        src_dates = src.Properties.RowTimes;
        src_vals  = src.Value;
        market_mat(:, i) = align_to_calendar(src_dates, src_vals, biz_dates, Inf);
    end
    market_tt = array2timetable(market_mat, 'RowTimes', biz_dates, ...
        'VariableNames', market_series_names);
end
market_tt.Properties.DimensionNames{1} = 'Date';
% Add BAA and AAA spreads from macro_raw if available (for baa_aaa_spr feature)
for nm = {'BAA', 'AAA'}
    if isfield(macro_raw, nm{1}) && ~isempty(macro_raw.(nm{1}))
        src = macro_raw.(nm{1});
        v = align_to_calendar(src.Properties.RowTimes, src.Value, biz_dates, Inf);
        market_tt.(nm{1}) = v;
    end
end

% Add CorePCE YoY to policy_tt (derived from level)
if ismember('CorePCE_level', policy_tt.Properties.VariableNames)
    pce_lev  = policy_tt.CorePCE_level;
    pce_lag  = [nan(252,1); pce_lev(1:end-252)];
    pce_yoy  = 100 * (pce_lev ./ pce_lag - 1);
    policy_tt.CorePCE = pce_yoy;
end

%% =========================================================================
%% STEP 3: COMPUTE MODULE SIGNALS
%% =========================================================================
fprintf('\n[3/6] Computing module signals ...\n');

% --- Module 1: Momentum ---------------------------------------------------
fprintf('  Module 1: Momentum & Trend ...\n');
[s_mom, mom_sub, ~] = compute_momentum_signal(yield_tt);

% --- Module 2: Macro Fundamentals ----------------------------------------
fprintf('  Module 2: Macro Fundamentals ...\n');
[s_macro, macro_sub] = compute_macro_signal(macro_daily_tt);

% --- Module 3: Level & Policy ---------------------------------------------
fprintf('  Module 3: Level & Policy ...\n');
[s_policy, policy_sub] = compute_policy_signal(policy_tt, yield_tt);

% --- Decision Tree (optional) --------------------------------------------
tree_info  = struct();   %#ok<NASGU> — overwritten if USE_TREE = true; default for error safety
tree_score = [];         %#ok<NASGU>
if USE_TREE
    fprintf('  Building feature matrix ...\n');
    [X_feat, feat_names] = build_feature_matrix(yield_tt, macro_daily_tt, policy_tt, market_tt, mom_sub);
    fprintf('  Module Tree: Walk-forward decision tree (patience — may take a minute) ...\n');
    [tree_score, ~, tree_info] = train_duration_tree(X_feat, feat_names, yield_tt, TREE_PARAMS);
    fprintf('  Tree: %d retrains, label dist: 2y=%d  4y=%d  6y=%d\n', ...
        tree_info.n_retrains, tree_info.label_counts(1), ...
        tree_info.label_counts(2), tree_info.label_counts(3));
end

%% =========================================================================
%% STEP 4: PARAMETER OPTIMISATION (or use defaults)
%% =========================================================================
fprintf('\n[4/6] Parameter optimisation ...\n');

if USE_TREE
    % In tree mode only threshold and smooth_win are tunable; calibrate them
    % on the already-OOS tree_score (fast — no tree retraining needed).
    fprintf('  Tree mode: calibrating threshold and smooth_win ...\n');
    [opt_params, grid_results] = calibrate_tree_params(tree_score, yield_tt, BT_PARAMS);
    % Build pareto_data compatible struct from calibration table for plot_dashboard
    n_cal = height(grid_results);
    pareto_data = struct( ...
        'sharpe',     grid_results.sharpe, ...
        'maxdd',      grid_results.max_dd, ...
        'alpha',      nan(n_cal,1), ...
        'beta',       nan(n_cal,1), ...
        'threshold',  grid_results.threshold, ...
        'smooth_win', grid_results.smooth_win, ...
        'feasible',   double(grid_results.max_dd < 0.20 & grid_results.turnover_pa < 5), ...
        'is_pareto',  zeros(n_cal, 1));
elseif RUN_OPTIMISE %#ok<UNRCH>
    [opt_params, grid_results, pareto_data] = optimize_parameters( ...
        s_mom, s_macro, s_policy, yield_tt, BT_PARAMS);
else
    fprintf('  Skipping optimisation — using DEFAULT_PARAMS\n');
    opt_params    = DEFAULT_PARAMS;
    grid_results  = table();
    pareto_data   = struct('sharpe', NaN, 'maxdd', NaN, 'alpha', NaN, ...
                           'beta', NaN, 'threshold', NaN, 'smooth_win', NaN, ...
                           'feasible', NaN, 'is_pareto', NaN);
end

%% =========================================================================
%% STEP 5: FINAL SIGNAL AGGREGATION & BACKTEST
%% =========================================================================
fprintf('\n[5/6] Running backtest with optimal parameters ...\n');

if USE_TREE
    % Decision-tree path: pre_score bypasses the weighted linear combination.
    [S_raw, S_smooth, position, S_discrete] = aggregate_signals( ...
        [], [], [], [], [], opt_params.threshold, opt_params.smooth_win, tree_score);
else
    a = opt_params.alpha; b = opt_params.beta; thr = opt_params.threshold; sw = opt_params.smooth_win; %#ok<UNRCH>
    [S_raw, S_smooth, position, S_discrete] = aggregate_signals(s_mom, s_macro, s_policy, a, b, thr, sw);
end

perf = run_backtest(position, yield_tt, BT_PARAMS);

% Bundle signals for plotting
signals.S_raw      = S_raw;
signals.S_smooth   = S_smooth;
signals.s_mom      = s_mom;
signals.s_macro    = s_macro;
signals.s_policy   = s_policy;
signals.position   = position;
signals.S_discrete = S_discrete;
signals.use_tree   = USE_TREE;
if USE_TREE
    signals.tree_score = tree_score;
end

sub_signals.mom    = mom_sub;
sub_signals.macro  = macro_sub;
sub_signals.policy = policy_sub;

%% =========================================================================
%% STEP 6: OUTPUT — SUMMARY TABLE + DASHBOARD
%% =========================================================================
fprintf('\n[6/6] Generating dashboard and summary ...\n');

% --- Summary table --------------------------------------------------------
fprintf('\n');
fprintf('╔══════════════════════════════════════════════════════════════╗\n');
fprintf('║         USD FIXED INCOME DURATION SIGNAL — PERFORMANCE      ║\n');
fprintf('╠══════════════════════════════════════════════════════════════╣\n');
fprintf('║ %-28s  %12s  %12s ║\n', 'Metric', 'Strategy', 'Benchmark');
fprintf('╠══════════════════════════════════════════════════════════════╣\n');

metrics = {
    'Annualised Return (%)',    100*perf.ann_ret_strat,   100*perf.ann_ret_bench;
    'Annualised Volatility (%)',100*perf.ann_vol_strat,   100*perf.ann_vol_bench;
    'Sharpe Ratio',             perf.sharpe_strat,        perf.sharpe_bench;
    'Max Drawdown (%)',         100*perf.max_dd_strat,    100*perf.max_dd_bench;
};
for i = 1:size(metrics, 1)
    fprintf('║ %-28s  %12.3f  %12.3f ║\n', metrics{i,1}, metrics{i,2}, metrics{i,3});
end

fprintf('╠══════════════════════════════════════════════════════════════╣\n');
fprintf('║ %-28s  %12.3f  %-12s ║\n', 'Information Ratio',   perf.info_ratio, '');
fprintf('║ %-28s  %12.1f  %-12s ║\n', 'Hit Rate (%)',         100*perf.hit_rate, '');
fprintf('║ %-28s  %12.2f  %-12s ║\n', 'Avg Duration Tilt (yr)', perf.avg_dur_tilt, '');
fprintf('║ %-28s  %12.1f  %-12s ║\n', 'Turnover (trades/yr)',  perf.turnover_pa, '');
fprintf('╠══════════════════════════════════════════════════════════════╣\n');
if USE_TREE
    fprintf('║ MODE: Decision Tree  thr=%.2f  smooth=%dd  retrains=%d          ║\n', ...
            opt_params.threshold, opt_params.smooth_win, tree_info.n_retrains);
    fprintf('║ Labels — 2y: %4d  4y: %4d  6y: %4d                         ║\n', ...
            tree_info.label_counts(1), tree_info.label_counts(2), tree_info.label_counts(3));
else
    p8 = sprintf('║ OPTIMAL PARAMETERS:  α=%.2f  β=%.2f  γ=%.2f  thr=%.2f  sm=%dd  ║\n', opt_params.alpha, opt_params.beta, opt_params.gamma, opt_params.threshold, opt_params.smooth_win); %#ok<UNRCH>
    fprintf('%s', p8);
end
fprintf('╚══════════════════════════════════════════════════════════════╝\n\n');

% --- Dashboard plot -------------------------------------------------------
plot_dashboard(perf, signals, yield_tt, opt_params, pareto_data, sub_signals, OUTPUT_PDF, tree_info);

% --- Decision tree diagram (tree mode only) --------------------------------
if USE_TREE && isfield(tree_info, 'last_tree') && ~isempty(tree_info.last_tree)
    tree_pdf   = strrep(OUTPUT_PDF, '.pdf', '_tree_diagram.pdf');
    tree_title = sprintf('USD Duration Decision Tree  |  thr=%.2f  smooth=%dd  retrains=%d', ...
        opt_params.threshold, opt_params.smooth_win, tree_info.n_retrains);
    plot_decision_tree(tree_info.last_tree, tree_title, tree_pdf);
end

fprintf('\nComplete.  Dashboard saved to: %s\n', OUTPUT_PDF);

%% =========================================================================
%% LOCAL HELPER FUNCTIONS
%% =========================================================================

function aligned = align_to_calendar(src_dates, src_vals, biz_dates, max_gap)
% ALIGN_TO_CALENDAR  Align a source series to biz_dates with LOCF up to max_gap.
%   max_gap = Inf applies unlimited forward-fill (for monthly series).
%   O(T) complexity: single-pass pointer advance through both arrays.
n       = numel(biz_dates);
aligned = nan(n, 1);
last_v  = NaN;
last_bd_idx = 0;    % index in biz_dates of the last valid src observation
si      = 1;
n_src   = numel(src_dates);

% Pre-build a lookup: for each src_date, find its index in biz_dates
% (or the nearest prior business day)
% Simpler: track last valid business-day index as we advance

for t = 1:n
    d = biz_dates(t);
    % Advance src pointer while src_dates(si) <= biz_dates(t)
    while si <= n_src && src_dates(si) <= d
        if ~isnan(src_vals(si))
            last_v        = src_vals(si);
            last_bd_idx   = t;   % record which biz-date index we are at
        end
        si = si + 1;
    end
    % Apply LOCF: distance is number of business days since last observation
    if ~isnan(last_v)
        bd_gap = t - last_bd_idx;   % business days since last valid value
        if isinf(max_gap) || bd_gap <= max_gap
            aligned(t) = last_v;
        end
    end
end
end
