function daily_tt = interp_to_daily(monthly_tt, biz_dates)
% INTERP_TO_DAILY  Forward-fill a low-frequency timetable to daily business dates.
%
%   daily_tt = interp_to_daily(monthly_tt, biz_dates)
%
%   Inputs:
%     monthly_tt - Timetable of monthly (or other low-frequency) data
%     biz_dates  - datetime column vector of target business day dates
%
%   Output:
%     daily_tt   - Timetable aligned to biz_dates, values forward-filled
%                  from the last available observation on or before each date.
%
%   Notes:
%     Any date in biz_dates before the first observation in monthly_tt
%     receives NaN.  No interpolation between observations — last value
%     carried forward (LOCF).

src_dates = monthly_tt.Properties.RowTimes;
var_names = monthly_tt.Properties.VariableNames;
n_vars    = numel(var_names);
n_days    = numel(biz_dates);

data_out  = nan(n_days, n_vars);

for v = 1:n_vars
    src_vals = monthly_tt.(var_names{v});
    for i = 1:n_days
        idx = find(src_dates <= biz_dates(i), 1, 'last');
        if ~isempty(idx)
            data_out(i, v) = src_vals(idx);
        end
    end
end

daily_tt = array2timetable(data_out, ...
    'RowTimes',      biz_dates, ...
    'VariableNames', var_names);
daily_tt.Properties.DimensionNames{1} = 'Date';
end
