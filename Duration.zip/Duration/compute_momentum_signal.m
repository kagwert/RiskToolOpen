function [s_mom, sub_signals, signal_dates] = compute_momentum_signal(yield_tt)
% COMPUTE_MOMENTUM_SIGNAL  Module 1: Momentum & Trend (Rate Directionality).
%
%   [s_mom, sub_signals, signal_dates] = compute_momentum_signal(yield_tt)
%
%   Input:
%     yield_tt - Timetable of daily CMT yields.
%                Required variables (% p.a.): DGS2, DGS5, DGS7, DGS10, DGS20, DGS30
%                Optional additional tenors used only if present.
%
%   Outputs:
%     s_mom        - T×1 double, aggregate momentum signal in [-1, +1]
%                    +1 = rising rates (bearish duration), -1 = falling (bullish)
%     sub_signals  - Struct with fields s_short, s_medium, s_long, s_slope
%                    each T×1 signals before final aggregation
%     signal_dates - T×1 datetime vector (row times of yield_tt)
%
%   Algorithm:
%     1. Time-series momentum (TSMOM) — 21/63/126/252d lookbacks,
%        vol-weighted and averaged
%     2. Moving average crossover (MAC) — 4 fast/slow pairs
%     3. ADX-equivalent trend strength filter
%     4. Cross-tenor slope signals (2s10s, 5s30s)
%     Short-term sub-signal  : lookbacks ≤ 63d
%     Medium-term sub-signal : lookbacks 64–126d
%     Long-term sub-signal   : lookbacks > 126d
%
%   Notes:
%     All computations are strictly causal (no look-ahead).
%     Output signal is capped to [-1, +1] at each stage.

%% === Setup ================================================================
signal_dates = yield_tt.Properties.RowTimes;
T            = height(yield_tt);

% Extract yield matrix (T × K); use all available standard tenors
tenor_names = {'DGS2','DGS5','DGS7','DGS10','DGS20','DGS30'};
avail = ismember(tenor_names, yield_tt.Properties.VariableNames);
tenor_names = tenor_names(avail);

Y = zeros(T, sum(avail));
for k = 1:numel(tenor_names)
    Y(:, k) = yield_tt.(tenor_names{k});
end

K = size(Y, 2);   % number of tenors

%% === Helper: fill small gaps in yields (≤5bd LOCF) =======================
for k = 1:K
    Y(:, k) = fill_small_gaps(Y(:, k), 5);
end

%% === 1. TIME-SERIES MOMENTUM =============================================
% Only use medium- and long-term lookbacks (≥63d) to identify durable regimes.
% The 21-day window is too reactive for duration allocation.
tsmom_windows = [63, 126, 252];
tsmom_mat     = nan(T, K * numel(tsmom_windows));
col           = 0;

for L = tsmom_windows
    for k = 1:K
        col    = col + 1;
        dy     = [nan; diff(Y(:, k))];           % daily yield changes
        sig_ts = nan(T, 1);

        for t = (L+1):T
            idx  = (t-L):t;
            chg  = Y(t, k) - Y(t-L, k);          % cumulative change
            dchg = dy(idx);
            dchg = dchg(~isnan(dchg));
            if numel(dchg) < round(L * 0.5)
                continue
            end
            vol = std(dchg);
            if vol < 1e-8, vol = 1e-8; end
            sig_ts(t) = sign(chg) / vol;          % inverse-vol weighted sign
        end

        % Normalise to [-1, +1] via rolling z-score then tanh squeeze
        sig_z          = rolling_zscore(sig_ts, 252);
        tsmom_mat(:, col) = tanh(sig_z);
    end
end

% Average across tenors and windows; separate by horizon.
% Column layout: [L=63,k=1..K | L=126,k=1..K | L=252,k=1..K]
idx_short  = logical([ones(1, K),   zeros(1, 2*K)]);  % L=63
idx_medium = logical([zeros(1, K),  ones(1, K),  zeros(1, K)]);  % L=126
idx_long   = logical([zeros(1, 2*K), ones(1, K)]);                % L=252

s_tsmom_short  = mean(tsmom_mat(:, idx_short), 2, 'omitnan');
s_tsmom_medium = mean(tsmom_mat(:, idx_medium), 2, 'omitnan');
s_tsmom_long   = mean(tsmom_mat(:, idx_long), 2, 'omitnan');

%% === 2. MOVING AVERAGE CROSSOVER =========================================
% Only medium/long-term crossovers; sub-63d fast legs create excessive turnover.
mac_pairs = [21, 126; 63, 252];
mac_mat   = nan(T, K * size(mac_pairs, 1));
col       = 0;

for p = 1:size(mac_pairs, 1)
    fast = mac_pairs(p, 1);
    slow = mac_pairs(p, 2);
    for k = 1:K
        col  = col + 1;
        sig  = nan(T, 1);
        for t = slow:T
            fast_ma = mean(Y(max(1, t-fast+1):t, k), 'omitnan');
            slow_ma = mean(Y(t-slow+1:t,         k), 'omitnan');
            if ~isnan(fast_ma) && ~isnan(slow_ma)
                sig(t) = sign(fast_ma - slow_ma);
            end
        end
        mac_mat(:, col) = sig;
    end
end

% Separate MAC by horizon.
% Column layout: [pair1,k=1..K | pair2,k=1..K]
% Pairs: [21/126, 63/252] → medium=pair1, long=pair2
medium_mac = logical([ones(1, K),  zeros(1, K)]);   % fast=21
long_mac   = logical([zeros(1, K), ones(1, K)]);    % fast=63

s_mac_medium = mean(mac_mat(:, medium_mac), 2, 'omitnan');
s_mac_long   = mean(mac_mat(:, long_mac), 2, 'omitnan');

%% === 3. ADX TREND-STRENGTH FILTER ========================================
% Adapted for single time-series: compute smoothed directional index
% on yield changes, scale signal magnitude by ADX/40 (cap 1)
adx_window = 14;
adx_smooth = 14;
adx_scale  = nan(T, K);

for k = 1:K
    dy     = [nan; diff(Y(:, k))];
    pdm    = max(dy, 0);          % positive directional movement
    ndm    = max(-dy, 0);         % negative directional movement
    tr     = abs(dy);             % true range equivalent

    % Smooth with Wilder EMA (factor 1/N)
    alpha  = 1 / adx_smooth;
    pdm_s  = nan(T, 1);
    ndm_s  = nan(T, 1);
    tr_s   = nan(T, 1);
    dx_raw = nan(T, 1);

    % Initialise with simple average over first adx_window periods
    t0 = adx_window + adx_smooth + 1;
    if t0 > T, continue, end

    init_idx = adx_window:(adx_window + adx_smooth - 1);
    valid_tr = tr(init_idx(~isnan(tr(init_idx))));
    if isempty(valid_tr), continue, end

    pdm_s(adx_window + adx_smooth - 1) = mean(pdm(init_idx), 'omitnan');
    ndm_s(adx_window + adx_smooth - 1) = mean(ndm(init_idx), 'omitnan');
    tr_s(adx_window  + adx_smooth - 1) = mean(tr(init_idx),  'omitnan');

    for t = (adx_window + adx_smooth):T
        if isnan(pdm(t)) || isnan(tr(t)), continue, end
        pdm_s(t) = (1 - alpha) * pdm_s(t-1) + alpha * pdm(t);
        ndm_s(t) = (1 - alpha) * ndm_s(t-1) + alpha * ndm(t);
        tr_s(t)  = (1 - alpha) * tr_s(t-1)  + alpha * tr(t);

        if tr_s(t) > 1e-10
            pdi = 100 * pdm_s(t) / tr_s(t);
            ndi = 100 * ndm_s(t) / tr_s(t);
            if (pdi + ndi) > 1e-10
                dx_raw(t) = 100 * abs(pdi - ndi) / (pdi + ndi);
            end
        end
    end

    % Wilder-smooth DX → ADX
    adx_raw = nan(T, 1);
    t0_adx  = adx_window + 2 * adx_smooth;
    if t0_adx > T, continue, end
    adx_raw(t0_adx - 1) = mean(dx_raw(max(1, t0_adx-adx_smooth):t0_adx-1), 'omitnan');
    for t = t0_adx:T
        if ~isnan(dx_raw(t)) && ~isnan(adx_raw(t-1))
            adx_raw(t) = (1 - alpha) * adx_raw(t-1) + alpha * dx_raw(t);
        end
    end

    % Scale: 0 when ADX < 20, linear 0→1 for ADX 20→40, cap at 1
    scale = max(0, min(1, (adx_raw - 20) / 20));
    adx_scale(:, k) = scale;
end

adx_scale_mean = mean(adx_scale, 2, 'omitnan');   % average across tenors

%% === 4. CROSS-TENOR SLOPE SIGNALS ========================================
% 2s10s and 5s30s spreads
has_2y  = ismember('DGS2',  tenor_names);
has_5y  = ismember('DGS5',  tenor_names);
has_10y = ismember('DGS10', tenor_names);
has_30y = ismember('DGS30', tenor_names);

s_slope = zeros(T, 1);
n_slope = 0;

if has_2y && has_10y
    idx_2  = strcmp(tenor_names, 'DGS2');
    idx_10 = strcmp(tenor_names, 'DGS10');
    spr    = Y(:, idx_10) - Y(:, idx_2);        % 2s10s spread

    % Level signal: z-score of spread level — wide = steepen = reflationary = bearish (+1)
    spr_level_z = rolling_zscore(spr, 252);
    % MoM change signal: rising spread = steepening = bearish (+1)
    spr_chg     = [nan(21,1); spr(22:end) - spr(1:end-21)];
    spr_chg_z   = rolling_zscore(spr_chg, 252);
    spr_sig     = 0.5 * tanh(spr_level_z) + 0.5 * tanh(spr_chg_z);
    s_slope     = s_slope + spr_sig;
    n_slope     = n_slope + 1;
end

if has_5y && has_30y
    idx_5  = strcmp(tenor_names, 'DGS5');
    idx_30 = strcmp(tenor_names, 'DGS30');
    spr    = Y(:, idx_30) - Y(:, idx_5);        % 5s30s spread

    spr_level_z = rolling_zscore(spr, 252);
    spr_chg     = [nan(21,1); spr(22:end) - spr(1:end-21)];
    spr_chg_z   = rolling_zscore(spr_chg, 252);
    spr_sig     = 0.5 * tanh(spr_level_z) + 0.5 * tanh(spr_chg_z);
    s_slope     = s_slope + spr_sig;
    n_slope     = n_slope + 1;
end

if n_slope > 0
    s_slope = s_slope / n_slope;
end
s_slope = max(-1, min(1, s_slope));

%% === 5. AGGREGATE SUB-SIGNALS ============================================
% Combine TSMOM + MAC per horizon, then apply ADX trend-strength scaling.
% No short MAC (removed), so short horizon is TSMOM-only (63d lookback).
s_short  = s_tsmom_short;                                    % TSMOM 63d only
s_medium = 0.5 * s_tsmom_medium + 0.5 * s_mac_medium;       % TSMOM+MAC 126d
s_long   = 0.5 * s_tsmom_long   + 0.5 * s_mac_long;         % TSMOM+MAC 252d

% Apply ADX scale
s_short  = s_short  .* adx_scale_mean;
s_medium = s_medium .* adx_scale_mean;
s_long   = s_long   .* adx_scale_mean;

s_short  = max(-1, min(1, s_short));
s_medium = max(-1, min(1, s_medium));
s_long   = max(-1, min(1, s_long));

% Weight strongly toward longer horizons — regime signals, not noise
s_mom_raw = 0.10 * s_short + 0.30 * s_medium + 0.50 * s_long + 0.10 * s_slope;
s_mom_raw = max(-1, min(1, s_mom_raw));

% Apply a 42-day trailing mean to reduce day-to-day noise before handing
% the signal to the aggregator.  This is causal (no look-ahead).
MOM_SMOOTH = 42;
s_mom = movmean(s_mom_raw, [MOM_SMOOTH-1, 0], 'omitnan');
s_mom = max(-1, min(1, s_mom));

%% === Outputs =============================================================
sub_signals.s_short   = s_short;
sub_signals.s_medium  = s_medium;
sub_signals.s_long    = s_long;
sub_signals.s_slope   = s_slope;
sub_signals.adx_scale = adx_scale_mean;
sub_signals.s_raw     = s_mom_raw;
end

%% =========================================================================
function x = fill_small_gaps(x, max_gap)
% FILL_SMALL_GAPS  Forward-fill NaN runs of length ≤ max_gap.
n = length(x);
for t = 2:n
    if isnan(x(t))
        % Count consecutive NaNs from here
        run_end = t;
        while run_end <= n && isnan(x(run_end))
            run_end = run_end + 1;
        end
        run_len = run_end - t;
        if run_len <= max_gap && ~isnan(x(t-1))
            x(t:run_end-1) = x(t-1);
        end
    end
end
end
