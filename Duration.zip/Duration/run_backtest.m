function perf = run_backtest(position, yield_tt, params)
% RUN_BACKTEST  Module 5: Backtest engine & performance attribution.
%
%   perf = run_backtest(position, yield_tt, params)
%
%   Inputs:
%     position  - T×1 vector of duration positions (2, 4, or 6 years).
%                 Signal is lagged by 1 business day inside this function.
%     yield_tt  - Timetable of daily CMT yields (DGS2, DGS5, DGS7, DGS10,
%                 DGS20, DGS30).  Must span the same T dates as position.
%     params    - Struct with optional fields:
%       .tc_bps_per_yr  - Transaction cost in bps per year of duration shifted
%                         (default 0.5 bps/yr → 0.005% per duration-year)
%       .benchmark_dur  - Benchmark duration in years (default 4)
%
%   Output:
%     perf - Struct with fields:
%       .dates        - T×1 datetime
%       .r_strat      - T×1 daily strategy returns (after TC)
%       .r_bench      - T×1 daily benchmark returns
%       .r_active     - T×1 active (excess) returns
%       .cum_strat    - T×1 cumulative strategy wealth index
%       .cum_bench    - T×1 cumulative benchmark wealth index
%       .cum_active   - T×1 cumulative active return
%       .position     - T×1 actual duration used (after 1d lag)
%       .trade        - T×1 indicator of position change (1 = trade)
%       .tc_cost      - T×1 transaction cost vector
%       Scalar performance metrics:
%       .ann_ret_strat   .ann_ret_bench   .ann_vol_strat   .ann_vol_bench
%       .sharpe_strat    .sharpe_bench    .info_ratio
%       .max_dd_strat    .max_dd_bench    .hit_rate
%       .avg_dur_tilt    .turnover_pa
%       .roll_sharpe     - T×1 rolling 1-year active Sharpe
%
%   Synthetic return construction (no look-ahead):
%     r_port_D(t) = -D * Δy_D(t) + y_D(t-1)/252
%     where y_D is par yield interpolated at exactly D years.
%     Δy_D(t) = y_D(t) - y_D(t-1)
%     Signal lag: position from day t-1 drives return on day t.

%% === Parameters ===========================================================
if nargin < 3, params = struct(); end
if ~isfield(params, 'tc_bps_per_yr'),  params.tc_bps_per_yr = 0.5;  end
if ~isfield(params, 'benchmark_dur'),  params.benchmark_dur = 4;     end

TC_BPS    = params.tc_bps_per_yr;
BM_DUR    = params.benchmark_dur;
TC_FACTOR = TC_BPS * 1e-4;          % bps → fraction per year of duration

dates = yield_tt.Properties.RowTimes;
T     = height(yield_tt);

%% === Build par yield matrix at 2y, 4y, 6y ================================
% FRED provides: DGS1, DGS2, DGS3, DGS5, DGS7, DGS10, DGS20, DGS30
known_tenors_labels = {'DGS1','DGS2','DGS3','DGS5','DGS7','DGS10','DGS20','DGS30'};
known_tenors_yrs    = [1, 2, 3, 5, 7, 10, 20, 30];
avail_idx = ismember(known_tenors_labels, yield_tt.Properties.VariableNames);
use_labels = known_tenors_labels(avail_idx);
use_tenors = known_tenors_yrs(avail_idx);

Y_known = zeros(T, sum(avail_idx));
for k = 1:numel(use_labels)
    Y_known(:, k) = yield_tt.(use_labels{k});
end

target_durs = [2, BM_DUR, 6];
Y_interp    = nan(T, 3);   % columns: 2y, 4y (BM), 6y

for t = 1:T
    yv = Y_known(t, :);
    tv = use_tenors;
    valid = ~isnan(yv);
    if sum(valid) < 2, continue, end
    tv_v = tv(valid);  yv_v = yv(valid);
    for d = 1:3
        td = target_durs(d);
        if td >= min(tv_v) && td <= max(tv_v)
            Y_interp(t, d) = interp1(tv_v, yv_v, td, 'pchip');
        elseif td < min(tv_v)
            Y_interp(t, d) = interp1(tv_v, yv_v, td, 'linear', 'extrap');
        else
            Y_interp(t, d) = interp1(tv_v, yv_v, td, 'linear', 'extrap');
        end
    end
end

%% === Synthetic daily returns for each duration bucket ====================
% r_D(t) = -D * (y_D(t) - y_D(t-1)) + y_D(t-1)/252
R_synthetic = nan(T, 3);   % columns: 2y, 4y, 6y

for d = 1:3
    y_D  = Y_interp(:, d) / 100;   % convert % to decimal
    Dur  = target_durs(d);
    for t = 2:T
        if isnan(y_D(t)) || isnan(y_D(t-1)), continue, end
        delta_y   = y_D(t) - y_D(t-1);
        carry     = y_D(t-1) / 252;
        R_synthetic(t, d) = -Dur * delta_y + carry;
    end
end

%% === Apply 1-day signal lag ==============================================
% Strategy return on day t uses position decided on day t-1
pos_lagged = [NaN; position(1:end-1)];    % shift forward by 1 day

%% === Strategy returns ====================================================
r_strat  = nan(T, 1);
r_bench  = nan(T, 1);
tc_cost  = zeros(T, 1);
trade    = zeros(T, 1);

for t = 2:T
    p_t  = pos_lagged(t);
    bm_d = BM_DUR;

    % Identify which column corresponds to this position
    col_map = [2, BM_DUR, 6];
    [~, col_s] = min(abs(col_map - p_t));
    [~, col_b] = min(abs(col_map - bm_d));

    if isnan(p_t) || isnan(R_synthetic(t, col_s))
        continue
    end

    % Transaction cost: applied when position changes
    if t > 2 && ~isnan(pos_lagged(t-1))
        dur_shift = abs(p_t - pos_lagged(t-1));
        if dur_shift > 0
            trade(t)   = 1;
            tc_cost(t) = TC_FACTOR * dur_shift;  % cost in return terms
        end
    end

    r_strat(t) = R_synthetic(t, col_s) - tc_cost(t);
    r_bench(t) = R_synthetic(t, col_b);
end

r_active = r_strat - r_bench;

%% === Cumulative wealth indices ===========================================
r_strat_clean  = fillmissing(r_strat,  'constant', 0);
r_bench_clean  = fillmissing(r_bench,  'constant', 0);
r_active_clean = fillmissing(r_active, 'constant', 0);

cum_strat  = cumprod(1 + r_strat_clean);
cum_bench  = cumprod(1 + r_bench_clean);
cum_active = cumprod(1 + r_active_clean);

%% === Performance metrics =================================================
% Annualised return
ann_ret_strat = 252 * nanmean(r_strat);
ann_ret_bench = 252 * nanmean(r_bench);

% Annualised volatility
ann_vol_strat = sqrt(252) * nanstd(r_strat);
ann_vol_bench = sqrt(252) * nanstd(r_bench);

% Sharpe ratio
sharpe_strat  = ann_ret_strat / max(ann_vol_strat, 1e-8);
sharpe_bench  = ann_ret_bench / max(ann_vol_bench, 1e-8);

% Information ratio
ann_ret_active  = 252 * nanmean(r_active);
ann_vol_active  = sqrt(252) * nanstd(r_active);
info_ratio      = ann_ret_active / max(ann_vol_active, 1e-8);

% Max drawdown
max_dd_strat    = max_drawdown(cum_strat);
max_dd_bench    = max_drawdown(cum_bench);

% Monthly hit rate: % of calendar months strategy > benchmark
[strat_monthly, bench_monthly] = monthly_returns(dates, r_strat, r_bench);
hit_rate = sum(strat_monthly > bench_monthly) / sum(~isnan(strat_monthly) & ~isnan(bench_monthly));

% Average duration tilt (mean absolute deviation from benchmark)
valid_pos = pos_lagged(~isnan(pos_lagged));
avg_dur_tilt = mean(abs(valid_pos - BM_DUR));

% Turnover: average number of duration changes per year
n_years   = sum(~isnan(r_strat)) / 252;
turnover  = sum(trade) / max(n_years, 1e-3);

% Rolling 1-year Sharpe of active return (252-day window)
roll_sharpe = nan(T, 1);
for t = 252:T
    win = r_active(t-251:t);
    win = win(~isnan(win));
    if numel(win) < 63, continue, end
    roll_sharpe(t) = 252 * mean(win) / (sqrt(252) * std(win) + 1e-8);
end

%% === Pack output =========================================================
perf.dates         = dates;
perf.r_strat       = r_strat;
perf.r_bench       = r_bench;
perf.r_active      = r_active;
perf.cum_strat     = cum_strat;
perf.cum_bench     = cum_bench;
perf.cum_active    = cum_active;
perf.position      = pos_lagged;
perf.trade         = trade;
perf.tc_cost       = tc_cost;
perf.ann_ret_strat = ann_ret_strat;
perf.ann_ret_bench = ann_ret_bench;
perf.ann_vol_strat = ann_vol_strat;
perf.ann_vol_bench = ann_vol_bench;
perf.sharpe_strat  = sharpe_strat;
perf.sharpe_bench  = sharpe_bench;
perf.info_ratio    = info_ratio;
perf.max_dd_strat  = max_dd_strat;
perf.max_dd_bench  = max_dd_bench;
perf.hit_rate      = hit_rate;
perf.avg_dur_tilt  = avg_dur_tilt;
perf.turnover_pa   = turnover;
perf.roll_sharpe   = roll_sharpe;
end

%% =========================================================================
function mdd = max_drawdown(cum_wealth)
% MAX_DRAWDOWN  Largest peak-to-trough decline in cumulative wealth.
mdd = 0;
peak = cum_wealth(1);
for t = 2:numel(cum_wealth)
    if isnan(cum_wealth(t)), continue, end
    peak = max(peak, cum_wealth(t));
    dd   = (peak - cum_wealth(t)) / peak;
    mdd  = max(mdd, dd);
end
end

function [strat_m, bench_m] = monthly_returns(dates, r_strat, r_bench)
% MONTHLY_RETURNS  Compound daily returns to calendar months.
months     = dateshift(dates, 'start', 'month');
u_months   = unique(months(~isnat(months)));
strat_m    = nan(numel(u_months), 1);
bench_m    = nan(numel(u_months), 1);
for i = 1:numel(u_months)
    idx = months == u_months(i);
    rs  = r_strat(idx);  rs = rs(~isnan(rs));
    rb  = r_bench(idx);  rb = rb(~isnan(rb));
    if ~isempty(rs), strat_m(i) = prod(1 + rs) - 1; end
    if ~isempty(rb), bench_m(i) = prod(1 + rb) - 1; end
end
end
