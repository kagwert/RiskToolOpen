function [opt_params, grid_results, pareto_data] = optimize_parameters(s_mom, s_macro, s_policy, yield_tt, bt_params)
% OPTIMIZE_PARAMETERS  Walk-forward grid search over (alpha, beta, threshold, smooth_win).
%
%   [opt_params, grid_results, pareto_data] = optimize_parameters(...)
%
%   Inputs:
%     s_mom      - T×1 momentum signal
%     s_macro    - T×1 macro signal
%     s_policy   - T×1 policy signal
%     yield_tt   - Timetable of CMT yields (same T dates)
%     bt_params  - Backtest params struct (passed to run_backtest)
%
%   Outputs:
%     opt_params   - Struct with optimal alpha, beta, gamma, threshold, smooth_win
%     grid_results - Table with all parameter combos and OOS metrics
%     pareto_data  - Struct for Sharpe-vs-drawdown Pareto frontier
%
%   Walk-forward scheme:
%     In-sample window  : 3 years (756 business days)
%     Out-of-sample     : 1 year  (252 business days)
%     Expanding windows : first fold ends at t=756; each fold shifts by 252
%
%   Constraints applied:
%     Max drawdown  < 15%
%     Turnover      < 3 trades/year  (regime-persistence focus)
%
%   Selection criterion: median OOS Sharpe across folds (not best IS).

%% === Parameter grid =====================================================
alpha_grid  = 0.20 : 0.05 : 0.60;
beta_grid   = 0.20 : 0.05 : 0.60;
thresh_grid = 0.10 : 0.05 : 0.35;
% Smoothing window: 42d (2mo), 63d (3mo), 126d (6mo)
smooth_grid = [42, 63, 126];

%% === Build valid parameter combinations ==================================
combos = [];
for a = alpha_grid
    for b = beta_grid
        if (a + b) > 1.00 + 1e-9, continue, end
        g = 1 - a - b;
        if g < 0 || g > 1, continue, end
        for thr = thresh_grid
            for sw = smooth_grid
                combos(end+1, :) = [a, b, g, thr, sw]; %#ok<AGROW>
            end
        end
    end
end
n_combos = size(combos, 1);
fprintf('optimize_parameters: %d parameter combinations × walk-forward folds\n', n_combos);

%% === Define walk-forward folds ===========================================
T         = numel(s_mom);
IS_WIN    = 756;   % 3 years in-sample
OOS_WIN   = 252;   % 1 year out-of-sample

folds = [];
fold_end = IS_WIN;
while fold_end + OOS_WIN <= T
    folds(end+1, :) = [1, fold_end, fold_end+1, fold_end+OOS_WIN]; %#ok<AGROW>
    fold_end = fold_end + OOS_WIN;
end
n_folds = size(folds, 1);

if n_folds < 2
    warning('optimize_parameters: insufficient data for walk-forward (need %d days, have %d).', ...
            IS_WIN + 2*OOS_WIN, T);
    n_folds = max(1, n_folds);
end

fprintf('optimize_parameters: %d walk-forward folds\n', n_folds);

%% === Run grid search =====================================================
% oos_sharpe(combo, fold), oos_maxdd(combo, fold), oos_to(combo, fold)
oos_sharpe = nan(n_combos, n_folds);
oos_maxdd  = nan(n_combos, n_folds);
oos_turnov = nan(n_combos, n_folds);

progress_pct = 0;
for c = 1:n_combos
    a   = combos(c, 1);
    b   = combos(c, 2);
    thr = combos(c, 4);
    sw  = combos(c, 5);

    for f = 1:n_folds
        oos_start = folds(f, 3);
        oos_end   = folds(f, 4);

        % For smoothing to be valid over the OOS window we need a warm-up
        % prefix of length sw before oos_start (capped at start of data).
        warmup_start = max(1, oos_start - sw);
        idx_full     = warmup_start : oos_end;
        idx_oos_rel  = (oos_start - warmup_start + 1) : numel(idx_full);

        sm_full   = s_mom(idx_full);
        smac_full = s_macro(idx_full);
        sp_full   = s_policy(idx_full);

        % Aggregate over full window (includes warm-up), then slice OOS
        [~, ~, pos_full, ~] = aggregate_signals(sm_full, smac_full, sp_full, a, b, thr, sw);
        pos_oos   = pos_full(idx_oos_rel);
        yield_oos = yield_tt(oos_start:oos_end, :);

        % Backtest
        try
            pf = run_backtest(pos_oos, yield_oos, bt_params);
            oos_sharpe(c, f) = pf.sharpe_strat;
            oos_maxdd(c, f)  = pf.max_dd_strat;
            oos_turnov(c, f) = pf.turnover_pa;
        catch
            % Keep NaN on failure
        end
    end

    % Progress update every 10%
    pct = round(100 * c / n_combos);
    if pct >= progress_pct + 10
        progress_pct = floor(pct / 10) * 10;
        fprintf('  ... %d%% complete\n', progress_pct);
    end
end

%% === Compute median OOS statistics across folds ==========================
med_sharpe = median(oos_sharpe, 2, 'omitnan');
med_maxdd  = median(oos_maxdd, 2, 'omitnan');
med_turnov = median(oos_turnov, 2, 'omitnan');

%% === Apply robustness constraints ========================================
feasible = med_maxdd  < 0.15  & ...    % max drawdown < 15%
           med_turnov < 3     & ...    % turnover     < 3 trades/yr (regime focus)
           ~isnan(med_sharpe);

%% === Select optimal parameters ===========================================
med_sharpe_feas = med_sharpe;
med_sharpe_feas(~feasible) = -Inf;

[best_sharpe, best_idx] = max(med_sharpe_feas);

if isinf(best_sharpe) || best_sharpe == -Inf
    warning('optimize_parameters: No feasible combo meets all constraints. Relaxing to unconstrained best.');
    [~, best_idx] = max(med_sharpe);
end

opt_params.alpha      = combos(best_idx, 1);
opt_params.beta       = combos(best_idx, 2);
opt_params.gamma      = combos(best_idx, 3);
opt_params.threshold  = combos(best_idx, 4);
opt_params.smooth_win = combos(best_idx, 5);
opt_params.med_sharpe = med_sharpe(best_idx);
opt_params.med_maxdd  = med_maxdd(best_idx);
opt_params.med_turnov = med_turnov(best_idx);

fprintf('\nOptimal parameters:\n');
fprintf('  alpha=%.2f  beta=%.2f  gamma=%.2f  threshold=%.2f  smooth_win=%d\n', ...
        opt_params.alpha, opt_params.beta, opt_params.gamma, ...
        opt_params.threshold, opt_params.smooth_win);
fprintf('  Median OOS Sharpe=%.3f  MaxDD=%.1f%%  Turnover=%.1f/yr\n', ...
        opt_params.med_sharpe, 100*opt_params.med_maxdd, opt_params.med_turnov);

%% === Build results table =================================================
grid_results = table(combos(:,1), combos(:,2), combos(:,3), combos(:,4), combos(:,5), ...
                     med_sharpe, med_maxdd, med_turnov, feasible, ...
    'VariableNames', {'alpha','beta','gamma','threshold','smooth_win', ...
                      'median_sharpe','median_maxdd','median_turnover','feasible'});
grid_results = sortrows(grid_results, 'median_sharpe', 'descend');

%% === Pareto frontier (Sharpe vs MaxDD) ===================================
pareto_data.sharpe     = med_sharpe;
pareto_data.maxdd      = med_maxdd;
pareto_data.alpha      = combos(:, 1);
pareto_data.beta       = combos(:, 2);
pareto_data.threshold  = combos(:, 4);
pareto_data.smooth_win = combos(:, 5);
pareto_data.feasible   = feasible;

% Identify Pareto-optimal points (higher Sharpe AND lower MaxDD)
is_pareto = true(n_combos, 1);
for i = 1:n_combos
    if isnan(med_sharpe(i)), is_pareto(i) = false; continue, end
    for j = 1:n_combos
        if i == j || isnan(med_sharpe(j)), continue, end
        if med_sharpe(j) >= med_sharpe(i) && med_maxdd(j) <= med_maxdd(i)
            if med_sharpe(j) > med_sharpe(i) || med_maxdd(j) < med_maxdd(i)
                is_pareto(i) = false;
                break
            end
        end
    end
end
pareto_data.is_pareto = is_pareto;
end
