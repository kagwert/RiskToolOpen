function data = fetch_fred_data(series_id, start_date, end_date, api_key, force_refresh)
% FETCH_FRED_DATA  Pull a FRED series via the REST API with local .mat caching.
%
%   data = fetch_fred_data(series_id, start_date, end_date, api_key)
%   data = fetch_fred_data(series_id, start_date, end_date, api_key, force_refresh)
%
%   Inputs:
%     series_id     - FRED series identifier string, e.g. 'DGS10'
%     start_date    - Start date string 'YYYY-MM-DD'
%     end_date      - End date string 'YYYY-MM-DD'
%     api_key       - FRED API key string
%     force_refresh - Logical flag (default false); set true to bypass cache
%
%   Output:
%     data - Timetable with row dimension 'Date' and single variable 'Value'
%            Dates are datetime; missing FRED observations are NaN.
%
%   Notes:
%     Cache files are stored in ./fred_cache/<series_id>_<start>_<end>.mat
%     FRED returns "." for missing observations; these become NaN.

if nargin < 5, force_refresh = false; end

%% --- Cache handling -------------------------------------------------------
cache_dir  = 'fred_cache';
if ~exist(cache_dir, 'dir')
    mkdir(cache_dir);
end

safe_start = strrep(start_date, '-', '');
safe_end   = strrep(end_date,   '-', '');
cache_file = fullfile(cache_dir, sprintf('%s_%s_%s.mat', series_id, safe_start, safe_end));

if ~force_refresh && isfile(cache_file)
    s = load(cache_file, 'data');
    data = s.data;
    return
end

%% --- FRED API call (with retry on transient errors) ----------------------
base_url   = 'https://api.stlouisfed.org/fred/series/observations';
MAX_TRIES  = 4;
RETRY_WAIT = 3;   % seconds between attempts (doubles each retry)
raw_json   = '';
for attempt = 1:MAX_TRIES
    try
        opts     = weboptions('Timeout', 60, 'ContentType', 'text');
        raw_json = webread(base_url, ...
            'series_id',         series_id, ...
            'observation_start', start_date, ...
            'observation_end',   end_date, ...
            'api_key',           api_key, ...
            'file_type',         'json', ...
            opts);
        break   % success — exit retry loop
    catch ME
        is_transient = contains(ME.message, {'500','502','503','504', ...
                                             'Internal Server Error', ...
                                             'timed out','timeout'}, ...
                                'IgnoreCase', true);
        if attempt < MAX_TRIES && is_transient
            wait_sec = RETRY_WAIT * 2^(attempt - 1);
            fprintf('\n    [retry %d/%d in %ds — %s]', attempt, MAX_TRIES-1, ...
                    wait_sec, strtrim(ME.message(1:min(60,end))));
            pause(wait_sec);
        else
            error('fetch_fred_data: HTTP request failed for %s after %d attempt(s).\n  %s', ...
                  series_id, attempt, ME.message);
        end
    end
end

%% --- JSON parsing ---------------------------------------------------------
try
    parsed = jsondecode(raw_json);
catch ME
    error('fetch_fred_data: JSON decode failed for %s.\n  %s', series_id, ME.message);
end

if ~isfield(parsed, 'observations')
    error('fetch_fred_data: No ''observations'' field in response for %s.\n  Response: %s', ...
        series_id, raw_json(1:min(500, end)));
end

obs = parsed.observations;   % struct array  (N × 1)

%% --- Convert to timetable -------------------------------------------------
n      = numel(obs);
dates  = NaT(n, 1);
values = nan(n, 1);

for i = 1:n
    % Date field
    d = obs(i).date;
    if ischar(d) || isstring(d)
        dates(i) = datetime(d, 'InputFormat', 'yyyy-MM-dd');
    end
    % Value field — FRED uses '.' for missing
    v = obs(i).value;
    if ischar(v) || isstring(v)
        if ~strcmp(strtrim(v), '.') && ~isempty(strtrim(v))
            num = str2double(v);
            if ~isnan(num)
                values(i) = num;
            end
        end
    elseif isnumeric(v)
        values(i) = v;
    end
end

% Remove rows with invalid dates
valid  = ~isnat(dates);
dates  = dates(valid);
values = values(valid);

% Build timetable
data = timetable(values, 'RowTimes', dates, 'VariableNames', {'Value'});
data.Properties.DimensionNames{1} = 'Date';

%% --- Save cache -----------------------------------------------------------
save(cache_file, 'data');
end
