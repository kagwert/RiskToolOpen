function z = rolling_zscore(x, window, clip_val)
% ROLLING_ZSCORE  Rolling z-score with expanding warm-up period.
%
%   z = rolling_zscore(x, window)
%   z = rolling_zscore(x, window, clip_val)
%
%   Inputs:
%     x        - Numeric column vector (NaN allowed)
%     window   - Integer lookback window in observations
%     clip_val - Symmetric clip threshold (default 3); set 0 to disable
%
%   Output:
%     z - Column vector of z-scores, same length as x
%
%   Notes:
%     Uses an expanding window until 'window' observations are available.
%     Requires at least max(20, 0.25*window) non-NaN observations to compute.
%     NaN inputs produce NaN outputs; no look-ahead bias.

if nargin < 3, clip_val = 3; end

x       = x(:);
n       = length(x);
z       = nan(n, 1);
min_obs = max(20, round(window * 0.25));

for t = min_obs:n
    idx    = max(1, t - window + 1):t;
    sample = x(idx);
    valid  = sample(~isnan(sample));
    if length(valid) < min_obs || isnan(x(t))
        continue
    end
    mu    = mean(valid);
    sigma = std(valid);
    if sigma > 1e-12
        z(t) = (x(t) - mu) / sigma;
    end
end

if clip_val > 0
    z = max(-clip_val, min(clip_val, z));
end
end
