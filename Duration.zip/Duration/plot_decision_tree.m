function plot_decision_tree(Mdl, title_str, output_file)
% PLOT_DECISION_TREE  Visualise a MATLAB ClassificationTree object.
%
%   plot_decision_tree(Mdl, title_str, output_file)
%
%   Inputs:
%     Mdl         - ClassificationTree from fitctree
%     title_str   - String title for the figure
%     output_file - Filename to save as PDF; pass '' to skip saving
%
%   Layout:
%     Leaf positions are evenly spaced left-to-right using DFS order.
%     Internal node x = midpoint of children; y reflects tree depth.
%     Nodes are drawn as text boxes (cream = internal, blue/grey/pink = leaves).
%     Edges labelled '≤' (left child) and '>' (right child).

if nargin < 2 || isempty(title_str),   title_str   = 'Decision Tree';             end
if nargin < 3 || isempty(output_file), output_file = 'duration_tree_diagram.pdf'; end

%% --- Guard: trivial / empty tree ------------------------------------------
if isempty(Mdl) || Mdl.NumNodes < 1
    warning('plot_decision_tree: empty model — nothing to draw.');
    return
end

%% === Extract tree structure ================================================
N          = Mdl.NumNodes;
Children   = Mdl.Children;     % N×2: [left, right]; 0 if absent
IsBranch   = Mdl.IsBranch;     % N×1 logical
ClassNames = Mdl.ClassNames;   % K×1 (numeric for duration labels 2/4/6)
ClassProb  = Mdl.ClassProb;    % N×K
NodeSize   = Mdl.NodeSize;     % N×1

try
    CutPred = Mdl.CutPredictor;   % N×1 cell of feature names
    CutPt   = Mdl.CutPoint;       % N×1 split thresholds
catch
    CutPred = repmat({''}, N, 1);
    CutPt   = nan(N, 1);
end

%% === Compute depth via BFS =================================================
depth = zeros(N, 1);
queue = 1;
while ~isempty(queue)
    nd    = queue(1);  queue(1) = [];
    left  = Children(nd, 1);
    right = Children(nd, 2);
    if left  > 0, depth(left)  = depth(nd) + 1; queue(end+1) = left;  end %#ok<AGROW>
    if right > 0, depth(right) = depth(nd) + 1; queue(end+1) = right; end %#ok<AGROW>
end
max_depth = max(depth);

%% === Leaf ordering via DFS (left-first) ====================================
leaf_order   = zeros(N, 1);
leaf_counter = 0;
stk          = 1;
while ~isempty(stk)
    nd    = stk(end);  stk(end) = [];
    left  = Children(nd, 1);
    right = Children(nd, 2);
    if ~IsBranch(nd)
        leaf_counter        = leaf_counter + 1;
        leaf_order(nd)      = leaf_counter;
    else
        % Push right then left so left is popped first (LIFO)
        if right > 0, stk(end+1) = right; end %#ok<AGROW>
        if left  > 0, stk(end+1) = left;  end %#ok<AGROW>
    end
end
n_leaves = max(leaf_counter, 1);

%% === Assign x-coordinates ==================================================
xpos = zeros(N, 1);
% Leaves: uniformly spaced in (0,1)
for nd = 1:N
    if ~IsBranch(nd)
        xpos(nd) = (leaf_order(nd) - 0.5) / n_leaves;
    end
end
% Internal nodes: bottom-up, x = mean of children's x
for d = max_depth-1 : -1 : 0
    for nd = 1:N
        if IsBranch(nd) && depth(nd) == d
            left  = Children(nd, 1);
            right = Children(nd, 2);
            x_ch  = [];
            if left  > 0, x_ch(end+1) = xpos(left);  end %#ok<AGROW>
            if right > 0, x_ch(end+1) = xpos(right); end %#ok<AGROW>
            xpos(nd) = mean(x_ch);
        end
    end
end

%% === Y-coordinates =========================================================
% y=1 at root, y=0 at deepest level; add margin
y_margin = 0.05;
if max_depth == 0
    ypos = ones(N, 1);
else
    ypos = 1 - depth / max_depth * (1 - 2*y_margin) - y_margin;
end

%% === Colour map ============================================================
% Duration class colours
col_class = containers.Map([2, 4, 6], ...
    {[0.97, 0.78, 0.78], [0.92, 0.92, 0.92], [0.75, 0.88, 0.96]});
col_internal = [1.00, 0.98, 0.85];   % warm cream for split nodes

%% === Figure size ===========================================================
fig_w = max(14, n_leaves * 1.4);
fig_h = max(8,  (max_depth + 1) * 1.8);

fig = figure('Name', 'Decision Tree', 'Units', 'inches', ...
             'Position', [0.5, 0.5, fig_w, fig_h], ...
             'Color', 'white');

ax = axes(fig, 'Units', 'normalized', 'Position', [0.01, 0.06, 0.98, 0.88]);
hold(ax, 'on');
axis(ax, 'off');
xlim(ax, [-0.02, 1.02]);
ylim(ax, [-0.02, 1.08]);

% Title
text(ax, 0.5, 1.04, title_str, 'FontSize', 10, 'FontWeight', 'bold', ...
     'HorizontalAlignment', 'center', 'Units', 'data');

%% === Draw edges ============================================================
for nd = 1:N
    if ~IsBranch(nd), continue, end
    left  = Children(nd, 1);
    right = Children(nd, 2);
    if left > 0
        line(ax, [xpos(nd), xpos(left)],  [ypos(nd), ypos(left)],  ...
             'Color', [0.5 0.5 0.5], 'LineWidth', 0.9);
        mx = (xpos(nd) + xpos(left))  / 2;
        my = (ypos(nd) + ypos(left))  / 2 + 0.005;
        text(ax, mx, my, '≤', 'FontSize', 6, 'HorizontalAlignment', 'center', ...
             'Color', [0.4 0.4 0.4], 'Interpreter', 'none');
    end
    if right > 0
        line(ax, [xpos(nd), xpos(right)], [ypos(nd), ypos(right)], ...
             'Color', [0.5 0.5 0.5], 'LineWidth', 0.9);
        mx = (xpos(nd) + xpos(right)) / 2;
        my = (ypos(nd) + ypos(right)) / 2 + 0.005;
        text(ax, mx, my, '>', 'FontSize', 6, 'HorizontalAlignment', 'center', ...
             'Color', [0.4 0.4 0.4], 'Interpreter', 'none');
    end
end

%% === Draw nodes ============================================================
font_sz = max(5, min(8, 60 / n_leaves));

for nd = 1:N
    x = xpos(nd);
    y = ypos(nd);

    if IsBranch(nd)
        % --- Internal node: feature ≤ threshold -----------------------------
        feat_nm = CutPred{nd};
        cut_val = CutPt(nd);
        if ~isempty(feat_nm) && ~isnan(cut_val)
            % Shorten long feature names (keep last 12 chars after last '_' if long)
            if numel(feat_nm) > 14
                idx_ = strfind(feat_nm, '_');
                if ~isempty(idx_) && idx_(end) < numel(feat_nm) - 1
                    feat_nm = feat_nm(idx_(end)+1:end);
                else
                    feat_nm = feat_nm(end-12:end);
                end
            end
            lbl = sprintf('%s\n\x2264 %.3g', feat_nm, cut_val);
        else
            lbl = sprintf('node %d', nd);
        end
        bg_col = col_internal;
        fc_col = [0.25 0.25 0.25];
    else
        % --- Leaf node: class + probability + n ------------------------------
        [max_p, best_k] = max(ClassProb(nd, :));
        cn = ClassNames(best_k);
        if isnumeric(cn)
            class_str = sprintf('%dy', cn);
        else
            class_str = char(cn);
        end
        lbl = sprintf('%s\np=%.2f  n=%d', class_str, max_p, NodeSize(nd));
        if isnumeric(cn) && isKey(col_class, cn)
            bg_col = col_class(cn);
        else
            bg_col = [0.88 0.88 0.88];
        end
        fc_col = [0.15 0.15 0.15];
    end

    text(ax, x, y, lbl, ...
         'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
         'FontSize', font_sz, 'FontName', 'Monospaced', ...
         'Color', fc_col, ...
         'BackgroundColor', bg_col, ...
         'EdgeColor', [0.45 0.45 0.45], 'LineWidth', 0.7, ...
         'Margin', 2.5, 'Interpreter', 'none');
end

%% === Legend (bottom strip) =================================================
leg_items = {'Short (2y)', 'Neutral (4y)', 'Long (6y)', 'Split node'};
leg_cols  = {col_class(2), col_class(4), col_class(6), col_internal};
n_li      = numel(leg_items);
x_step    = 1 / n_li;

for li = 1:n_li
    xc = (li - 0.5) * x_step;
    rectangle(ax, 'Position', [xc - 0.035, -0.018, 0.025, 0.014], ...
              'FaceColor', leg_cols{li}, 'EdgeColor', [0.4 0.4 0.4], 'LineWidth', 0.5);
    text(ax, xc - 0.006, -0.011, leg_items{li}, ...
         'FontSize', 7, 'VerticalAlignment', 'middle');
end

%% === Save ==================================================================
if ~isempty(output_file)
    try
        exportgraphics(fig, output_file, 'ContentType', 'vector', 'Resolution', 150);
        fprintf('Decision tree diagram saved to: %s\n', output_file);
    catch ME
        warning('plot_decision_tree:saveFailed', '%s', ME.message);
        try
            print(fig, strrep(output_file, '.pdf', ''), '-dpdf', '-bestfit');
        catch
            warning('plot_decision_tree: PDF save failed. Figure remains open.');
        end
    end
end
end
