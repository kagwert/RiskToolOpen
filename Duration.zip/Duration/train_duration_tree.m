function [tree_score, tree_position, tree_info] = train_duration_tree(X, feat_names, yield_tt, params)
% TRAIN_DURATION_TREE  Walk-forward shallow decision tree for USD duration positioning.
%
%   [tree_score, tree_position, tree_info] = train_duration_tree(X, feat_names, yield_tt, params)
%
%   Inputs:
%     X          - T×p feature matrix from build_feature_matrix (NaN allowed)
%     feat_names - 1×p cell array of feature names
%     yield_tt   - CMT yield timetable (same T rows), for constructing labels
%     params     - Optional struct with fields:
%       .label_horizon   - Forward-return window for labels  (default 63 = 3 months)
%       .tree_depth      - Maximum tree depth, i.e. MaxNumSplits = 2^depth - 1
%                          (default 4 → 15 splits → max 16 leaves)
%       .min_leaf        - Minimum observations per leaf      (default 63)
%       .train_window    - Rolling IS window in days          (default 1260 = 5 years)
%       .min_train_size  - Minimum training observations      (default 756 = 3 years)
%       .retrain_freq    - Days between retrains              (default 21 = monthly)
%       .bench_dur       - Benchmark duration for neutral label (default 4)
%       .neutral_eps     - Min excess return to assign non-neutral label (default 0)
%
%   Outputs:
%     tree_score    - T×1 probability score in [-1,+1]:
%                     P(6y position best) - P(2y position best)
%     tree_position - T×1 raw modal class {2, 4, 6}
%     tree_info     - Struct with diagnostics:
%       .feat_importance  - p×1 feature importance (mean decrease in Gini, last tree)
%       .feat_names       - copy of feat_names
%       .n_retrains       - number of times tree was retrained
%       .label_counts     - [n_2y, n_4y, n_6y] in training labels
%       .last_tree        - the most recently fitted ClassificationTree object
%
%   Walk-forward scheme (strictly causal):
%     At each retrain point t:
%       Training set:  features and labels for [t - train_window : t - label_horizon]
%         (label at row s = argmax of portfolio returns over [s+1 : s+label_horizon])
%       Prediction:    features for [t : t + retrain_freq - 1]
%     The label_horizon buffer ensures future returns never leak into training.
%
%   Requires: Statistics and Machine Learning Toolbox (fitctree, predict)

%% === Defaults =============================================================
if nargin < 4, params = struct(); end
p = @(f,d) get_param(params, f, d);

label_horizon  = p('label_horizon',  63);    % 3-month forward return
tree_depth     = p('tree_depth',      4);    % max depth (15 splits)
min_leaf       = p('min_leaf',       63);    % min 3 months of data per leaf
train_window   = p('train_window',  1260);   % 5-year rolling window
min_train_size = p('min_train_size', 756);   % need 3 years minimum to start
retrain_freq   = p('retrain_freq',   21);    % retrain monthly
bench_dur      = p('bench_dur',       4);    % neutral benchmark duration (must be in DUR_MAP)
neutral_eps    = p('neutral_eps',     0);    % min excess return for non-neutral label

max_splits     = 2^tree_depth - 1;
T              = size(X, 1);
p_feat         = size(X, 2);
DUR_MAP        = [2, bench_dur, 6];          % middle element is always neutral

%% === Step 1: Pre-compute synthetic portfolio returns =====================
fprintf('    train_duration_tree: computing synthetic returns ...\n');
R_synth = compute_synthetic_returns(yield_tt, DUR_MAP);   % T × 3

% Replace NaN with 0 for cumsum (gap days earn nothing)
R_clean      = R_synth;
R_clean(isnan(R_clean)) = 0;
cum_R        = cumsum(R_clean, 1);   % T × 3, cumulative return series

%% === Step 2: Build forward-return labels =================================
% label(t) = argmax of portfolio return over [t+1 : t+label_horizon]
%           = column index of max(cum_R(t+label_horizon,:) - cum_R(t,:))
% Mapped to duration years via DUR_MAP.
fprintf('    train_duration_tree: building labels (H=%d days) ...\n', label_horizon);

labels = nan(T, 1);
for t = 1 : T - label_horizon
    fwd = cum_R(t + label_horizon, :) - cum_R(t, :);   % 1×3
    if any(isnan(fwd)), continue, end

    max_ret = max(fwd);
    % Award non-neutral only if winner beats bench by neutral_eps
    bench_col = find(DUR_MAP == bench_dur, 1);   % index of neutral duration in DUR_MAP
    if max_ret - fwd(bench_col) <= neutral_eps
        labels(t) = 4;   % neutral when win margin is marginal
    else
        [~, best] = max(fwd);
        labels(t) = DUR_MAP(best);
    end
end

%% === Step 3: Walk-forward training and prediction ========================
tree_score    = nan(T, 1);
tree_position = 4 * ones(T, 1);    % default = neutral
last_tree     = [];
n_retrains    = 0;

% Retrain schedule: every retrain_freq days, starting at min_train_size + label_horizon
t_start = min_train_size + label_horizon + 1;
retrain_points = t_start : retrain_freq : T;

fprintf('    train_duration_tree: %d retrain points, window=%ddy ...\n', ...
        numel(retrain_points), train_window);

for ri = 1:numel(retrain_points)
    t = retrain_points(ri);

    % Training range: rolling window ending at t-label_horizon
    % (ensures label at s uses returns from s+1:s+H, all ≤ t)
    t_is_end   = t - label_horizon - 1;   % last training row with valid label
    t_is_start = max(1, t_is_end - train_window + 1);

    if t_is_end < t_is_start + min_train_size
        continue   % not enough history yet
    end

    idx_train  = t_is_start : t_is_end;
    X_train    = X(idx_train, :);
    y_train    = labels(idx_train);

    % Remove rows where label or any feature is NaN
    % fitctree can handle NaN predictors via surrogate splits, but NaN labels
    % must be dropped.
    valid_rows = ~isnan(y_train);
    X_tr       = X_train(valid_rows, :);
    y_tr       = y_train(valid_rows);

    if numel(unique(y_tr)) < 2
        continue   % need at least 2 classes to fit a tree
    end

    % --- Fit shallow classification tree ----------------------------------
    try
        Mdl = fitctree(X_tr, y_tr, ...
            'MaxNumSplits',    max_splits, ...
            'MinLeafSize',     min_leaf, ...
            'SplitCriterion',  'gdi', ...
            'Surrogate',       'on', ...   % handle NaN predictors at test time
            'PredictorNames',  feat_names);
    catch ME
        warning('train_duration_tree: fitctree failed at t=%d: %s', t, ME.message);
        continue
    end

    last_tree = Mdl;
    n_retrains = n_retrains + 1;

    % --- Predict OOS window: [t : next_retrain - 1] ----------------------
    if ri < numel(retrain_points)
        t_oos_end = retrain_points(ri + 1) - 1;
    else
        t_oos_end = T;
    end
    idx_oos  = t : min(t_oos_end, T);
    X_oos    = X(idx_oos, :);

    try
        [pred_class, pred_scores] = predict(Mdl, X_oos);
    catch
        continue
    end

    % Map probability scores to a scalar in [-1,+1]:
    %   score = P(long=6y) - P(short=2y)
    cn   = Mdl.ClassNames;              % numeric class labels in model order
    i2   = find(cn == 2, 1);
    i6   = find(cn == 6, 1);
    if isempty(i2), i2 = 0; end
    if isempty(i6), i6 = 0; end

    score_oos = zeros(numel(idx_oos), 1);
    if i6 > 0, score_oos = score_oos + pred_scores(:, i6); end
    if i2 > 0, score_oos = score_oos - pred_scores(:, i2); end

    tree_score(idx_oos)    = score_oos;
    tree_position(idx_oos) = pred_class;
end

fprintf('    train_duration_tree: %d trees fitted.\n', n_retrains);

%% === Step 4: Feature importance from last tree ===========================
feat_imp = zeros(p_feat, 1);
if ~isempty(last_tree)
    try
        imp = predictorImportance(last_tree);
        feat_imp(1:numel(imp)) = imp(:);
    catch
        % older MATLAB: importance not available
    end
end

%% === Diagnostics ==========================================================
valid_labels  = labels(~isnan(labels));
label_counts  = [sum(valid_labels==2), sum(valid_labels==4), sum(valid_labels==6)];

tree_info.feat_importance = feat_imp;
tree_info.feat_names      = feat_names;
tree_info.n_retrains      = n_retrains;
tree_info.label_counts    = label_counts;
tree_info.last_tree       = last_tree;
tree_info.labels          = labels;    % keep for inspection

fprintf('    Label distribution — 2y: %d  4y: %d  6y: %d (total valid: %d)\n', ...
        label_counts(1), label_counts(2), label_counts(3), sum(label_counts));
end

%% =========================================================================
function R = compute_synthetic_returns(yield_tt, target_durs)
% COMPUTE_SYNTHETIC_RETURNS  r_D(t) = -D·Δy_D(t) + y_D(t-1)/252
% Returns T×numel(target_durs) matrix of daily returns.

known_labels  = {'DGS1','DGS2','DGS3','DGS5','DGS7','DGS10','DGS20','DGS30'};
known_tenors  = [1, 2, 3, 5, 7, 10, 20, 30];
avail = ismember(known_labels, yield_tt.Properties.VariableNames);
use_labels  = known_labels(avail);
use_tenors  = known_tenors(avail);

T       = height(yield_tt);
n_d     = numel(target_durs);
Y_known = nan(T, sum(avail));
for k = 1:sum(avail)
    Y_known(:, k) = yield_tt.(use_labels{k});
end

% Interpolate to target durations
Y_target = nan(T, n_d);
for t = 1:T
    yv = Y_known(t, :);
    valid = ~isnan(yv);
    if sum(valid) < 2, continue, end
    tv = use_tenors(valid);  yv = yv(valid);
    for d = 1:n_d
        td = target_durs(d);
        if td >= min(tv) && td <= max(tv)
            Y_target(t, d) = interp1(tv, yv, td, 'pchip');
        elseif td < min(tv)
            Y_target(t, d) = interp1(tv, yv, td, 'linear', 'extrap');
        else
            Y_target(t, d) = interp1(tv, yv, td, 'linear', 'extrap');
        end
    end
end

% Daily returns for each duration
R = nan(T, n_d);
for d = 1:n_d
    y_D = Y_target(:, d) / 100;
    D   = target_durs(d);
    for t = 2:T
        if isnan(y_D(t)) || isnan(y_D(t-1)), continue, end
        R(t, d) = -D * (y_D(t) - y_D(t-1)) + y_D(t-1) / 252;
    end
end
end

%% =========================================================================
function v = get_param(s, field, default)
if isfield(s, field) && ~isempty(s.(field))
    v = s.(field);
else
    v = default;
end
end
