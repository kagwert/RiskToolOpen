function plot_dashboard(perf, signals, yield_tt, opt_params, pareto_data, ~, output_file, tree_info)
% PLOT_DASHBOARD  Generate the 8-panel performance and signal dashboard.
%
%   plot_dashboard(perf, signals, yield_tt, opt_params, pareto_data, sub_signals)
%   plot_dashboard(..., output_file)
%
%   Inputs:
%     perf         - Output struct from run_backtest
%     signals      - Struct with fields: S_raw, s_mom, s_macro, s_policy, position
%     yield_tt     - CMT yield timetable (for heatmap panel)
%     opt_params   - Optimal parameters struct from optimize_parameters
%     pareto_data  - Pareto frontier struct from optimize_parameters
%     sub_signals  - Struct: .mom (compute_momentum_signal sub_signals),
%                            .macro (compute_macro_signal sub_signals),
%                            .policy (compute_policy_signal sub_signals)
%     output_file  - (optional) filename string for PDF output
%                    default: 'duration_signal_dashboard.pdf'
%
%   Panels:
%     1. Cumulative returns: strategy vs benchmark (log scale)
%     2. Cumulative active return
%     3. Rolling 1-year active Sharpe ratio
%     4. Signal history: S_raw with 2/4/6y positioning overlay
%     5. Module sub-signal contributions (stacked area)
%     6. Yield curve heatmap (tenor × time)
%     7. Drawdown profile: strategy vs benchmark
%     8. Parameter grid heatmap (Sharpe vs alpha and threshold, best beta)

if nargin < 7, output_file = 'duration_signal_dashboard.pdf'; end
if nargin < 8, tree_info  = struct(); end
use_tree = isfield(signals, 'use_tree') && signals.use_tree;

dates       = perf.dates;
T           = numel(dates);

%% === Create figure ========================================================
fig = figure('Name', 'Duration Signal Dashboard', ...
             'Units', 'inches', 'Position', [0.5, 0.5, 22, 16], ...
             'Color', [0.96 0.96 0.96], 'PaperOrientation', 'landscape');

colours.strat  = [0.12, 0.47, 0.71];
colours.bench  = [0.50, 0.50, 0.50];
colours.active = [0.17, 0.63, 0.17];
colours.pos    = [0.84, 0.15, 0.16];
colours.mom    = [0.58, 0.40, 0.74];
colours.macro  = [1.00, 0.50, 0.05];
colours.policy = [0.09, 0.75, 0.81];

tiledlayout(4, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

%% --- Panel 1: Cumulative returns (log scale) -----------------------------
nexttile;
semilogy(dates, perf.cum_strat, 'Color', colours.strat, 'LineWidth', 1.6); hold on;
semilogy(dates, perf.cum_bench, 'Color', colours.bench, 'LineWidth', 1.2, 'LineStyle', '--');
grid on; legend('Strategy', 'Benchmark (4y dur)', 'Location', 'northwest', 'FontSize', 8);
title('Cumulative Return (Log Scale)', 'FontWeight', 'bold');
ylabel('Wealth Index');
format_axes(gca);
text_box(gca, sprintf('Strat: %.1f%%p.a.  Sharpe: %.2f', ...
    100*perf.ann_ret_strat, perf.sharpe_strat));

%% --- Panel 2: Cumulative active return -----------------------------------
nexttile;
fill_between(dates, perf.cum_active - 1, zeros(T,1), colours.active);
hold on;
plot(dates, perf.cum_active - 1, 'Color', colours.active, 'LineWidth', 1.4);
yline(0, 'k--', 'LineWidth', 0.8);
grid on; title('Cumulative Active Return', 'FontWeight', 'bold');
ylabel('Active Wealth (above par)');
text_box(gca, sprintf('IR: %.2f  Hit Rate: %.1f%%', perf.info_ratio, 100*perf.hit_rate));
format_axes(gca);

%% --- Panel 3: Rolling 1-year Sharpe --------------------------------------
nexttile;
plot(dates, perf.roll_sharpe, 'Color', colours.active, 'LineWidth', 1.3); hold on;
yline(0,   'k--', 'LineWidth', 0.8);
yline(0.5, '--', 'Color', [0.6 0.6 0.6], 'LineWidth', 0.8);
yline(-0.5,'--', 'Color', [0.6 0.6 0.6], 'LineWidth', 0.8);
grid on; title('Rolling 1-Year Active Sharpe', 'FontWeight', 'bold');
ylabel('Sharpe Ratio');
ylim([-3, 3]);
format_axes(gca);

%% --- Panel 4: Position regime bands with signal overlay ---------------------
nexttile;
ax4 = gca;
hold(ax4, 'on');

% Regime colour map: 6y=long (blue), 4y=neutral (grey), 2y=short (pink)
reg_vals  = [6,                    4,                    2                   ];
reg_cols  = {[0.75, 0.88, 0.96],   [0.92, 0.92, 0.92],   [0.97, 0.78, 0.78] };
reg_lbls  = {'Long (6y)',           'Neutral (4y)',        'Short (2y)'       };
y_band    = [-1.35, 1.35];
pos_vec   = signals.position;

h_patch = gobjects(3, 1);
for ri = 1:3
    rv   = reg_vals(ri);
    in_r = (pos_vec == rv);
    sts  = find(diff([0; double(in_r)]) >  0);
    ens  = find(diff([double(in_r); 0]) < 0);
    pct  = 100 * sum(in_r, 'omitnan') / max(sum(~isnan(pos_vec)), 1);
    reg_lbl = sprintf('%s  %.0f%%', reg_lbls{ri}, pct);
    % Create one handle for the legend (zero-area, invisible placement)
    h_patch(ri) = fill(ax4, repmat(dates(1), 1, 4), [0 0 0 0], reg_cols{ri}, ...
                       'EdgeColor', 'none', 'FaceAlpha', 0.70);
    % Draw actual regime bands (exclude from legend via HandleVisibility)
    for k = 1:numel(sts)
        x_b = [dates(sts(k)), dates(ens(k)), dates(ens(k)), dates(sts(k))];
        y_b = [y_band(1), y_band(1), y_band(2), y_band(2)];
        fill(ax4, x_b, y_b, reg_cols{ri}, 'EdgeColor', 'none', 'FaceAlpha', 0.70, ...
             'HandleVisibility', 'off');
    end
    reg_lbls{ri} = reg_lbl;   % update with percentage
end

% Signal overlay: tree_score (light grey) + S_smooth (blue)
S_smooth_p = signals.S_smooth;
if ~isfield(signals, 'S_smooth'), S_smooth_p = signals.S_raw; end
if use_tree && isfield(signals, 'tree_score')
    plot(ax4, dates, signals.tree_score, 'Color', [0.72 0.72 0.72], 'LineWidth', 0.7, ...
         'HandleVisibility', 'off');
end
plot(ax4, dates, S_smooth_p, 'Color', colours.strat, 'LineWidth', 1.6, ...
     'HandleVisibility', 'off');

% Threshold lines
thr_enter = opt_params.threshold;
thr_exit  = opt_params.threshold * 0.5;
yline(ax4,  thr_enter, 'r-',  'LineWidth', 0.9, 'HandleVisibility', 'off');
yline(ax4, -thr_enter, 'r-',  'LineWidth', 0.9, 'HandleVisibility', 'off');
yline(ax4,  thr_exit,  'r--', 'LineWidth', 0.6, 'HandleVisibility', 'off');
yline(ax4, -thr_exit,  'r--', 'LineWidth', 0.6, 'HandleVisibility', 'off');
yline(ax4, 0, 'k-', 'LineWidth', 0.5, 'HandleVisibility', 'off');

ylim(ax4, y_band);
grid(ax4, 'on');
title(ax4, 'Duration Position Regimes & Signal', 'FontWeight', 'bold');
ylabel(ax4, 'Signal ∈ [−1, +1]');
legend(ax4, h_patch, reg_lbls, 'Location', 'southwest', 'FontSize', 7);
format_axes(ax4);

%% --- Panel 5: Module signals (individual lines in tree mode, weighted areas in linear mode)
nexttile;
s_mom_s    = signals.s_mom;
s_macro_s  = signals.s_macro;
s_policy_s = signals.s_policy;

if use_tree
    % Tree mode: show each module signal as a line (tree ignores weights)
    plot(dates, s_mom_s,    'Color', colours.mom,    'LineWidth', 1.2); hold on;
    plot(dates, s_macro_s,  'Color', colours.macro,  'LineWidth', 1.2);
    plot(dates, s_policy_s, 'Color', colours.policy, 'LineWidth', 1.2);
    yline(0, 'k-', 'LineWidth', 0.7);
    ylim([-1.2, 1.2]);
    legend({'Momentum','Macro','Policy'}, 'Location', 'northwest', 'FontSize', 8);
    title('Module Signals (inputs to Decision Tree)', 'FontWeight', 'bold');
    ylabel('Signal ∈ [−1, +1]');
else
    pos_mom    = max(0,  s_mom_s    * opt_params.alpha);
    pos_mac    = max(0,  s_macro_s  * opt_params.beta);
    pos_pol    = max(0,  s_policy_s * opt_params.gamma);
    neg_mom    = min(0,  s_mom_s    * opt_params.alpha);
    neg_mac    = min(0,  s_macro_s  * opt_params.beta);
    neg_pol    = min(0,  s_policy_s * opt_params.gamma);

    colororder(gca, [colours.mom; colours.macro; colours.policy]);
    area(dates, [pos_mom, pos_mac, pos_pol], 'FaceAlpha', 0.7); hold on;
    colororder(gca, [colours.mom; colours.macro; colours.policy]);
    area(dates, [neg_mom, neg_mac, neg_pol], 'FaceAlpha', 0.7);
    yline(0, 'k-', 'LineWidth', 0.7);
    legend({'Mom','Macro','Policy'}, 'Location', 'northwest', 'FontSize', 8);
    title('Module Signal Contributions (Weighted)', 'FontWeight', 'bold');
    ylabel('Contribution to S_{raw}');
end
grid on; format_axes(gca);

%% --- Panel 6: Yield curve heatmap (tenor × time) -------------------------
nexttile;
tenor_labels = {'DGS2','DGS5','DGS7','DGS10','DGS20','DGS30'};
tenor_yrs    = [2, 5, 7, 10, 20, 30];
avail = ismember(tenor_labels, yield_tt.Properties.VariableNames);

avail_labels = tenor_labels(avail);
Y_hm  = nan(T, numel(avail_labels));
t_yrs = tenor_yrs(avail);
for k = 1:numel(avail_labels)
    Y_hm(:, k) = yield_tt.(avail_labels{k});
end

% Downsample to weekly for heatmap (fewer columns)
step    = max(1, round(T / 600));
idx_ds  = 1:step:T;
Y_ds    = Y_hm(idx_ds, :)';
dates_ds = dates(idx_ds);
dnums_ds = datenum(dates_ds);

imagesc(dnums_ds, t_yrs, Y_ds);
axis xy;
datetick('x', 'yyyy', 'keeplimits', 'keepticks');
cb = colorbar; cb.Label.String = 'Yield (%)';
colormap(gca, hot(128));
yticks(t_yrs);  yticklabels(arrayfun(@(x) sprintf('%dy', x), t_yrs, 'UniformOutput', false));
title('CMT Yield Curve Heatmap', 'FontWeight', 'bold');
xlabel('Date');  ylabel('Tenor');
format_axes(gca);

%% --- Panel 7: Drawdown profile -------------------------------------------
nexttile;
dd_strat = drawdown_series(perf.cum_strat);
dd_bench = drawdown_series(perf.cum_bench);
plot(dates, -100*dd_strat, 'Color', colours.strat, 'LineWidth', 1.4); hold on;
plot(dates, -100*dd_bench, 'Color', colours.bench, 'LineWidth', 1.0, 'LineStyle', '--');
fill_between(dates, -100*dd_strat, zeros(T,1), colours.strat, 0.3);
grid on; legend('Strategy','Benchmark','Location','southwest','FontSize',8);
title('Drawdown Profile', 'FontWeight', 'bold');
ylabel('Drawdown (%)');
text_box(gca, sprintf('Strat MaxDD: %.1f%%  Bench MaxDD: %.1f%%', ...
    100*perf.max_dd_strat, 100*perf.max_dd_bench));
format_axes(gca);

%% --- Panel 8: Feature importance (tree mode) or Parameter grid (linear mode)
nexttile;
if use_tree && isfield(tree_info, 'feat_importance') && ...
        isfield(tree_info, 'feat_names') && ~isempty(tree_info.last_tree)
    % --- Feature importance bar chart ------------------------------------
    fi   = tree_info.feat_importance;
    fn   = tree_info.feat_names;
    % Sort descending
    [fi_s, ord] = sort(fi, 'descend');
    fn_s = fn(ord);
    % Only show top 15
    n_show = min(15, numel(fi_s));
    fi_s   = fi_s(1:n_show);
    fn_s   = fn_s(1:n_show);
    % Flip for horizontal bar (largest at top)
    barh(1:n_show, flip(fi_s), 'FaceColor', colours.strat, 'EdgeColor', 'none');
    yticks(1:n_show);
    yticklabels(flip(fn_s));
    xlabel('Mean Gini Decrease');
    title('Feature Importance (Last Tree)', 'FontWeight', 'bold');
    grid on; format_axes(gca);
    text_box(gca, sprintf('Retrains: %d', tree_info.n_retrains));
else
    % --- Parameter grid heatmap (linear mode) ----------------------------
    pr = pareto_data;
    all_betas = unique(pr.beta);
    best_beta = NaN;
    best_beta_sharpe = -Inf;
    for bi = 1:numel(all_betas)
        mask  = abs(pr.beta - all_betas(bi)) < 1e-6;
        mn_sh = median(pr.sharpe(mask), 'omitnan');
        if mn_sh > best_beta_sharpe
            best_beta_sharpe = mn_sh;
            best_beta = all_betas(bi);
        end
    end

    mask_b  = abs(pr.beta - best_beta) < 1e-6;
    a_b     = pr.alpha(mask_b);
    t_b     = pr.threshold(mask_b);
    sh_b    = pr.sharpe(mask_b);
    a_uniq  = unique(a_b);
    t_uniq  = unique(t_b);
    SH_grid = nan(numel(t_uniq), numel(a_uniq));
    for i = 1:numel(a_b)
        ri = find(abs(t_uniq - t_b(i)) < 1e-6);
        ci = find(abs(a_uniq - a_b(i)) < 1e-6);
        if ~isempty(ri) && ~isempty(ci)
            SH_grid(ri, ci) = sh_b(i);
        end
    end
    imagesc(a_uniq, t_uniq, SH_grid);
    axis xy; colorbar; colormap(gca, parula(64));
    xlabel('\alpha (momentum weight)'); ylabel('Threshold');
    title(sprintf('OOS Median Sharpe (\\beta=%.2f)', best_beta), 'FontWeight', 'bold');
    hold on;
    plot(opt_params.alpha, opt_params.threshold, 'r*', 'MarkerSize', 12, 'LineWidth', 2);
    legend('Optimal', 'Location', 'northeast', 'FontSize', 8);
    format_axes(gca);
end

%% === Super-title =========================================================
sw_val = 63; if isfield(opt_params,'smooth_win'), sw_val = opt_params.smooth_win; end
if use_tree
    n_ret = 0;
    if isfield(tree_info, 'n_retrains'), n_ret = tree_info.n_retrains; end
    sgtitle(sprintf('USD FI Duration Signal  |  Decision Tree  |  thr=%.2f  smooth=%dd  retrains=%d', ...
        opt_params.threshold, sw_val, n_ret), 'FontSize', 11, 'FontWeight', 'bold');
else
    sgtitle(sprintf('USD FI Duration Signal  |  \\alpha=%.2f  \\beta=%.2f  \\gamma=%.2f  thr=%.2f  smooth=%dd', ...
        opt_params.alpha, opt_params.beta, opt_params.gamma, opt_params.threshold, sw_val), ...
        'FontSize', 11, 'FontWeight', 'bold');
end

%% === Save output =========================================================
try
    exportgraphics(fig, output_file, 'ContentType', 'vector', 'Resolution', 150);
    fprintf('Dashboard saved to: %s\n', output_file);
catch ME
    warning('plot_dashboard:saveFailed', '%s', ME.message);
    try
        print(fig, strrep(output_file, '.pdf', ''), '-dpdf', '-bestfit');
    catch
        warning('plot_dashboard: PDF save failed. Figure remains open.');
    end
end
end

%% =========================================================================
function format_axes(ax)
set(ax, 'FontSize', 8, 'Box', 'off', 'TickDir', 'out', ...
        'GridAlpha', 0.3, 'Color', [0.99 0.99 0.99]);
end

function text_box(ax, str)
ylims = ylim(ax);
xlims = xlim(ax);
text(ax, xlims(1) + 0.02*(xlims(2)-xlims(1)), ylims(2) - 0.08*(ylims(2)-ylims(1)), ...
     str, 'FontSize', 7.5, 'VerticalAlignment', 'top', 'BackgroundColor', [1 1 1 0.7]);
end

function fill_between(dates, y_upper, y_lower, col, alpha_val)
% FILL_BETWEEN  Shaded area between y_upper and y_lower over datetime dates.
if nargin < 5, alpha_val = 0.25; end
x_fill = [dates(:); flipud(dates(:))];
y_fill = [y_upper(:); flipud(y_lower(:))];
y_fill(isnan(y_fill)) = 0;
fill(x_fill, y_fill, col, 'FaceAlpha', alpha_val, 'EdgeColor', 'none');
end

function dd = drawdown_series(cum_wealth)
n   = numel(cum_wealth);
dd  = zeros(n, 1);
pk  = cum_wealth(1);
for t = 1:n
    if isnan(cum_wealth(t)), dd(t) = dd(max(1,t-1)); continue, end
    pk    = max(pk, cum_wealth(t));
    dd(t) = (pk - cum_wealth(t)) / max(pk, 1e-10);
end
end
