function [s_policy, sub_signals] = compute_policy_signal(policy_tt, yield_tt)
% COMPUTE_POLICY_SIGNAL  Module 3: Level & Policy Attractiveness.
%
%   [s_policy, sub_signals] = compute_policy_signal(policy_tt, yield_tt)
%
%   Inputs:
%     policy_tt - Timetable (business-daily) with columns:
%       DFII10   - 10y TIPS real yield (%)
%       DFII2    - 2y  TIPS real yield (%)
%       FEDFUNDS - Effective Federal Funds Rate (%)
%       CorePCE  - Core PCE YoY inflation (%, from PCEPILFE)
%       UNRATE   - Unemployment rate (%)
%       NROU     - Natural rate of unemployment (%)
%     yield_tt  - Same timetable as Module 1 (CMT yields: DGS1..DGS30)
%                 Must contain at least DGS2 and DGS10.
%
%   Outputs:
%     s_policy    - T×1 signal in [-1,+1]
%                   +1 = Fed tight / overpriced hikes → bearish duration
%                   -1 = Fed loose / cutting / rich valuations → bullish
%     sub_signals - Struct with s_realrate, s_taylor, s_cycle, s_fwd
%
%   Weights (default; overridden in aggregate_signals via optimization):
%     w_real=0.25, w_taylor=0.35, w_cycle=0.20, w_fwd=0.20

%% === Parameters ===========================================================
W_REAL   = 0.25;
W_TAYLOR = 0.35;
W_CYCLE  = 0.20;
W_FWD    = 0.20;
R_NEUTRAL = 0.50;    % assumed long-run neutral real rate (%)
PI_STAR   = 2.00;    % Fed inflation target (%)
Z_WIN_REAL = 252*5;  % 5-year window for real-rate z-score

T = height(policy_tt);

%% === Extract series =======================================================
real10   = gcol(policy_tt, 'DFII10');
real2    = gcol(policy_tt, 'DFII2');
fedfunds = gcol(policy_tt, 'FEDFUNDS');
core_pce = gcol(policy_tt, 'CorePCE');   % already in YoY %
unrate   = gcol(policy_tt, 'UNRATE');
nrou     = gcol(policy_tt, 'NROU');

%% === 1. REAL YIELD SIGNAL ================================================
% High real yields → bonds cheap (attractive) → bullish duration → signal −1
% Low/negative real yields → expensive → bearish → signal +1
% (Note: direction: high real yield = bullish duration = −1)

real_avg    = nanmean([real10, real2], 2);
z_real_10   = rolling_zscore(real10,   Z_WIN_REAL);
z_real_avg  = rolling_zscore(real_avg, Z_WIN_REAL);

% High real yield → bullish duration → s = −1 (invert sign)
s_realrate  = -tanh(0.5 * (z_real_10 + z_real_avg));
s_realrate  = max(-1, min(1, s_realrate));

%% === 2. TAYLOR RULE GAP ==================================================
% r_taylor = r_neutral + π + 0.5*(π - π*) + 0.5*(output_gap)
% output_gap = -(UNRATE - NROU)  [positive when overheating]
output_gap  = -(unrate - nrou);
r_taylor    = R_NEUTRAL + core_pce + 0.5 * (core_pce - PI_STAR) + 0.5 * output_gap;

% taylor_gap = Fed Funds - r_taylor
% Positive → Fed tighter than mandate → policy already restrictive → bullish duration
% Negative → Fed loose / behind curve → bearish duration
taylor_gap  = fedfunds - r_taylor;
z_taylor    = rolling_zscore(taylor_gap, 252 * 3);

% Positive gap (tight Fed) → bullish duration → −1 in our convention
s_taylor    = -tanh(z_taylor);
s_taylor    = max(-1, min(1, s_taylor));

%% === 3. FED CYCLE INDICATOR ==============================================
% Hiking cycle → rates rising → bearish (+1)
% Cutting cycle → rates falling → bullish (−1)
chg_6m      = [nan(126, 1); fedfunds(127:end) - fedfunds(1:end-126)];

s_cycle     = nan(T, 1);
for t = 1:T
    if isnan(chg_6m(t))
        continue
    elseif chg_6m(t) > 0.25      % hiking: > +25bps over 6 months
        s_cycle(t) = 1;          % bearish duration
    elseif chg_6m(t) < -0.25     % cutting: < -25bps
        s_cycle(t) = -1;         % bullish duration
    else
        s_cycle(t) = 0;          % neutral
    end
end

% Smooth with 21-day moving average to reduce noise
s_cycle_smooth = nan(T, 1);
for t = 21:T
    win = s_cycle(t-20:t);
    s_cycle_smooth(t) = nanmean(win);
end
s_cycle = max(-1, min(1, s_cycle_smooth));

%% === 4. FORWARD RATE PRICING SIGNAL =====================================
% Compute 1y1y and 2y2y forward rates from the CMT curve
% Compare to current short rate and Taylor implied path
% If forwards embed MORE hikes than Taylor → market over-priced → bullish (−1)

DGS1  = get_yield(yield_tt, 'DGS1',  []);
DGS2  = get_yield(yield_tt, 'DGS2',  []);
DGS3  = get_yield(yield_tt, 'DGS3',  []);
DGS5  = get_yield(yield_tt, 'DGS5',  []);
DGS7  = get_yield(yield_tt, 'DGS7',  []);
DGS10 = get_yield(yield_tt, 'DGS10', []);

% Interpolate 4y yield (not on FRED) for forward rate construction
known_tenors = [1, 2, 3, 5, 7, 10];
known_yields = [DGS1, DGS2, DGS3, DGS5, DGS7, DGS10];

fwd_1y1y = nan(T, 1);    % 1-year rate, 1 year forward
fwd_2y2y = nan(T, 1);    % 2-year rate, 2 years forward

for t = 1:T
    yv = known_yields(t, :);
    tv = known_tenors;
    valid = ~isnan(yv);
    if sum(valid) < 3, continue, end
    tv_v = tv(valid); yv_v = yv(valid);

    % Interpolate to get 1y, 2y, 4y yields
    y1 = interp_yield(tv_v, yv_v, 1);
    y2 = interp_yield(tv_v, yv_v, 2);
    y4 = interp_yield(tv_v, yv_v, 4);

    if ~isnan(y1) && ~isnan(y2)
        fwd_1y1y(t) = 2*y2 - y1;    % 1y rate, 1y forward (continuous approx)
    end
    if ~isnan(y2) && ~isnan(y4)
        fwd_2y2y(t) = 2*y4 - y2;    % 2y rate, 2y forward
    end
end

% Taylor implied path 1y forward: r_taylor + expected change in pi/growth
% Simplification: use current Taylor rate as 1y forward estimate
% Forward premium = fwd_1y1y - r_taylor (excess above Taylor path)
fwd_premium   = fwd_1y1y - r_taylor;
fwd_premium_2 = fwd_2y2y - r_taylor;
avg_fwd_premium = nanmean([fwd_premium, fwd_premium_2], 2);

z_fwd = rolling_zscore(avg_fwd_premium, 252 * 3);

% High forward premium → market pricing more hikes than Taylor → bullish (−1)
s_fwd = -tanh(z_fwd);
s_fwd = max(-1, min(1, s_fwd));

%% === 5. AGGREGATE POLICY SIGNAL ==========================================
s_policy_raw = W_REAL   * s_realrate + ...
               W_TAYLOR * s_taylor   + ...
               W_CYCLE  * s_cycle    + ...
               W_FWD    * s_fwd;
s_policy     = max(-1, min(1, s_policy_raw));

%% === Pack sub-signals ====================================================
sub_signals.s_realrate  = s_realrate;
sub_signals.s_taylor    = s_taylor;
sub_signals.s_cycle     = s_cycle;
sub_signals.s_fwd       = s_fwd;
sub_signals.r_taylor    = r_taylor;
sub_signals.taylor_gap  = taylor_gap;
sub_signals.fwd_1y1y    = fwd_1y1y;
sub_signals.fwd_2y2y    = fwd_2y2y;
end

%% =========================================================================
function v = gcol(tt, name)
% GCOL  Safely extract a variable from a timetable; return NaN column if missing.
if ismember(name, tt.Properties.VariableNames)
    v = tt.(name);
else
    v = nan(height(tt), 1);
    warning('compute_policy_signal: ''%s'' not found.', name);
end
end

function v = get_yield(yield_tt, name, default)
if ismember(name, yield_tt.Properties.VariableNames)
    v = yield_tt.(name);
else
    if isempty(default)
        v = nan(height(yield_tt), 1);
    else
        v = repmat(default, height(yield_tt), 1);
    end
end
end

function y = interp_yield(tenors, yields, target)
% INTERP_YIELD  Interpolate yield at target tenor using pchip.
if target < min(tenors) || target > max(tenors)
    y = NaN;
    return
end
try
    y = interp1(tenors, yields, target, 'pchip');
catch
    y = NaN;
end
end
