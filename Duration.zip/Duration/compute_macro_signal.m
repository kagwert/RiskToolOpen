function [s_macro, sub_signals] = compute_macro_signal(macro_daily_tt)
% COMPUTE_MACRO_SIGNAL  Module 2: Macro Fundamentals (Growth & Inflation).
%
%   [s_macro, sub_signals] = compute_macro_signal(macro_daily_tt)
%
%   Input:
%     macro_daily_tt - Timetable aligned to business-day calendar with columns:
%       CPI        - CPI level (CPIAUCSL), seasonally adjusted
%       CoreCPI    - Core CPI level (CPILFESL)
%       Breakeven5y5y  - 5y5y forward breakeven inflation (T5YIFR)
%       Breakeven10y   - 10y breakeven (T10YIE)
%       INDPRO     - Industrial Production index (INDPRO)
%       Payrolls   - Nonfarm Payrolls level (PAYEMS)
%       PMI        - ISM Manufacturing PMI (NAPM/MANEMP proxy)
%       LEI        - Conference Board LEI (USSLIND)
%       RetailSales - Retail & Food Services Sales (RSXFS)
%       UNRATE     - Civilian Unemployment Rate (%)
%       NROU       - Natural Rate of Unemployment (NROU)
%       BAA        - Moody's BAA corporate bond yield (BAA)
%       AAA        - Moody's AAA corporate bond yield (AAA)
%
%   Outputs:
%     s_macro     - T×1 signal in [-1,+1]:
%                   +1 = strong growth + high inflation (bearish duration)
%                   -1 = weak growth  + low  inflation (bullish duration)
%     sub_signals - Struct with c_inf, c_growth, and per-series z-scores
%
%   Weights (hard-coded, see aggregate_signals for optimization):
%     Inflation composite:  CPI_yoy=0.30, CoreCPI=0.25, BE5y5y=0.30, CPI_mom=0.15
%     Growth composite:     INDPRO=0.25,  Payrolls=0.25, PMI=0.20, LEI=0.20, UE_gap=0.10

%% === Parameters ===========================================================
W_INF = struct('CPI_yoy', 0.30, 'CoreCPI_yoy', 0.25, 'BE5y5y', 0.30, 'CPI_mom', 0.15);
W_GRO = struct('INDPRO',  0.25, 'Payrolls_mom', 0.25, 'PMI', 0.20, 'LEI', 0.20, 'UE_gap', 0.10);
Z_WIN = 252 * 3;     % 3-year rolling z-score window
MA12_WIN = 252;      % 12-month moving average window for regime flag
MIN_SERIES = 0.7;    % require 70% of series to be non-NaN

T = height(macro_daily_tt); %#ok<NASGU> — used implicitly via series vectors

%% === Derive series ========================================================
CPI        = get_col(macro_daily_tt, 'CPI');
CoreCPI    = get_col(macro_daily_tt, 'CoreCPI');
BE5y5y     = get_col(macro_daily_tt, 'Breakeven5y5y');
INDPRO_raw = get_col(macro_daily_tt, 'INDPRO');
Payrolls   = get_col(macro_daily_tt, 'Payrolls');
PMI        = get_col(macro_daily_tt, 'PMI');
LEI        = get_col(macro_daily_tt, 'LEI');
UNRATE     = get_col(macro_daily_tt, 'UNRATE');
NROU       = get_col(macro_daily_tt, 'NROU');
BAA        = get_col(macro_daily_tt, 'BAA');
AAA        = get_col(macro_daily_tt, 'AAA');

%% === Compute derived series ===============================================
% CPI YoY: approximate from monthly data (already forward-filled to daily)
% Because this is monthly, we use a 252-day lag for YoY
CPI_yoy     = 100 * (CPI ./ lag_series(CPI, 252) - 1);   % approximate YoY
CoreCPI_yoy = 100 * (CoreCPI ./ lag_series(CoreCPI, 252) - 1);

% CPI MoM (using 21-day lag as monthly proxy)
CPI_mom     = 100 * (CPI ./ lag_series(CPI, 21) - 1);

% --- Annualized short-horizon inflation rates and their momentum ----------
% 3-month annualized: compound the 63-day return to an annual rate
% 6-month annualized: compound the 126-day return to an annual rate
% Momentum = 3m_ann - 6m_ann  (positive → inflation accelerating)
DAYS_3M = 63;
DAYS_6M = 126;

infl_3m_ann  = 100 * ((CPI     ./ lag_series(CPI,     DAYS_3M)) .^ (252/DAYS_3M) - 1);
infl_6m_ann  = 100 * ((CPI     ./ lag_series(CPI,     DAYS_6M)) .^ (252/DAYS_6M) - 1);
infl_mom_raw = infl_3m_ann - infl_6m_ann;   % >0 = inflation picking up

core_3m_ann  = 100 * ((CoreCPI ./ lag_series(CoreCPI, DAYS_3M)) .^ (252/DAYS_3M) - 1);
core_6m_ann  = 100 * ((CoreCPI ./ lag_series(CoreCPI, DAYS_6M)) .^ (252/DAYS_6M) - 1);
core_mom_raw = core_3m_ann - core_6m_ann;

% INDPRO YoY
INDPRO_yoy  = 100 * (INDPRO_raw ./ lag_series(INDPRO_raw, 252) - 1);

% Payrolls MoM change (level → monthly change)
Payrolls_mom = Payrolls - lag_series(Payrolls, 21);

% LEI YoY
LEI_yoy     = 100 * (LEI ./ lag_series(LEI, 252) - 1);

% Unemployment gap: positive = economy overheating (above NAIRU)
UE_gap      = -(UNRATE - NROU);    % positive when below NAIRU

% Credit spread
Credit_spr  = BAA - AAA;

%% === Z-score each series (3-year rolling window) =========================
z_CPI_yoy     = rolling_zscore(CPI_yoy,      Z_WIN);
z_CoreCPI_yoy = rolling_zscore(CoreCPI_yoy,  Z_WIN);
z_BE5y5y      = rolling_zscore(BE5y5y,       Z_WIN);
z_CPI_mom     = rolling_zscore(CPI_mom,      Z_WIN);
z_infl_3m     = rolling_zscore(infl_3m_ann,  Z_WIN);
z_infl_6m     = rolling_zscore(infl_6m_ann,  Z_WIN);
z_infl_mom    = rolling_zscore(infl_mom_raw, Z_WIN);
z_core_3m     = rolling_zscore(core_3m_ann,  Z_WIN);
z_core_6m     = rolling_zscore(core_6m_ann,  Z_WIN);
z_core_mom    = rolling_zscore(core_mom_raw, Z_WIN);

z_INDPRO      = rolling_zscore(INDPRO_yoy,   Z_WIN);
z_Payrolls    = rolling_zscore(Payrolls_mom, Z_WIN);
z_PMI         = rolling_zscore(PMI,          Z_WIN);    % raw level
z_LEI         = rolling_zscore(LEI_yoy,      Z_WIN);
z_UE_gap      = rolling_zscore(UE_gap,       Z_WIN);
z_Credit      = rolling_zscore(Credit_spr,   Z_WIN);

%% === Binary regime flag (above 12-month MA) ==============================
b_CPI_yoy     = above_ma(CPI_yoy,      MA12_WIN);
b_CoreCPI_yoy = above_ma(CoreCPI_yoy,  MA12_WIN); %#ok<NASGU> — retained for potential dashboard use
b_PMI_50      = double(PMI > 50);       % PMI > 50 = expansion
b_INDPRO      = above_ma(INDPRO_yoy,   MA12_WIN); %#ok<NASGU>
b_LEI         = above_ma(LEI_yoy,      MA12_WIN); %#ok<NASGU>

%% === Inflation composite ==================================================
% High inflation → bearish duration → positive score
c_inf_raw = W_INF.CPI_yoy    * z_CPI_yoy     + ...
            W_INF.CoreCPI_yoy * z_CoreCPI_yoy + ...
            W_INF.BE5y5y     * z_BE5y5y       + ...
            W_INF.CPI_mom    * z_CPI_mom;

c_inf = normalise_signal(c_inf_raw);

%% === Growth composite ====================================================
% Strong growth → bearish duration → positive score
c_growth_raw = W_GRO.INDPRO      * z_INDPRO    + ...
               W_GRO.Payrolls_mom * z_Payrolls  + ...
               W_GRO.PMI         * z_PMI        + ...
               W_GRO.LEI         * z_LEI        + ...
               W_GRO.UE_gap      * z_UE_gap;

c_growth = normalise_signal(c_growth_raw);

%% === Combined macro signal ===============================================
s_macro_raw = 0.5 * c_inf + 0.5 * c_growth;
s_macro     = max(-1, min(1, s_macro_raw));

%% === Missing data mask ====================================================
% If too many series are NaN on a given date, set signal to NaN
series_stack = [z_CPI_yoy, z_CoreCPI_yoy, z_BE5y5y, z_CPI_mom, ...
                z_INDPRO, z_Payrolls, z_PMI, z_LEI, z_UE_gap];
frac_avail   = sum(~isnan(series_stack), 2) / size(series_stack, 2);
s_macro(frac_avail < MIN_SERIES) = NaN;

%% === Pack sub-signals ====================================================
sub_signals.c_inf         = c_inf;
sub_signals.c_growth      = c_growth;
sub_signals.z_CPI_yoy     = z_CPI_yoy;
sub_signals.z_CoreCPI_yoy = z_CoreCPI_yoy;
sub_signals.z_BE5y5y      = z_BE5y5y;
sub_signals.z_CPI_mom     = z_CPI_mom;
sub_signals.z_INDPRO      = z_INDPRO;
sub_signals.z_Payrolls    = z_Payrolls;
sub_signals.z_PMI         = z_PMI;
sub_signals.z_LEI         = z_LEI;
sub_signals.z_UE_gap      = z_UE_gap;
sub_signals.z_Credit      = z_Credit;
sub_signals.b_PMI_50      = b_PMI_50;
sub_signals.b_CPI_yoy     = b_CPI_yoy;
% Annualized inflation rates and momentum (for decision tree)
sub_signals.infl_3m_ann   = infl_3m_ann;
sub_signals.infl_6m_ann   = infl_6m_ann;
sub_signals.infl_mom_raw  = infl_mom_raw;
sub_signals.core_3m_ann   = core_3m_ann;
sub_signals.core_6m_ann   = core_6m_ann;
sub_signals.core_mom_raw  = core_mom_raw;
sub_signals.z_infl_3m     = z_infl_3m;
sub_signals.z_infl_6m     = z_infl_6m;
sub_signals.z_infl_mom    = z_infl_mom;
sub_signals.z_core_3m     = z_core_3m;
sub_signals.z_core_6m     = z_core_6m;
sub_signals.z_core_mom    = z_core_mom;
end

%% =========================================================================
function y = lag_series(x, k)
% LAG_SERIES  Shift series forward by k periods (introduce k leading NaNs).
y = [nan(k, 1); x(1:end-k)];
end

function b = above_ma(x, window)
% ABOVE_MA  Binary flag: 1 when x > rolling mean over 'window' periods.
n = numel(x);
b = nan(n, 1);
for t = window:n
    m = mean(x(max(1,t-window+1):t), 'omitnan');
    if ~isnan(x(t)) && ~isnan(m)
        b(t) = double(x(t) > m);
    end
end
end

function s = normalise_signal(x)
% NORMALISE_SIGNAL  Map composite score to [-1,+1] via tanh of z-score.
z = rolling_zscore(x, 252);
s = tanh(z);
s = max(-1, min(1, s));
end

function v = get_col(tt, name)
% GET_COL  Safely extract a variable from a timetable; return NaN column if absent.
if ismember(name, tt.Properties.VariableNames)
    v = tt.(name);
else
    v = nan(height(tt), 1);
    warning('compute_macro_signal: column ''%s'' not found; using NaN.', name);
end
end
