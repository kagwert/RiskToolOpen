function [best_params, calib_table] = calibrate_tree_params(tree_score, yield_tt, bt_params)
% CALIBRATE_TREE_PARAMS  Grid search over threshold and smooth_win for the tree path.
%
%   [best_params, calib_table] = calibrate_tree_params(tree_score, yield_tt, bt_params)
%
%   Background:
%     The decision tree produces a score in [-1,+1] = P(6y best) - P(2y best).
%     Two post-processing parameters convert this score into discrete positions:
%       threshold  - entry level for tree_score (after smoothing) to flip position
%       smooth_win - causal trailing-mean window applied to tree_score before
%                    thresholding (controls regime persistence)
%
%     Since tree_score is already out-of-sample (walk-forward), evaluating
%     aggregate_signals on the full series with different threshold/smooth_win
%     involves only modest post-hoc selection bias.  Best practice: report
%     results for the full grid, not just the chosen pair.
%
%   Inputs:
%     tree_score - T×1 vector of tree probability scores in [-1,+1]
%     yield_tt   - CMT yield timetable (passed through to run_backtest)
%     bt_params  - Struct with .tc_bps_per_yr, .benchmark_dur (from main script)
%
%   Outputs:
%     best_params  - Struct with .threshold, .smooth_win (and NaN alpha/beta/gamma)
%     calib_table  - Table with all grid results (20 rows)
%
%   Selection criterion:
%     Best Information Ratio subject to MaxDD < 20% and Turnover < 5 trades/yr.
%     If no feasible point exists, constraint on MaxDD is relaxed.

%% === Grid definition =======================================================
thresh_grid  = [0.10, 0.15, 0.20, 0.25, 0.30];
smooth_grid  = [21,   42,   63,   126];

n_thresh = numel(thresh_grid);
n_smooth = numel(smooth_grid);
n_combo  = n_thresh * n_smooth;

%% === Evaluate each combination =============================================
res = nan(n_combo, 6);   % [threshold, smooth_win, sharpe, IR, max_dd, turnover]

row = 0;
for ti = 1:n_thresh
    for si = 1:n_smooth
        row = row + 1;
        thr = thresh_grid(ti);
        sw  = smooth_grid(si);
        res(row, 1) = thr;
        res(row, 2) = sw;

        % Require enough non-NaN observations to fill the smooth window
        n_valid = sum(~isnan(tree_score));
        if n_valid < sw * 3
            continue
        end

        try
            [~, ~, pos, ~] = aggregate_signals([], [], [], [], [], thr, sw, tree_score);
            p = run_backtest(pos, yield_tt, bt_params);
            res(row, 3) = p.sharpe_strat;
            res(row, 4) = p.info_ratio;
            res(row, 5) = p.max_dd_strat;
            res(row, 6) = p.turnover_pa;
        catch
            % Leave as NaN if evaluation fails
        end
    end
end

%% === Print results table ===================================================
fprintf('\n');
fprintf('  ╔══════════════════════════════════════════════════════════════╗\n');
fprintf('  ║     Tree Threshold / Smooth-Window Calibration Grid         ║\n');
fprintf('  ╠══════════╦══════════╦════════╦════════╦══════════╦══════════╣\n');
fprintf('  ║ threshold║smooth_win║ Sharpe ║   IR   ║ MaxDD(%%)║Turnover  ║\n');
fprintf('  ╠══════════╬══════════╬════════╬════════╬══════════╬══════════╣\n');

% Determine best row index (for marking)
feasible_mask = ~isnan(res(:,3)) & res(:,5) < 0.20 & res(:,6) < 5;
if any(feasible_mask)
    score_vec = res(:, 4) .* feasible_mask;
else
    % Relax constraints
    feasible_mask = ~isnan(res(:, 3));
    score_vec = res(:, 4) .* feasible_mask;
end
[~, best_row] = max(score_vec);

prev_thresh = NaN;
for i = 1:n_combo
    if isnan(res(i, 3)), continue, end
    % Insert divider when threshold group changes
    if ~isnan(prev_thresh) && res(i,1) ~= prev_thresh
        fprintf('  ╠══════════╬══════════╬════════╬════════╬══════════╬══════════╣\n');
    end
    prev_thresh = res(i, 1);

    marker = '  ';
    if i == best_row, marker = '◄ '; end

    fprintf('  ║  %.2f    ║   %3d    ║ %6.2f ║ %6.2f ║  %6.1f  ║  %5.1f   ║ %s\n', ...
            res(i,1), res(i,2), res(i,3), res(i,4), 100*res(i,5), res(i,6), marker);
end
fprintf('  ╚══════════╩══════════╩════════╩════════╩══════════╩══════════╝\n');
fprintf('  ◄ = selected (best IR, MaxDD<20%%, Turnover<5/yr)\n\n');

%% === Return best parameters ================================================
best_params.threshold  = res(best_row, 1);
best_params.smooth_win = res(best_row, 2);
best_params.alpha      = NaN;   % unused in tree mode
best_params.beta       = NaN;
best_params.gamma      = NaN;

%% === Build output table ====================================================
valid_rows = ~isnan(res(:, 3));
calib_table = array2table(res(valid_rows, :), ...
    'VariableNames', {'threshold','smooth_win','sharpe','info_ratio','max_dd','turnover_pa'});
end
