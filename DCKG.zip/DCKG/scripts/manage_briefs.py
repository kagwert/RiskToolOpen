"""
manage_briefs.py — CLI for managing DCKG focus briefs.

Usage:
  python scripts/manage_briefs.py list
  python scripts/manage_briefs.py activate BRIEF_ID
  python scripts/manage_briefs.py deactivate BRIEF_ID
  python scripts/manage_briefs.py add --id ID --name NAME --keywords "kw1,kw2" --targets "VLO,DAL"
  python scripts/manage_briefs.py remove BRIEF_ID
  python scripts/manage_briefs.py test "Some news headline text here"

The 'test' command shows which active briefs a given text would match,
and whether it would be admitted to the extraction pipeline.
"""
import sys
import argparse
from pathlib import Path

import yaml

BRIEFS_PATH = Path(__file__).parent.parent / "config" / "focus_briefs.yaml"


def load_data():
    with open(BRIEFS_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def save_data(data):
    with open(BRIEFS_PATH, "w", encoding="utf-8") as f:
        yaml.dump(data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)


def cmd_list(args):
    data = load_data()
    active = data.get("active_briefs", [])
    inactive = data.get("inactive_briefs", []) or []

    print("\n" + "-" * 60)
    print(f"  DCKG FOCUS BRIEFS  ({BRIEFS_PATH.name})")
    print("-" * 60)

    if not active:
        print("  [no active briefs — system in open mode, all news processed]")
    else:
        print(f"\n  ACTIVE ({len(active)}):\n")
        for b in active:
            status = "ON " if b.get("active", True) else "OFF"
            kw_count = len(b.get("watch_keywords", []))
            tgt = ", ".join(b.get("universe_targets", []))
            pri = b.get("graph_priority", "?")
            print(f"  [{status}] [{pri}] {b['id']}")
            print(f"         {b.get('name', '')}")
            print(f"         keywords: {kw_count}  targets: {tgt}")
            print()

    if inactive and inactive != []:
        print(f"  INACTIVE ({len(inactive)}):")
        for b in (inactive if isinstance(inactive, list) else []):
            if isinstance(b, dict):
                print(f"  [ - ] {b.get('id', '?')}  {b.get('name', '')}")
        print()

    print("-" * 60 + "\n")


def cmd_activate(args):
    data = load_data()
    inactive = data.get("inactive_briefs") or []
    active = data.get("active_briefs", [])

    # Check if it's already in active_briefs but with active: false
    for b in active:
        if b["id"] == args.brief_id:
            b["active"] = True
            save_data(data)
            print(f"  Activated: {args.brief_id}")
            return

    # Move from inactive_briefs to active_briefs
    if isinstance(inactive, list):
        for b in list(inactive):
            if isinstance(b, dict) and b.get("id") == args.brief_id:
                inactive.remove(b)
                b["active"] = True
                active.append(b)
                data["active_briefs"] = active
                data["inactive_briefs"] = inactive
                save_data(data)
                print(f"  Moved to active: {args.brief_id}")
                return

    print(f"  ERROR: Brief '{args.brief_id}' not found.")
    sys.exit(1)


def cmd_deactivate(args):
    data = load_data()
    active = data.get("active_briefs", [])
    inactive = data.get("inactive_briefs") or []
    if not isinstance(inactive, list):
        inactive = []

    for b in list(active):
        if b["id"] == args.brief_id:
            active.remove(b)
            b["active"] = False
            inactive.append(b)
            data["active_briefs"] = active
            data["inactive_briefs"] = inactive
            save_data(data)
            print(f"  Deactivated (moved to inactive): {args.brief_id}")
            return

    print(f"  ERROR: Active brief '{args.brief_id}' not found.")
    sys.exit(1)


def cmd_add(args):
    data = load_data()
    active = data.get("active_briefs", [])

    # Check for duplicate id
    all_ids = [b["id"] for b in active]
    inactive = data.get("inactive_briefs") or []
    if isinstance(inactive, list):
        all_ids += [b["id"] for b in inactive if isinstance(b, dict)]
    if args.id in all_ids:
        print(f"  ERROR: Brief id '{args.id}' already exists. Use activate/deactivate.")
        sys.exit(1)

    keywords = [k.strip() for k in args.keywords.split(",")] if args.keywords else []
    targets = [t.strip() for t in args.targets.split(",")] if args.targets else []
    edge_types = [e.strip() for e in args.edge_types.split(",")] if args.edge_types else [
        "CONSTRAINS_SUPPLY_OF", "INCREASES_COST_OF", "CAUSES_POLICY_SHIFT_IN",
        "ALTERS_RISK_APPETITE_FOR", "DISRUPTS_INFRASTRUCTURE_OF", "CREATES_DEMAND_FOR",
    ]

    brief = {
        "id": args.id,
        "name": args.name,
        "active": True,
        "description": args.description or "",
        "watch_keywords": keywords,
        "watch_nodes": [],
        "watch_edge_types": edge_types,
        "universe_targets": targets,
        "regime_relevant": [],
        "min_novelty_score": float(args.min_novelty) if args.min_novelty else 0.25,
        "graph_priority": len(active) + 1,
    }

    active.append(brief)
    data["active_briefs"] = active
    save_data(data)
    print(f"  Added brief: {args.id} ({args.name})")
    print(f"  Keywords: {keywords}")
    print(f"  Universe targets: {targets}")


def cmd_remove(args):
    data = load_data()
    active = data.get("active_briefs", [])
    inactive = data.get("inactive_briefs") or []

    for collection in [active, inactive if isinstance(inactive, list) else []]:
        for b in list(collection):
            if isinstance(b, dict) and b.get("id") == args.brief_id:
                collection.remove(b)
                data["active_briefs"] = active
                data["inactive_briefs"] = inactive if isinstance(inactive, list) else []
                save_data(data)
                print(f"  Removed: {args.brief_id}")
                return

    print(f"  ERROR: Brief '{args.brief_id}' not found.")
    sys.exit(1)


def cmd_test(args):
    """Dry-run: show which briefs a text would match and whether it passes Layer 3."""
    data = load_data()
    active = [b for b in data.get("active_briefs", []) if b.get("active", True)]
    text = args.text.lower()

    print(f"\n  TEXT: \"{args.text[:80]}{'...' if len(args.text) > 80 else ''}\"")
    print("  " + "-" * 56)

    if not active:
        print("  No active briefs — open mode, text WOULD BE PROCESSED.")
        return

    matched = []
    for brief in active:
        hits = [kw for kw in brief.get("watch_keywords", []) if kw.lower() in text]
        if hits:
            matched.append((brief["id"], brief.get("name", ""), hits))

    if matched:
        print(f"  RESULT: PASS — matched {len(matched)} brief(s)\n")
        for brief_id, name, hits in matched:
            print(f"  MATCH: {brief_id}  ({name})")
            print(f"    matched keywords: {hits[:5]}")
    else:
        print("  RESULT: DROPPED — no active brief matched.")
        print("  Text would not reach Claude API (zero API cost).")
        print()
        print("  Active briefs checked:")
        for b in active:
            print(f"    - {b['id']} ({len(b.get('watch_keywords', []))} keywords)")

    print()


def main():
    parser = argparse.ArgumentParser(
        description="Manage DCKG focus briefs (config/focus_briefs.yaml)"
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("list", help="List all briefs")

    p_act = sub.add_parser("activate", help="Activate a brief by ID")
    p_act.add_argument("brief_id")

    p_deact = sub.add_parser("deactivate", help="Deactivate a brief by ID")
    p_deact.add_argument("brief_id")

    p_add = sub.add_parser("add", help="Add a new brief")
    p_add.add_argument("--id", required=True)
    p_add.add_argument("--name", required=True)
    p_add.add_argument("--keywords", help="Comma-separated keyword list")
    p_add.add_argument("--targets", help="Comma-separated universe asset IDs")
    p_add.add_argument("--edge-types", dest="edge_types", help="Comma-separated edge types")
    p_add.add_argument("--description", default="")
    p_add.add_argument("--min-novelty", dest="min_novelty", default="0.25")

    p_rm = sub.add_parser("remove", help="Permanently remove a brief by ID")
    p_rm.add_argument("brief_id")

    p_test = sub.add_parser("test", help="Test which briefs a text would match")
    p_test.add_argument("text", help="News text to test")

    args = parser.parse_args()

    if args.command == "list":
        cmd_list(args)
    elif args.command == "activate":
        cmd_activate(args)
    elif args.command == "deactivate":
        cmd_deactivate(args)
    elif args.command == "add":
        cmd_add(args)
    elif args.command == "remove":
        cmd_remove(args)
    elif args.command == "test":
        cmd_test(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
