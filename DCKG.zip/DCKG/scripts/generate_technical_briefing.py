"""
generate_technical_briefing.py
Produces a technical architecture briefing PDF for the DCKG system.

Output: C:\\Users\\H\\Downloads\\dckg_technical_briefing.pdf

Style: A4 portrait, white background, Times-Roman, LaTeX aesthetic.
       Reuses the LatexDoc builder from generate_manual_latex.py.
"""
import sys
from pathlib import Path
from datetime import date

from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor, white

# ── Reuse the LatexDoc builder from the sibling script ─────────────────────
sys.path.insert(0, str(Path(__file__).parent))
from generate_manual_latex import (
    LatexDoc, PW, PH, LM, RM, TM, BM, BW,
    C_BLACK, C_BLUE, C_MUTED, C_FAINT, C_RULE,
    C_CODE_BG, C_NOTE_BG, C_NOTE_BD, C_WARN_BD, C_TIP_BD,
    F_BODY, F_BOLD, F_ITALIC, F_BOLDITAL,
    F_SANS, F_SANS_BOLD, F_CODE,
)

DOC_TITLE_HDR = "DCKG System — Technical Architecture Briefing"
DOC_FOOTER_L  = "Dynamic Causal Knowledge Graph"
DOC_FOOTER_R  = "Confidential — Internal Use Only"


# ── Subclass to customise header / footer / cover text ─────────────────────

class TechBriefDoc(LatexDoc):

    def _draw_header(self):
        y = PH - 36
        self.c.setFont(F_SANS, 8.5)
        self.c.setFillColor(C_MUTED)
        self.c.drawString(LM, y, DOC_TITLE_HDR)
        self.c.drawRightString(PW - RM, y, self._section_title)
        self.c.setStrokeColor(C_RULE)
        self.c.setLineWidth(0.5)
        self.c.line(LM, y - 4, PW - RM, y - 4)

    def _draw_footer(self):
        y = 36
        self.c.setStrokeColor(C_RULE)
        self.c.setLineWidth(0.5)
        self.c.line(LM, y + 6, PW - RM, y + 6)
        self.c.setFont(F_SANS, 8.5)
        self.c.setFillColor(C_MUTED)
        self.c.drawCentredString(PW / 2, y, str(self.page_num))
        self.c.drawString(LM, y, DOC_FOOTER_L)
        self.c.drawRightString(PW - RM, y, DOC_FOOTER_R)

    def cover(self, title, subtitle, version, doc_date):
        c = self.c
        c.setFillColor(white)
        c.rect(0, 0, PW, PH, fill=1, stroke=0)

        c.setFillColor(C_BLUE)
        c.rect(LM, PH - 90, BW, 3, fill=1, stroke=0)

        c.setFont(F_SANS_BOLD, 11)
        c.setFillColor(C_BLUE)
        c.drawString(LM, PH - 78, "DYNAMIC CAUSAL KNOWLEDGE GRAPH")

        ty = PH - 200
        c.setFont(F_BOLD, 26)
        c.setFillColor(C_BLACK)
        for line in self._wrap(title, F_BOLD, 26, BW):
            c.drawString(LM, ty, line)
            ty -= 34

        ty -= 6
        c.setFont(F_ITALIC, 14)
        c.setFillColor(C_MUTED)
        for line in self._wrap(subtitle, F_ITALIC, 14, BW):
            c.drawString(LM, ty, line)
            ty -= 20

        c.setStrokeColor(C_RULE)
        c.setLineWidth(0.7)
        c.line(LM, PH / 2 + 60, PW - RM, PH / 2 + 60)

        my = PH / 2 + 42
        meta = [
            ("Version",  version),
            ("Date",     doc_date),
            ("System",   "DCKG v1.0  |  85/85 tests passing"),
            ("API",      "http://localhost:8000"),
            ("Pillars",  "Perception  |  Knowledge Graph  |  Execution"),
        ]
        for label, value in meta:
            c.setFont(F_BOLD, 10)
            c.setFillColor(C_BLACK)
            c.drawString(LM, my, label + ":")
            c.setFont(F_BODY, 10)
            c.setFillColor(C_MUTED)
            c.drawString(LM + 72, my, value)
            my -= 16

        c.setFillColor(C_NOTE_BG)
        c.setStrokeColor(C_NOTE_BD)
        c.setLineWidth(0.8)
        c.rect(LM, 130, BW, 120, fill=1, stroke=1)
        c.setFillColor(C_BLUE)
        c.setFont(F_SANS_BOLD, 9)
        c.drawString(LM + 10, 238, "ABSTRACT")
        abstract = (
            "This document describes the complete technical architecture of the Dynamic "
            "Causal Knowledge Graph (DCKG) system: a three-pillar investment research "
            "platform that ingests news, market and macro data; constructs a probabilistic "
            "causal graph over financial instruments; and generates portfolio weights via a "
            "constrained optimiser. The briefing covers data sourcing and ingestion (Pillar I), "
            "graph construction and updating (Pillar II), portfolio construction and trade "
            "selection (Pillar III), and the visualisation and API layer. All class names, "
            "formulas, and configuration keys are drawn directly from the Phase 1 source code."
        )
        ax, ay, aw = LM + 10, 223, BW - 20
        for line in self._wrap(abstract, F_BODY, 9.5, aw):
            c.setFont(F_BODY, 9.5)
            c.setFillColor(C_BLACK)
            c.drawString(ax, ay, line)
            ay -= 13

        c.setFillColor(C_BLUE)
        c.rect(LM, 90, BW, 1.5, fill=1, stroke=0)
        c.setFont(F_SANS, 8)
        c.setFillColor(C_MUTED)
        c.drawCentredString(PW / 2, 70, "Dynamic Causal Knowledge Graph  |  Internal Use Only")
        c.drawCentredString(PW / 2, 58, doc_date)

        self.cy = BM
        return self


# ══════════════════════════════════════════════════════════════════════════
# CONTENT
# ══════════════════════════════════════════════════════════════════════════

def build(doc):

    # ── Section 1: Data Sourcing & Ingestion ──────────────────────────────
    doc.section("Data Sourcing and Ingestion")

    doc.para(
        "Pillar I (Perception) is responsible for ingesting raw data from three independent "
        "channels, applying a two-stage focus-brief filter before any LLM call is made, and "
        "publishing structured causal events to the immutable event bus. All data entering "
        "the system must pass ontology validation, novelty scoring, and verifiability scoring "
        "before it is eligible to update the knowledge graph."
    )

    # 1.1
    doc.subsection("Input Channels")
    doc.para(
        "Three agents cover the major data domains. Each agent is independently deployable "
        "and replaceable; the event bus contract is the only coupling between pillars."
    )
    doc.param_table(
        ["Agent", "Key Data Fields", "Phase 1 Implementation", "Production Source"],
        [
            ["Agent A (Newsflow)",
             "text, source_url, publication_timestamp",
             "Claude Sonnet 4.6 via Anthropic SDK; stub fixture mode when key absent",
             "Reuters wire, Bloomberg News, RSS feeds"],
            ["Agent B (Market)",
             "asset_id, price, volume, spread, returns[]",
             "JSON fixture loader; returns hardcoded price series",
             "Bloomberg B-PIPE / Refinitiv Elektron adapter"],
            ["Agent C (Macro)",
             "dimension (growth/inflation/risk_appetite), value, confidence",
             "Hardcoded STAGFLATION_RISK stub; overrideable via constructor",
             "Macro data API (BLS, ECB, Bloomberg Economic)"],
        ],
        col_widths=[80, 130, 150, 91],
    )
    doc.note(
        "Agent B and Agent C are Phase 1 stubs. They produce the correct DCKGEvent schema "
        "so that downstream components (graph store, optimizer) are fully exercised. "
        "Production adapters replace the stub internals without changing the event contract."
    )

    # 1.2
    doc.subsection("Focus-Brief Filtering (Two-Stage Gate)")
    doc.para(
        "Layer 3 of the five-layer filtering architecture is controlled by "
        "config/focus_briefs.yaml. It operates as a two-stage gate: a cheap keyword scan "
        "before any LLM call (Layer 3a), and a structured node/edge check on extracted claims "
        "after the LLM call (Layer 3b). Texts that pass neither stage are silently dropped "
        "and forwarded to ThemeScanner for emerging-theme detection."
    )
    doc.para(
        "The BriefMatcher class (pillar1_perception/agent_a_newsflow.py) loads and manages "
        "active briefs. Its three public methods are:"
    )
    doc.bullet_list([
        "text_matches_any_brief(text) -> (matched: bool, matched_brief_ids: list) -- "
        "case-insensitive substring scan of text against every active brief's watch_keywords. "
        "Called before the Claude API call; returns immediately on first keyword hit.",
        "claim_matches_any_brief(claim: dict) -> bool -- post-extraction check. "
        "Tests whether source_node_id, target_node_id, or edge_type appears in any brief's "
        "watch_nodes, watch_edge_types, or universe_targets combination.",
        "get_min_novelty(brief_ids: list) -> float -- returns the lowest min_novelty_score "
        "across all matched briefs, used to gate duplicate signals.",
    ])
    doc.para(
        "Hot-reload is supported: calling agent.reload_briefs() re-reads focus_briefs.yaml "
        "from disk without restarting the process. The brief below shows the full structure "
        "for the IRAN_WAR_SUPPLY_SHOCK brief (keywords truncated for space):"
    )
    doc.code([
        "- id: IRAN_WAR_SUPPLY_SHOCK",
        "  name: 'Iran Crisis - Energy Supply Shock'",
        "  active: true",
        "  description: >",
        "    US-Iran war and its causal chain through energy markets.",
        "    Hormuz closure -> crude/products deficit -> crack spread",
        "    expansion -> refiner margin (VLO) and airline cost (DAL).",
        "  watch_keywords:",
        "    - hormuz",
        "    - strait of hormuz",
        "    - iran",
        "    - irgc",
        "    - ras tanura",
        "    - ras laffan",
        "    - gasoil crack",
        "    - jet fuel crack",
        "    - lng deficit",
        "    - energy supply shock",
        "  watch_nodes:",
        "    - Hormuz_Closure",
        "    - Ras_Tanura_Strike",
        "    - Ras_Laffan_Strike",
        "    - AIS_Tanker_Transit",
        "  watch_edge_types:",
        "    - CONSTRAINS_SUPPLY_OF",
        "    - INFRASTRUCTURE_DAMAGE_TO",
        "    - INCREASES_COST_OF",
        "  universe_targets:",
        "    - ICE_GASOIL",
        "    - BRENT_CRUDE",
        "    - VLO",
        "    - DAL",
        "    - EU_UTILITIES",
        "  min_novelty_score: 0.3",
        "  graph_priority: 1",
    ], caption="focus_briefs.yaml — IRAN_WAR_SUPPLY_SHOCK (abridged)", lang="yaml")
    doc.note(
        "Pre-LLM filtering reduces Claude API calls to under 1% of total article volume "
        "under normal operating conditions. The ThemeScanner receives all dropped texts, "
        "creating a discovery corpus from normal system operation at zero additional cost."
    )

    # 1.3
    doc.subsection("Event Bus and Immutable Log")
    doc.para(
        "All inter-component data flows through the event bus (pillar1_perception/event_bus.py). "
        "Phase 1 uses SQLite with WAL mode and two database triggers that raise an "
        "IMMUTABILITY VIOLATION error at the engine level if any DELETE or UPDATE is "
        "attempted. The production replacement is Apache Kafka with Apache Iceberg for "
        "long-term storage."
    )
    doc.para(
        "Every message must carry the DCKGEvent mandatory field set (AR64):"
    )
    doc.param_table(
        ["Field", "Type", "Description"],
        [
            ["event_id",             "str (UUID)",  "Globally unique; immutable once assigned"],
            ["event_type",           "str",         "Controlled vocabulary (see below)"],
            ["source_component",     "str",         "Pillar/agent that produced the event"],
            ["receipt_timestamp",    "str ISO8601", "When the bus received the event (UTC)"],
            ["publication_timestamp","str ISO8601", "When the source data was published (UTC)"],
            ["ontology_version",     "str",         "Ontology version active at extraction time"],
            ["payload",              "dict",        "Event-specific structured data"],
        ],
        col_widths=[130, 90, 231],
    )
    doc.para("The full controlled vocabulary of event_type values, grouped by pillar:")
    doc.bullet_list([
        "Pillar I to II: CAUSAL_EXTRACTION, MARKET_DATA_UPDATE, MACRO_RELEASE, "
        "FEED_FAILURE, FEED_RESTORED.",
        "Pillar II internal: EDGE_CREATED, EDGE_UPDATED, EDGE_CONTESTED, EDGE_RETIRED, "
        "CONFLICT_DETECTED, CONFLICT_RESOLVED, REGIME_CLASSIFIED, "
        "REGIME_OVERLAY_ACTIVATED, ALPHA_VECTOR_UPDATED, ALPHA_VECTOR_PUBLISHED.",
        "Pillar III: OPTIMIZER_SOLVE_STARTED, OPTIMIZER_SOLVE_COMPLETED, "
        "OPTIMIZER_SOLVE_FAILED, PORTFOLIO_WEIGHTS_PUBLISHED.",
    ])
    doc.para(
        "Point-in-time reconstruction is available via bus.reconstruct_at(timestamp), "
        "which replays all events with receipt_timestamp <= the supplied ISO8601 value. "
        "This supports full audit, backtesting, and regulatory replay."
    )
    doc.warning(
        "Never issue UPDATE or DELETE against the events table. The SQLite triggers raise "
        "an IMMUTABILITY VIOLATION error at the engine level before any application code "
        "runs. All corrections must be forward-only new events. This constraint is "
        "mandatory per AR22 and is preserved in the Kafka production design."
    )

    # 1.4
    doc.subsection("Data Quality, Novelty and Verifiability Scoring")
    doc.para(
        "data_quality.py provides schema validation for causal extractions and feed-failure "
        "detection. Two scores are computed on every extraction and stored on the event "
        "payload; they are used downstream in conflict resolution."
    )
    doc.para("Novelty scoring (AR25) uses MD5 partial hashing against a 100-text ring buffer:")
    doc.code([
        "h = md5(text.encode()).hexdigest()[:16]",
        "if h in recent_hashes: return 0.0   # exact duplicate",
        "count_similar = sum(1 for old in recent_hashes if old[:4] == h[:4])",
        "novelty = max(0.1, 1.0 - count_similar * 0.25)",
    ], caption="agent_a_newsflow.py -- _compute_novelty()", lang="python")
    doc.para("Verifiability scoring (AR27) is determined from the source URL domain:")
    doc.param_table(
        ["Source Domain Pattern", "Verifiability Score"],
        [
            ["reuters.com or bloomberg.com", "0.85"],
            ["gov or official (in URL)",     "0.90"],
            ["Any other URL present",        "0.60"],
            ["No URL (source_url is None)",  "0.00"],
        ],
        col_widths=[280, 171],
    )

    # 1.5
    doc.subsection("Emerging Theme Discovery (ThemeScanner)")
    doc.para(
        "ThemeScanner (pillar1_perception/theme_scanner.py) operates on the corpus of texts "
        "that were dropped by the brief filter. It runs three tiers of increasing cost to "
        "surface themes not yet covered by any active brief."
    )
    doc.param_table(
        ["Tier", "Method", "API Cost", "Threshold / Config"],
        [
            ["1 -- Velocity",    "Phrase frequency: recent vs. baseline window",
             "Free",             "ratio >= 2.5x, buffer >= 200 texts, min count 4"],
            ["2 -- Semantic",    "Claude batch: groups velocity hits into themes",
             "1 API call",       "Up to 80 velocity candidates per batch"],
            ["3 -- Price Orphan","Assets with >10% move but <1 ACTIVE incoming edge",
             "Free",             "Static check against graph state"],
        ],
        col_widths=[80, 160, 70, 141],
    )
    doc.para(
        "Tier 1 tokenises each text into 2- and 3-word phrases, strips stop words, and "
        "computes velocity_ratio = recent_freq / baseline_freq where recent is the last "
        "100 texts and baseline is the full 500-text rolling buffer. Co-occurring phrases "
        "are clustered via Jaccard similarity into CandidateBrief objects."
    )
    doc.para(
        "VelocityCandidate fields: phrase, recent_count, baseline_count, velocity_ratio, "
        "example_texts. CandidateBrief fields: id, name, description, watch_keywords, "
        "universe_targets, watch_edge_types, confidence, source, supporting_texts. "
        "The to_yaml_block() method serialises a candidate into YAML ready for "
        "copy-paste into focus_briefs.yaml."
    )

    # ── Section 2: Knowledge Graph ────────────────────────────────────────
    doc.section("Knowledge Graph: Construction and Updating")

    doc.para(
        "Pillar II (Graph) maintains a directed, typed, probabilistic causal graph using "
        "NetworkX DiGraph in Phase 1. All writes are gated by OntologyValidator; the "
        "Bayesian update engine computes edge weights; and DecayClock implements temporal "
        "decay with class-specific half-lives. A conflict resolution protocol routes "
        "contested evidence to either penalised ACTIVE edges or options strategies. "
        "RegimeClassifier determines the macro regime and activates overlays deterministically."
    )

    # 2.1
    doc.subsection("Ontology: Node and Edge Vocabulary")
    doc.para(
        "The ontology (config/ontology_v1.yaml, enforced by governance/ontology.py) defines "
        "the strict typed vocabulary. OntologyViolationError is raised immediately on any "
        "invalid write -- before any NetworkX mutation occurs (AR48c)."
    )
    doc.param_table(
        ["Node Type", "Description", "Source", "Target"],
        [
            ["GEOPOLITICAL_EVENT",  "Discrete state/non-state actor events with physical or policy consequences", "Yes", "Yes"],
            ["MACRO_INDICATOR",     "Periodically published economic measurements (CPI, PMI, NFP, GDP)",          "Yes", "Yes"],
            ["PHYSICAL_OBSERVABLE", "Directly measurable quantities independent of market pricing (AIS, inventory, throughput)", "Yes", "Yes"],
            ["TRADEABLE_ASSET",     "Financial instruments (equities, futures, bonds, options). Only target; never source", "No",  "Yes"],
        ],
        col_widths=[120, 215, 48, 48],
    )
    doc.skip(4)
    doc.param_table(
        ["Edge Type", "Mechanism", "Direction", "Decay Class", "Half-life"],
        [
            ["CONSTRAINS_SUPPLY_OF",    "Reduces quantity available to market",   "Neg to price",    "SUPPLY_FLOW",          "14 d"],
            ["INCREASES_COST_OF",       "Raises input costs, compressing margins", "Neg to margins",  "COST",                 "45 d"],
            ["INFRASTRUCTURE_DAMAGE_TO","Physical capacity damage (years to repair)","Neg to capacity","INFRASTRUCTURE_DAMAGE","1825 d"],
            ["POLICY_RISK_TO",          "Probability of regime-altering policy change","Regime-cond.", "POLICY",               "180 d"],
            ["ACCELERATES_DEMAND_FOR",  "Increases end-user demand via necessity/substitution","Pos to price","SUPPLY_FLOW",   "14 d"],
            ["LIQUIDITY_STRESS_ON",     "Raises credit spreads, reduces market liquidity","Neg to price","LIQUIDITY_STRESS",   "7 d"],
            ["SUBSTITUTION_TO",         "Shifts demand from one asset to target",  "Pos to price",    "SUPPLY_FLOW",          "14 d"],
        ],
        col_widths=[130, 140, 72, 72, 37],
    )

    # 2.2
    doc.subsection("Causal Claim Extraction (Agent A)")
    doc.para(
        "Agent A (pillar1_perception/agent_a_newsflow.py) calls Claude Sonnet 4.6 with a "
        "structured system prompt that restricts the model to the ontology vocabulary. "
        "The model maps language to the controlled vocabulary but does NOT produce edge "
        "weights (DP14): all probabilistic quantities are computed by the Bayesian engine "
        "from the model's p_raw estimate."
    )
    doc.para("The extraction system prompt (EXTRACTION_SYSTEM_PROMPT constant) is:")
    doc.code([
        "You are a causal extraction agent for a systematic investment system.",
        "Your task: read a news article and extract structured causal claims.",
        "",
        "CRITICAL CONSTRAINTS:",
        "1. You may ONLY use node types: {node_types}",
        "2. You may ONLY use edge types: {edge_types}",
        "3. If a causal claim does not map to any permitted edge type,",
        "   output edge_type: 'UNCLASSIFIABLE' -- do not force a fit.",
        "4. You are mapping language to a controlled vocabulary.",
        "   Do NOT make investment decisions. Do NOT invent mechanisms.",
        "",
        "For each causal claim, output a JSON object with fields:",
        "  source_node_type, source_node_id,",
        "  target_node_type, target_node_id,",
        "  edge_type          (or UNCLASSIFIABLE),",
        "  p_raw              P(relationship real & active), 0-1.",
        "                     Confirmed announcement: 0.75-0.85.",
        "                     Unverified report: 0.40-0.55.",
        "                     Speculation: 0.20-0.40.",
        "  magnitude_estimate signed fraction of normal impact on target.",
        "  magnitude_ci_width 95% confidence interval width.",
        "  narrative_sensitive true if moveable by statements/sentiment.",
        "  source_url         URL of the source, null if unavailable.",
        "  raw_text_excerpt   exact supporting sentence(s).",
        "",
        "Output a JSON array. If no causal claims exist, output [].",
        "Do not output any other text.",
    ], caption="EXTRACTION_SYSTEM_PROMPT (agent_a_newsflow.py)", lang="text")

    # 2.3
    doc.subsection("Bayesian Updating and Edge Weight")
    doc.para(
        "The Bayesian update engine (pillar2_graph/bayesian_update.py) applies a "
        "sequential Bayes formula. Each new extraction uses the previous p_posterior "
        "as the new p_prior -- evidence accumulates genuinely over time."
    )
    doc.code([
        "# Sequential Bayesian update (bayesian_update.py:56-59)",
        "P_post = (LR * P_prior) / (LR * P_prior + (1 - P_prior))",
        "",
        "# Magnitude adjustment (AR18a)",
        "M_adj = M_base * (1 - CI_width / 2)",
        "",
        "# Edge weight property on EdgeState (AR57)",
        "wt = P_post * M_adj * decay_factor * (1 - rho_corr)",
        "",
        "# rho_corr = max pairwise correlation from SOURCE_CORRELATION_MATRIX",
        "# e.g. two primary_wire_service sources: rho_corr = 0.75",
        "# primary_wire_service + ais_vessel_tracking: rho_corr = 0.15",
    ], caption="Bayesian formulas (bayesian_update.py)", lang="python")
    doc.para(
        "The EdgeState dataclass carries the full probabilistic state of a graph edge:"
    )
    doc.param_table(
        ["Field", "Type", "Description"],
        [
            ["edge_id",              "str",         "UUID assigned on creation"],
            ["source_node_id",       "str",         "Canonical source node identifier"],
            ["target_node_id",       "str",         "Canonical target node identifier"],
            ["edge_type",            "str",         "Ontology-validated edge type"],
            ["ontology_version",     "str",         "Ontology version at creation"],
            ["p_prior",              "float",       "Prior probability before latest update"],
            ["p_posterior",          "float",       "Posterior after Bayesian update"],
            ["likelihood_ratio",     "float",       "Bayes factor from latest evidence"],
            ["magnitude_base",       "float",       "Raw signed magnitude from extraction"],
            ["magnitude_ci_width",   "float",       "95% confidence interval width"],
            ["magnitude_adjusted",   "float",       "M_base * (1 - CI_width/2)"],
            ["decay_clock",          "DecayClock",  "Temporal decay state (class-specific)"],
            ["rho_corr",             "float",       "Source correlation penalty in [0,1]"],
            ["narrative_sensitive",  "bool",        "True if moveable by statements/sentiment"],
            ["status",               "str",         "ACTIVE | CONTESTED | RETIRED"],
            ["contested_type",       "str|None",    "Type A (close evidence) or Type B (options)"],
            ["evidence_source_urls", "list",        "URLs of all confirming sources"],
            ["extraction_event_ids", "list",        "Event bus IDs of all contributing extractions"],
            ["wt  (property)",       "float",       "P_post * M_adj * decay_factor * (1-rho_corr)"],
        ],
        col_widths=[120, 80, 251],
    )

    # 2.4
    doc.subsection("Temporal Decay (DecayClock)")
    doc.para(
        "DecayClock (pillar2_graph/decay.py) implements exponential decay independently "
        "for each edge based on its decay class. The clock measures time from "
        "last_confirmed_at, which is reset when a class-specific confirmation event arrives."
    )
    doc.code([
        "# Decay factor formula (decay.py:66-74)",
        "lambda_ = ln(2) / half_life_days",
        "decay_factor = exp(-lambda_ * t_days)",
        "",
        "# t_days = days since last_confirmed_at",
        "# For a SUPPLY_FLOW edge (14d half-life):",
        "#   Day 0 (fresh):  decay = 1.000",
        "#   Day 7:          decay = 0.707",
        "#   Day 14:         decay = 0.500",
        "#   Day 28:         decay = 0.250",
    ], caption="Decay factor formula (decay.py)", lang="python")
    doc.param_table(
        ["Decay Class", "Half-life", "Reset Triggers", "Freeze Triggers"],
        [
            ["LIQUIDITY_STRESS",     "7 days",    "new_confirming_wire, physical_observable_confirmation", "feed_failure"],
            ["SUPPLY_FLOW",          "14 days",   "ais_confirmation, physical_flow_data, exchange_data",   "feed_failure"],
            ["COST",                 "45 days",   "macro_release_confirmation, earnings_confirmation",     "feed_failure"],
            ["POLICY",               "180 days",  "central_bank_decision, government_announcement",        "feed_failure"],
            ["INFRASTRUCTURE_DAMAGE","1825 days", "engineering_verification_confirmed",                    "feed_failure, ceasefire_announced, diplomatic_agreement"],
        ],
        col_widths=[100, 60, 175, 116],
    )
    doc.para(
        "Three clock operations are available on DecayClock: reset(trigger) sets "
        "last_confirmed_at = now, frozen = False; freeze(trigger) preserves the current "
        "t value and halts further decay; process_trigger(trigger_name) routes the trigger "
        "to the correct operation based on the decay class configuration. For "
        "INFRASTRUCTURE_DAMAGE, freeze triggers take priority over reset triggers -- a "
        "ceasefire freezes the clock, it does not reset it."
    )
    doc.warning(
        "An INFRASTRUCTURE_DAMAGE edge ceases to decay on ceasefire_announced -- it is "
        "frozen, not reset. Physical capacity remains degraded even if hostilities pause. "
        "Only engineering_verification_confirmed can reset the clock. This is a critical "
        "distinction: narrative signals (diplomatic announcements, Trump statements) must "
        "never trigger a clock reset on physical edges."
    )

    # 2.5
    doc.subsection("Conflict Resolution")
    doc.para(
        "When two extractions target the same asset via the same causal mechanism, the "
        "conflict resolution module (pillar2_graph/conflict_resolution.py) runs a "
        "three-stage protocol to determine which edge remains ACTIVE."
    )
    doc.numbered_list([
        "Stage 1 -- Same-mechanism check: if the two edges differ in edge_type or "
        "target_node_id, the protocol returns NO_CONFLICT immediately. No action taken.",
        "Stage 2 -- Adversarial evidence scoring: score = f(p_posterior, verifiability_score, "
        "decay_factor). Higher score = stronger, more recent, more verifiable evidence.",
        "Stage 3 -- Outcome determination: if |score_A - score_B| < 0.15 the evidence is "
        "too close to call and both edges are flagged CONTESTED_TYPE_A (both retained, both "
        "penalised in alpha). If a polymarket resolution exists AND bimodal_spread > 30 AND "
        "both P_post > 0.25, the conflict routes to options strategy as CONTESTED_TYPE_B "
        "(not the directional portfolio). Otherwise the higher-scoring edge becomes ACTIVE "
        "and the lower is RETIRED.",
    ])

    # 2.6
    doc.subsection("Regime Classification")
    doc.para(
        "RegimeClassifier (pillar2_graph/regime_classifier.py) is independent of the "
        "causal graph (AR58). It classifies the macro regime from three dimensions: growth, "
        "inflation, and risk_appetite. Overlays activate deterministically on regime entry "
        "(AR58b). Reclassification requires 2 of 3 dimensions to shift AND at least 2 "
        "independent confirming sources (AR58c)."
    )
    doc.param_table(
        ["Regime", "Growth", "Inflation", "Risk Appetite", "POLICY_RISK_TO Mult.", "Overlays"],
        [
            ["GROWTH_EXPANSION", "POSITIVE", "BELOW_TARGET", "ON",  "+1.0", "None"],
            ["STAGFLATION_RISK", "NEGATIVE", "ABOVE_TARGET", "OFF", "-1.0", "equity_index_short 5% delta, equity_vol_long 2% vega"],
            ["INFLATION_ONLY",   "POSITIVE", "ABOVE_TARGET", "ON",  "-0.5", "duration_short 3% DV01"],
            ["RISK_OFF",         "NEGATIVE", "BELOW_TARGET", "OFF", "-1.0", "equity_index_short 3% delta"],
        ],
        col_widths=[90, 65, 75, 72, 60, 89],
    )
    doc.para(
        "The RegimeClassification dataclass carries: regime (str), confidence (float), "
        "dimensions (RegimeDimensions), classified_at (ISO8601), confirming_sources (list), "
        "and overlays (list of overlay dicts). The get_edge_sign_multiplier(regime, edge_type) "
        "method returns the sign multiplier for POLICY_RISK_TO edges based on current regime."
    )
    doc.note(
        "Single signals -- a ceasefire announcement, a single CPI print, a prediction market "
        "move -- are insufficient to trigger reclassification. The system requires 2 of 3 "
        "macro dimensions to shift, confirmed by at least 2 independent data sources. This "
        "prevents regime flip-flopping on noise."
    )

    # ── Section 3: Trade Selection & Portfolio Construction ───────────────
    doc.section("Trade Selection and Portfolio Construction")

    doc.para(
        "Pillar III (Execution) translates the causal graph state into portfolio weights. "
        "AlphaVectorBuilder aggregates edge weights into per-asset alpha signals; "
        "PortfolioOptimizer solves a constrained mean-variance problem via SLSQP; "
        "and regime overlays are applied additively outside the optimiser. Every solve "
        "is logged to the immutable event bus via SolveLogger."
    )

    # 3.1
    doc.subsection("Asset Universe")
    doc.para(
        "The Phase 1 universe (pillar3_execution/universe.py) contains 10 instruments "
        "covering the Iran case study. The Instrument dataclass fields are: asset_id, "
        "ticker, name, sector, asset_class, long_eligible, short_eligible, "
        "options_eligible, currency, exchange."
    )
    doc.param_table(
        ["asset_id", "Name", "Class", "Sector", "L", "S", "Opt", "Notes"],
        [
            ["VLO",               "Valero Energy Corp",         "equity",       "energy",       "Y","Y","Y",""],
            ["DAL",               "Delta Air Lines",            "equity",       "industrials",  "Y","Y","Y",""],
            ["ICE_GASOIL",        "ICE Gasoil Futures (QS1)",   "commodity",    "energy",       "Y","Y","Y",""],
            ["EU_UTILITIES",      "STOXX Europe 600 Utilities", "equity",       "utilities",    "Y","Y","N",""],
            ["BRENT_CRUDE",       "Brent Crude Futures (CO1)",  "commodity",    "energy",       "Y","Y","Y",""],
            ["XLE",               "Energy Select Sector SPDR",  "equity",       "energy",       "Y","Y","Y",""],
            ["SPX",               "S&P 500 Index",              "equity",       "broad_market", "Y","Y","Y",""],
            ["equity_index_short","ProShares Short S&P500 (SH)","equity",       "broad_market", "Y","N","N","Overlay only"],
            ["equity_vol_long",   "iPath S&P 500 VIX (VXX)",   "volatility",   "broad_market", "Y","N","N","Overlay only"],
            ["duration_short",    "ProShares Short 20Y Tsy (TBF)","fixed_income","fixed_income","Y","N","N","Overlay only"],
        ],
        col_widths=[88, 130, 58, 68, 14, 14, 22, 57],
    )
    doc.caption("Table 3.1 -- Phase 1 instrument universe. L=Long, S=Short, Opt=Options eligible.")

    # 3.2
    doc.subsection("Alpha Vector Construction")
    doc.para(
        "AlphaVectorBuilder.build(edges, current_regime, universe) iterates over all "
        "ACTIVE edges and aggregates adjusted weights into per-asset AssetAlpha objects. "
        "CONTESTED and RETIRED edges are excluded."
    )
    doc.code([
        "# For each ACTIVE edge targeting a universe asset:",
        "regime_multiplier = classifier.get_edge_sign_multiplier(regime, edge_type)",
        "adjusted_wt = edge.wt * regime_multiplier",
        "",
        "# Accumulate into AssetAlpha:",
        "alpha_sum = sum(c.adjusted_wt for c in contributions)",
        "is_narrative = any edge's narrative_sensitive is True",
    ], caption="AlphaVectorBuilder.build() (alpha_vector.py)", lang="python")
    doc.para(
        "AlphaContribution fields: edge_id, edge_type, wt, regime_multiplier, "
        "adjusted_wt, source_urls. Every alpha contribution is traceable to a specific "
        "graph edge and its source evidence URLs (BR01/BR19)."
    )
    doc.para(
        "AssetAlpha fields: asset_id, alpha (float), contributions (list of "
        "AlphaContribution), narrative_sensitive (True if ANY contributing edge is "
        "narrative-sensitive), computed_at (ISO8601)."
    )

    # 3.3
    doc.subsection("Portfolio Optimisation (SLSQP)")
    doc.para(
        "PortfolioOptimizer (pillar3_execution/optimizer.py) solves a "
        "mean-variance-with-transaction-costs problem using scipy.optimize.minimize "
        "with method='SLSQP'. All constraint parameters are read from "
        "config/mandate_global_alloc.yaml."
    )
    doc.code([
        "# Objective (minimise negative of):                    (optimizer.py:92-97)",
        "port_return   = w @ alpha",
        "port_variance = w @ cov_matrix @ w",
        "port_tc       = transaction_cost_coeff * sum(|w - w_prior|)",
        "",
        "maximise:  w'*mu  -  (lambda/2)*w'*Sigma*w  -  c*||dw||_1",
        "",
        "where:",
        "  mu       = alpha vector  (from AlphaVectorBuilder)",
        "  Sigma    = covariance matrix  (60-day rolling window)",
        "  lambda   = risk_aversion  = 2.0",
        "  c        = transaction_cost_coeff  = 0.001  (10 bps/unit)",
        "  dw       = w - w_prior  (zero at inception)",
    ], caption="Portfolio objective function (mandate_global_alloc.yaml keys)", lang="python")
    doc.param_table(
        ["Constraint", "YAML Key", "Value", "Description"],
        [
            ["Net exposure (min)", "net_exposure_min",           "-0.20", "Sum(w) >= -20%"],
            ["Net exposure (max)", "net_exposure_max",           "+1.20", "Sum(w) <= +120%"],
            ["Gross exposure",     "gross_exposure_max",         "2.0",   "Sum(|w|) <= 200%"],
            ["Long per name",      "single_name_long_max",       "0.15",  "w_i <= +15%"],
            ["Short per name",     "single_name_short_max",      "-0.10", "w_i >= -10%"],
            ["Sector max",         "sector_concentration_max",   "0.35",  "Sum sector |w| <= 35%"],
            ["Cardinality",        "max_positions",              "20",    "Non-zero positions <= 20"],
            ["Turnover budget",    "turnover_budget_annual",     "3.0",   "Annual turnover <= 300%"],
            ["Risk aversion",      "risk_aversion",              "2.0",   "Lambda in objective"],
            ["Transaction cost",   "transaction_cost_coeff",     "0.001", "10 bps per unit turnover"],
            ["Cov. lookback",      "covariance_lookback_days",   "60",    "Rolling window for Sigma"],
        ],
        col_widths=[100, 140, 50, 161],
    )
    doc.para(
        "Phase 1 uses a two-stage cardinality approximation (the production Gurobi "
        "implementation solves the true MIQP exactly): Stage 1 -- solve the full problem "
        "without a hard cardinality constraint. Stage 2 -- identify the top K=20 positions "
        "by |weight|, force all others to zero via bounds, and re-solve."
    )
    doc.para(
        "Solver output dict fields: weights (Dict[str, float]), objective_value, "
        "solve_status ('optimal' | 'infeasible' | 'timeout'), binding_constraints (list), "
        "solve_time_ms, cardinality_approximated (always True in Phase 1), notes (str)."
    )

    # 3.4
    doc.subsection("Regime Overlays")
    doc.para(
        "Regime overlays are activated deterministically on regime entry (AR58b). They are "
        "applied additively to the SLSQP-optimised weights and bypass the objective "
        "function entirely. This is intentional: convexity payoff from tail-risk instruments "
        "is not captured by a mean-variance objective."
    )
    doc.param_table(
        ["Regime", "Instrument", "Sizing", "Entry Trigger", "Exit Trigger"],
        [
            ["STAGFLATION_RISK", "equity_index_short", "+5% delta of NAV",  "Regime entry", "Regime reclassification"],
            ["STAGFLATION_RISK", "equity_vol_long",    "+2% vega of NAV",   "Regime entry", "Regime reclassification"],
            ["INFLATION_ONLY",   "duration_short",     "+3% DV01 of NAV",   "Regime entry", "Regime reclassification"],
            ["RISK_OFF",         "equity_index_short", "+3% delta of NAV",  "Regime entry", "Regime reclassification"],
        ],
        col_widths=[100, 100, 80, 80, 91],
    )
    doc.tip(
        "Overlays exist precisely because the optimiser would under-weight tail-risk "
        "instruments. The mean-variance objective rewards expected return per unit of "
        "variance, but options and inverse ETFs have negative expected return in normal "
        "regimes. The overlay mechanism separates the systematic hedge mandate from the "
        "alpha extraction mandate."
    )

    # 3.5
    doc.subsection("Solve Logger and Audit Trail")
    doc.para(
        "SolveLogger (pillar3_execution/solve_logger.py) publishes two events to the "
        "event bus for every optimizer run: OPTIMIZER_SOLVE_STARTED (before the SLSQP "
        "call) and either OPTIMIZER_SOLVE_COMPLETED or OPTIMIZER_SOLVE_FAILED. On "
        "success, PORTFOLIO_WEIGHTS_PUBLISHED is emitted as a separate event."
    )
    doc.para(
        "OPTIMIZER_SOLVE_COMPLETED payload fields: alpha_version (hash of the alpha vector "
        "used), mandate_version, regime, n_assets, n_constraints, objective_value, "
        "solve_status, binding_constraints, solve_time_ms, cardinality_approximated. "
        "All events are immutable in the SQLite WAL -- a full audit history of every "
        "portfolio solve is permanently reconstructable."
    )

    # 3.6
    doc.subsection("End-to-End Walk-Through: Iran Case (Day 0-40)")
    doc.para(
        "The following timeline illustrates the full pipeline from news ingestion to "
        "portfolio weights, using the Iran energy supply shock as the worked example."
    )
    doc.numbered_list([
        "Day 0 -- Strike headline ingested. Agent A extracts 3 edges: "
        "Hormuz_Closure CONSTRAINS_SUPPLY_OF ICE_GASOIL (p_raw=0.65), "
        "Hormuz_Closure ACCELERATES_DEMAND_FOR VLO (p_raw=0.60), "
        "Hormuz_Closure INCREASES_COST_OF DAL (p_raw=0.60). "
        "LR=4.5 (primary_wire_service). P_post approx 0.68 on all three edges.",

        "Day 2 -- AIS zero tanker transit confirmed (physical_observable). "
        "LR update from 4.5 to 8.0 on the supply edge. "
        "P_post on ICE_GASOIL edge: 0.68 -> 0.944. "
        "Decay clock reset to last_confirmed_at=now (t=0). "
        "rho_corr drops: primary_wire + ais_vessel_tracking = 0.15.",

        "Day 7 -- Ras Tanura strike. New INFRASTRUCTURE_DAMAGE_TO edge on ICE_GASOIL. "
        "magnitude_base=-0.40, CI_width=0.25, M_adj=-0.35. LR=5.0. "
        "Half-life 1825 days. Clock will freeze on ceasefire, not reset.",

        "Day 9 -- Macro readings shift (growth NEGATIVE, inflation ABOVE_TARGET, "
        "risk OFF) confirmed by 2+ independent sources. "
        "RegimeClassifier reclassifies to STAGFLATION_RISK. "
        "Overlays activate: equity_index_short +5% delta, equity_vol_long +2% vega. "
        "POLICY_RISK_TO multiplier = -1.0.",

        "Day 23 -- Trump Truth Social post. narrative_sensitive=True, low novelty. "
        "Layer 3a: text passes IRAN_WAR_SUPPLY_SHOCK keyword filter. "
        "Layer 3b: extracted claim has narrative_sensitive=True. "
        "Physical edges (CONSTRAINS_SUPPLY_OF, INFRASTRUCTURE_DAMAGE_TO) are NOT "
        "updated -- narrative signals are immune to physical edge clocks (DP07).",

        "Day 29 -- SLSQP solve. Alpha: ICE_GASOIL +0.011, VLO +0.009, DAL -0.012, "
        "EU_UTILITIES +0.008. Portfolio weights: VLO +9%, DAL -12%, "
        "ICE_GASOIL +6%, EU_UTILITIES +14%, equity_index_short +5% (overlay).",

        "Day 40 -- Ceasefire announced. process_trigger('ceasefire_announced') called "
        "on INFRASTRUCTURE_DAMAGE_TO edge. Result: clock FROZEN at current t (not reset). "
        "Physical damage persists. SUPPLY_FLOW edges continue to decay normally.",
    ])
    doc.note(
        "Physical damage edges survive ceasefire. The refinery remains offline until "
        "engineering_verification_confirmed is received. A frozen clock means the edge "
        "weight stops decaying -- it is preserved at its current level until physical "
        "reality is independently confirmed as changed."
    )

    # ── Section 4: Visualisation & System Interfaces ──────────────────────
    doc.section("Visualisation and System Interfaces")

    doc.para(
        "The system exposes its state through three interfaces: a REST API (FastAPI), "
        "a browser-based administration dashboard (self-contained SPA), and PDF investment "
        "dashboards generated via ReportLab. All outputs are fully traceable: every "
        "InvestmentView links back to its source graph edges and evidence URLs."
    )

    # 4.1
    doc.subsection("Investment View Dashboard")
    doc.para(
        "governance/view_dashboard.py constructs InvestmentView objects from the live "
        "graph state. Each view represents a directional stance on one asset, with full "
        "provenance from source edges to evidence URLs."
    )
    doc.param_table(
        ["InvestmentView Field", "Type", "Description"],
        [
            ["view_id",            "str",         "Unique identifier for this view"],
            ["asset",              "str",         "asset_id (e.g. VLO, ICE_GASOIL)"],
            ["direction",          "str",         "LONG or SHORT"],
            ["conviction",         "str",         "HIGH | MEDIUM | LOW (alpha/P_post thresholds)"],
            ["alpha_contribution", "float",       "Sum of adjusted edge weights for this asset"],
            ["position_weight_pct","float",       "Optimizer-assigned portfolio weight (%)"],
            ["narrative_sensitive","bool",        "True if any contributing edge is narrative-sensitive"],
            ["supporting_edges",   "List[EdgeSummary]", "List of contributing edges with source URLs"],
            ["causal_chain_text",  "str",         "Human-readable causal explanation"],
        ],
        col_widths=[120, 90, 241],
    )
    doc.para(
        "Conviction mapping: HIGH if alpha > 0.015 AND max P_post > 0.80; "
        "MEDIUM if alpha > 0.007 AND max P_post > 0.55; else LOW. "
        "Example causal chain text from the Iran case: "
        "'Hormuz_Closure CONSTRAINS_SUPPLY_OF ICE_GASOIL -> refined product tight -> "
        "VLO cracking margin expansion -> LONG VLO'."
    )

    # 4.2
    doc.subsection("REST API Endpoints")
    doc.para(
        "api/main.py exposes the core read endpoints. api/admin_router.py (prefix "
        "/admin/api) exposes the management endpoints. All routes are served by FastAPI "
        "on http://localhost:8000 in Phase 1."
    )
    doc.param_table(
        ["Method", "Path", "Description", "Key Response Fields"],
        [
            ["GET",  "/views",                      "Full investment dashboard",          "active_views, contested_views, regime_overlays, weights"],
            ["GET",  "/graph/state",                "Graph as node-link JSON",            "nodes[], edges[] (id, type, wt, status)"],
            ["GET",  "/graph/reconstruct",          "Point-in-time reconstruction",       "event_count, edge_event_count, event_types[]"],
            ["GET",  "/admin",                      "Admin dashboard HTML (SPA)",         "Self-contained HTML; no external CDN"],
            ["GET",  "/admin/api/briefs",           "List active + inactive briefs",      "active_briefs[], inactive_briefs[]"],
            ["POST", "/admin/api/briefs",           "Create new brief",                   "brief_id, name, active"],
            ["POST", "/admin/api/briefs/{id}/activate",  "Activate a brief",             "id, active=true"],
            ["POST", "/admin/api/briefs/{id}/deactivate","Deactivate a brief",           "id, active=false"],
            ["DELETE","/admin/api/briefs/{id}",    "Archive a brief",                    "id, archived=true"],
            ["POST", "/admin/api/briefs/test",      "Test brief matching on text",        "matched_brief, result (PASS|DROP), keywords"],
            ["GET",  "/admin/api/governance",       "Full governance config",             "decay_classes, ontology, regime_overlays"],
            ["PATCH","/admin/api/governance/mandate","Edit one constraint/risk param",   "section, key, value, updated_at"],
            ["GET",  "/admin/api/activity",         "Recent 30 bus events",              "events[] with type, timestamp, summary"],
            ["POST", "/admin/api/scanner/ingest",   "Ingest text via Agent A",            "matched_briefs, claims_extracted, dropped"],
            ["POST", "/admin/api/scanner/velocity", "Run Tier 1 velocity scan",           "velocity_hits[], candidates[]"],
            ["POST", "/admin/api/scanner/semantic", "Run Tier 2 semantic scan (1 call)",  "candidates[]"],
        ],
        col_widths=[40, 160, 120, 131],
    )

    # 4.3
    doc.subsection("Administration Dashboard (Browser SPA)")
    doc.para(
        "The admin dashboard (api/admin.html, served at GET /admin) is a self-contained "
        "single-page application with no external CDN dependencies. It is split across "
        "three genuinely distinct tabs, each communicating with the /admin/api endpoints."
    )
    doc.bullet_list([
        "Briefs tab: brief cards with expand/collapse, Activate/Deactivate/Delete buttons, "
        "Add New Brief form (always-visible right panel), headline tester with keyword "
        "highlights, and quick ingest with match statistics.",
        "Discovery tab: scanner status card showing buffer fill level, ingest textarea, "
        "Velocity Scan (free) and Semantic Scan (1 API call) buttons, velocity hits list "
        "with ratio bars, candidate brief cards with one-click Activate, and a price "
        "orphan detector (paste CSV of asset|move pairs).",
        "Settings tab: all mandate constraints inline-editable with individual SAVE buttons "
        "(calls PATCH /admin/api/governance/mandate), risk parameters, graph budget "
        "(read-only), decay classes visualised as a bar chart, regime overlay cards "
        "color-coded by regime, active edges table with wt bars and decay-class colors, "
        "and a live activity feed with event-type pills that auto-refreshes every 15 seconds.",
    ])

    # 4.4
    doc.subsection("PDF Investment Dashboards")
    doc.para(
        "scripts/generate_pdfs.py produces dark-themed investment dashboards using "
        "ReportLab. A3 landscape format is used for dashboards; A4 portrait for "
        "technical manuals (including this document)."
    )
    doc.param_table(
        ["Attribute", "Dashboard PDFs", "Technical Manuals"],
        [
            ["Page size",   "A3 landscape (1191 x 842 pt)", "A4 portrait (595 x 842 pt)"],
            ["Background",  "#0a0a0a (near-black)",          "White"],
            ["Body font",   "Helvetica / custom sans",        "Times-Roman 10.5pt"],
            ["Accent color","Gold #f0a500",                   "Blue #1a3a6b"],
            ["Long signal", "Green #00c060",                  "N/A"],
            ["Short signal","Red #e03030",                    "N/A"],
            ["Key outputs", "day29_dashboard.pdf, day40_dashboard.pdf", "dckg_admin_manual_tech.pdf, dckg_technical_briefing.pdf"],
        ],
        col_widths=[80, 200, 171],
    )

    # 4.5
    doc.subsection("Storage and Production Roadmap")
    doc.para(
        "The Phase 1 implementation uses in-process storage with SQLite and NetworkX. "
        "All components are designed for drop-in replacement; the event bus interface "
        "contract (publish/subscribe/reconstruct_at) is backend-agnostic."
    )
    doc.param_table(
        ["Component", "Phase 1 (current)", "Production Replacement", "Notes"],
        [
            ["Event log",    "SQLite WAL (append-only)",     "Apache Kafka + Apache Iceberg", "Immutability triggers enforced at DB level"],
            ["Graph store",  "NetworkX DiGraph (in-process)","Neo4j",                         "Full ontology validation on all writes"],
            ["Config",       "YAML files (git-versioned)",   "Git-versioned config store",    "Ontology never hot-reloaded; briefs are"],
            ["Market data",  "JSON fixture loader",          "Bloomberg B-PIPE / Refinitiv",  "Agent B stub; same event schema"],
            ["Macro data",   "Hardcoded STAGFLATION_RISK",   "Macro data API (BLS/ECB/Bbg)",  "Agent C stub; overrideable via constructor"],
            ["Solver",       "SLSQP (scipy.optimize)",       "Gurobi MIQP",                   "Phase 1 approximates cardinality (2-stage)"],
            ["Dashboard",    "ReportLab PDF / FastAPI HTML", "Internal BI platform",          "GET /views returns JSON for any frontend"],
        ],
        col_widths=[80, 120, 120, 131],
    )
    doc.note(
        "All Phase 1 components satisfy the full functional requirements and pass 85/85 "
        "unit tests. The production replacements (Neo4j, Kafka, Gurobi) replace internals "
        "without changing the inter-pillar event contracts. The ontology YAML is the "
        "only component that is never hot-reloaded; all other config supports live updates."
    )


# ══════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════

def build_technical_briefing_pdf(path: str):
    today = date.today().strftime("%d %B %Y")
    cv = canvas.Canvas(path, pagesize=A4)
    doc = TechBriefDoc(cv)

    doc.cover(
        title="DCKG System\nTechnical Architecture Briefing",
        subtitle=(
            "Data Sourcing, Processing, Knowledge Graph Construction, "
            "Portfolio Construction and Visualisation"
        ),
        version="1.0",
        doc_date=today,
    )

    # TOC page (entries registered during build below)
    # We build content first, then the TOC is inserted programmatically
    # after section() calls register entries in doc._toc.
    # ReportLab doesn't support back-insertion, so we use a two-pass approach:
    # pass 1 = build to a temp buffer and capture TOC entries,
    # pass 2 = final render. For simplicity we render inline and skip a
    # live-linked TOC (page numbers would require two passes).
    # Instead, emit a clean section list as the TOC substitute.
    doc._start_page()
    doc._draw_header()
    c = doc.c
    c.setFillColor(C_BLUE)
    c.setFont(F_BOLD, 16)
    c.drawString(LM, doc.cy, "Contents")
    doc.cy -= 8
    c.setStrokeColor(C_BLUE)
    c.setLineWidth(1.2)
    c.line(LM, doc.cy, PW - RM, doc.cy)
    doc.cy -= 20

    toc_entries = [
        ("1",   "Data Sourcing and Ingestion"),
        ("1.1", "Input Channels"),
        ("1.2", "Focus-Brief Filtering (Two-Stage Gate)"),
        ("1.3", "Event Bus and Immutable Log"),
        ("1.4", "Data Quality, Novelty and Verifiability Scoring"),
        ("1.5", "Emerging Theme Discovery (ThemeScanner)"),
        ("2",   "Knowledge Graph: Construction and Updating"),
        ("2.1", "Ontology: Node and Edge Vocabulary"),
        ("2.2", "Causal Claim Extraction (Agent A)"),
        ("2.3", "Bayesian Updating and Edge Weight"),
        ("2.4", "Temporal Decay (DecayClock)"),
        ("2.5", "Conflict Resolution"),
        ("2.6", "Regime Classification"),
        ("3",   "Trade Selection and Portfolio Construction"),
        ("3.1", "Asset Universe"),
        ("3.2", "Alpha Vector Construction"),
        ("3.3", "Portfolio Optimisation (SLSQP)"),
        ("3.4", "Regime Overlays"),
        ("3.5", "Solve Logger and Audit Trail"),
        ("3.6", "End-to-End Walk-Through: Iran Case (Day 0-40)"),
        ("4",   "Visualisation and System Interfaces"),
        ("4.1", "Investment View Dashboard"),
        ("4.2", "REST API Endpoints"),
        ("4.3", "Administration Dashboard (Browser SPA)"),
        ("4.4", "PDF Investment Dashboards"),
        ("4.5", "Storage and Production Roadmap"),
    ]
    for num, title in toc_entries:
        is_section = "." not in num
        indent = 0 if is_section else 20
        font = F_BOLD if is_section else F_BODY
        size = 11 if is_section else 10.5
        lead = 18 if is_section else 16
        doc._need(lead + 2)
        c.setFont(font, size)
        c.setFillColor(C_BLACK)
        label = f"{num}   {title}"
        c.drawString(LM + indent, doc.cy, label)
        doc.cy -= lead

    # Build all content sections
    build(doc)
    doc.finish()

    count = doc.page_num
    print(f"  Saved: {path}  ({count} pages)")


if __name__ == "__main__":
    out = r"C:\Users\H\Downloads\dckg_technical_briefing.pdf"
    print("Generating DCKG Technical Architecture Briefing...")
    build_technical_briefing_pdf(out)
    print("Done.")
