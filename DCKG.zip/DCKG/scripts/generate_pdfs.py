"""
DCKG PDF Dashboard Generator
Produces dark-themed investment dashboard PDFs for Day 29 and Day 40.
All columns fill the full body height. No clipped spine text.
"""
import os
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A3, landscape
from reportlab.lib.colors import HexColor, white, black
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# ── Palette ──────────────────────────────────────────────────────────────────
BG          = HexColor("#0a0a0a")
BG2         = HexColor("#111111")
BG3         = HexColor("#1a1a1a")
BG4         = HexColor("#1f1f1f")
GOLD        = HexColor("#f0a500")
AMBER       = HexColor("#e8890c")
AMBER_DIM   = HexColor("#8a5205")
CYAN        = HexColor("#00c8c8")
CYAN_DIM    = HexColor("#004444")
ORANGE      = HexColor("#e06020")
ORANGE_DIM  = HexColor("#4a1a08")
GREEN       = HexColor("#2ecc71")
GREEN_DIM   = HexColor("#0d3d20")
RED         = HexColor("#e74c3c")
RED_DIM     = HexColor("#3d0d09")
GREY        = HexColor("#555555")
GREY_DIM    = HexColor("#222222")
WHITE       = HexColor("#e8e8e8")
WHITE_DIM   = HexColor("#888888")
WHITE_FAINT = HexColor("#333333")
PURPLE      = HexColor("#9b59b6")
PURPLE_DIM  = HexColor("#2d1040")
HEADER_BG   = HexColor("#0d0d0d")
TICKER_BG   = HexColor("#1a0e00")
ALERT_BG    = HexColor("#1a0e00")
CARD_BG     = HexColor("#141414")
SPINE_BG    = HexColor("#0c0c0c")

PW, PH = landscape(A3)   # ~1191 x 842 pts

# ── Low-level drawing helpers ─────────────────────────────────────────────────

def filled_rect(c, x, y, w, h, fill, stroke=None, sw=0.5, radius=0):
    c.setFillColor(fill)
    if stroke:
        c.setStrokeColor(stroke)
        c.setLineWidth(sw)
    if radius:
        c.roundRect(x, y, w, h, radius, fill=1, stroke=1 if stroke else 0)
    else:
        c.rect(x, y, w, h, fill=1, stroke=1 if stroke else 0)

def bordered_rect(c, x, y, w, h, fill, border_color, bw=1.2, radius=3):
    filled_rect(c, x, y, w, h, fill, border_color, bw, radius)

def txt(c, text, x, y, size=6, color=WHITE, bold=False, font="Helvetica"):
    fn = font + ("-Bold" if bold else "")
    c.setFont(fn, size)
    c.setFillColor(color)
    c.drawString(x, y, text)

def txt_right(c, text, x, y, size=6, color=WHITE, bold=False):
    fn = "Helvetica-Bold" if bold else "Helvetica"
    c.setFont(fn, size)
    c.setFillColor(color)
    c.drawRightString(x, y, text)

def txt_center(c, text, x, y, size=6, color=WHITE, bold=False):
    fn = "Helvetica-Bold" if bold else "Helvetica"
    c.setFont(fn, size)
    c.setFillColor(color)
    c.drawCentredString(x, y, text)

def pill(c, label, x, y, bg, fg=None, w=None, h=8, size=5, bold=True):
    fg = fg or WHITE
    fn = "Helvetica-Bold" if bold else "Helvetica"
    c.setFont(fn, size)
    tw = c.stringWidth(label, fn, size)
    pw2 = (w or tw + 6)
    filled_rect(c, x, y - 1, pw2, h, bg, radius=2)
    c.setFillColor(fg)
    c.drawCentredString(x + pw2/2, y + 2, label)
    return pw2

def score_badge(c, score_str, x, y, color=CYAN):
    """Score badge placed at (x, y) = bottom-left of badge."""
    w, h = 30, 14
    filled_rect(c, x, y, w, h, BG3, color, 1.0, 3)
    c.setFont("Helvetica-Bold", 8)
    c.setFillColor(color)
    c.drawCentredString(x + w/2, y + 4, score_str)

def divider(c, x, y, w, color=WHITE_FAINT, lw=0.4):
    c.setStrokeColor(color)
    c.setLineWidth(lw)
    c.line(x, y, x + w, y)

def arrow_right(c, x, y, color=AMBER):
    c.setStrokeColor(color)
    c.setFillColor(color)
    c.setLineWidth(0.8)
    c.line(x, y, x+5, y)
    p = c.beginPath()
    p.moveTo(x+5, y+2); p.lineTo(x+8, y); p.lineTo(x+5, y-2); p.close()
    c.drawPath(p, fill=1, stroke=0)

# ── Card builder ──────────────────────────────────────────────────────────────

def draw_card(c, x, y, w, h, title, border_color, bg=CARD_BG,
              score=None, score_color=None,
              lines=None, pills=None, radius=3):
    """
    Generic card. (x, y) = bottom-left corner.
    lines: list of (text, color, size, bold)
    pills: list of (label, bg, fg)
    Score badge sits at top-right; title at top-left with room for badge.
    """
    bordered_rect(c, x, y, w, h, bg, border_color, bw=1.2, radius=radius)

    # Title at top-left; reserve 38pt for score badge on the right
    title_max_w = w - 42 if score is not None else w - 8
    c.setFont("Helvetica-Bold", 6)
    c.setFillColor(border_color)
    c.drawString(x + 4, y + h - 9, title)

    # Score badge at top-right, anchored inside card top
    if score is not None:
        sc = score_color or border_color
        # badge bottom = card top - 14 - 1 padding = y + h - 15
        score_badge(c, score, x + w - 34, y + h - 15, sc)

    # Content starts below title
    cy = y + h - 18

    if lines:
        for (ltext, lcolor, lsize, lbold) in lines:
            if cy < y + 3:
                break
            fn = "Helvetica-Bold" if lbold else "Helvetica"
            c.setFont(fn, lsize)
            c.setFillColor(lcolor)
            # Simple word-wrap at card width
            max_w = w - 8
            words = ltext.split()
            line_buf = ""
            for word in words:
                test = (line_buf + " " + word).strip()
                if c.stringWidth(test, fn, lsize) <= max_w:
                    line_buf = test
                else:
                    if cy < y + 3:
                        break
                    c.drawString(x + 4, cy, line_buf)
                    cy -= lsize + 1.5
                    line_buf = word
            if line_buf and cy >= y + 3:
                c.drawString(x + 4, cy, line_buf)
                cy -= lsize + 1.5

    if pills:
        px = x + 4
        for (plabel, pbg, pfg) in pills:
            if px > x + w - 10:
                break
            pw2 = pill(c, plabel, px, cy - 1, pbg, pfg, h=7, size=4.5)
            px += pw2 + 3
        cy -= 10

def L(text, color=WHITE_DIM, size=5.5, bold=False):
    return (text, color, size, bold)

def LB(text, color=WHITE, size=5.5):
    return (text, color, size, True)

def LH(text, color=AMBER, size=5.5):
    return (text, color, size, False)

# ── Header ────────────────────────────────────────────────────────────────────

def draw_header(c, subtitle, graph_state, stats):
    """Top header bar."""
    filled_rect(c, 0, PH - 36, PW, 36, HEADER_BG)
    txt(c, "DYNAMIC CAUSAL KNOWLEDGE GRAPH  \xb7  LIVE UPDATE",
        8, PH - 12, 9, GOLD, True)
    txt(c, subtitle, 8, PH - 24, 7.5, WHITE, False)
    txt(c, graph_state, 8, PH - 33, 5.5, WHITE_DIM)
    # Stats pills (right side)
    sx = PW - 8
    for (label, val, col) in reversed(stats):
        w2 = pill(c, val, 0, PH - 28, col, WHITE, w=None, h=9, size=5.5)
        sx -= w2 + 4
        c.setFont("Helvetica", 5.5)
        c.setFillColor(WHITE_DIM)
        lw = c.stringWidth(label + "  ", "Helvetica", 5.5)
        c.drawString(sx - lw + 4, PH - 25, label)
        sx -= lw + 2
    # Right: timestamp
    txt_right(c, graph_state, PW - 8, PH - 10, 6.5, CYAN)

def draw_ticker(c, items, y, h=14):
    filled_rect(c, 0, y, PW, h, TICKER_BG)
    x = 8
    sep = "   \xb7   "
    for item in items:
        c.setFont("Helvetica-Bold", 5.5)
        c.setFillColor(AMBER)
        c.drawString(x, y + 4, item)
        x += c.stringWidth(item, "Helvetica-Bold", 5.5)
        c.setFillColor(HexColor("#4a3010"))
        c.drawString(x, y + 4, sep)
        x += c.stringWidth(sep, "Helvetica-Bold", 5.5)

def draw_alert(c, text, y, h=20):
    filled_rect(c, 0, y, PW, h, ALERT_BG)
    c.setStrokeColor(AMBER)
    c.setLineWidth(1.0)
    c.line(0, y + h - 1, PW, y + h - 1)
    c.line(0, y, PW, y)
    pill(c, "GRAPH UPDATE \xb7 D40", 6, y + 6, AMBER, BG, h=10, size=5.5)
    txt(c, text, 110, y + 12, 5.2, AMBER)
    txt(c, text[len(text)//2:], 110, y + 5, 5.2, HexColor("#c07020"))

def draw_alert_full(c, text, y, h=22):
    filled_rect(c, 0, y, PW, h, ALERT_BG)
    c.setStrokeColor(AMBER)
    c.setLineWidth(0.8)
    c.line(0, y + h - 0.4, PW, y + h - 0.4)
    pill(c, "GRAPH UPDATE \xb7 D40", 6, y + 7, AMBER, BG, h=9, size=5)
    mid = len(text) // 2
    split = text.rfind(" \xb7 ", mid - 40, mid + 40)
    if split < 0:
        split = mid
    line1 = text[:split].strip()
    line2 = text[split:].strip()
    txt(c, line1, 110, y + 14, 5.0, AMBER)
    txt(c, line2, 110, y + 6,  5.0, HexColor("#b06818"))

# ── Event Spine ───────────────────────────────────────────────────────────────

def draw_event_spine(c, events, y=28, h=26):
    filled_rect(c, 0, y, PW, h, SPINE_BG)
    c.setStrokeColor(HexColor("#222222"))
    c.setLineWidth(0.4)
    c.line(0, y + h - 0.2, PW, y + h - 0.2)
    txt(c, "EVENT SPINE  \xb7  DAY 0 \u2192 DAY 40", 8, y + h - 8, 5, WHITE_DIM, True)

    # Timeline line — add left offset so first node label is not clipped
    left_offset = 30   # push first node away from left edge
    margin = 8
    tw = PW - 2 * margin - left_offset
    n = len(events)
    step = tw / (n - 1) if n > 1 else tw
    ly = y + 11

    c.setStrokeColor(HexColor("#333333"))
    c.setLineWidth(0.6)
    # Draw line from first node to last node position
    first_ex = margin + left_offset
    last_ex  = first_ex + (n - 1) * step
    c.line(first_ex, ly, last_ex, ly)

    for i, (day, label, sublabel, col, is_new) in enumerate(events):
        ex = margin + left_offset + i * step
        # Node dot
        c.setFillColor(col)
        c.circle(ex, ly, 3, fill=1, stroke=0)
        if is_new:
            c.setStrokeColor(GOLD)
            c.setLineWidth(1.0)
            c.circle(ex, ly, 4.5, fill=0, stroke=1)
        # Day label above
        c.setFont("Helvetica-Bold", 5)
        c.setFillColor(col)
        c.drawCentredString(ex, ly + 6, day)
        # Label below
        c.setFont("Helvetica", 4.5)
        c.setFillColor(WHITE_DIM)
        c.drawCentredString(ex, ly - 7, label)
        if sublabel:
            c.setFont("Helvetica", 4.0)
            c.setFillColor(GREY)
            c.drawCentredString(ex, ly - 13, sublabel)

# ── Section label ─────────────────────────────────────────────────────────────

def section_label(c, label, x, y, w):
    filled_rect(c, x, y, w, 13, BG3)
    c.setFont("Helvetica-Bold", 5.5)
    c.setFillColor(WHITE_DIM)
    c.drawCentredString(x + w/2, y + 4, label)

# ── place_cards: natural heights, distribute gaps equally ─────────────────────

def place_cards(c, cx, cw, cards_data, top_y, bottom_y):
    """
    Place cards with natural heights, distributing whitespace as equal gaps.
    cards_data: list of tuples: (title, bc, score, lines, pills, min_h)
    """
    n = len(cards_data)
    if n == 0:
        return
    total_card_h = sum(d[5] for d in cards_data)
    available = top_y - bottom_y
    total_gap = available - total_card_h
    # Distribute gap equally: 1 unit top, n-1 between, 1 unit bottom = n+1 units
    if n > 1:
        gap = max(4, total_gap / (n + 1))
    else:
        gap = total_gap / 2  # center the single card

    cy = top_y - gap  # start below top margin
    for (title, bc, score, lines, pills, min_h) in cards_data:
        h = min_h
        draw_card(c, cx, cy - h, cw, h, title, bc, score=score, lines=lines, pills=pills)
        cy -= h + gap


# Legacy alias — kept so any remaining callers compile; not used for new logic
def distribute_cards(c, cx, cw, cards_data, top_y, bottom_y, gap=4):
    """Deprecated: use place_cards instead."""
    place_cards(c, cx, cw, cards_data, top_y, bottom_y)


# ── Custom column renderers for complex (non-card) content ────────────────────

def draw_col_iv_day29(c, cx, cw, top_y, bottom_y):
    """
    Column IV Day29: Brent Contested card + STAGFLATION custom block + Regime Overlays.
    Gap-distribution: natural heights, equal gaps between 3 blocks.
    Each block ~230pt for a ~740pt body.
    """
    n = 3
    block_h = [230, 230, 230]
    total_card_h = sum(block_h)
    available = top_y - bottom_y
    total_gap = available - total_card_h
    gap = max(4, total_gap / (n + 1))

    cy = top_y - gap  # first gap from top

    # ── Block 0: Brent Paper Contested card ──────────────────────────────────
    h = block_h[0]
    y0 = cy - h
    bordered_rect(c, cx, y0, cw, h, CARD_BG, ORANGE, 1.2, 3)
    txt(c, "Brent Paper", cx + 4, y0 + h - 9, 6, ORANGE, True)
    score_badge(c, "0.29", cx + cw - 34, y0 + h - 15, ORANGE)
    divider(c, cx + 2, y0 + h - 17, cw - 4, ORANGE)
    brent_lines = [
        LB("CONTESTED  Type B  Bimodal", ORANGE),
        L("Spot $98. Pre-war $73. War prem ~$25."),
        LH("Ceasefire mode  P: 0.12  (D29)"),
        LH("Escalation mode  P: 0.38  (D29)"),
        L("Bimodal NOT unimodal — two distinct"),
        L("pricing regimes coexist. Spread ~$55."),
        L("Linear weighting invalid. Route to OPTIONS"),
        L("strategies, not single-price forecast."),
        LH("Polymarket: ceasefire contract exists."),
        L("Physical Brent anchored by AIS + supply."),
        L("Paper Brent: narrative-sensitive overlay."),
        L("CONTESTED flag: do not use as linear signal."),
        L("Watch for bimodal resolution trigger."),
        L("2wk ceasefire = reweighting NOT resolution."),
    ]
    bly = y0 + h - 26
    for (lt, lc, ls, lb_) in brent_lines:
        if bly < y0 + 14:
            break
        fn = "Helvetica-Bold" if lb_ else "Helvetica"
        c.setFont(fn, ls)
        c.setFillColor(lc)
        c.drawString(cx + 4, bly, lt)
        bly -= ls + 1.8
    pill(c, "TYPE B", cx + 4, y0 + 14, ORANGE_DIM, ORANGE, h=8, size=4.5)
    pill(c, "OPTIONS", cx + 48, y0 + 14, GREY_DIM, AMBER, h=8, size=4.5)
    pill(c, "BIMODAL", cx + 92, y0 + 14, ORANGE_DIM, ORANGE, h=8, size=4.5)
    cy -= h + gap

    # ── Block 1: STAGFLATION_RISK custom block ────────────────────────────────
    h = block_h[1]
    y0 = cy - h
    bordered_rect(c, cx, y0, cw, h, RED_DIM, RED, 1.5, 3)
    txt(c, "STAGFLATION_RISK  CONFIRMED  D9", cx + 4, y0 + h - 9, 6, RED, True)
    divider(c, cx + 2, y0 + h - 13, cw - 4, RED)
    rows = [
        ("Growth:",    "NEGATIVE  PMI 44.1",     GREY, RED),
        ("Inflation:", "ABOVE_TARGET  CPI 8.2%", GREY, RED),
        ("Risk app:",  "OFF  VIX 38",            GREY, RED),
        ("Confirmed:", "2/3 dimensions  D9",     GREY, GREEN),
    ]
    ry = y0 + h - 24
    for (lbl, val, lc, vc) in rows:
        txt(c, lbl, cx + 4, ry, 5.5, lc)
        txt(c, val, cx + 42, ry, 5.5, vc, True)
        ry -= 10
    ry -= 4
    stag_notes = [
        ("PMI 44.1: manufacturing contraction confirmed.", WHITE_DIM),
        ("CPI 8.2%: above target across G7.", WHITE_DIM),
        ("VIX 38: risk-off confirmed by vol surface.", WHITE_DIM),
        ("2-of-3 dimensions triggered D9 regime lock.", AMBER),
        ("Regime affects: rate path, equity overlays,", WHITE_DIM),
        ("CB policy optionality, credit spreads.", WHITE_DIM),
        ("SHORT equity index overlay added 5% delta.", RED),
        ("LONG equity vol overlay added 2% vega.", GREEN),
        ("Exit: requires 2/3 reclassification confirmed.", WHITE_DIM),
        ("Regime LOCKED until reclassification signal.", RED),
    ]
    for (note, col) in stag_notes:
        if ry < y0 + 18:
            break
        c.setFont("Helvetica", 5.2)
        c.setFillColor(col)
        c.drawString(cx + 4, ry, note)
        ry -= 7.5
    pill(c, "REGIME LOCKED", cx + 4, y0 + 6, RED_DIM, RED, h=9, size=5)
    cy -= h + gap

    # ── Block 2: Regime Overlays ──────────────────────────────────────────────
    h = block_h[2]
    y0 = cy - h
    bordered_rect(c, cx, y0, cw, h, RED_DIM, ORANGE, 1.2, 3)
    txt(c, "Regime Overlays  D9  STAGFLATION_RISK", cx + 4, y0 + h - 9, 5.5, ORANGE, True)
    divider(c, cx + 2, y0 + h - 13, cw - 4, ORANGE)
    ov_rows = [
        ("SHORT equity index", "5% delta NAV", RED),
        ("LONG equity vol",    "2% vega NAV",  GREEN),
    ]
    ry = y0 + h - 24
    for (inst, sz, col) in ov_rows:
        txt(c, inst, cx + 4, ry, 5.5, col, True)
        txt_right(c, sz, cx + cw - 6, ry, 5.5, WHITE_DIM)
        ry -= 10
    ry -= 2
    ov_notes = [
        ("Regime overlays are ADDITIONS to core book.", WHITE_DIM),
        ("They do not replace core long/short thesis.", WHITE_DIM),
        ("SHORT equity index: S&P 500 / EuroStoxx 50.", RED),
        ("  Rationale: stagflation compresses multiples.", WHITE_DIM),
        ("  Size: 5% delta NAV. Stop: regime reclassify.", WHITE_DIM),
        ("LONG equity vol: VIX Jun26 / EuroStoxx var.", GREEN),
        ("  Rationale: uncertainty structurally elevated.", WHITE_DIM),
        ("  Size: 2% vega NAV. Bimodal keeps vol high.", WHITE_DIM),
        ("Exit trigger: formal regime reclassification.", AMBER),
        ("  Requires 2/3 STAGFLATION dimensions to shift.", WHITE_DIM),
        ("  Growth: PMI > 50  OR  Inflation: CPI < 2.5%", WHITE_DIM),
        ("  + Risk appetite confirmed on / VIX < 20.", WHITE_DIM),
        ("D29: overlays ACTIVE. No reclassification yet.", ORANGE),
    ]
    for (note, col) in ov_notes:
        if ry < y0 + 18:
            break
        c.setFont("Helvetica", 5.0)
        c.setFillColor(col)
        c.drawString(cx + 4, ry, note)
        ry -= 7.2
    pill(c, "OVERLAYS ACTIVE", cx + 4, y0 + 6, RED_DIM, ORANGE, h=9, size=5)


def draw_col_v_day29(c, cx, cw, top_y, bottom_y):
    """
    Column V Day29: NAV summary + LONG + SHORT + Validation.
    Gap-distribution: 4 blocks ~170pt each for ~740pt body.
    """
    n = 4
    block_h = [170, 170, 170, 170]
    total_card_h = sum(block_h)
    available = top_y - bottom_y
    total_gap = available - total_card_h
    gap = max(4, total_gap / (n + 1))

    cy = top_y - gap

    long_positions = [
        ("VLO  Valero",      "+9.0%",  GREEN, "HOLD"),
        ("ICE Gasoil Crack", "+6.0%",  GREEN, "HOLD"),
        ("EU Gas Utilities", "+14.0%", GREEN, "HOLD"),
    ]
    short_positions = [
        ("DAL  Airlines", "-12.0%", RED, "HOLD"),
    ]

    # ── NAV Summary ───────────────────────────────────────────────────────────
    h = block_h[0]
    y0 = cy - h
    bordered_rect(c, cx, y0, cw, h, BG3, GOLD, 1.2, 3)
    txt(c, "NAV SUMMARY  DAY 29", cx + 4, y0 + h - 9, 6, GOLD, True)
    divider(c, cx + 2, y0 + h - 13, cw - 4, GOLD)
    nav_items = [
        ("LONG delta",      "29%",  CYAN),
        ("SHORT delta",     "12%",  RED),
        ("Gross NAV",       "~41%", WHITE),
        ("Regime overlays", "7%",   ORANGE),
        ("Vega (vol)",      "2%v",  GREEN),
    ]
    ny = y0 + h - 24
    for (lbl, val, col) in nav_items:
        txt(c, lbl, cx + 4, ny, 5.5, WHITE_DIM)
        txt_right(c, val, cx + cw - 6, ny, 7, col, True)
        ny -= 10
    nav_notes = [
        ("Book construction complete D29.", WHITE_DIM),
        ("5 core positions + 2 regime overlays.", WHITE_DIM),
        ("Physical thesis: crack + LNG + refiner.", CYAN),
        ("Regime thesis: stagflation_risk D9.", ORANGE),
        ("All core targets met within +/-2%.", GREEN),
        ("DCKG system: 85/85 tests passing.", WHITE_DIM),
        ("Iran case validated end-to-end.", GREEN),
    ]
    ny -= 4
    for (note, col) in nav_notes:
        if ny < y0 + 12:
            break
        c.setFont("Helvetica", 5.0)
        c.setFillColor(col)
        c.drawString(cx + 4, ny, note)
        ny -= 7
    cy -= h + gap

    # ── LONG Positions ────────────────────────────────────────────────────────
    h = block_h[1]
    y0 = cy - h
    bordered_rect(c, cx, y0, cw, h, CARD_BG, GREEN, 1.2, 3)
    txt(c, "LONG POSITIONS  DAY 29", cx + 4, y0 + h - 9, 5.5, GREEN, True)
    divider(c, cx + 2, y0 + h - 13, cw - 4, GREEN)
    ey = y0 + h - 24
    for (inst, pct, col, status) in long_positions:
        txt(c, inst, cx + 4, ey, 5.5, WHITE)
        txt_right(c, pct, cx + cw - 45, ey, 6, col, True)
        pill(c, status, cx + cw - 40, ey - 2,
             GREEN_DIM if status == "HOLD" else RED_DIM,
             GREEN if status == "HOLD" else RED, h=8, size=4.5)
        ey -= 11
    ey -= 4
    long_notes = [
        ("VLO: crack $40+/bbl. Refiner margin structural.", WHITE_DIM),
        ("  Physical thesis. NARRATIVE_INSENSITIVE.", CYAN),
        ("ICE Gasoil: most direct physical instrument.", WHITE_DIM),
        ("  Backwardation intact. Backlog 2.5x crude.", CYAN),
        ("EU Gas Util: Ras Laffan lam=0.0004 active.", WHITE_DIM),
        ("  5yr repair timeline. Immune to ceasefire.", GREEN),
        ("All 3 longs corroborated by physical data.", WHITE_DIM),
        ("No narrative-driven exits. Physical anchors.", GREEN),
    ]
    for (note, col) in long_notes:
        if ey < y0 + 10:
            break
        c.setFont("Helvetica", 5.0)
        c.setFillColor(col)
        c.drawString(cx + 4, ey, note)
        ey -= 7
    cy -= h + gap

    # ── SHORT Positions ───────────────────────────────────────────────────────
    h = block_h[2]
    y0 = cy - h
    bordered_rect(c, cx, y0, cw, h, CARD_BG, RED, 1.2, 3)
    txt(c, "SHORT POSITIONS  DAY 29", cx + 4, y0 + h - 9, 5.5, RED, True)
    divider(c, cx + 2, y0 + h - 13, cw - 4, RED)
    ey = y0 + h - 24
    for (inst, pct, col, status) in short_positions:
        txt(c, inst, cx + 4, ey, 5.5, WHITE)
        txt_right(c, pct, cx + cw - 45, ey, 6, col, True)
        pill(c, status, cx + cw - 40, ey - 2,
             GREEN_DIM if status == "HOLD" else RED_DIM,
             GREEN if status == "HOLD" else RED, h=8, size=4.5)
        ey -= 11
    ey -= 4
    short_notes = [
        ("DAL Airlines: -12.0% since D0.", WHITE_DIM),
        ("  INCREASES_COST_OF edge active.", RED),
        ("  Jet fuel ~2x pre-war levels D29.", WHITE_DIM),
        ("  Delta $2B extra Q2 fuel cost.", WHITE_DIM),
        ("  Credit spreads widening. Thesis intact.", RED),
        ("  IATA: months to recover jet supply chain.", WHITE_DIM),
        ("SHORT DAL retained. No ceasefire yet D29.", WHITE_DIM),
        ("Regime overlays: SHORT equity index 5%.", ORANGE),
        ("  Added D9 on STAGFLATION_RISK lock.", WHITE_DIM),
        ("  Separate from core airline thesis.", WHITE_DIM),
        ("  Exit: regime reclassification only.", ORANGE),
    ]
    for (note, col) in short_notes:
        if ey < y0 + 10:
            break
        c.setFont("Helvetica", 5.0)
        c.setFillColor(col)
        c.drawString(cx + 4, ey, note)
        ey -= 7
    cy -= h + gap

    # ── Validation ────────────────────────────────────────────────────────────
    h = block_h[3]
    y0 = cy - h
    bordered_rect(c, cx, y0, cw, h, CARD_BG, GREEN, 1.2, 3)
    txt(c, "VALIDATION vs TARGETS  (all within +/-2%)", cx + 4, y0 + h - 9, 5.5, GREEN, True)
    divider(c, cx + 2, y0 + h - 13, cw - 4, GREEN)
    val_rows = [
        ("VLO",          "+8.92%",  "+9.00%",  True),
        ("DAL",          "-10.00%", "-12.00%", True),
        ("ICE_GASOIL",   "+6.01%",  "+6.00%",  True),
        ("EU_UTILITIES", "+12.67%", "+14.00%", True),
    ]
    vy = y0 + h - 25
    # Header row
    txt(c, "Asset", cx + 4, vy, 5, WHITE_DIM, True)
    txt(c, "Actual", cx + 68, vy, 5, WHITE_DIM, True)
    txt(c, "Target", cx + 100, vy, 5, WHITE_DIM, True)
    vy -= 9
    for (asset, actual, target, passed) in val_rows:
        col = GREEN if passed else RED
        mark = "PASS" if passed else "FAIL"
        txt(c, asset, cx + 4, vy, 5.5, WHITE)
        txt(c, actual, cx + 68, vy, 5.5, col, True)
        txt(c, "vs " + target, cx + 100, vy, 5, WHITE_DIM)
        pill(c, mark, cx + cw - 34, vy - 2,
             GREEN_DIM if passed else RED_DIM,
             GREEN if passed else RED, h=8, size=4.5)
        vy -= 10
    vy -= 4
    val_notes = [
        ("DCKG graph produced all 4 position signals.", WHITE_DIM),
        ("Bayesian inference: P_raw -> P_post pipeline.", WHITE_DIM),
        ("Physical corroboration all 4 instruments.", CYAN),
        ("85/85 test cases passing. System validated.", GREEN),
        ("Iran case: first full end-to-end validation.", WHITE_DIM),
        ("Novel event -> causal chain -> positions.", WHITE_DIM),
        ("No narrative contamination in INFRA edges.", CYAN),
        ("STAGFLATION_RISK regime: systematic check.", ORANGE),
    ]
    for (note, col) in val_notes:
        if vy < y0 + 18:
            break
        c.setFont("Helvetica", 5.0)
        c.setFillColor(col)
        c.drawString(cx + 4, vy, note)
        vy -= 7
    pill(c, "ALL TARGETS MET", cx + 4, y0 + 6, GREEN_DIM, GREEN, h=9, size=5.5, bold=True)


# ─────────────────────────────────────────────────────────────────────────────
# PDF 1: DAY 29 PORTFOLIO
# ─────────────────────────────────────────────────────────────────────────────

def build_day29(path):
    c = canvas.Canvas(path, pagesize=landscape(A3))
    c.setTitle("DCKG Day 29 Portfolio")
    c.setAuthor("DCKG System")

    filled_rect(c, 0, 0, PW, PH, BG)

    draw_header(c, "US-Iran War  \xb7  Day 29  \xb7  Portfolio Construction",
                "30 March 2026  \xb7  16:00 UTC",
                [("", "D29", GOLD),
                 ("", "5 EDGES ACTIVE", CYAN),
                 ("", "STAGFLATION_RISK", ORANGE),
                 ("", "P_post MAX 0.944", GREEN)])

    ticker_y = PH - 36 - 14
    draw_ticker(c, [
        "BRENT $98  +15% war prem.",
        "GASOIL CRACK ~$40/bbl",
        "AIS ZERO TANKERS D2-D29",
        "DAL -12%  fuel shock",
        "VLO +9%  crack expansion",
        "STAGFLATION REGIME  D9 confirmed",
    ], ticker_y)

    spine_events = [
        ("D0 00:14", "US-Israel Strikes", "Novel event. LONG VLO, SHORT DAL", GOLD, False),
        ("D2",       "Hormuz Closed",     "AIS zero tankers. P_post 0.944",   CYAN, False),
        ("D7",       "Ras Tanura Strike", "INFRA_DAMAGE. lam=0.015",          ORANGE, False),
        ("D9",       "Regime Locked",     "STAGFLATION_RISK. Overlays on",    RED, False),
        ("D18",      "Ras Laffan Strike", "lam=0.0004. 5yr half-life",        PURPLE, False),
        ("D23 !!",   "Trump Post",        "NO ACTION. Physical immune",       GREY, False),
        ("D29",      "Portfolio Complete","All targets met",                  GREEN, False),
    ]
    draw_event_spine(c, spine_events, y=28, h=26)

    # Layout
    margin = 6
    body_top = ticker_y - 2
    body_bot = 56            # spine top is at y=28+26=54, give 2pt clear
    col_w = [130, 210, 180, 170, 175]
    gap = 5
    xs = [margin]
    for w in col_w[:-1]:
        xs.append(xs[-1] + w + gap)

    # Column headers (section_label is 13pt tall now)
    labels = ["I  TRIGGER EVENTS", "II  PHYSICAL SHOCKS",
              "III  MARKET SIGNALS", "IV  CONTESTED + REGIME",
              "V  PORTFOLIO  DAY 29"]
    colors = [GOLD, CYAN, AMBER, ORANGE, GREEN]
    for i, (lbl, col) in enumerate(zip(labels, colors)):
        section_label(c, lbl, xs[i], body_top - 13, col_w[i])

    # Cards fill from card_top down to body_bot
    card_top = body_top - 14   # just below section label (13pt + 1pt gap)
    card_bot = body_bot + 2

    # ── Col I: Trigger events ─────────────────────────────────────────────────
    cards_I = [
        ("US-Israel Strikes", GOLD, "0.72",
         [LB("D0  00:14 UTC  Reuters", GOLD),
          L("Novel event. Causal chain initiated."),
          L("CONSTRAINS_SUPPLY_OF chain activated."),
          LH("P_raw: 0.72  novelty_score: 0.95"),
          L("First US military strike on Iran soil."),
          L("Hormuz closure signal: ships rerouting"),
          L("within hours of strike confirmation."),
          LH("Causal chain: Strike -> Hormuz -> Supply"),
          L("Initial AIS signal: tankers slowing D1."),
          L("Reuters/AP physical corroboration D0."),
          L("Regime_check triggered: PMI + CPI watch."),],
         [("NOVEL", GOLD, BG), ("D0", GREY_DIM, WHITE_DIM)], 220),
        ("Ras Tanura Strike", ORANGE, "0.81",
         [LB("D7  INFRASTRUCTURE_DAMAGE", ORANGE),
          L("Drone strike on Ras Tanura Saudi refinery."),
          LH("lam=0.015  t_half=45d  class: FAST"),
          L("P_post: 0.81  INFRA_DAMAGE edge active."),
          L("Engineering repair timeline: 45-60 days"),
          L("primary unit; total recovery 90-120d."),
          L("Infrastructure decay class: FAST (lam=0.015)"),
          L("vs Ras Laffan SLOW (lam=0.0004)."),
          LH("Ceasefire reduces probability but NOT"),
          L("the physical repair clock. Backlog persists"),
          L("regardless of political narrative. P 0.81."),],
         [("INFRA", ORANGE_DIM, ORANGE), ("D7", GREY_DIM, WHITE_DIM)], 220),
        ("Ras Laffan Strike", PURPLE, "0.88",
         [LB("D18  QatarEnergy FM  -17% LNG", PURPLE),
          LH("lam=0.0004  t_half=1825d  class: SLOW"),
          L("5-year infrastructure repair timeline."),
          L("Qatar LNG: 77 mtpa = ~20% global LNG."),
          L("Physical damage to liquefaction trains."),
          L("lam=0.0004 means: even after 5 years,"),
          L("probability decays only to ~0.46."),
          L("COMPLETELY IMMUNE to ceasefire narrative."),
          LH("Ceasefire has zero impact on repair clock."),
          L("Physical observable. Unaffected by politics."),
          L("EU gas utilities thesis fully intact D29."),],
         [("INFRA IMMUNE", PURPLE_DIM, PURPLE), ("D18", GREY_DIM, WHITE_DIM)], 220),
    ]
    distribute_cards(c, xs[0], col_w[0], cards_I, card_top, card_bot, gap=5)

    # ── Col II: Physical Shocks ───────────────────────────────────────────────
    cards_II = [
        ("Hormuz Closure", CYAN, "0.944",
         [LB("CONSTRAINS_SUPPLY_OF", CYAN),
          L("D0-D2  AIS zero tankers confirmed D2."),
          LH("0.68 -> 0.944  AIS confirmation  LR=8.0"),
          L("Decay factor: 0.84  t=15d"),
          L("NARRATIVE_INSENSITIVE  Physical obs."),],
         [("ACTIVE", CYAN_DIM, CYAN), ("NARR-INSENS", GREY_DIM, WHITE_DIM)], 58),
        ("Refined Products Deficit", CYAN, "0.82",
         [LB("Physical backlog  2.5x crude", CYAN),
          L("IATA: months to recover jet supply."),
          L("Refinery damage real. Backlog persists."),],
         [("ACTIVE", CYAN_DIM, CYAN)], 40),
        ("Gulf Crude Deficit", CYAN, "0.78",
         [LB("-10 mb/d  physical observable", CYAN),
          L("Physical supply unchanged. AIS data."),],
         [("ACTIVE", CYAN_DIM, CYAN)], 36),
        ("LNG Deficit  Ras Laffan", PURPLE, "0.88",
         [LB("lam=0.0004  UNCHANGED", PURPLE),
          L("Infrastructure: 3-5yr repair."),
          L("Ceasefire has zero impact on this edge."),],
         [("INFRA IMMUNE", PURPLE_DIM, PURPLE), ("lam=0.0004", GREY_DIM, GREY)], 44),
        ("Airline Fuel Cost Shock", CYAN, "0.72",
         [LB("INCREASES_COST_OF(DAL)", CYAN),
          L("Jet fuel ~2x pre-war levels."),
          L("Delta: $2B extra Q2 fuel cost."),],
         [("ACTIVE", CYAN_DIM, CYAN)], 40),
        ("NWE Gasoil Crack", CYAN, "0.63",
         [LB("Physical backwardation $34+/bbl", CYAN),
          L("Decay clock running normally."),],
         [("ACTIVE", CYAN_DIM, CYAN)], 34),
    ]
    distribute_cards(c, xs[1], col_w[1], cards_II, card_top, card_bot, gap=5)

    # ── Col III: Market Signals ───────────────────────────────────────────────
    cards_III = [
        ("SGP Jet Fuel Crack", CYAN, "0.71",
         [LB("Physical  NARRATIVE_INSENSITIVE", CYAN),
          L("Crack spreads sticky. Supply pipeline."),
          L("Backwardation persists."),],
         [("ACTIVE", CYAN_DIM, CYAN), ("NARR-INSENS", GREY_DIM, WHITE_DIM)], 44),
        ("Refiner Margin  VLO", CYAN, "0.63",
         [LB("VLO +9%  crack $40+/bbl", CYAN),
          L("Physical thesis intact."),
          L("Stock move confirms causal signal."),],
         [("ACTIVE", CYAN_DIM, CYAN)], 42),
        ("Airline HY Credit", CYAN, "0.52",
         [LB("DAL: $2B extra Q2 fuel", CYAN),
          L("Credit spreads widening. Thesis intact."),],
         [("ACTIVE", CYAN_DIM, CYAN)], 38),
        ("CB Rate Path", AMBER, "0.48",
         [LB("POLICY_RISK_TO  REGIME_CONDITIONAL", AMBER),
          L("STAGFLATION: rate cuts off table."),
          L("Sign: -1.0 (regime multiplier)."),],
         [("ACTIVE", CYAN_DIM, CYAN), ("REGIME-COND", AMBER_DIM, AMBER)], 44),
        ("Trump Truth Social  D23", GREY, None,
         [LB("narrative_sensitive: TRUE", GREY),
          L("novelty_score: 0.15  (4th similar pattern)"),
          L("NO ACTION taken. Physical edges immune."),
          LH("DP07: narrative != physical update"),
          L("Brent -11% paper move IGNORED."),],
         [("IGNORED", GREY_DIM, GREY), ("DP07", GREY_DIM, WHITE_DIM)], 50),
    ]
    distribute_cards(c, xs[2], col_w[2], cards_III, card_top, card_bot, gap=5)

    # ── Col IV: Contested + Regime (custom blocks) ────────────────────────────
    draw_col_iv_day29(c, xs[3], col_w[3], card_top, card_bot)

    # ── Col V: Portfolio (custom blocks) ─────────────────────────────────────
    draw_col_v_day29(c, xs[4], col_w[4], card_top, card_bot)

    # Column dividers
    for xi in xs[1:]:
        c.setStrokeColor(WHITE_FAINT)
        c.setLineWidth(0.3)
        c.line(xi - gap/2, card_bot, xi - gap/2, card_top)

    c.save()
    print(f"  Saved: {path}")


# ── Day 40 custom column helpers ──────────────────────────────────────────────

def draw_col_iii_day40(c, cx, cw, top_y, bottom_y):
    """Col III Day40: Agent D Game Tree + CB Rate + Brent Type B + Strangle + B6 Airline.
    Gap-distribution: 5 blocks, equal gaps."""
    n = 5
    block_h = [148, 120, 120, 110, 110]
    total_card_h = sum(block_h)
    available = top_y - bottom_y
    total_gap = available - total_card_h
    gap = max(4, total_gap / (n + 1))
    heights = block_h

    cy = top_y - gap

    # ── Block 0: Agent D Game Tree ────────────────────────────────────────────
    h = heights[0]
    y0 = cy - h
    bordered_rect(c, cx, y0, cw, h, BG3, GOLD, 1.2, 3)
    txt(c, "AGENT D2/D3  GAME TREE UPDATE  D40", cx + 4, y0 + h - 9, 5.5, GOLD, True)
    divider(c, cx + 2, y0 + h - 13, cw - 4, GOLD)
    rows = [
        ("Negotiated peace",  "5%",  "20%", GREEN),
        ("Partial accord",    "25%", "40%", AMBER),
        ("Standoff/collapse", "45%", "30%", ORANGE),
        ("Escalation",        "15%", "10%", RED),
    ]
    gy = y0 + h - 22
    txt(c, "Scenario", cx + 4, gy, 5, WHITE_DIM, True)
    txt(c, "Before", cx + 90, gy, 5, WHITE_DIM, True)
    txt(c, "After", cx + 130, gy, 5, WHITE_DIM, True)
    gy -= 8
    for (sc, before, after, col) in rows:
        txt(c, sc, cx + 4, gy, 5.5, WHITE)
        txt(c, before, cx + 90, gy, 5.5, WHITE_DIM)
        txt(c, after, cx + 130, gy, 6, col, True)
        gy -= 9
    gy -= 2
    gamenotes = [
        ("Pakistan: neutral mediator. PM Sharif + Army Chief.", WHITE_DIM),
        ("Raises partial-accommodation probability 25->40%.", AMBER),
        ("Trust deficit persists. BCA: 'fighting ignites later.'", HexColor("#888888")),
        ("2-week ceasefire = timing signal NOT resolution.", WHITE_DIM),
        ("Islamabad talks 10 Apr. Iran 10-point proposal.", WHITE_DIM),
        ("Game tree not resolved. Bimodal maintained.", ORANGE),
        ("Agent D monitors: coalition defection, BCA, Iran.", WHITE_DIM),
        ("D39 Pakistan entry: biggest single-event shift.", GOLD),
    ]
    for (note, col) in gamenotes:
        if gy < y0 + 10:
            break
        c.setFont("Helvetica", 4.8)
        c.setFillColor(col)
        c.drawString(cx + 4, gy, note)
        gy -= 7
    cy -= h + gap

    # ── Block 1: CB Rate Path ─────────────────────────────────────────────────
    h = heights[1]
    draw_card(c, cx, cy - h, cw, h, "CB Rate Path  Contested", AMBER, score="0.35",
              lines=[LB("0.48 -> 0.35  rate cut odds +45%", AMBER),
                     L("POLICY_RISK_TO. Regime under review."),
                     L("CB re-constrained if ceasefire breaks."),
                     L("Fed: ceasefire reduces supply shock path."),
                     L("Rate cut probability: yr-end +45%."),
                     LH("STAGFLATION_RISK not yet reclassified."),
                     L("Need 2/3 dimensions to shift for exit."),
                     L("Current: 1/3 (risk app improving)."),
                     L("Growth still contractionary PMI < 50."),
                     L("Tripwire: ceasefire + CPI < 2.5%."),],
              pills=[("REDUCED", AMBER_DIM, AMBER), ("REGIME REVIEW", RED_DIM, RED)])
    cy -= h + gap

    # ── Block 2: Brent Paper Type B ──────────────────────────────────────────
    h = heights[2]
    draw_card(c, cx, cy - h, cw, h, "Brent Paper  CONTESTED Type B", ORANGE, score="0.29",
              score_color=ORANGE,
              lines=[LB("Bimodal distribution reweighted D40", ORANGE),
                     LH("Ceasefire mode P: 0.32 -> 0.55"),
                     LH("Escalation mode P: 0.38 -> 0.20"),
                     L("Bimodal NOT resolved. 2wk timeline."),
                     L("Linear weight UNCHANGED. Dist. shifts."),
                     L("Physical Brent $95 (-$3 from $98 D29)."),
                     L("Pre-war was $73. War prem ~$22 remains."),
                     L("Bimodal resolution needs confirmed peace."),
                     L("2wk ceasefire insufficient for resolution."),],
              pills=[("TYPE B", ORANGE_DIM, ORANGE), ("CONTESTED", ORANGE_DIM, ORANGE)])
    cy -= h + gap

    # ── Block 3: Brent Strangle ───────────────────────────────────────────────
    h = heights[3]
    draw_card(c, cx, cy - h, cw, h, "Brent Strangle  UPDATED", GREEN, score="3%v",
              score_color=GREEN,
              lines=[LB("Puts $80 / Calls $125  Jun26", GREEN),
                     L("Ceasefire: puts closer to money ($95)."),
                     L("Vol spike enriched both legs."),
                     LH("HOLD  bimodal still active  2wk"),
                     L("Puts leg: $95 spot, $80 strike, OTM."),
                     L("Calls leg: $125 strike, far OTM."),
                     L("Both legs enriched by vol spike."),
                     L("Hold: bimodal unresolved in 2wk."),],
              pills=[("HOLD", GREEN_DIM, GREEN), ("BOTH LEGS LIVE", GREEN_DIM, GREEN)])
    cy -= h + gap

    # ── Block 4: B6 Airline Revenue Breadth ──────────────────────────────────
    h = heights[4]
    draw_card(c, cx, cy - h, cw, h, "B6: Airline Rev. Breadth", ORANGE, score="0.30",
              score_color=ORANGE,
              lines=[LB("0.44 -> 0.30  CONTESTED flag raised", ORANGE),
                     L("Stocks +10-12% on ceasefire D40."),
                     L("Short-squeeze risk emerging DAL/IAG."),
                     L("Physical jet fuel elevated: months."),
                     L("Fuel cost thesis intact (IATA)."),
                     L("Cover 3% squeeze risk. Hold 9%."),
                     L("Agent B6: monitors airline breadth."),],
              pills=[("AGENT B6", GREY_DIM, AMBER), ("CONTESTED", ORANGE_DIM, ORANGE)])


def draw_col_iv_day40(c, cx, cw, top_y, bottom_y):
    """Col IV Day40: Regime Transition Watch + Regime Overlays + NAV Summary.
    Gap-distribution: 3 blocks, equal gaps."""
    n = 3
    block_h = [240, 240, 200]
    total_card_h = sum(block_h)
    available = top_y - bottom_y
    total_gap = available - total_card_h
    gap = max(4, total_gap / (n + 1))
    heights = block_h

    cy = top_y - gap

    # ── Block 0: Regime Transition Watch ─────────────────────────────────────
    h = heights[0]
    y0 = cy - h
    bordered_rect(c, cx, y0, cw, h, RED_DIM, RED, 1.5, 3)
    txt(c, "REGIME TRANSITION WATCH", cx + 4, y0 + h - 9, 6, RED, True)
    txt(c, "STAGFLATION_RISK", cx + 4, y0 + h - 18, 5.5, ORANGE, True)
    divider(c, cx + 2, y0 + h - 22, cw - 4, RED)
    rw_rows = [
        ("x", "Growth:",    "PMI still contractionary",   RED),
        ("x", "Inflation:", "CPI 3.4%  not fallen yet",   RED),
        ("~", "Risk app:",  "OFF->improving (ceasefire)",  AMBER),
    ]
    ry = y0 + h - 31
    for (mark, dim, val, col) in rw_rows:
        txt(c, mark, cx + 4, ry, 6, col, True)
        txt(c, dim, cx + 14, ry, 5.5, WHITE_DIM, True)
        txt(c, val, cx + 55, ry, 5.5, col)
        ry -= 10
    regime_notes = [
        ("Verdict: 1 of 3 dimensions shifting.", WHITE_DIM),
        ("Need 2/3 to reclassify. Overlays NOT exited.", WHITE_DIM),
        ("Tripwire: confirmed ceasefire + CPI <2.5%.", AMBER),
        ("Growth: PMI still contractionary. x NOT met.", RED),
        ("Inflation: CPI 3.4%, above target. x NOT met.", RED),
        ("Risk app: improving on ceasefire. ~ PARTIAL.", AMBER),
        ("Only 1/3 shifting -> regime LOCKED D40.", ORANGE),
        ("SHORT equity + LONG vol overlays maintained.", WHITE_DIM),
        ("SHORT 2yr rates: reduce to 4% (rate cut odds).", AMBER),
        ("Formal reclassification: systematic not narrative.", WHITE_DIM),
        ("Agent R monitors all 3 dimensions daily.", WHITE_DIM),
    ]
    for (note, col) in regime_notes:
        if ry < y0 + 18:
            break
        c.setFont("Helvetica", 5.0)
        c.setFillColor(col)
        c.drawString(cx + 4, ry, note)
        ry -= 7.2
    pill(c, "UNDER REVIEW  NOT RECLASSIFIED", cx + 4, y0 + 6, RED_DIM, ORANGE, h=9, size=4.5)
    cy -= h + gap

    # ── Block 1: Regime Overlays Under Watch ─────────────────────────────────
    h = heights[1]
    y0 = cy - h
    bordered_rect(c, cx, y0, cw, h, RED_DIM, ORANGE, 1.2, 3)
    txt(c, "Regime Overlays  Under Watch  D9", cx + 4, y0 + h - 9, 5.5, ORANGE, True)
    divider(c, cx + 2, y0 + h - 13, cw - 4, ORANGE)
    ov2 = [
        ("SHORT equity index", "5%->3%d",  AMBER, "PARTIAL REDUCE"),
        ("LONG equity vol",    "HOLD 2%v", GREEN, "HOLD"),
        ("SHORT 2yr rates",    "7%->4%",   AMBER, "REDUCE"),
    ]
    ry = y0 + h - 24
    for (inst, sz, col, status) in ov2:
        txt(c, inst, cx + 4, ry, 5.5, col)
        txt_right(c, sz, cx + cw - 42, ry, 5.5, WHITE_DIM)
        sc = GREEN_DIM if status == "HOLD" else AMBER_DIM
        fc = GREEN if status == "HOLD" else AMBER
        pill(c, status, cx + cw - 38, ry - 2, sc, fc, h=8, size=4.2)
        ry -= 11
    ry -= 2
    ov_notes2 = [
        ("Regime requires 2/3 confirmation to exit.", WHITE_DIM),
        ("SHORT equity: S&P/EuroStoxx 50. 5%->3%.", AMBER),
        ("  Reduce: ceasefire rally risk. Not full exit.", WHITE_DIM),
        ("  Retain 3%: stagflation NOT reclassified.", ORANGE),
        ("LONG vol: VIX Jun26 + EuroStoxx variance.", GREEN),
        ("  HOLD: bimodal uncertainty still elevated.", WHITE_DIM),
        ("  2wk ceasefire = peak uncertainty. Vol up.", WHITE_DIM),
        ("SHORT 2yr: rate cut odds +45%. 7%->4%.", AMBER),
        ("  Regime in flux. Retain residual 4%.", WHITE_DIM),
        ("  Exit fully on confirmed reclassification.", WHITE_DIM),
        ("All overlays: D9 STAGFLATION_RISK origin.", ORANGE),
    ]
    for (note, col) in ov_notes2:
        if ry < y0 + 12:
            break
        c.setFont("Helvetica", 4.8)
        c.setFillColor(col)
        c.drawString(cx + 4, ry, note)
        ry -= 7
    cy -= h + gap

    # ── Block 2: NAV Summary Day 40 ───────────────────────────────────────────
    h = heights[2]
    y0 = cy - h
    bordered_rect(c, cx, y0, cw, h, BG3, GOLD, 1.2, 3)
    txt(c, "NAV SUMMARY  DAY 40 POST-UPDATE", cx + 4, y0 + h - 9, 5.5, GOLD, True)
    divider(c, cx + 2, y0 + h - 13, cw - 4, GOLD)
    nav40 = [
        ("LONG delta",  "43%",  CYAN),
        ("SHORT delta", "16%",  RED),
        ("  was",       "24%",  GREY),
        ("Vega (all)",  "5%",   GREEN),
        ("Gross NAV",   "~67%", WHITE),
        ("  was",       "82%",  GREY),
    ]
    ny = y0 + h - 24
    for (lbl, val, col) in nav40:
        txt(c, lbl, cx + 4, ny, 5.5, WHITE_DIM)
        txt_right(c, val, cx + cw - 6, ny, 6.5, col, True)
        ny -= 9
    ny -= 4
    nav40_notes = [
        ("LONG delta up: MPC/PSX/Yara + Rheinmetall.", CYAN),
        ("SHORT delta down: cover 3% airline squeeze.", RED),
        ("Gross NAV down 82->67%: regime reduces.", WHITE_DIM),
        ("Vega maintained: bimodal persists 2wk.", GREEN),
        ("Physical anchor positions unchanged.", CYAN),
        ("Regime overlays partially reduced.", AMBER),
    ]
    for (note, col) in nav40_notes:
        if ny < y0 + 10:
            break
        c.setFont("Helvetica", 5.0)
        c.setFillColor(col)
        c.drawString(cx + 4, ny, note)
        ny -= 7.2


def draw_col_v_day40(c, cx, cw, top_y, bottom_y, actions):
    """Col V Day40: action cards with gap-distribution."""
    n = len(actions)
    # Each card gets a natural height based on content (~70pt each for 10 actions)
    card_h = 70
    total_card_h = card_h * n
    available = top_y - bottom_y
    total_gap = available - total_card_h
    gap = max(4, total_gap / (n + 1))
    heights = [card_h] * n

    cy = top_y - gap
    for i, ((title, bc, score, detail, status, sbg), h) in enumerate(zip(actions, heights)):
        y0 = cy - h
        bordered_rect(c, cx, y0, cw, h, CARD_BG, bc, 1.2, 3)
        # Title at top-left, score at top-right
        txt(c, title, cx + 4, y0 + h - 9, 5.5, bc, True)
        if score:
            txt_right(c, score, cx + cw - 6, y0 + h - 9, 7, bc, True)
        divider(c, cx + 2, y0 + h - 13, cw - 4)
        # Detail word-wrap
        fn = "Helvetica"; fs = 5
        words = detail.split(); line = ""; dy = y0 + h - 21
        for word in words:
            test = (line + " " + word).strip()
            if c.stringWidth(test, fn, fs) <= cw - 10:
                line = test
            else:
                if dy < y0 + 14:
                    break
                c.setFont(fn, fs)
                c.setFillColor(WHITE_DIM)
                c.drawString(cx + 4, dy, line)
                dy -= 7
                line = word
        if line and dy >= y0 + 14:
            c.setFont(fn, fs)
            c.setFillColor(WHITE_DIM)
            c.drawString(cx + 4, dy, line)
        pill(c, status, cx + 4, y0 + 5,
             sbg,
             GREEN if "HOLD" in status else (AMBER if "REDUCE" in status or "PARTIAL" in status else RED),
             h=8, size=4.5)
        cy -= h + gap


# ─────────────────────────────────────────────────────────────────────────────
# PDF 2: DAY 40 CEASEFIRE
# ─────────────────────────────────────────────────────────────────────────────

def build_day40(path):
    c = canvas.Canvas(path, pagesize=landscape(A3))
    c.setTitle("DCKG Day 40 Ceasefire")
    c.setAuthor("DCKG System")

    filled_rect(c, 0, 0, PW, PH, BG)

    draw_header(c, "US-Iran War  \xb7  Day 40  \xb7  Ceasefire Event",
                "Graph State Revised: 08 April 2026  \xb7  15:30 UTC",
                [("", "D40", GOLD),
                 ("", "6 EDGES UPDATED", ORANGE),
                 ("", "3 EDGES UNCHANGED", CYAN),
                 ("", "~55% CEASEFIRE PROB", GREEN),
                 ("", "08 Apr 2026 15:30 UTC", GREY)])

    alert_y = PH - 36 - 20
    draw_alert_full(c,
        "CEASEFIRE EVENT: Trump-Iran 2-week ceasefire announced ~22:00 UTC 7 Apr "
        "\xb7 brokered by Pakistan \xb7 contingent on Hormuz reopening \xb7 Islamabad talks 10 Apr "
        "\xb7 TIMING signal NOT a resolution signal. Physical infrastructure unchanged. "
        "Ras Laffan lam=0.0004 edges intact. STAGFLATION_RISK regime under review. "
        "Brent CONTESTED Type B: ceasefire mode P rises 0.32->0.55.",
        alert_y, h=20)

    ticker_y = alert_y - 14
    draw_ticker(c, [
        "BRENT $95  APR8  -13% war prem. unwind",
        "PRE-WAR BRENT $73  +30% still embedded",
        "GASOIL CRACK ~$40  Physical unchanged",
        "~1000 VESSELS STRANDED  Bloomberg Gulf",
        "2wk CEASEFIRE  Talks 10 Apr ISB",
        "DAL +11% APR8  Cover SHORT?",
        "VLO -5% APR8  Crack premium unwind",
        "~55% CEASEFIRE PROB  was 12% D29",
    ], ticker_y)

    spine_events = [
        ("D0 00:14", "US-Israel Strikes",   "Causal chain started",    GOLD,   False),
        ("D2",       "Hormuz Closed",        "AIS zero tankers",        CYAN,   False),
        ("D7",       "Ras Tanura",           "INFRA_DAMAGE lam=0.015",  ORANGE, False),
        ("D9",       "Regime Locked",        "STAGFLATION_RISK",        RED,    False),
        ("D18",      "Ras Laffan Strike",    "lam=0.0004 5yr",          PURPLE, False),
        ("D23 !!",   "Trump Post",           "NO ACTION",               GREY,   False),
        ("D25-D26",  "Rate+PSX+Rheinmetall", "Book complete",           AMBER,  False),
        ("D39 NEW",  "Pakistan Mediation",   "PM Sharif mediator",      GOLD,   True),
        ("D40 22UTC","Ceasefire Announced",  "Trump TruthSocial",       AMBER,  True),
        ("D40 NOW",  "Graph Updated",        "6 edges. Regime review.", GREEN,  False),
    ]
    draw_event_spine(c, spine_events, y=28, h=26)

    body_top = ticker_y - 2
    body_bot = 56
    margin = 6
    gap = 4
    col_w = [128, 200, 185, 168, 180]
    xs = [margin]
    for w in col_w[:-1]:
        xs.append(xs[-1] + w + gap)

    labels = ["I  TRIGGER EVENTS", "II  PHYSICAL SHOCKS",
              "III  CONTESTED + AGENT D", "IV  REGIME WATCH",
              "VI  PORTFOLIO ACTIONS"]
    colors = [GOLD, CYAN, ORANGE, RED, GREEN]
    for i, (lbl, col) in enumerate(zip(labels, colors)):
        section_label(c, lbl, xs[i], body_top - 13, col_w[i])

    card_top = body_top - 14
    card_bot = body_bot + 2

    # ── Col I: Triggers ───────────────────────────────────────────────────────
    cards_I40 = [
        ("US-Israel Strikes", GOLD, "0.72",
         [LB("D0  00:14 UTC  Reuters", GOLD),
          L("Novel event. Causal chain initiated."),],
         [("D0", GREY_DIM, WHITE_DIM)], 40),
        ("Ras Tanura Strike", ORANGE, "0.81",
         [LB("D7  INFRASTRUCTURE_DAMAGE", ORANGE),
          LH("lam=0.015  t_half=45d"),],
         [("INFRA", ORANGE_DIM, ORANGE)], 38),
        ("Ras Laffan Strike", PURPLE, "0.88",
         [LB("D18  UNAFFECTED by ceasefire", PURPLE),
          LH("lam=0.0004  t_half=1825d"),
          L("Ceasefire = zero impact."),],
         [("INFRA IMMUNE", PURPLE_DIM, PURPLE)], 42),
        ("2-Week Ceasefire", AMBER, None,
         [LB("D40  Trump Truth Social 22:00 UTC", AMBER),
          L("Pakistan-brokered. Iran 10-pt proposal."),
          L("Islamabad talks 10 Apr. 2wk window."),
          LH("TIMING signal NOT resolution signal"),],
         [("NEW D40", AMBER_DIM, AMBER), ("NOVEL", GOLD, BG)], 48),
        ("Pakistan Mediator Entry", GOLD, None,
         [LB("D39-D40  PM Sharif + Army Chief", GOLD),
          L("Agent D3: coalition dynamics update."),
          L("Shifts game tree significantly."),],
         [("AGENT D3", GREY_DIM, GOLD), ("NEW D39", AMBER_DIM, AMBER)], 44),
    ]
    distribute_cards(c, xs[0], col_w[0], cards_I40, card_top, card_bot, gap=4)

    # ── Col II: Physical Shocks ───────────────────────────────────────────────
    cards_II40 = [
        ("Gulf Crude Deficit", ORANGE, "0.78",
         [LB("0.90 -> 0.78  TIMING signal", ORANGE),
          L("Ceasefire = timing. Physical unchanged."),],
         [("UPDATED", ORANGE_DIM, ORANGE), ("REDUCED", AMBER_DIM, AMBER)], 38),
        ("Refined Products Deficit", ORANGE, "0.76",
         [LB("0.82 -> 0.76  still 2.5x crude", ORANGE),
          L("IATA: months to recover jet supply."),],
         [("UPDATED", ORANGE_DIM, ORANGE), ("ACTIVE", CYAN_DIM, CYAN)], 38),
        ("LNG Deficit  Ras Laffan", PURPLE, "0.88",
         [LB("0.88  UNCHANGED  lam=0.0004", PURPLE),
          L("Infrastructure: 3-5yr repair."),
          L("Ceasefire has ZERO impact."),],
         [("INFRA IMMUNE", PURPLE_DIM, PURPLE), ("UNCHANGED", GREY_DIM, GREY)], 42),
        ("Airline Fuel Cost Shock", ORANGE, "0.61",
         [LB("0.72 -> 0.61  fuel price softening", ORANGE),],
         [("UPDATED", ORANGE_DIM, ORANGE), ("REDUCED", AMBER_DIM, AMBER)], 32),
        ("LPG / Ammonia Feedstock", CYAN, "0.52",
         [LB("0.52  ACTIVE  unchanged", CYAN),
          L("Gulf 45% global sulfur. Backlog slow."),],
         [("ACTIVE", CYAN_DIM, CYAN)], 34),
        ("SGP Jet Fuel Crack", ORANGE, "0.64",
         [LB("0.71 -> 0.64  AIS early transits", ORANGE),
          L("Physical. Backwardation persists."),],
         [("UPDATED", ORANGE_DIM, ORANGE)], 34),
        ("NWE Gasoil Crack", ORANGE, "0.58",
         [LB("0.63 -> 0.58  clock NOT reset", ORANGE),
          L("Ceasefire != confirmation. Decay runs."),],
         [("UPDATED", ORANGE_DIM, ORANGE), ("DECAY RUNS", GREY_DIM, WHITE_DIM)], 36),
        ("Refiner Margin", ORANGE, "0.55",
         [LB("0.63 -> 0.55  narrative overshoot", ORANGE),
          L("VLO -5% D40. Physical crack $40+/bbl."),],
         [("UPDATED", ORANGE_DIM, ORANGE), ("HOLD THESIS", GREEN_DIM, GREEN)], 34),
    ]
    distribute_cards(c, xs[1], col_w[1], cards_II40, card_top, card_bot, gap=4)

    # ── Col III: Contested + Agent D (custom) ─────────────────────────────────
    draw_col_iii_day40(c, xs[2], col_w[2], card_top, card_bot)

    # ── Col IV: Regime Watch (custom) ─────────────────────────────────────────
    draw_col_iv_day40(c, xs[3], col_w[3], card_top, card_bot)

    # ── Col V: Portfolio Actions (custom distributed) ─────────────────────────
    actions = [
        ("LONG VLO  Valero", GREEN, "9%",
         "VLO -5% D40. Physical crack still $40+/bbl. Narrative overshoot. Physical thesis intact.",
         "HOLD", GREEN_DIM),
        ("LONG ICE Gasoil Crack", GREEN, "6%",
         "HOLD FULL. Most physical instrument. Backwardation unchanged. Immune to narrative. No change.",
         "HOLD  PHYSICAL ANCHOR", GREEN_DIM),
        ("LONG EU Gas Utilities", GREEN, "14%",
         "HOLD FULL. Ras Laffan lam=0.0004 infra edge fully active. Ceasefire does not affect 5yr repair.",
         "HOLD  RAS LAFFAN INTACT", GREEN_DIM),
        ("LONG MPC + PSX + Yara", GREEN, "9%",
         "HOLD. Refinery margin structural. CF Inds LPG backlog persists. PSX B6 thesis intact.",
         "HOLD", GREEN_DIM),
        ("LONG Rheinmetall", GREEN, "2%",
         "HOLD. Defense cycle multi-year. lam=0.004 r=0 structural.",
         "HOLD", GREEN_DIM),
        ("SHORT Airlines", RED, "12%->9%",
         "DAL +11% IAG +8% on ceasefire. Cover 3% short-squeeze risk. Retain 9% fuel cost thesis. IATA: jet fuel elevated months.",
         "PARTIAL COVER  3% CLOSED", AMBER_DIM),
        ("SHORT 2yr Rates", AMBER, "7%->4%",
         "Rate cut odds +45% yr-end. STAGFLATION not reclassified. Reduce materially. Retain 4% residual.",
         "REDUCE  REGIME IN FLUX", AMBER_DIM),
        ("LONG Brent Strangle", GREEN, "3%v",
         "Puts $80 / Calls $125 Jun26. Bimodal still active. 2wk uncertainty. Hold until structure clearer.",
         "HOLD  BIMODAL PERSISTS", GREEN_DIM),
        ("SHORT Equity Index", AMBER, "5%->3%d",
         "S&P +2.6% Dow +2.9% on ceasefire. Regime NOT reclassified. Reduce to 3% delta.",
         "PARTIAL REDUCTION", AMBER_DIM),
        ("LONG Equity Vol", GREEN, "2%v",
         "VIX Jun26 / EuroStoxx variance. 2wk ceasefire = peak uncertainty. Vol elevated. HOLD fully.",
         "HOLD  REGIME OVERLAY", GREEN_DIM),
    ]
    draw_col_v_day40(c, xs[4], col_w[4], card_top, card_bot, actions)

    # Column dividers
    for xi in xs[1:]:
        c.setStrokeColor(WHITE_FAINT)
        c.setLineWidth(0.3)
        c.line(xi - gap/2, card_bot, xi - gap/2, card_top)

    c.save()
    print(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# PDF 3: FOCUS ARCHITECTURE
# ─────────────────────────────────────────────────────────────────────────────

def _focus_section(c, title, title_color, x, y, w, h, items, bg=CARD_BG, radius=4):
    """Draw a labelled section card with bullet items."""
    bordered_rect(c, x, y - h, w, h, bg, title_color, 1.4, radius)
    txt(c, title, x + 5, y - 10, 6.5, title_color, True)
    divider(c, x + 3, y - 14, w - 6, title_color)
    cy = y - 22
    for (bullet, line, color, bold) in items:
        if cy < y - h + 4:
            break
        fn = "Helvetica-Bold" if bold else "Helvetica"
        c.setFont(fn, 5.5)
        c.setFillColor(color)
        c.drawString(x + 5, cy, bullet + "  " + line)
        cy -= 8.5
    return y - h


def build_focus_pdf(path):
    """
    Single-page A3-landscape PDF: How to define focus in DCKG.
    Five-layer architecture answer styled like the dashboard.
    """
    c = canvas.Canvas(path, pagesize=landscape(A3))
    c.setTitle("DCKG: Defining System Focus")
    c.setAuthor("DCKG System")

    filled_rect(c, 0, 0, PW, PH, BG)

    # ── Header ────────────────────────────────────────────────────────────────
    hh = 36
    filled_rect(c, 0, PH - hh, PW, hh, HEADER_BG)
    txt(c, "DYNAMIC CAUSAL KNOWLEDGE GRAPH  \xb7  FOCUS ARCHITECTURE",
        14, PH - 14, 11, GOLD, True)
    txt(c, "How to define system focus given 100s-1000s of simultaneous market influences",
        14, PH - 26, 7.5, WHITE_DIM)
    txt_right(c, "11 April 2026  \xb7  DCKG v1.0", PW - 10, PH - 14, 6.5, AMBER)
    txt_right(c, "85/85 TESTS PASSING  \xb7  IRAN CASE VALIDATED", PW - 10, PH - 26, 6, GREEN)
    divider(c, 0, PH - hh, PW, GOLD, 1.5)

    # ── Subtitle band ─────────────────────────────────────────────────────────
    filled_rect(c, 0, PH - hh - 18, PW, 18, BG2)
    txt(c, "CORE ANSWER:", 14, PH - hh - 7, 7, AMBER, True)
    txt(c, "Five cascading filters eliminate ~99% of market noise before any causal edge enters the graph.",
        105, PH - hh - 7, 7, WHITE)
    txt(c, "Only events that pass all five layers consume graph budget.", 105, PH - hh - 16, 6.5, WHITE_DIM)

    # ── Pipeline arrow strip ───────────────────────────────────────────────────
    pipe_y = PH - hh - 28
    filled_rect(c, 0, pipe_y - 14, PW, 14, HexColor("#0d0d0d"))
    stages = [
        ("NEWS FIREHOSE", GREY),
        ("L1: ONTOLOGY", GOLD),
        ("L2: UNIVERSE", CYAN),
        ("L3: THESIS BRIEF", AMBER),
        ("L4: REGIME GATE", ORANGE),
        ("L5: GRAPH BUDGET", RED),
        ("EDGE CREATED", GREEN),
    ]
    sw = PW / (len(stages) * 1.4)
    sx = 10
    for i, (label, col) in enumerate(stages):
        filled_rect(c, sx, pipe_y - 13, sw, 12, HexColor("#1a1a1a"), col, 0.8, 2)
        txt_center(c, label, sx + sw / 2, pipe_y - 7, 5, col, True)
        if i < len(stages) - 1:
            arrow_right(c, sx + sw + 1, pipe_y - 7, col)
        sx += sw + 10

    # ── Body layout: 3 columns (narrow | wide | narrow) ──────────────────────
    body_top = pipe_y - 16
    body_bot = 54
    body_h = body_top - body_bot
    margin = 8
    gap = 7

    # Col widths: L1+L2, L3+L4, L5+conclusion
    col_w = [320, 330, PW - 320 - 330 - 3 * margin - 2 * gap]
    xs = [margin, margin + col_w[0] + gap, margin + col_w[0] + gap + col_w[1] + gap]

    # ── LEFT COLUMN: L1 + L2 ─────────────────────────────────────────────────
    cx, cw = xs[0], col_w[0]

    # L1: Ontology Filter
    l1_h = 210
    l1_bot = _focus_section(c,
        "LAYER 1 — ONTOLOGY FILTER  (eliminates ~90% of news)",
        GOLD, cx, body_top, cw, l1_h,
        [
            ("\u25cf", "The ontology is the first and hardest filter.", GOLD, True),
            ("\u25e6", "7 permitted edge types in ontology_v1.yaml.", WHITE_DIM, False),
            ("\u25e6", "Any causal mechanism not in ontology -> UNCLASSIFIABLE -> rejected.", WHITE_DIM, False),
            ("\u25e6", "4 node types: GEOPOLITICAL_EVENT, MACRO_INDICATOR,", WHITE_DIM, False),
            ("\u25e6", "  PHYSICAL_OBSERVABLE, TRADEABLE_ASSET.", WHITE_DIM, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "Ontology rejection is the cheapest filter (no LLM call).", AMBER, True),
            ("\u25e6", "Agent A checks ontology membership BEFORE calling Claude API.", WHITE_DIM, False),
            ("\u25e6", "OntologyViolationError raised immediately on unknown type.", WHITE_DIM, False),
            ("\u25e6", "Example rejects: earnings surprise, CEO comment, FX sentiment,", WHITE_DIM, False),
            ("\u25e6", "  macro-narrative, technical breakout, analyst upgrade.", WHITE_DIM, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "Permitted edge types (only these 7 survive):", CYAN, True),
            ("\u25e6", "CONSTRAINS_SUPPLY_OF", CYAN, False),
            ("\u25e6", "INCREASES_COST_OF", CYAN, False),
            ("\u25e6", "CREATES_DEMAND_FOR", CYAN, False),
            ("\u25e6", "CAUSES_POLICY_SHIFT_IN", CYAN, False),
            ("\u25e6", "DISRUPTS_INFRASTRUCTURE_OF", CYAN, False),
            ("\u25e6", "ALTERS_RISK_APPETITE_FOR", CYAN, False),
            ("\u25e6", "PROVIDES_PHYSICAL_EVIDENCE_FOR", CYAN, False),
        ])
    pill(c, "~90% REJECTED AT ONTOLOGY", cx + 5, l1_bot + 5, GOLD, HexColor("#0a0a0a"), h=10, size=5.5, bold=True)

    # L2: Universe Intersection
    l2_h = body_h - l1_h - gap - 2
    _focus_section(c,
        "LAYER 2 — UNIVERSE INTERSECTION TEST",
        CYAN, cx, l1_bot - gap, cw, l2_h,
        [
            ("\u25cf", "Causal chain must terminate at an investable TRADEABLE_ASSET.", CYAN, True),
            ("\u25e6", "Check: does any node in chain exist in universe.py?", WHITE_DIM, False),
            ("\u25e6", "Universe: VLO, DAL, ICE_GASOIL, EU_UTILITIES, BRENT_CRUDE,", WHITE_DIM, False),
            ("\u25e6", "  XLE, SPX, equity_index_short, equity_vol_long, duration_short.", WHITE_DIM, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "Example: 'Drought in Kazakhstan -> Kazakh wheat prices'", WHITE_DIM, False),
            ("\u25e6", "  -> Ontology pass (CONSTRAINS_SUPPLY_OF), Universe FAIL.", RED, False),
            ("\u25e6", "  Kazakhstan wheat not in universe. Entire chain dropped.", RED, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "Example: 'Ras Tanura strike -> Saudi crude output'", WHITE_DIM, False),
            ("\u25e6", "  -> CONSTRAINS_SUPPLY_OF -> BRENT_CRUDE in universe.", GREEN, False),
            ("\u25e6", "  Chain passes. Proceeds to Layer 3.", GREEN, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "This gate is computationally free: simple set membership check.", AMBER, False),
        ])

    # ── CENTRE COLUMN: L3 + L4 ───────────────────────────────────────────────
    cx, cw = xs[1], col_w[1]

    # L3: Thesis Briefs
    l3_h = 240
    l3_bot = _focus_section(c,
        "LAYER 3 — INVESTMENT THESIS BRIEFS  (focus_briefs.yaml)",
        AMBER, cx, body_top, cw, l3_h,
        [
            ("\u25cf", "This is the most powerful focus mechanism in the system.", AMBER, True),
            ("\u25e6", "Each active research brief declares exactly what it watches.", WHITE_DIM, False),
            ("\u25e6", "Agent A filters incoming news against active_briefs.", WHITE_DIM, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "focus_briefs.yaml structure:", GOLD, True),
            ("\u25e6", "active_briefs:", CYAN, False),
            ("\u25e6", "  - id: IRAN_WAR_SUPPLY_SHOCK", CYAN, False),
            ("\u25e6", "    watch_nodes:", CYAN, False),
            ("\u25e6", "      - Strait_of_Hormuz", CYAN, False),
            ("\u25e6", "      - Ras_Tanura_Terminal", CYAN, False),
            ("\u25e6", "      - AIS_tanker_transit", CYAN, False),
            ("\u25e6", "    watch_edge_types:", CYAN, False),
            ("\u25e6", "      - CONSTRAINS_SUPPLY_OF", CYAN, False),
            ("\u25e6", "      - DISRUPTS_INFRASTRUCTURE_OF", CYAN, False),
            ("\u25e6", "    universe_targets: [VLO, DAL, ICE_GASOIL, EU_UTILITIES]", CYAN, False),
            ("\u25e6", "    regime_relevant: [STAGFLATION_RISK, RISK_OFF]", CYAN, False),
            ("\u25e6", "    min_novelty_score: 0.3", CYAN, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "A news item must match at least one active brief's watch_nodes", WHITE_DIM, False),
            ("\u25e6", "  OR watch_edge_types to proceed beyond Layer 3.", WHITE_DIM, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "Brief discipline forces PM to pre-commit research questions.", AMBER, True),
            ("\u25e6", "Run 3-5 briefs maximum. Each brief = an investable hypothesis.", WHITE_DIM, False),
            ("\u25e6", "Trump tariff -> add TRADE_POLICY brief. Iran war -> add IRAN brief.", WHITE_DIM, False),
            ("\u25e6", "Brief creation itself is the focus decision. Everything else follows.", WHITE_DIM, False),
        ])
    pill(c, "BRIEF MATCH REQUIRED", cx + 5, l3_bot + 5, AMBER_DIM, AMBER, h=10, size=5.5, bold=True)

    # L4: Regime-conditional attention
    l4_h = body_h - l3_h - gap - 2
    _focus_section(c,
        "LAYER 4 — REGIME-CONDITIONAL ATTENTION",
        ORANGE, cx, l3_bot - gap, cw, l4_h,
        [
            ("\u25cf", "Active regime determines which edge types to suppress.", ORANGE, True),
            ("\u25e6", "RegimeClassifier.classify() returns current regime.", WHITE_DIM, False),
            ("\u25e6", "Each regime has an attention_suppress list in regimes.yaml.", WHITE_DIM, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "Example — STAGFLATION_RISK regime suppresses:", WHITE_DIM, False),
            ("\u25e6", "  CREATES_DEMAND_FOR (growth-driven demand signals irrelevant).", RED, False),
            ("\u25e6", "  ALTERS_RISK_APPETITE_FOR (risk appetite already OFF, stable).", RED, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "STAGFLATION_RISK elevates:", WHITE_DIM, False),
            ("\u25e6", "  CONSTRAINS_SUPPLY_OF (core supply-shock mechanism).", GREEN, False),
            ("\u25e6", "  INCREASES_COST_OF (inflation pass-through).", GREEN, False),
            ("\u25e6", "  CAUSES_POLICY_SHIFT_IN (rate path re-pricing).", GREEN, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "Trump Truth Social post (D23) — Layer 4 failure example:", AMBER, False),
            ("\u25e6", "  narrative_sensitive=True, physical edge narrative_sensitive=False.", WHITE_DIM, False),
            ("\u25e6", "  DP07: narrative ≠ physical update. Post suppressed. NO ACTION.", WHITE_DIM, False),
        ])

    # ── RIGHT COLUMN: L5 + conclusion ─────────────────────────────────────────
    cx, cw = xs[2], col_w[2]

    # L5: Graph budget
    l5_h = 220
    l5_bot = _focus_section(c,
        "LAYER 5 — GRAPH DEPTH BUDGET",
        RED, cx, body_top, cw, l5_h,
        [
            ("\u25cf", "Hard cap on live edges in the graph.", RED, True),
            ("\u25e6", "mandate_global_alloc.yaml:", WHITE_DIM, False),
            ("\u25e6", "  max_active_edges: 30", CYAN, False),
            ("\u25e6", "  min_wt_to_retain: 0.015", CYAN, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "Pruning logic (run after every update):", WHITE_DIM, False),
            ("\u25e6", "  1. Compute Wt for all edges.", WHITE_DIM, False),
            ("\u25e6", "  2. Prune edges where Wt < 0.015.", RED, False),
            ("\u25e6", "  3. If remaining > 30, drop lowest Wt edges.", RED, False),
            ("\u25e6", "  4. Log pruned edges to event bus (immutable audit).", WHITE_DIM, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "Decay naturally retires stale edges:", WHITE_DIM, False),
            ("\u25e6", "  LIQUIDITY_STRESS: t_half=7d. Gone in ~3 weeks.", WHITE_DIM, False),
            ("\u25e6", "  SUPPLY_FLOW:      t_half=14d. Gone in ~6 weeks.", WHITE_DIM, False),
            ("\u25e6", "  COST:             t_half=45d.", WHITE_DIM, False),
            ("\u25e6", "  POLICY:           t_half=180d.", WHITE_DIM, False),
            ("\u25e6", "  INFRASTRUCTURE:   t_half=1825d (5yr).", WHITE_DIM, False),
            ("", "", WHITE_DIM, False),
            ("\u25cf", "Budget enforces opportunity cost: new edge vs retained edge.", AMBER, True),
            ("\u25e6", "Forces analyst to confirm or retire vs add new.", WHITE_DIM, False),
        ])
    pill(c, "MAX 30 LIVE EDGES", cx + 5, l5_bot + 5, RED, HexColor("#ffaaaa"), h=10, size=5.5, bold=True)

    # Conclusion card
    conc_h = body_h - l5_h - gap - 2
    conc_items = [
        ("\u2605", "ANSWER: Focus is a governance decision, not a filter.", GOLD, True),
        ("", "", WHITE_DIM, False),
        ("\u25e6", "PM writes 3-5 focus_briefs.yaml entries = the 'research agenda'.", WHITE_DIM, False),
        ("\u25e6", "Only events matching an active brief get LLM extraction.", WHITE_DIM, False),
        ("\u25e6", "Ontology blocks ~90% before the brief even runs.", WHITE_DIM, False),
        ("\u25e6", "Universe intersection drops chains with no investable endpoint.", WHITE_DIM, False),
        ("\u25e6", "Regime gate suppresses irrelevant mechanism types.", WHITE_DIM, False),
        ("\u25e6", "Graph budget (30 edges) enforces hard scarcity.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("\u25cf", "Practical daily workflow:", AMBER, True),
        ("\u25e6", "8am: Review active briefs. Add/remove if thesis changes.", WHITE_DIM, False),
        ("\u25e6", "Intraday: System auto-routes news through 5 layers.", WHITE_DIM, False),
        ("\u25e6", "On regime shift: Layer 4 gate re-tunes automatically.", WHITE_DIM, False),
        ("\u25e6", "Weekly: Audit retained edges. Confirm or retire.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("\u25cf", "Key insight: The 100s of influences still ENTER at L1.", CYAN, True),
        ("\u25e6", "They are rejected in microseconds by cheap filters.", WHITE_DIM, False),
        ("\u25e6", "Claude API only sees the ~1% that cleared all 5 layers.", WHITE_DIM, False),
        ("\u25e6", "This makes the system economically viable at scale.", WHITE_DIM, False),
    ]
    _focus_section(c, "ANSWER  \u2014  PRACTICAL FOCUS PROTOCOL",
        GREEN, cx, l5_bot - gap, cw, conc_h, conc_items, bg=HexColor("#0d1a0d"))

    # ── Bottom spine: summary of the 5 layers ─────────────────────────────────
    spine_y = 28
    spine_h = 24
    filled_rect(c, 0, spine_y, PW, spine_h, SPINE_BG)
    divider(c, 0, spine_y + spine_h, PW, GOLD, 1.2)

    layers_summary = [
        ("L1 ONTOLOGY", "7 edge types  ~90% news rejected", GOLD),
        ("L2 UNIVERSE", "Must reach investable asset", CYAN),
        ("L3 THESIS BRIEF", "focus_briefs.yaml  3-5 active briefs", AMBER),
        ("L4 REGIME GATE", "Suppress irrelevant mechanisms", ORANGE),
        ("L5 GRAPH BUDGET", "30 edges max  min_wt=0.015", RED),
        ("RESULT", "~1% of signals become graph edges", GREEN),
    ]
    sw2 = (PW - 20) / len(layers_summary)
    lx = 10
    for (title, sub, col) in layers_summary:
        txt(c, title, lx + 3, spine_y + 15, 5.5, col, True)
        txt(c, sub,   lx + 3, spine_y + 7,  4.5, WHITE_DIM)
        if (title, sub, col) != layers_summary[-1]:
            c.setStrokeColor(WHITE_FAINT)
            c.setLineWidth(0.3)
            c.line(lx + sw2 - 3, spine_y + 5, lx + sw2 - 3, spine_y + spine_h - 5)
        lx += sw2

    c.save()
    print(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# PDF 4: THEME MANAGEMENT & DISCOVERY
# ─────────────────────────────────────────────────────────────────────────────

def _th(c, title, color, x, y, w, h, rows, bg=CARD_BG):
    """Theme-PDF card: title bar + rows of (bullet, text, color, bold)."""
    bordered_rect(c, x, y - h, w, h, bg, color, 1.4, 3)
    txt(c, title, x + 5, y - 10, 6.5, color, True)
    divider(c, x + 3, y - 14, w - 6, color)
    cy = y - 22
    for (bul, line, col, bold) in rows:
        if cy < y - h + 5:
            break
        fn = "Helvetica-Bold" if bold else "Helvetica"
        c.setFont(fn, 5.5)
        c.setFillColor(col)
        prefix = bul + "  " if bul else "   "
        # simple word-wrap
        words = (prefix + line).split()
        buf = ""
        for word in words:
            test = (buf + " " + word).strip()
            if c.stringWidth(test, fn, 5.5) <= w - 10:
                buf = test
            else:
                if cy < y - h + 5:
                    break
                c.drawString(x + 5, cy, buf)
                cy -= 8
                buf = "    " + word   # indent continuation
        if buf and cy >= y - h + 5:
            c.drawString(x + 5, cy, buf)
            cy -= 8
    return y - h   # bottom of card


def _code_block(c, lines, x, y, w, color=CYAN):
    """Monospace code block."""
    filled_rect(c, x, y - len(lines) * 8 - 6, w, len(lines) * 8 + 6, HexColor("#0d1a0d"))
    cy = y - 8
    for line in lines:
        c.setFont("Courier", 5)
        c.setFillColor(color)
        c.drawString(x + 4, cy, line)
        cy -= 7.5
    return y - len(lines) * 8 - 6


def build_themes_pdf(path):
    """
    Single A3-landscape page: Theme Management & Discovery technical reference.
    Covers: focus_briefs.yaml, manage_briefs.py CLI, ThemeScanner two-tier
    architecture, scan_themes.py, and price orphan detection.
    """
    c = canvas.Canvas(path, pagesize=landscape(A3))
    c.setTitle("DCKG: Theme Management & Discovery")
    c.setAuthor("DCKG System")

    filled_rect(c, 0, 0, PW, PH, BG)

    # ── Header ────────────────────────────────────────────────────────────────
    hh = 36
    filled_rect(c, 0, PH - hh, PW, hh, HEADER_BG)
    txt(c, "DYNAMIC CAUSAL KNOWLEDGE GRAPH  \xb7  THEME MANAGEMENT & DISCOVERY",
        14, PH - 14, 11, GOLD, True)
    txt(c, "How to update active research themes and automatically detect new emerging ones",
        14, PH - 26, 7.5, WHITE_DIM)
    txt_right(c, "11 April 2026  \xb7  DCKG v1.0", PW - 10, PH - 14, 6.5, AMBER)
    txt_right(c, "config/focus_briefs.yaml  |  manage_briefs.py  |  theme_scanner.py", PW - 10, PH - 26, 6, CYAN)
    divider(c, 0, PH - hh, PW, GOLD, 1.5)

    # ── Flow diagram strip ─────────────────────────────────────────────────────
    flow_y = PH - hh - 20
    filled_rect(c, 0, flow_y - 16, PW, 16, BG2)

    stages = [
        ("ALL NEWS", GREY),
        ("BRIEF FILTER", AMBER),
        ("MATCHED  ->  Claude API", CYAN),
        ("DROPPED  ->  ThemeScanner", ORANGE),
        ("Velocity Scan (free)", GREEN),
        ("Semantic Scan (1 API call)", GREEN),
        ("Candidate Brief YAML", GOLD),
        ("manage_briefs.py activate", GOLD),
    ]
    sw = (PW - 20) / len(stages)
    sx = 10
    for i, (label, col) in enumerate(stages):
        filled_rect(c, sx, flow_y - 15, sw - 2, 13, HexColor("#1a1a1a"), col, 0.7, 2)
        txt_center(c, label, sx + (sw - 2) / 2, flow_y - 9, 4.5, col, True)
        if i < len(stages) - 1:
            arrow_right(c, sx + sw - 2, flow_y - 9, col)
        sx += sw

    # ── Body: 3 columns ───────────────────────────────────────────────────────
    body_top = flow_y - 18
    body_bot = 54
    margin = 8
    gap = 6
    col_w = [290, 300, PW - 290 - 300 - 3 * margin - 2 * gap]
    xs = [margin,
          margin + col_w[0] + gap,
          margin + col_w[0] + gap + col_w[1] + gap]

    # ══════════════════════════════════════════════════════
    # LEFT COLUMN: focus_briefs.yaml + manage_briefs CLI
    # ══════════════════════════════════════════════════════
    cx, cw = xs[0], col_w[0]
    cy = body_top

    # Section label
    section_label(c, "UPDATING THEMES", cx, cy - 13, cw)
    cy -= 15

    # Card 1: focus_briefs.yaml explained
    h1 = 168
    _th(c, "config/focus_briefs.yaml  --  the research agenda file", AMBER,
        cx, cy, cw, h1,
        [
        ("*", "Single YAML file controls what the system pays attention to.", AMBER, True),
        ("", "", WHITE_DIM, False),
        (">", "Each entry declares one investable thesis:", WHITE_DIM, False),
        ("", "id: IRAN_WAR_SUPPLY_SHOCK", CYAN, False),
        ("", "name: Iran Crisis -- Energy Supply Shock", CYAN, False),
        ("", "active: true", CYAN, False),
        ("", "watch_keywords: [hormuz, tanker, ras tanura, gasoil crack ...]", CYAN, False),
        ("", "watch_nodes: [Hormuz_Closure, AIS_Tanker_Transit ...]", CYAN, False),
        ("", "watch_edge_types: [CONSTRAINS_SUPPLY_OF, INCREASES_COST_OF ...]", CYAN, False),
        ("", "universe_targets: [VLO, DAL, ICE_GASOIL, EU_UTILITIES]", CYAN, False),
        ("", "min_novelty_score: 0.20", CYAN, False),
        ("", "graph_priority: 1", CYAN, False),
        ("", "", WHITE_DIM, False),
        (">", "Two-stage gate around every Claude API call:", WHITE_DIM, False),
        ("", "Stage 1 (pre-LLM): keyword scan of raw text.", WHITE_DIM, False),
        ("", "  No keyword match -> DROPPED. Zero API cost.", RED, False),
        ("", "Stage 2 (post-LLM): node/edge check on extracted claim.", WHITE_DIM, False),
        ("", "  Claim not in watch_nodes or watch_edge_types -> DROPPED.", RED, False),
        ("", "", WHITE_DIM, False),
        (">", "Run 3-5 active briefs at any one time.", AMBER, True),
        ("", "Brief creation IS the focus decision. Everything else follows.", WHITE_DIM, False),
        ])
    cy -= h1 + gap

    # Card 2: Today's 3 active briefs
    h2 = 90
    _th(c, "TODAY'S ACTIVE BRIEFS  (11 April 2026)", GOLD,
        cx, cy, cw, h2,
        [
        ("[1]", "IRAN_WAR_SUPPLY_SHOCK -- 28 keywords -- VLO, DAL, ICE_GASOIL, EU_UTILITIES", GOLD, True),
        ("", "Hormuz, Ras Tanura, AIS, ceasefire, gasoil crack, jet fuel, stagflation ...", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("[2]", "PRIVATE_CREDIT_STRESS -- 33 keywords -- duration_short, eq_idx_short", ORANGE, True),
        ("", "CLO, BDC, leveraged loan, covenant breach, NAV mark, maturity wall ...", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("[3]", "AI_DISRUPTION -- 41 keywords -- XLE, EU_UTILITIES, equity_vol_long", CYAN, True),
        ("", "Nvidia, Blackwell, hyperscaler, data centre, GPU, inference demand ...", WHITE_DIM, False),
        ])
    cy -= h2 + gap

    # Card 3: manage_briefs.py CLI
    h3 = body_top - h1 - h2 - 15 - gap * 3 - body_bot
    _th(c, "manage_briefs.py  --  CLI for daily brief management", GREEN,
        cx, cy, cw, h3,
        [
        ("$", "python scripts/manage_briefs.py list", GREEN, True),
        ("", "Shows all active/inactive briefs with keyword counts and targets.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("$", "python scripts/manage_briefs.py test \"headline text here\"", GREEN, True),
        ("", "Dry-run: which briefs match? Would this reach Claude API?", WHITE_DIM, False),
        ("", "Example: 'Hormuz closure confirmed' -> PASS (IRAN brief, 2 kw hits).", CYAN, False),
        ("", "Example: 'Australian wheat harvest' -> DROPPED (no brief match).", RED, False),
        ("", "", WHITE_DIM, False),
        ("$", "python scripts/manage_briefs.py activate BRIEF_ID", GREEN, True),
        ("$", "python scripts/manage_briefs.py deactivate BRIEF_ID", GREEN, False),
        ("", "Moves brief between active_briefs and inactive_briefs.", WHITE_DIM, False),
        ("", "Inactive briefs are archived but auditable.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("$", "python scripts/manage_briefs.py add --id TARIFF_WAR \\", GREEN, True),
        ("", "  --name 'Trump Tariff Escalation' \\", GREEN, False),
        ("", "  --keywords 'tariff,trade war,section 232' \\", GREEN, False),
        ("", "  --targets 'XLE,equity_index_short'", GREEN, False),
        ("", "Adds a new brief. Set active: true to start routing news.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("$", "python scripts/manage_briefs.py remove BRIEF_ID", RED, False),
        ("", "Permanently deletes. Prefer deactivate for audit trail.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        (">", "After editing focus_briefs.yaml, call agent.reload_briefs()", AMBER, False),
        ("", "to pick up changes without restarting the process.", WHITE_DIM, False),
        ])

    # ══════════════════════════════════════════════════════
    # CENTRE COLUMN: ThemeScanner architecture
    # ══════════════════════════════════════════════════════
    cx, cw = xs[1], col_w[1]
    cy = body_top

    section_label(c, "DISCOVERING NEW THEMES", cx, cy - 13, cw)
    cy -= 15

    # Card: ThemeScanner overview
    h_overview = 62
    _th(c, "ThemeScanner  --  pillar1_perception/theme_scanner.py", CYAN,
        cx, cy, cw, h_overview,
        [
        ("*", "Accumulates all texts DROPPED by brief filter (Layer 3a).", CYAN, True),
        ("*", "Auto-wired: agent.extract() feeds dropped texts automatically.", WHITE_DIM, False),
        ("*", "No configuration needed. Runs silently in the background.", WHITE_DIM, False),
        (">", "Query at any time:", WHITE_DIM, False),
        ("", "scanner = agent.theme_scanner", CYAN, False),
        ("", "hits = scanner.scan_velocity()     # free, instant", CYAN, False),
        ("", "candidates = scanner.scan_semantic()  # 1 API call", CYAN, False),
        ],
        bg=HexColor("#001a1a"))
    cy -= h_overview + gap

    # Card: Tier 1 velocity
    h_t1 = 150
    _th(c, "TIER 1 -- Keyword Velocity Scan  (free, no API call)", GREEN,
        cx, cy, cw, h_t1,
        [
        ("*", "Compares keyword frequency in recent 100 texts vs prior 100.", GREEN, True),
        ("*", "Surfaces phrases with velocity ratio >= 2.5x baseline.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        (">", "Algorithm:", WHITE_DIM, False),
        ("", "1. Tokenise dropped texts -> unigrams + bigrams.", WHITE_DIM, False),
        ("", "2. Count frequency in recent window vs baseline window.", WHITE_DIM, False),
        ("", "3. Normalise to per-100-texts rate.", WHITE_DIM, False),
        ("", "4. Flag phrases where recent/baseline >= 2.5x.", WHITE_DIM, False),
        ("", "5. Cluster co-occurring phrases via Jaccard similarity.", WHITE_DIM, False),
        ("", "6. Output VelocityCandidate objects with example texts.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        (">", "Real example (Chile copper supply shock simulation):", AMBER, False),
        ("", "'copper'  recent=23  baseline=0  ratio=115x", GOLD, False),
        ("", "'chile'   recent=17  baseline=0  ratio=85x", GOLD, False),
        ("", "'chile drought'  recent=8  ratio=40x", GOLD, False),
        ("", "e.g. 'Codelco production falls 8% amid Chile drought'", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        (">", "Requires: buffer >= 200 texts for reliable comparison.", WHITE_DIM, False),
        ("*", "Detects: supply shocks, new geopolitical actors, company names.", WHITE_DIM, False),
        ("*", "Cost: zero. Latency: instant.", GREEN, True),
        ])
    cy -= h_t1 + gap

    # Card: Tier 2 semantic
    h_t2 = 148
    _th(c, "TIER 2 -- Semantic Theme Scan  (1 Claude API call/day)", AMBER,
        cx, cy, cw, h_t2,
        [
        ("*", "Sends up to 80 dropped texts to Claude in one batch.", AMBER, True),
        ("*", "Asks Claude to identify investable causal themes hidden in the pile.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        (">", "Claude's task:", WHITE_DIM, False),
        ("", "Find themes with: (1) clear causal mechanism, (2) link to tradeable", WHITE_DIM, False),
        ("", "asset, (3) recurrence across multiple texts.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        (">", "Returns structured JSON per theme:", WHITE_DIM, False),
        ("", "{ id, name, description, watch_keywords[8-15],", CYAN, False),
        ("", "  universe_targets, primary_edge_type, confidence,", CYAN, False),
        ("", "  key_evidence[1-3 text excerpts] }", CYAN, False),
        ("", "", WHITE_DIM, False),
        (">", "Catches themes Tier 1 misses:", WHITE_DIM, False),
        ("", "Latent causal logic spread across different vocabulary.", WHITE_DIM, False),
        ("", "E.g. 'semiconductor lead times' + 'TSMC capacity' + 'chip prices'", WHITE_DIM, False),
        ("", "may share no common keyword but describe one theme.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("*", "Cost: ~$0.05-0.10 per scan.  Run: daily at market close.", AMBER, True),
        ("*", "Output: CandidateBrief.to_yaml_block() -> paste into focus_briefs.yaml.", WHITE_DIM, False),
        ])
    cy -= h_t2 + gap

    # Card: Tier 3 price orphans
    h_t3 = body_top - h_overview - h_t1 - h_t2 - 15 - gap * 4 - body_bot
    _th(c, "TIER 3 -- Price Orphan Detection  (free, intraday)", RED,
        cx, cy, cw, h_t3,
        [
        ("*", "Flags universe assets with large moves and NO active causal edge.", RED, True),
        ("", "These are themes already moving markets but invisible to DCKG.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        (">", "Input: today's returns + graph_store active edge targets.", WHITE_DIM, False),
        ("", "ThemeScanner.find_price_orphans(universe_returns, active_targets)", CYAN, False),
        ("", "", WHITE_DIM, False),
        (">", "Detection logic:", WHITE_DIM, False),
        ("", "If returns_history available: flag |z-score| >= 2.0 sigma.", WHITE_DIM, False),
        ("", "Fallback: flag |return| >= 3% with no graph explanation.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("*", "Action: investigate each orphan. Add a brief if structural.", AMBER, True),
        ])

    # ══════════════════════════════════════════════════════
    # RIGHT COLUMN: scan_themes.py CLI + workflow
    # ══════════════════════════════════════════════════════
    cx, cw = xs[2], col_w[2]
    cy = body_top

    section_label(c, "RUNNING THE SCANNER", cx, cy - 13, cw)
    cy -= 15

    # Card: scan_themes CLI
    h_cli = 220
    _th(c, "scan_themes.py  --  discovery CLI", GREEN,
        cx, cy, cw, h_cli,
        [
        ("$", "Velocity scan (free):", GREEN, True),
        ("", "python scripts/scan_themes.py velocity \\", GREEN, False),
        ("", "  --input todays_headlines.txt", GREEN, False),
        ("", "Routes all texts through brief filter. Accumulates dropped.", WHITE_DIM, False),
        ("", "Prints velocity anomalies + candidate brief clusters.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("$", "Semantic scan (1 API call):", AMBER, True),
        ("", "python scripts/scan_themes.py semantic \\", AMBER, False),
        ("", "  --input todays_headlines.txt \\", AMBER, False),
        ("", "  --output candidates.yaml", AMBER, False),
        ("", "Same as velocity, then sends dropped pile to Claude.", WHITE_DIM, False),
        ("", "Writes YAML blocks ready to paste into focus_briefs.yaml.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("$", "Price orphan detection:", RED, True),
        ("", "python scripts/scan_themes.py orphans \\", RED, False),
        ("", "  --returns today_returns.csv \\", RED, False),
        ("", "  --graph-db dckg_events.db", RED, False),
        ("", "CSV format: asset_id,return  (e.g. VLO,0.04)", WHITE_DIM, False),
        ("", "Compares universe returns vs active graph edges.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("$", "Pipe from live feed:", GREEN, True),
        ("", "cat live_feed.txt | python scripts/scan_themes.py velocity", GREEN, False),
        ("", "", WHITE_DIM, False),
        ("$", "After reviewing candidates.yaml:", GOLD, True),
        ("", "python scripts/manage_briefs.py activate CANDIDATE_COPPER", GOLD, False),
        ])
    cy -= h_cli + gap

    # Card: daily workflow
    h_wf = body_top - h_cli - 15 - gap * 2 - body_bot
    _th(c, "DAILY WORKFLOW", GOLD,
        cx, cy, cw, h_wf,
        [
        ("8am", "Review active briefs.", GOLD, True),
        ("", "  python manage_briefs.py list", CYAN, False),
        ("", "  Add/remove briefs as thesis changes.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("Intraday", "System auto-routes news through 5 layers.", AMBER, True),
        ("", "  Matched -> Claude API -> graph update.", CYAN, False),
        ("", "  Dropped -> ThemeScanner buffer (silent).", ORANGE, False),
        ("", "  Test any headline:", WHITE_DIM, False),
        ("", "  python manage_briefs.py test 'headline...'", CYAN, False),
        ("", "", WHITE_DIM, False),
        ("4pm", "Velocity scan on day's dropped pile.", GREEN, True),
        ("", "  python scan_themes.py velocity --input feed.txt", CYAN, False),
        ("", "  Takes seconds. Flags velocity anomalies >= 2.5x.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("4:30pm", "Price orphan check.", RED, True),
        ("", "  python scan_themes.py orphans --returns eod.csv", CYAN, False),
        ("", "  Any asset >3% with no graph edge -> investigate.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        ("Weekly", "Semantic scan over week's dropped pile.", AMBER, True),
        ("", "  python scan_themes.py semantic --input week.txt \\", CYAN, False),
        ("", "    --output candidates.yaml", CYAN, False),
        ("", "  Review candidates.yaml. Activate promising briefs.", WHITE_DIM, False),
        ("", "", WHITE_DIM, False),
        (">", "Key property: DROPPED != IGNORED.", GOLD, True),
        ("", "Every dropped text feeds the discovery engine.", WHITE_DIM, False),
        ("", "The system learns what it doesn't know.", GREEN, False),
        ],
        bg=HexColor("#0d1400"))

    # ── Bottom spine ──────────────────────────────────────────────────────────
    spine_y = 28
    spine_h = 24
    filled_rect(c, 0, spine_y, PW, spine_h, SPINE_BG)
    divider(c, 0, spine_y + spine_h, PW, GOLD, 1.2)

    spine_items = [
        ("focus_briefs.yaml", "Single file = research agenda", GOLD),
        ("manage_briefs.py", "list / activate / deactivate / add / test", AMBER),
        ("ThemeScanner (T1)", "Velocity: free, keyword ratio >=2.5x", GREEN),
        ("ThemeScanner (T2)", "Semantic: 1 Claude call, ~$0.05/day", AMBER),
        ("ThemeScanner (T3)", "Price orphans: >3% move, no graph edge", RED),
        ("scan_themes.py", "CLI orchestrator for all three tiers", CYAN),
    ]
    sw2 = (PW - 20) / len(spine_items)
    lx = 10
    for (t, s, col) in spine_items:
        txt(c, t, lx + 3, spine_y + 15, 5.5, col, True)
        txt(c, s, lx + 3, spine_y + 7, 4.5, WHITE_DIM)
        if (t, s, col) != spine_items[-1]:
            c.setStrokeColor(WHITE_FAINT)
            c.setLineWidth(0.3)
            c.line(lx + sw2 - 3, spine_y + 4, lx + sw2 - 3, spine_y + spine_h - 4)
        lx += sw2

    c.save()
    print(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# PDF 5: ADMIN PANEL USER MANUAL  (4 pages, A3 landscape)
# ─────────────────────────────────────────────────────────────────────────────

# Manual uses larger, more readable type than dashboards.
# Helper palette aliases for clarity inside the manual functions.
M_BG    = BG
M_CARD  = HexColor("#141414")
M_CARD2 = HexColor("#1c1c1c")
M_HDR   = HexColor("#0d0d0d")

def _man_page_frame(c, page_num, total_pages, page_title, subtitle=""):
    """Draw the standard header and footer used on every manual page."""
    # Full page background
    filled_rect(c, 0, 0, PW, PH, M_BG)

    # Header band
    hh = 42
    filled_rect(c, 0, PH - hh, PW, hh, M_HDR)
    divider(c, 0, PH - hh, PW, GOLD, 1.5)

    txt(c, "DCKG", 14, PH - 14, 13, GOLD, True)
    txt(c, "Admin Panel  \xb7  User Manual", 52, PH - 14, 10, WHITE_DIM)
    txt(c, page_title, 14, PH - 28, 8.5, WHITE, True)
    if subtitle:
        txt(c, subtitle, 14, PH - 38, 7, WHITE_DIM)
    txt_right(c, f"Page {page_num} of {total_pages}", PW - 14, PH - 14, 7, WHITE_DIM)
    txt_right(c, "http://localhost:8000/admin", PW - 14, PH - 26, 7, CYAN)
    txt_right(c, "DCKG v1.0  \xb7  11 April 2026", PW - 14, PH - 37, 6.5, WHITE_DIM)

    # Footer band
    fh = 20
    filled_rect(c, 0, 0, PW, fh, M_HDR)
    divider(c, 0, fh, PW, WHITE_FAINT, 0.4)
    txt(c, "PROPRIETARY  \xb7  Internal use only  \xb7  Dynamic Causal Knowledge Graph Administration Manual",
        14, 7, 6, WHITE_DIM)
    txt_right(c, "DCKG System  \xb7  Pillar 1 Perception", PW - 14, 7, 6, WHITE_DIM)


def _mbox(c, x, y, w, h, title, title_color, body_lines, bg=M_CARD,
          number=None, step_color=None):
    """
    Manual content box: coloured left-border accent, title, body text.
    body_lines: list of (indent_level 0|1|2, text, color)
    Returns bottom y of the box.
    """
    accent_w = 3
    # Background
    filled_rect(c, x, y - h, w, h, bg)
    # Left accent
    filled_rect(c, x, y - h, accent_w, h, title_color)
    # Optional step number circle
    if number is not None:
        col = step_color or title_color
        filled_rect(c, x + 6, y - 16, 16, 16, col, radius=8)
        txt_center(c, str(number), x + 14, y - 10, 7, HexColor("#0a0a0a"), True)
        txt(c, title, x + 26, y - 10, 7.5, title_color, True)
        cy = y - 22
    else:
        txt(c, title, x + 8, y - 10, 7.5, title_color, True)
        cy = y - 22

    # Thin rule under title
    divider(c, x + accent_w + 2, y - 14, w - accent_w - 4, title_color)

    # Body lines
    for (indent, text, color) in body_lines:
        if cy < y - h + 4:
            break
        fn_bold = text.startswith("**") and text.endswith("**")
        clean = text.strip("*")
        xoff = x + accent_w + 6 + indent * 10
        fn = "Helvetica-Bold" if fn_bold else "Helvetica"
        fs = 7
        c.setFont(fn, fs)
        c.setFillColor(color)
        # word-wrap within box
        max_w = w - (xoff - x) - 8
        words = clean.split()
        buf = ""
        for word in words:
            test = (buf + " " + word).strip()
            if c.stringWidth(test, fn, fs) <= max_w:
                buf = test
            else:
                if cy < y - h + 4:
                    break
                c.drawString(xoff, cy, buf)
                cy -= 9.5
                buf = word
        if buf and cy >= y - h + 4:
            c.drawString(xoff, cy, buf)
            cy -= 9.5

    return y - h  # bottom of box


def _mcode(c, x, y, w, lines, title=None, color=CYAN):
    """Monospace code/command block with optional label."""
    h = len(lines) * 9 + (16 if title else 8)
    filled_rect(c, x, y - h, w, h, HexColor("#0d1a0d"))
    filled_rect(c, x, y - h, 3, h, color)
    iy = y - (16 if title else 8)
    if title:
        txt(c, title, x + 8, y - 9, 6, color, True)
        divider(c, x + 3, y - 12, w - 3, color, 0.4)
    for line in lines:
        c.setFont("Courier", 6.5)
        c.setFillColor(color)
        c.drawString(x + 8, iy, line)
        iy -= 9
    return y - h


def _mpill(c, label, x, y, bg_col, fg_col=None, w=None):
    fg = fg_col or WHITE
    fn = "Helvetica-Bold"
    c.setFont(fn, 6)
    tw = c.stringWidth(label, fn, 6)
    pw2 = w or tw + 8
    filled_rect(c, x, y - 2, pw2, 11, bg_col, radius=3)
    c.setFillColor(fg)
    c.drawCentredString(x + pw2 / 2, y + 3, label)
    return pw2


def _msection_label(c, x, y, text, color):
    """Bold section header with colour underline."""
    txt(c, text, x, y, 9, color, True)
    divider(c, x, y - 3, 200, color, 1.2)


# ── PAGE 1: Overview & Navigation ────────────────────────────────────────────

def _man_page1(c):
    _man_page_frame(c, 1, 4, "Overview & Navigation",
                    "What the admin panel does and how to navigate it")

    body_top = PH - 46
    body_bot = 22
    margin = 16
    gap = 12

    # ── Left column: intro + access ──────────────────────────────────────────
    cx, cw = margin, 340
    cy = body_top

    _msection_label(c, cx, cy, "WHAT IS THE ADMIN PANEL?", GOLD)
    cy -= 10

    cy = _mbox(c, cx, cy, cw, 115, "Purpose", GOLD,
        [(0, "The DCKG Admin Panel is a browser-based interface for managing the system's", WHITE_DIM),
         (0, "research agenda and monitoring live system status. It sits on top of the", WHITE_DIM),
         (0, "DCKG API and controls three things:", WHITE_DIM),
         (0, "", WHITE_DIM),
         (1, "1.  Which topics the system pays attention to (Focus Briefs)", AMBER),
         (1, "2.  How new emerging themes are automatically detected (Discovery)", GREEN),
         (1, "3.  Core risk parameters and live portfolio/graph status (Settings)", CYAN),
         (0, "", WHITE_DIM),
         (0, "Changes made here take effect immediately — no restart required.", WHITE),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 90, "Starting the Server", CYAN,
        [(0, "Run this command from the DCKG project root:", WHITE_DIM),
         (0, "", WHITE_DIM),
         (1, "python -m uvicorn api.main:app --port 8000", CYAN),
         (0, "", WHITE_DIM),
         (0, "Then open your browser to:", WHITE_DIM),
         (1, "http://localhost:8000/admin", CYAN),
         (0, "", WHITE_DIM),
         (0, "The green LIVE dot in the top-right confirms the API is responding.", GREEN),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 68, "Status Bar", WHITE_DIM,
        [(0, "The dark bar at the bottom of the screen shows:", WHITE_DIM),
         (1, "Left:    Last action result (green = success, red = error)", WHITE_DIM),
         (1, "Right:   System info (test count, version, active brief count)", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "Messages auto-clear after 4 seconds.", WHITE_DIM),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, body_top - 115 - 90 - 68 - 22 - gap * 4, "Key Principle", AMBER,
        [(0, "**The brief filter is the most important control in the system.**", AMBER),
         (0, "", WHITE_DIM),
         (0, "Only news that matches an active brief is sent to the Claude API.", WHITE_DIM),
         (0, "Everything else is silently dropped — zero cost, zero noise.", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "The Discovery tab then watches the DROPPED pile for new themes.", GREEN),
         (0, "So nothing is truly ignored — dropped = monitored for patterns.", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "Run 3-5 active briefs at any one time. More than 8 dilutes focus.", AMBER),
        ])

    # ── Centre column: three-tab navigation diagram ───────────────────────────
    cx2 = margin + cw + gap
    cw2 = 480
    cy = body_top

    _msection_label(c, cx2, cy, "THREE-TAB NAVIGATION", CYAN)
    cy -= 10

    tab_specs = [
        ("TAB 1  \xb7  BRIEFS", AMBER,
         "Manage your active research agenda",
         [("LEFT PANEL",   "Active brief cards. Click to expand keywords. Deactivate or Delete.", AMBER),
          ("CENTRE PANEL", "Test a headline against active briefs. Quick-ingest batch of headlines.", CYAN),
          ("RIGHT PANEL",  "Add New Brief form. Fill in ID, name, keywords, targets.", GOLD),
         ]),
        ("TAB 2  \xb7  DISCOVERY", GREEN,
         "Detect emerging themes you haven't thought of yet",
         [("LEFT PANEL",   "Ingest news batch. Run Velocity Scan (free) or Semantic Scan (1 API call).", GREEN),
          ("CENTRE PANEL", "Velocity anomaly list: phrases with >2.5x baseline frequency.", CYAN),
          ("RIGHT PANEL",  "Candidate Briefs: one-click Activate as Brief. Price Orphan Detector.", GOLD),
         ]),
        ("TAB 3  \xb7  SETTINGS & STATUS", PURPLE,
         "Governance parameters and live system monitoring",
         [("LEFT PANEL",   "Edit mandate constraints and risk parameters. Decay class visual.", AMBER),
          ("CENTRE PANEL", "Current regime card. Active graph edges with Wt bars.", CYAN),
          ("RIGHT PANEL",  "Live activity feed: last 30 events, auto-refresh every 15 seconds.", GREEN),
         ]),
    ]

    tab_h = (body_top - body_bot - gap * 2) / 3

    for (tab_title, col, sub, panels) in tab_specs:
        # Tab card
        filled_rect(c, cx2, cy - tab_h, cw2, tab_h, M_CARD)
        filled_rect(c, cx2, cy - tab_h, 4, tab_h, col)
        txt(c, tab_title, cx2 + 10, cy - 11, 8.5, col, True)
        txt(c, sub, cx2 + 10, cy - 21, 7, WHITE_DIM)
        divider(c, cx2 + 4, cy - 24, cw2 - 4, col, 0.6)

        py = cy - 34
        for (panel_name, panel_desc, panel_col) in panels:
            # Panel label pill
            _mpill(c, panel_name, cx2 + 10, py, HexColor("#1a1a1a"), panel_col, w=80)
            txt(c, panel_desc, cx2 + 96, py, 7, WHITE_DIM)
            py -= 14
        cy -= tab_h + gap

    # ── Right column: quick reference ────────────────────────────────────────
    cx3 = cx2 + cw2 + gap
    cw3 = PW - cx3 - margin
    cy = body_top

    _msection_label(c, cx3, cy, "QUICK REFERENCE", WHITE_DIM)
    cy -= 10

    quick = [
        ("Add a new theme",         "Tab 1 \u2192 Right panel \u2192 Fill form \u2192 CREATE BRIEF", GOLD),
        ("Test a headline",         "Tab 1 \u2192 Centre \u2192 Paste text \u2192 TEST", CYAN),
        ("Pause a theme",           "Tab 1 \u2192 Brief card \u2192 Deactivate", AMBER),
        ("Resume a paused theme",   "Tab 1 \u2192 Inactive section \u2192 Activate", GREEN),
        ("Find new themes",         "Tab 2 \u2192 Ingest batch \u2192 Run Velocity Scan", GREEN),
        ("AI theme detection",      "Tab 2 \u2192 Ingest batch \u2192 Run Semantic Scan", PURPLE),
        ("Spot unexplained moves",  "Tab 2 \u2192 Price Orphan Detector", RED),
        ("Change position limits",  "Tab 3 \u2192 Left panel \u2192 Edit \u2192 SAVE", AMBER),
        ("See current regime",      "Tab 3 \u2192 Centre panel \u2192 Regime card", ORANGE),
        ("View live graph edges",   "Tab 3 \u2192 Centre panel \u2192 Active Graph Edges", CYAN),
        ("See recent events",       "Tab 3 \u2192 Right panel \u2192 Activity Feed", GREEN),
        ("Refresh status",          "Tab 3 \u2192 REFRESH button (top-right of centre)", WHITE_DIM),
    ]

    for (action, where, col) in quick:
        if cy < body_bot + 22:
            break
        filled_rect(c, cx3, cy - 22, cw3, 21, M_CARD2)
        filled_rect(c, cx3, cy - 22, 3, 21, col)
        txt(c, action, cx3 + 7, cy - 9, 6.5, WHITE, True)
        txt(c, where, cx3 + 7, cy - 18, 6, WHITE_DIM)
        cy -= 23


# ── PAGE 2: Tab 1 — Brief Management ─────────────────────────────────────────

def _man_page2(c):
    _man_page_frame(c, 2, 4, "Tab 1: Brief Management",
                    "Adding themes, testing headlines, activating and deactivating briefs")

    body_top = PH - 46
    body_bot = 22
    margin = 16
    gap = 10

    col_w = [340, 340, PW - 340 - 340 - 3 * margin - 2 * gap]
    xs = [margin, margin + col_w[0] + gap, margin + col_w[0] + gap + col_w[1] + gap]

    # ── COL 1: Adding a new brief ─────────────────────────────────────────────
    cx, cw = xs[0], col_w[0]
    cy = body_top

    _msection_label(c, cx, cy, "ADDING A NEW BRIEF", GOLD)
    cy -= 10

    steps = [
        ("Click the BRIEFS tab", GOLD,
         [(0, "The Add New Brief form is always visible in the right panel.", WHITE_DIM),
          (0, "You do not need to click anything to open it.", WHITE_DIM),
         ]),
        ("Enter the Brief ID", AMBER,
         [(0, "Must be UPPER_SNAKE_CASE, e.g.  TARIFF_WAR_2026", CYAN),
          (0, "No spaces or lowercase. At least 2 characters.", WHITE_DIM),
          (0, "The system rejects duplicate IDs across active and inactive briefs.", WHITE_DIM),
         ]),
        ("Enter a Name", WHITE,
         [(0, "Human-readable label, e.g. 'Trump Tariff Escalation'.", WHITE_DIM),
          (0, "This appears on the brief card and in status messages.", WHITE_DIM),
         ]),
        ("Add Watch Keywords (one per line)", CYAN,
         [(0, "These are case-insensitive substring matches against raw news text.", WHITE_DIM),
          (0, "Add 10-30 keywords. Think like a journalist writing the story:", WHITE_DIM),
          (1, "tariff,  trade war,  section 232,  reciprocal tariff,", CYAN),
          (1, "customs duty,  wto dispute,  import levy,  retaliatory", CYAN),
          (0, "Good keywords: specific proper nouns, technical terms, official names.", GREEN),
          (0, "Avoid: very common words (market, price, rate) that create false matches.", RED),
         ]),
        ("Set Universe Targets (comma-separated)", GREEN,
         [(0, "Which tradeable assets in the DCKG universe are affected?", WHITE_DIM),
          (0, "Available assets:  VLO,  DAL,  ICE_GASOIL,  EU_UTILITIES,", WHITE_DIM),
          (0, "  BRENT_CRUDE,  XLE,  SPX,  equity_index_short,", WHITE_DIM),
          (0, "  equity_vol_long,  duration_short", WHITE_DIM),
         ]),
        ("Click CREATE BRIEF", GOLD,
         [(0, "The brief immediately appears in the Active Briefs list.", GREEN),
          (0, "The brief filter reloads instantly — no restart needed.", WHITE_DIM),
          (0, "Test it immediately using the Test Headline panel (centre).", AMBER),
         ]),
    ]

    for i, (title, col, lines) in enumerate(steps):
        h = 14 + len(lines) * 10 + 6
        cy = _mbox(c, cx, cy, cw, h, title, col, lines, number=i+1) - 6

    # ── COL 2: Testing + Managing ─────────────────────────────────────────────
    cx, cw = xs[1], col_w[1]
    cy = body_top

    _msection_label(c, cx, cy, "TESTING A HEADLINE", CYAN)
    cy -= 10

    cy = _mbox(c, cx, cy, cw, 108, "How to test", CYAN,
        [(0, "Before ingesting real news, verify your brief keywords work:", WHITE_DIM),
         (0, "", WHITE_DIM),
         (1, "1.  Paste a headline into the text area (centre panel, Tab 1)", WHITE_DIM),
         (1, "2.  Click TEST AGAINST ACTIVE BRIEFS", CYAN),
         (1, "3.  Read the result:", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "PASS (green): text matched at least one active brief.", GREEN),
         (1, "Shows which brief(s) matched and the exact keywords that hit.", GREEN),
         (0, "DROP (red): no brief matched. Text would be silently discarded.", RED),
         (1, "Shows how many active briefs were checked.", RED),
         (0, "", WHITE_DIM),
         (0, "This costs nothing — no API call is made, ever, for this test.", AMBER),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 70, "What PASS and DROP mean for the live system", AMBER,
        [(0, "PASS:  text proceeds to Claude API extraction. Edge may be created.", GREEN),
         (0, "DROP:  text is silently discarded AND fed to ThemeScanner buffer.", ORANGE),
         (0, "", WHITE_DIM),
         (0, "Dropped texts are NOT ignored. They accumulate in the Discovery", WHITE_DIM),
         (0, "scanner and are analysed for emerging patterns. See Tab 2.", WHITE_DIM),
        ]) - gap

    _msection_label(c, cx, cy, "MANAGING EXISTING BRIEFS", AMBER)
    cy -= 10

    cy = _mbox(c, cx, cy, cw, 75, "Expanding a brief card", WHITE_DIM,
        [(0, "Click anywhere on a brief card to expand it.", WHITE_DIM),
         (0, "The card shows the first 12 watch keywords in monospace grey text.", WHITE_DIM),
         (0, "Click again to collapse.", WHITE_DIM),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 75, "Deactivating a brief", AMBER,
        [(0, "Click [Deactivate] on the brief card.", WHITE_DIM),
         (0, "The brief moves to the Inactive Briefs section (collapsed by default).", WHITE_DIM),
         (0, "It stops filtering news immediately. No data is lost.", AMBER),
         (0, "Reactivate it at any time — just click the toggle section and [Activate].", WHITE_DIM),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 75, "Deleting a brief permanently", RED,
        [(0, "Click [Delete] on the brief card.", WHITE_DIM),
         (0, "A confirmation dialog appears — you must confirm the deletion.", RED),
         (0, "The brief is permanently removed from focus_briefs.yaml.", RED),
         (0, "Prefer Deactivate over Delete to maintain an audit trail.", AMBER),
        ]) - gap

    # Remaining space: quick ingest
    h_qi = body_top - 108 - 70 - 75 - 75 - 75 - 12 - gap * 6 - body_bot
    _mbox(c, cx, cy, cw, h_qi, "Quick Ingest (batch routing)", GREEN,
        [(0, "Paste multiple headlines into the Quick Ingest text area (one per line).", WHITE_DIM),
         (0, "Click INGEST & ROUTE. The system shows:", WHITE_DIM),
         (1, "Ingested:          total lines processed", WHITE_DIM),
         (1, "Matched briefs:    texts that reached Claude API", GREEN),
         (1, "Dropped to scanner: texts added to ThemeScanner buffer", ORANGE),
         (1, "Buffer:            total texts in discovery buffer", CYAN),
         (0, "", WHITE_DIM),
         (0, "Use Quick Ingest for daily newsflow processing. Use Tab 2 Ingest for", WHITE_DIM),
         (0, "large batches specifically aimed at theme discovery.", WHITE_DIM),
        ])

    # ── COL 3: Best practices ─────────────────────────────────────────────────
    cx, cw = xs[2], col_w[2]
    cy = body_top

    _msection_label(c, cx, cy, "BEST PRACTICES", WHITE_DIM)
    cy -= 10

    tips = [
        ("Keep 3-5 active briefs", AMBER,
         [(0, "Focus is a governance decision. Brief creation IS the decision.", WHITE_DIM),
          (0, "More than 8 active briefs dilutes the signal — too much passes the filter.", WHITE_DIM),
          (0, "Deactivate resolved theses promptly.", AMBER),
         ]),
        ("Write specific keywords", CYAN,
         [(0, "Specific: 'hormuz', 'ras tanura', 'ais zero tankers'  (good)", GREEN),
          (0, "Generic: 'oil', 'energy', 'supply'  (creates too many false matches)", RED),
          (0, "Test with real headlines before activating.", WHITE_DIM),
         ]),
        ("Include node IDs in watch_nodes", GREEN,
         [(0, "After first articles are processed, add canonical node IDs used in the", WHITE_DIM),
          (0, "graph (e.g. Hormuz_Closure, AIS_Tanker_Transit) to watch_nodes in the", WHITE_DIM),
          (0, "YAML file. This enables the post-extraction brief filter.", WHITE_DIM),
         ]),
        ("Match min_novelty to thesis age", WHITE_DIM,
         [(0, "New thesis (week 1): min_novelty 0.20 (catch everything)", WHITE_DIM),
          (0, "Mature thesis (month 2+): min_novelty 0.35 (only genuinely new updates)", WHITE_DIM),
         ]),
        ("Review inactive briefs weekly", PURPLE,
         [(0, "Inactive does not mean deleted. Review them at the start of each week.", WHITE_DIM),
          (0, "Geopolitical theses can re-activate quickly (e.g. ceasefire breakdown).", WHITE_DIM),
         ]),
    ]
    for (title, col, lines) in tips:
        h = 14 + len(lines) * 10
        cy = _mbox(c, cx, cy, cw, h, title, col, lines) - gap

    # Brief ID rules box
    h_id = body_top - sum(14 + len(l)*10 for _,_,l in tips) - 12 - gap * (len(tips)+1) - body_bot
    if h_id > 40:
        _mcode(c, cx, cy, cw,
               ["VALID IDs:   IRAN_WAR_2026",
                "             PRIVATE_CREDIT_STRESS",
                "             AI_DISRUPTION",
                "             TARIFF_WAR",
                "             COPPER_CHILE_SUPPLY",
                "",
                "INVALID:     iran war  (spaces)",
                "             IranWar   (not UPPER_SNAKE)",
                "             A         (too short)",
                ],
               title="Brief ID Format Rules", color=CYAN)


# ── PAGE 3: Tab 2 — Discovery ─────────────────────────────────────────────────

def _man_page3(c):
    _man_page_frame(c, 3, 4, "Tab 2: Theme Discovery",
                    "Velocity scanning, semantic analysis, price orphan detection, activating candidates")

    body_top = PH - 46
    body_bot = 22
    margin = 16
    gap = 10

    col_w = [320, 330, PW - 320 - 330 - 3 * margin - 2 * gap]
    xs = [margin, margin + col_w[0] + gap, margin + col_w[0] + gap + col_w[1] + gap]

    # ── COL 1: Ingest + Velocity ──────────────────────────────────────────────
    cx, cw = xs[0], col_w[0]
    cy = body_top

    _msection_label(c, cx, cy, "HOW DISCOVERY WORKS", GREEN)
    cy -= 10

    cy = _mbox(c, cx, cy, cw, 78, "The core insight", GREEN,
        [(0, "Every text DROPPED by the brief filter is not discarded.", GREEN),
         (0, "It is fed into the ThemeScanner buffer automatically.", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "This creates a constantly-growing pile of 'things the system doesn't", WHITE_DIM),
         (0, "currently care about.' The Discovery tab analyses this pile for patterns", WHITE_DIM),
         (0, "that might be the next important thesis.", WHITE_DIM),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 55, "Scanner Buffer", CYAN,
        [(0, "The Scanner Status card at the top shows the current buffer size.", WHITE_DIM),
         (0, "Buffer fills automatically as news is routed through the system.", WHITE_DIM),
         (0, "Velocity scan needs >=200 texts (100 recent vs 100 baseline).", AMBER),
         (0, "Semantic scan works with as few as 10 texts.", GREEN),
        ]) - gap

    _msection_label(c, cx, cy, "STEP-BY-STEP: FIND NEW THEMES", AMBER)
    cy -= 10

    disc_steps = [
        ("Collect today's headlines", WHITE,
         [(0, "Gather raw headlines from your news sources (RSS, Bloomberg terminal,", WHITE_DIM),
          (0, "Reuters, Twitter/X financial accounts, IAEA reports, AIS data feeds).", WHITE_DIM),
          (0, "No need to pre-filter. The more, the better for the discovery engine.", WHITE_DIM),
         ]),
        ("Paste into Ingest News Batch", AMBER,
         [(0, "In Tab 2, paste all headlines into the large text area (one per line).", WHITE_DIM),
          (0, "Then click INGEST BATCH.", WHITE_DIM),
          (0, "The counter shows how many were dropped to the scanner buffer.", ORANGE),
          (0, "Texts matching active briefs are routed to Claude API (not scanner).", CYAN),
         ]),
        ("Run Velocity Scan (free)", GREEN,
         [(0, "Click RUN VELOCITY SCAN (FREE) — no API call, instant results.", GREEN),
          (0, "Shows Velocity Anomalies: phrases with 2.5x+ baseline frequency.", WHITE_DIM),
          (0, "Each hit shows: phrase, recent count, baseline count, ratio, example.", WHITE_DIM),
          (0, "High ratio (>10x) = very strong emerging theme. Low ratio (2-4x) = watch.", WHITE_DIM),
         ]),
        ("Run Semantic Scan (optional)", PURPLE,
         [(0, "Click RUN SEMANTIC SCAN (1 API CALL) for deeper analysis.", WHITE_DIM),
          (0, "Sends up to 80 dropped texts to Claude in a single batch.", WHITE_DIM),
          (0, "Claude identifies investable causal themes across the full pile.", PURPLE),
          (0, "Returns Candidate Briefs with confidence scores and keywords.", WHITE_DIM),
          (0, "Best run weekly — daily velocity scan is usually sufficient.", AMBER),
         ]),
        ("Activate a Candidate Brief", GOLD,
         [(0, "Candidate Briefs appear in the right panel after any scan.", WHITE_DIM),
          (0, "Each card shows: ID, confidence %, description, top 8 keywords.", WHITE_DIM),
          (0, "Click ACTIVATE AS BRIEF to add it to your active research agenda.", GOLD),
          (0, "The brief immediately starts filtering incoming news.", GREEN),
          (0, "Edit its keywords in the YAML file to refine it further.", WHITE_DIM),
         ]),
    ]
    for i, (title, col, lines) in enumerate(disc_steps):
        h = 14 + len(lines) * 10 + 4
        cy = _mbox(c, cx, cy, cw, h, title, col, lines, number=i+1) - 6

    # ── COL 2: Price Orphans + reading results ────────────────────────────────
    cx, cw = xs[1], col_w[1]
    cy = body_top

    _msection_label(c, cx, cy, "PRICE ORPHAN DETECTOR", RED)
    cy -= 10

    cy = _mbox(c, cx, cy, cw, 110, "What it does", RED,
        [(0, "Flags universe assets with large price moves that have NO active causal", RED),
         (0, "edge in the DCKG graph. These are themes already moving markets but", WHITE_DIM),
         (0, "completely invisible to the system's current research agenda.", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "Logic:  If |return| >= 3% AND asset has no active graph edge -> ORPHAN.", RED),
         (0, "", WHITE_DIM),
         (0, "These orphans are the strongest signal for a missing brief.", AMBER),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 90, "How to use it", AMBER,
        [(0, "Paste end-of-day returns in the text area (bottom of left panel):", WHITE_DIM),
         (0, "", WHITE_DIM),
         (1, "VLO,0.042", CYAN),
         (1, "DAL,-0.031", CYAN),
         (1, "XLE,0.018", CYAN),
         (1, "BRENT_CRUDE,0.055", CYAN),
         (0, "", WHITE_DIM),
         (0, "Format:  ASSET_ID,return_as_decimal  (one per line)", WHITE_DIM),
         (0, "Click DETECT PRICE ORPHANS. Results show assets with unexplained moves.", WHITE_DIM),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 60, "Action on finding an orphan", GOLD,
        [(0, "1.  Note the asset and the magnitude of the move.", WHITE_DIM),
         (0, "2.  Search today's headlines for news about that asset.", WHITE_DIM),
         (0, "3.  Identify the causal mechanism (supply shock? policy shift?).", WHITE_DIM),
         (0, "4.  Add a Focus Brief targeting that mechanism.", GOLD),
        ]) - gap

    _msection_label(c, cx, cy, "READING VELOCITY RESULTS", CYAN)
    cy -= 10

    cy = _mbox(c, cx, cy, cw, 120, "Understanding velocity anomalies", CYAN,
        [(0, "Each velocity hit card shows:", WHITE_DIM),
         (1, "Phrase:     the keyword or bigram (e.g. 'copper', 'chile drought')", CYAN),
         (1, "recent=N:   occurrences in the last 100 texts", WHITE_DIM),
         (1, "baseline=N: occurrences in the prior 100 texts", WHITE_DIM),
         (1, "ratio=Nx:   recent / baseline frequency (normalised)", WHITE_DIM),
         (1, "Example:    a real headline where the phrase appeared", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "Interpretation guide:", AMBER),
         (1, ">50x ratio:   Breaking news, very strong signal. Investigate immediately.", RED),
         (1, "10-50x ratio: Building theme. Add to watchlist.", ORANGE),
         (1, "2.5-10x ratio: Early signal. Monitor for a few more days.", AMBER),
        ]) - gap

    h_rem = body_top - 110 - 90 - 60 - 120 - 13 - gap * 5 - body_bot
    _mbox(c, cx, cy, cw, h_rem, "Velocity vs Semantic: when to use each", PURPLE,
        [(0, "VELOCITY  (run daily):", GREEN),
         (1, "Fast, free, keyword-level. Best for detecting breaking news storms.", WHITE_DIM),
         (1, "Catches: supply shocks, new geopolitical actors, company names.", WHITE_DIM),
         (1, "Miss: latent themes spread across different vocabulary.", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "SEMANTIC  (run weekly):", PURPLE),
         (1, "One Claude API call (~$0.05). Catches what velocity misses.", WHITE_DIM),
         (1, "Understands causal meaning across varied text.", WHITE_DIM),
         (1, "E.g. 'semiconductor shortage' + 'TSMC capacity' + 'chip prices'", WHITE_DIM),
         (1, "    = one theme, caught semantically even with no shared keywords.", PURPLE),
        ])

    # ── COL 3: Candidate card anatomy + daily workflow ─────────────────────────
    cx, cw = xs[2], col_w[2]
    cy = body_top

    _msection_label(c, cx, cy, "CANDIDATE BRIEF CARDS", GOLD)
    cy -= 10

    cy = _mbox(c, cx, cy, cw, 115, "Anatomy of a candidate card", GOLD,
        [(0, "Each candidate card has:", WHITE_DIM),
         (1, "ID:          e.g. CANDIDATE_COPPER_CHILE  (auto-generated)", CYAN),
         (1, "Confidence:  0-100% how strongly the scanner believes it's real", GREEN),
         (1, "Name:        human-readable theme name", WHITE_DIM),
         (1, "Description: 2-3 sentence causal explanation", WHITE_DIM),
         (1, "Keywords:    first 8 suggested watch keywords", AMBER),
         (0, "", WHITE_DIM),
         (0, "Confidence thresholds:", WHITE_DIM),
         (1, ">70%: Strong signal. Activate immediately if investable.", GREEN),
         (1, "40-70%: Building theme. Activate and monitor.", AMBER),
         (1, "<40%: Early noise. Watch for a few more days first.", RED),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 75, "Activating a candidate", AMBER,
        [(0, "Click ACTIVATE AS BRIEF on the candidate card.", WHITE_DIM),
         (0, "The system creates the brief with the candidate's keywords.", GREEN),
         (0, "The 'CANDIDATE_' prefix is stripped from the ID automatically.", WHITE_DIM),
         (0, "After activating: go to Tab 1 to add Universe Targets and refine keywords.", AMBER),
        ]) - gap

    _msection_label(c, cx, cy, "DAILY DISCOVERY WORKFLOW", GREEN)
    cy -= 10

    workflow = [
        ("08:00", "Review active briefs",     "Tab 1 -> list. Deactivate resolved theses.", GOLD),
        ("09:00", "Morning news ingest",       "Tab 2 -> paste AM headlines -> INGEST BATCH", AMBER),
        ("09:05", "Velocity scan",             "Tab 2 -> RUN VELOCITY SCAN. Note any >10x hits.", GREEN),
        ("16:00", "EOD news ingest",           "Tab 2 -> paste afternoon headlines -> INGEST", AMBER),
        ("16:15", "Price orphan check",        "Tab 2 -> paste EOD returns -> DETECT ORPHANS", RED),
        ("16:30", "Regime check",              "Tab 3 -> REFRESH -> review regime card.", ORANGE),
        ("Friday", "Weekly semantic scan",     "Tab 2 -> RUN SEMANTIC SCAN -> review candidates.", PURPLE),
        ("Friday", "Brief housekeeping",       "Tab 1 -> deactivate stale briefs. Archive resolved.", WHITE_DIM),
    ]

    for (time_str, title, desc, col) in workflow:
        if cy < body_bot + 28:
            break
        filled_rect(c, cx, cy - 26, cw, 25, M_CARD)
        filled_rect(c, cx, cy - 26, 3, 25, col)
        txt(c, time_str, cx + 7, cy - 9, 6.5, col, True)
        txt(c, title, cx + 50, cy - 9, 7, WHITE, True)
        txt(c, desc, cx + 7, cy - 19, 6, WHITE_DIM)
        cy -= 27


# ── PAGE 4: Tab 3 — Settings & Status ────────────────────────────────────────

def _man_page4(c):
    _man_page_frame(c, 4, 4, "Tab 3: Settings & Status",
                    "Governance parameters, regime monitoring, live activity feed")

    body_top = PH - 46
    body_bot = 22
    margin = 16
    gap = 10

    col_w = [310, 330, PW - 310 - 330 - 3 * margin - 2 * gap]
    xs = [margin, margin + col_w[0] + gap, margin + col_w[0] + gap + col_w[1] + gap]

    # ── COL 1: Parameters ─────────────────────────────────────────────────────
    cx, cw = xs[0], col_w[0]
    cy = body_top

    _msection_label(c, cx, cy, "MANDATE CONSTRAINTS", GOLD)
    cy -= 10

    params = [
        ("gross_exposure_max",       "2.0 × NAV", "Maximum total long + short exposure as a multiple of NAV."),
        ("net_exposure_min",         "-0.20 × NAV", "Minimum net (long minus short). Floor on net short positioning."),
        ("net_exposure_max",         "+1.20 × NAV", "Maximum net long positioning as a fraction of NAV."),
        ("single_name_long_max",     "0.15 × NAV", "Maximum size of any single long position (15% of NAV)."),
        ("single_name_short_max",    "-0.10 × NAV", "Maximum size of any single short position (-10% of NAV)."),
        ("sector_concentration_max", "0.35 × NAV", "Maximum exposure to any one sector."),
        ("max_positions",            "20 names",   "Cardinality constraint — maximum number of live positions."),
        ("turnover_budget_annual",   "3.0 × NAV",  "Annual portfolio turnover limit (300% of NAV)."),
    ]

    for (key, default, desc) in params:
        if cy < body_bot + 28:
            break
        filled_rect(c, cx, cy - 30, cw, 29, M_CARD)
        filled_rect(c, cx, cy - 30, 3, 29, GOLD)
        txt(c, key, cx + 7, cy - 8, 6.5, CYAN, True)
        txt(c, f"Default: {default}", cx + 7, cy - 18, 6, AMBER)
        txt(c, desc, cx + 7, cy - 27, 6, WHITE_DIM)
        cy -= 31

    _msection_label(c, cx, cy, "RISK PARAMETERS", AMBER)
    cy -= 10

    risk_params = [
        ("risk_aversion (lambda)", "2.0", "Controls the trade-off between expected return and portfolio variance. Higher = more conservative."),
        ("transaction_cost_coeff", "0.001", "Cost per unit of turnover in the optimiser objective (10 basis points per side)."),
        ("covariance_lookback_days", "60 days", "Rolling window for estimating the asset covariance matrix (Sigma)."),
    ]
    for (key, default, desc) in risk_params:
        if cy < body_bot + 28:
            break
        filled_rect(c, cx, cy - 36, cw, 35, M_CARD2)
        filled_rect(c, cx, cy - 36, 3, 35, AMBER)
        txt(c, key, cx + 7, cy - 9, 6.5, CYAN, True)
        txt(c, f"Default: {default}", cx + 7, cy - 19, 6, AMBER)
        # Wrap description
        c.setFont("Helvetica", 6)
        c.setFillColor(WHITE_DIM)
        words = desc.split()
        buf = ""
        dy = cy - 28
        for word in words:
            test = (buf + " " + word).strip()
            if c.stringWidth(test, "Helvetica", 6) <= cw - 16:
                buf = test
            else:
                c.drawString(cx + 7, dy, buf); dy -= 8; buf = word
        if buf:
            c.drawString(cx + 7, dy, buf)
        cy -= 37

    # Saving params box
    h_save = body_top - len(params) * 31 - len(risk_params) * 37 - 13 - gap * 3 - body_bot
    if h_save > 50:
        _mbox(c, cx, cy, cw, h_save, "How to save a parameter change", GREEN,
            [(0, "1.  Click on the numeric input field next to the parameter name.", WHITE_DIM),
             (0, "2.  Type the new value.", WHITE_DIM),
             (0, "3.  Click the SAVE button immediately to the right.", GREEN),
             (0, "4.  The field briefly turns green to confirm the write.", GREEN),
             (0, "5.  The change is written to mandate_global_alloc.yaml immediately.", WHITE_DIM),
             (0, "", WHITE_DIM),
             (0, "Note: the optimiser picks up the new value on its next solve cycle.", AMBER),
             (0, "The API does not need to be restarted.", WHITE_DIM),
            ])

    # ── COL 2: Regime + graph edges ───────────────────────────────────────────
    cx, cw = xs[1], col_w[1]
    cy = body_top

    _msection_label(c, cx, cy, "CURRENT REGIME CARD", ORANGE)
    cy -= 10

    cy = _mbox(c, cx, cy, cw, 115, "Reading the regime card", ORANGE,
        [(0, "The regime card (centre panel) shows the current market regime:", WHITE_DIM),
         (0, "", WHITE_DIM),
         (1, "Name (large text):  one of four regimes:", WHITE_DIM),
         (2, "GROWTH_EXPANSION    (green)   Growth +, Inflation -, Risk ON", GREEN),
         (2, "STAGFLATION_RISK    (orange)  Growth -, Inflation +, Risk OFF", ORANGE),
         (2, "INFLATION_ONLY      (amber)   Growth +, Inflation +, Risk ON", AMBER),
         (2, "RISK_OFF            (red)     Growth -, Inflation -, Risk OFF", RED),
         (0, "", WHITE_DIM),
         (1, "Confidence:  fraction of confirming sources in agreement.", WHITE_DIM),
         (1, "Active edges: how many causal edges are currently active.", CYAN),
         (1, "Buffer: how many texts are in the ThemeScanner buffer.", ORANGE),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 80, "What the regime controls", AMBER,
        [(0, "The active regime automatically adjusts:", WHITE_DIM),
         (1, "Edge sign multipliers:  whether a policy edge is bullish or bearish.", WHITE_DIM),
         (1, "Portfolio overlays:     systematic hedges applied on regime entry.", WHITE_DIM),
         (1, "Layer 4 attention gate: which edge types are suppressed from extraction.", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "Example: STAGFLATION_RISK adds equity_index_short (5% delta) and", WHITE_DIM),
         (0, "equity_vol_long (2% vega) overlays automatically on entry.", ORANGE),
        ]) - gap

    _msection_label(c, cx, cy, "ACTIVE GRAPH EDGES TABLE", CYAN)
    cy -= 10

    cy = _mbox(c, cx, cy, cw, 120, "Reading the edge table", CYAN,
        [(0, "Each row shows one active causal edge:", WHITE_DIM),
         (1, "Source:     the cause node (e.g. Hormuz_Closure)", CYAN),
         (1, "Arrow ->:   the edge direction (cause -> effect)", WHITE_DIM),
         (1, "Target:     the effect node (e.g. ICE_GASOIL)", GOLD),
         (1, "Edge type:  abbreviated mechanism (SUPPLY, COST, POLICY etc.)", WHITE_DIM),
         (1, "Wt bar:     coloured bar proportional to Wt value", GREEN),
         (1, "Wt=X.XXXX:  current Bayesian edge weight (max ~0.5)", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "Wt formula:  P_post x M_adj x exp(-lambda x t) x (1 - rho_corr)", WHITE_DIM),
         (0, "Edges with Wt < 0.015 are automatically pruned from the graph.", RED),
         (0, "Edges decay over time unless new confirming evidence arrives.", AMBER),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 60, "Decay class colour coding on the Wt bar", WHITE_DIM,
        [(1, "Red bar:       LIQUIDITY_STRESS   half-life = 7 days", RED),
         (1, "Orange bar:    SUPPLY_FLOW        half-life = 14 days", ORANGE),
         (1, "Amber bar:     COST               half-life = 45 days", AMBER),
         (1, "Purple bar:    POLICY             half-life = 180 days", PURPLE),
         (1, "Green bar:     INFRASTRUCTURE     half-life = 1825 days (5yr)", GREEN),
        ]) - gap

    # Refresh note
    h_ref = body_top - 115 - 80 - 120 - 60 - 13 - gap * 5 - body_bot
    if h_ref > 30:
        _mbox(c, cx, cy, cw, h_ref, "Refreshing the status panels", GREEN,
            [(0, "Click the REFRESH button (top-right of centre panel) to reload data.", WHITE_DIM),
             (0, "The live activity feed auto-refreshes every 15 seconds.", GREEN),
             (0, "The clock in the top-right header updates every second.", WHITE_DIM),
            ])

    # ── COL 3: Activity feed + decay + ontology ───────────────────────────────
    cx, cw = xs[2], col_w[2]
    cy = body_top

    _msection_label(c, cx, cy, "LIVE ACTIVITY FEED", GREEN)
    cy -= 10

    cy = _mbox(c, cx, cy, cw, 130, "Reading the activity feed", GREEN,
        [(0, "The activity feed (right panel, Tab 3) shows the last 30 events.", WHITE_DIM),
         (0, "Each row shows:", WHITE_DIM),
         (1, "Timestamp:   HH:MM:SS UTC (when the event entered the event log)", WHITE_DIM),
         (1, "Type pill:   colour-coded event type", WHITE_DIM),
         (1, "Summary:     one-line description of what happened", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "Event type colour coding:", WHITE_DIM),
         (1, "Cyan:    CAUSAL_EXTRACTION  (new signal extracted from news)", CYAN),
         (1, "Green:   EDGE_CREATED       (new causal edge added to graph)", GREEN),
         (1, "Gold:    EDGE_UPDATED       (Bayesian update to existing edge)", GOLD),
         (1, "Amber:   REGIME_CLASSIFICATION  (regime change or confirmation)", AMBER),
         (1, "Purple:  OPTIMIZER_SOLVE_COMPLETED  (portfolio recomputed)", PURPLE),
         (0, "", WHITE_DIM),
         (0, "Auto-refreshes every 15 seconds. Click REFRESH for immediate update.", GREEN),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 78, "Decay classes (Settings, left panel)", ORANGE,
        [(0, "The Decay Classes visual shows each class as a horizontal bar:", WHITE_DIM),
         (1, "Bar length proportional to half-life (5yr INFRA = full width)", WHITE_DIM),
         (1, "Colour matches the Wt bar colour in the edge table", WHITE_DIM),
         (0, "", WHITE_DIM),
         (0, "Critical: INFRASTRUCTURE_DAMAGE edges FREEZE on ceasefire", ORANGE),
         (0, "  (ceasefire_announced = freeze clock, NOT reset clock).", WHITE_DIM),
         (0, "  Only engineering_verification_confirmed resets the clock.", WHITE_DIM),
        ]) - gap

    cy = _mbox(c, cx, cy, cw, 60, "Graph Budget (read-only)", CYAN,
        [(0, "The Graph Budget panel shows two hard limits enforced by the system:", WHITE_DIM),
         (1, "max_active_edges: 30   (hard cap — lowest Wt edges pruned above this)", CYAN),
         (1, "min_wt_to_retain: 0.015  (decayed edges pruned below this threshold)", CYAN),
         (0, "These are Phase 1 hardcoded values. Phase 2 will make them configurable.", WHITE_DIM),
        ]) - gap

    _msection_label(c, cx, cy, "TROUBLESHOOTING", RED)
    cy -= 10

    issues = [
        ("All headlines dropping", RED,
         "Check active briefs (Tab 1). If count = 0, add at least one brief. Test a known headline."),
        ("Velocity scan returns nothing", AMBER,
         "Buffer needs >=200 texts (100 recent + 100 baseline). Ingest more headlines first."),
        ("Candidate confidence very low", WHITE_DIM,
         "Low confidence (<30%) is normal early in discovery. Wait for more signals. Run semantic for deeper analysis."),
        ("SAVE button has no effect", AMBER,
         "Check server is running (green LIVE dot). Reload the page if dot is grey."),
        ("Activity feed shows no events", WHITE_DIM,
         "The event log is empty — no news has been ingested yet. Run the Iran case demo to populate it."),
        ("Regime shows STAGFLATION_RISK always", ORANGE,
         "The stub regime classifier uses hardcoded STAGFLATION_RISK dimensions. Phase 2 will wire real macro data."),
    ]

    for (title, col, desc) in issues:
        if cy < body_bot + 26:
            break
        filled_rect(c, cx, cy - 30, cw, 29, M_CARD)
        filled_rect(c, cx, cy - 30, 3, 29, col)
        txt(c, title, cx + 7, cy - 9, 6.5, col, True)
        c.setFont("Helvetica", 6)
        c.setFillColor(WHITE_DIM)
        words = desc.split(); buf = ""; dy = cy - 18
        for word in words:
            test = (buf + " " + word).strip()
            if c.stringWidth(test, "Helvetica", 6) <= cw - 14:
                buf = test
            else:
                c.drawString(cx + 7, dy, buf); dy -= 8; buf = word
        if buf: c.drawString(cx + 7, dy, buf)
        cy -= 31


# ── Master builder ─────────────────────────────────────────────────────────────

def build_admin_manual_pdf(path):
    """4-page A3 landscape user manual for the DCKG Admin Panel."""
    c = canvas.Canvas(path, pagesize=landscape(A3))
    c.setTitle("DCKG Admin Panel — User Manual")
    c.setAuthor("DCKG System")

    pages = [_man_page1, _man_page2, _man_page3, _man_page4]
    for i, draw_fn in enumerate(pages):
        draw_fn(c)
        if i < len(pages) - 1:
            c.showPage()

    c.save()
    print(f"  Saved: {path}")


# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    out1 = r"C:\Users\H\Downloads\dckg_day29_portfolio.pdf"
    out2 = r"C:\Users\H\Downloads\dckg_day40_ceasefire_v2.pdf"
    out3 = r"C:\Users\H\Downloads\dckg_focus_architecture.pdf"
    out4 = r"C:\Users\H\Downloads\dckg_theme_management.pdf"
    out5 = r"C:\Users\H\Downloads\dckg_admin_manual.pdf"
    print("Generating DCKG PDF dashboards...")
    build_day29(out1)
    build_day40(out2)
    build_focus_pdf(out3)
    build_themes_pdf(out4)
    build_admin_manual_pdf(out5)
    print("Done.")
