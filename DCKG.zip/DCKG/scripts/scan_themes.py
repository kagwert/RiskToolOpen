"""
scan_themes.py — Discover emerging themes from a news file or stdin.

Two modes:

  velocity  (free, no API):
    Reads headlines from a file, routes them through active brief filter,
    accumulates dropped texts, then runs velocity scanner to find emerging
    phrases with anomalous frequency.

  semantic  (cheap, 1 API call):
    Same as velocity, but also sends the dropped texts to Claude for
    semantic theme clustering. Returns structured CandidateBrief suggestions
    you can paste directly into focus_briefs.yaml.

  orphans  (no API):
    Given a CSV of today's asset returns, identifies universe assets with
    large moves that have no active causal edge in the DCKG graph.

Usage:
  # Velocity scan from a headlines file (one headline per line)
  python scripts/scan_themes.py velocity --input headlines.txt

  # Semantic scan — generates candidate YAML blocks
  python scripts/scan_themes.py semantic --input headlines.txt

  # Pipe headlines from another process
  cat headlines.txt | python scripts/scan_themes.py velocity

  # Price orphan detection (CSV: asset,return e.g. VLO,0.04)
  python scripts/scan_themes.py orphans --returns returns.csv

  # Output candidate briefs to a file for review
  python scripts/scan_themes.py semantic --input headlines.txt --output candidates.yaml
"""
import sys
import os
import argparse
import csv
from pathlib import Path

# Ensure project root is on path
_root = Path(__file__).parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from pillar1_perception.agent_a_newsflow import AgentANewsflow
from pillar1_perception.theme_scanner import ThemeScanner


def load_texts(input_path: str) -> list:
    """Load texts from file (one per line) or stdin."""
    if input_path:
        with open(input_path, "r", encoding="utf-8", errors="replace") as f:
            lines = [l.strip() for l in f if l.strip()]
    else:
        lines = [l.strip() for l in sys.stdin if l.strip()]
    return lines


def run_velocity(args):
    texts = load_texts(args.input)
    if not texts:
        print("No texts provided.")
        return

    # Route through brief filter — dropped texts auto-ingest into scanner
    agent = AgentANewsflow()
    for text in texts:
        agent.extract(text)  # dropped texts flow to agent.theme_scanner automatically

    scanner = agent.theme_scanner
    print(f"\nProcessed {len(texts)} texts. "
          f"Dropped (no brief match): {scanner.buffer_size}")

    if scanner.buffer_size < 200:
        print(f"Buffer has {scanner.buffer_size} texts "
              f"(need >=200 for velocity comparison). "
              f"Add more input or use --semantic for smaller batches.")

    hits = scanner.scan_velocity()
    if not hits:
        print("No velocity anomalies detected. (Buffer may be too small for comparison.)")
        return

    print(f"\n{'='*60}")
    print(f"  VELOCITY ANOMALIES  ({len(hits)} found)")
    print(f"{'='*60}\n")
    for h in hits:
        print(h)
        print()

    # Cluster into candidate briefs
    # Collect all existing brief keywords to filter out already-known terms
    from pillar1_perception.theme_scanner import CANDIDATE_BRIEF_TOP_N
    import yaml
    briefs_path = _root / "config" / "focus_briefs.yaml"
    existing_kws = []
    if briefs_path.exists():
        with open(briefs_path) as f:
            data = yaml.safe_load(f) or {}
        for b in data.get("active_briefs", []):
            existing_kws.extend(b.get("watch_keywords", []))

    candidates = scanner.velocity_to_candidates(hits, existing_brief_keywords=existing_kws)
    if candidates:
        print(f"\n{'='*60}")
        print(f"  CANDIDATE BRIEFS from velocity clustering ({len(candidates)})")
        print(f"{'='*60}")
        for c in candidates:
            print(f"\n  [{c.id}]  confidence={c.confidence}")
            print(f"  {c.name}")
            print(f"  {c.description[:120]}")
            print(f"  keywords: {c.watch_keywords[:6]}")
            if c.supporting_texts:
                print(f"  e.g. \"{c.supporting_texts[0][:100]}\"")

    if args.output:
        _write_candidates(candidates, args.output)


def run_semantic(args):
    texts = load_texts(args.input)
    if not texts:
        print("No texts provided.")
        return

    agent = AgentANewsflow()
    for text in texts:
        agent.extract(text)

    scanner = agent.theme_scanner
    print(f"\nProcessed {len(texts)} texts. "
          f"Dropped: {scanner.buffer_size}")

    print("\nRunning semantic theme scanner (1 Claude API call)...")
    candidates = scanner.scan_semantic(api_key=args.api_key)

    if not candidates:
        print("No investable themes found in dropped texts.")
        return

    print(f"\n{'='*60}")
    print(f"  SEMANTIC CANDIDATE BRIEFS  ({len(candidates)} themes)")
    print(f"{'='*60}")
    for c in candidates:
        print(f"\n  [{c.id}]  confidence={c.confidence:.2f}")
        print(f"  {c.name}")
        print(f"  {c.description}")
        print(f"  keywords: {c.watch_keywords[:8]}")
        print(f"  universe targets: {c.universe_targets}")
        if c.supporting_texts:
            print(f"  evidence: \"{c.supporting_texts[0][:120]}\"")

    if args.output:
        _write_candidates(candidates, args.output)
    else:
        print(f"\n{'='*60}")
        print("  YAML BLOCKS (paste into config/focus_briefs.yaml)")
        print(f"{'='*60}")
        for c in candidates:
            print(c.to_yaml_block())


def run_orphans(args):
    """Price orphan detection: large moves with no causal graph edge."""
    if not args.returns:
        print("Provide --returns CSV file (format: asset_id,return_as_decimal)")
        return

    returns = {}
    with open(args.returns, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) >= 2:
                try:
                    returns[row[0].strip()] = float(row[1].strip())
                except ValueError:
                    pass

    # Try to load active edge targets from graph store
    active_edge_targets = []
    if args.graph_db:
        try:
            from pillar2_graph.graph_store import GraphStore
            gs = GraphStore(db_path=args.graph_db)
            snapshot = gs.get_state_snapshot()
            active_edge_targets = list({
                e["target_node_id"] for e in snapshot.get("edges", [])
                if e.get("status") == "ACTIVE"
            })
        except Exception as e:
            print(f"  Warning: could not load graph store: {e}")

    orphans = ThemeScanner.find_price_orphans(returns, active_edge_targets)

    if not orphans:
        print("\nNo price orphans detected — all large moves have causal graph coverage.")
        return

    print(f"\n{'='*60}")
    print(f"  PRICE ORPHANS — unexplained moves ({len(orphans)} assets)")
    print(f"{'='*60}\n")
    for asset, ret, reason in orphans:
        direction = "UP" if ret > 0 else "DOWN"
        print(f"  {asset:20s}  {ret*100:+6.1f}%  [{direction}]  {reason}")

    print(f"\n  Action: investigate each orphan for a new causal thesis.")
    print(f"  Consider adding a focus brief if the mechanism is structural.")


def _write_candidates(candidates, output_path):
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("# DCKG Candidate Briefs — review and paste into focus_briefs.yaml\n\n")
        for c in candidates:
            f.write(c.to_yaml_block())
    print(f"\nCandidate briefs written to: {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description="DCKG theme scanner — discover emerging themes from news"
    )
    sub = parser.add_subparsers(dest="command")

    # velocity
    p_vel = sub.add_parser("velocity", help="Keyword velocity scan (free, no API)")
    p_vel.add_argument("--input", "-i", help="Input file (one text per line); defaults to stdin")
    p_vel.add_argument("--output", "-o", help="Write candidate YAML to this file")

    # semantic
    p_sem = sub.add_parser("semantic", help="Semantic theme scan (1 Claude API call)")
    p_sem.add_argument("--input", "-i", help="Input file")
    p_sem.add_argument("--output", "-o", help="Write candidate YAML to this file")
    p_sem.add_argument("--api-key", dest="api_key", help="Anthropic API key (or set ANTHROPIC_API_KEY env)")

    # orphans
    p_orp = sub.add_parser("orphans", help="Price orphan detection — moves with no causal edge")
    p_orp.add_argument("--returns", help="CSV file: asset_id,return_decimal")
    p_orp.add_argument("--graph-db", dest="graph_db", help="Path to DCKG SQLite event DB")

    args = parser.parse_args()

    if args.command == "velocity":
        run_velocity(args)
    elif args.command == "semantic":
        run_semantic(args)
    elif args.command == "orphans":
        run_orphans(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
