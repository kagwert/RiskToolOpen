"""
generate_manual_latex.py
Produces a LaTeX-style technical PDF manual for the DCKG Admin Panel.

Output: C:\\Users\\H\\Downloads\\dckg_admin_manual_tech.pdf

Style: A4 portrait, white background, Times-Roman body, section numbering,
running headers, code blocks, parameter tables, note/warning boxes.
"""
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor, black, white
from reportlab.lib.units import mm

# ── Page geometry ──────────────────────────────────────────────────────────────
PW, PH = A4          # 595 x 842 pts
LM = 72              # left margin
RM = 72              # right margin
TM = 76              # top margin (below header rule)
BM = 64              # bottom margin (above footer rule)
BW = PW - LM - RM   # body width = 451 pts

# ── Colours ────────────────────────────────────────────────────────────────────
C_BLACK   = HexColor("#1a1a1a")
C_BLUE    = HexColor("#1a3a6b")   # section headings
C_MUTED   = HexColor("#555555")
C_FAINT   = HexColor("#999999")
C_RULE    = HexColor("#bbbbbb")
C_CODE_BG = HexColor("#f3f3f3")
C_CODE_FG = HexColor("#1a1a1a")
C_NOTE_BG = HexColor("#eef4fb")
C_NOTE_BD = HexColor("#3a6ea5")
C_WARN_BG = HexColor("#fdf6e3")
C_WARN_BD = HexColor("#c9a227")
C_TIP_BG  = HexColor("#f0faf0")
C_TIP_BD  = HexColor("#4a7c59")
C_TBL_HD  = HexColor("#e8e8e8")
C_TBL_ALT = HexColor("#f9f9f9")

# ── Font aliases ───────────────────────────────────────────────────────────────
F_BODY      = "Times-Roman"
F_BOLD      = "Times-Bold"
F_ITALIC    = "Times-Italic"
F_BOLDITAL  = "Times-BoldItalic"
F_SANS      = "Helvetica"
F_SANS_BOLD = "Helvetica-Bold"
F_CODE      = "Courier"
F_CODE_BOLD = "Courier-Bold"


# ══════════════════════════════════════════════════════════════════════════════
# Document builder class
# ══════════════════════════════════════════════════════════════════════════════

class LatexDoc:
    """
    Stateful document builder.  Tracks current y-position and auto-paginates.
    All draw methods return self for optional chaining.
    """

    BODY_SIZE    = 10.5
    BODY_LEAD    = 15.5   # line height for body
    CODE_SIZE    = 8.5
    CODE_LEAD    = 12.5
    SMALL_SIZE   = 9
    SMALL_LEAD   = 13

    def __init__(self, cv):
        self.c = cv
        self.page_num    = 0
        self.sec_num     = 0
        self.sub_num     = 0
        self.subsub_num  = 0
        self._section_title = ""   # for running header
        self._toc = []             # [(level, number, title, page)]
        self.cy = 0
        self._start_page()

    # ── Pagination ─────────────────────────────────────────────────────────────

    def _start_page(self):
        if self.page_num > 0:
            self._draw_footer()
            self.c.showPage()
        self.page_num += 1
        self.cy = PH - TM
        if self.page_num > 1:
            self._draw_header()

    def _draw_header(self):
        """Running header: left = document title, right = section."""
        y = PH - 36
        self.c.setFont(F_SANS, 8.5)
        self.c.setFillColor(C_MUTED)
        self.c.drawString(LM, y, "DCKG Admin Panel — User Manual")
        self.c.drawRightString(PW - RM, y, self._section_title)
        self.c.setStrokeColor(C_RULE)
        self.c.setLineWidth(0.5)
        self.c.line(LM, y - 4, PW - RM, y - 4)

    def _draw_footer(self):
        y = 36
        self.c.setStrokeColor(C_RULE)
        self.c.setLineWidth(0.5)
        self.c.line(LM, y + 6, PW - RM, y + 6)
        self.c.setFont(F_SANS, 8.5)
        self.c.setFillColor(C_MUTED)
        self.c.drawCentredString(PW / 2, y, str(self.page_num))
        self.c.drawString(LM, y, "Dynamic Causal Knowledge Graph")
        self.c.drawRightString(PW - RM, y, "Confidential — Internal Use Only")

    def _need(self, pts):
        """Ensure pts of vertical space; paginate if necessary."""
        if self.cy - pts < BM:
            self._start_page()
        return self

    def _skip(self, pts):
        self.cy -= pts
        return self

    # ── Text helpers ───────────────────────────────────────────────────────────

    def _wrap(self, text, font, size, max_w):
        """Word-wrap text into lines of at most max_w pts."""
        self.c.setFont(font, size)
        words = text.split()
        lines = []
        buf = ""
        for word in words:
            test = (buf + " " + word).strip()
            if self.c.stringWidth(test, font, size) <= max_w:
                buf = test
            else:
                if buf:
                    lines.append(buf)
                buf = word
        if buf:
            lines.append(buf)
        return lines

    def _draw_lines(self, lines, x, font, size, lead, color, indent=0):
        self.c.setFont(font, size)
        self.c.setFillColor(color)
        for line in lines:
            self._need(lead)
            self.c.drawString(x + indent, self.cy, line)
            self.cy -= lead
        return self

    # ── Cover / title page ─────────────────────────────────────────────────────

    def cover(self, title, subtitle, version, date, authors):
        """Full-page cover (page 1, no header)."""
        c = self.c
        c.setFillColor(white)
        c.rect(0, 0, PW, PH, fill=1, stroke=0)

        # Top accent rule
        c.setFillColor(C_BLUE)
        c.rect(LM, PH - 90, BW, 3, fill=1, stroke=0)

        # Monogram / system label
        c.setFont(F_SANS_BOLD, 11)
        c.setFillColor(C_BLUE)
        c.drawString(LM, PH - 78, "DYNAMIC CAUSAL KNOWLEDGE GRAPH")

        # Main title block
        ty = PH - 200
        c.setFont(F_BOLD, 28)
        c.setFillColor(C_BLACK)
        # Wrap title
        for line in self._wrap(title, F_BOLD, 28, BW):
            c.drawString(LM, ty, line)
            ty -= 36

        ty -= 6
        c.setFont(F_ITALIC, 15)
        c.setFillColor(C_MUTED)
        for line in self._wrap(subtitle, F_ITALIC, 15, BW):
            c.drawString(LM, ty, line)
            ty -= 20

        # Mid rule
        c.setStrokeColor(C_RULE)
        c.setLineWidth(0.7)
        c.line(LM, PH/2 + 60, PW - RM, PH/2 + 60)

        # Meta block
        my = PH/2 + 40
        meta = [
            ("Version",  version),
            ("Date",     date),
            ("System",   "DCKG v1.0  ·  85/85 tests passing"),
            ("URL",      "http://localhost:8000/admin"),
            ("Authors",  authors),
        ]
        for (label, value) in meta:
            c.setFont(F_BOLD, 10)
            c.setFillColor(C_BLACK)
            c.drawString(LM, my, label + ":")
            c.setFont(F_BODY, 10)
            c.setFillColor(C_MUTED)
            c.drawString(LM + 70, my, value)
            my -= 16

        # Abstract box
        c.setFillColor(C_NOTE_BG)
        c.setStrokeColor(C_NOTE_BD)
        c.setLineWidth(0.8)
        c.rect(LM, 130, BW, 110, fill=1, stroke=1)
        c.setFillColor(C_BLUE)
        c.setFont(F_BOLD, 9)
        c.drawString(LM + 10, 228, "ABSTRACT")
        c.setFont(F_BODY, 9.5)
        c.setFillColor(C_BLACK)
        abstract = (
            "This manual describes the operation of the DCKG Administration Panel — "
            "a browser-based interface for managing focus briefs, discovering emerging "
            "market themes, and monitoring system governance parameters. The panel "
            "controls a five-layer filtering architecture that routes news signals through "
            "ontology validation, universe intersection, thesis-brief matching, regime-"
            "conditional attention, and graph budget constraints before any causal edge "
            "is created. This document covers all three tabs of the interface: Brief "
            "Management, Theme Discovery, and Settings & Live Status."
        )
        ax = LM + 10; ay = 213; aw = BW - 20
        for line in self._wrap(abstract, F_BODY, 9.5, aw):
            c.setFont(F_BODY, 9.5)
            c.setFillColor(C_BLACK)
            c.drawString(ax, ay, line)
            ay -= 13

        # Bottom accent rule
        c.setFillColor(C_BLUE)
        c.rect(LM, 90, BW, 1.5, fill=1, stroke=0)

        # Page 1 footer
        c.setFont(F_SANS, 8)
        c.setFillColor(C_MUTED)
        c.drawCentredString(PW/2, 70, "Dynamic Causal Knowledge Graph  ·  Internal Use Only")
        c.drawCentredString(PW/2, 58, date)

        self.cy = BM  # cover page "used up"
        return self

    # ── Table of contents ──────────────────────────────────────────────────────

    def toc_page(self):
        """Render a table of contents from self._toc."""
        self._start_page()
        self._draw_header()

        c = self.c
        c.setFillColor(C_BLUE)
        c.setFont(F_BOLD, 16)
        c.drawString(LM, self.cy, "Contents")
        self.cy -= 8
        c.setStrokeColor(C_BLUE)
        c.setLineWidth(1.2)
        c.line(LM, self.cy, PW - RM, self.cy)
        self.cy -= 20

        for (level, number, title, pg) in self._toc:
            if level == 1:
                indent = 0
                font = F_BOLD
                size = 11
                lead = 18
            elif level == 2:
                indent = 16
                font = F_BODY
                size = 10.5
                lead = 16
            else:
                indent = 32
                font = F_ITALIC
                size = 10
                lead = 15

            self._need(lead + 2)
            label = f"{number}  {title}"
            c.setFont(font, size)
            c.setFillColor(C_BLACK)
            c.drawString(LM + indent, self.cy, label)
            # Dot leader
            lw = c.stringWidth(label, font, size)
            pg_str = str(pg)
            pgw = c.stringWidth(pg_str, font, size)
            dot_x = LM + indent + lw + 4
            dot_end = PW - RM - pgw - 4
            c.setFont(F_BODY, size)
            c.setFillColor(C_FAINT)
            if dot_end > dot_x:
                c.drawString(dot_x, self.cy,
                    "." * int((dot_end - dot_x) / c.stringWidth(".", F_BODY, size)))
            c.setFillColor(C_MUTED)
            c.drawRightString(PW - RM, self.cy, pg_str)
            self.cy -= lead
        return self

    # ── Section headings ───────────────────────────────────────────────────────

    def section(self, title):
        self.sec_num += 1
        self.sub_num = 0
        self.subsub_num = 0
        number = str(self.sec_num)
        self._section_title = f"{number}  {title}"
        self._toc.append((1, number, title, self.page_num))

        self._need(40)
        self._skip(10)
        full = f"{number}  {title}"
        self.c.setFont(F_BOLD, 15)
        self.c.setFillColor(C_BLUE)
        self.c.drawString(LM, self.cy, full)
        self.cy -= 5
        self.c.setStrokeColor(C_BLUE)
        self.c.setLineWidth(0.9)
        self.c.line(LM, self.cy, PW - RM, self.cy)
        self.cy -= 14
        return self

    def subsection(self, title):
        self.sub_num += 1
        self.subsub_num = 0
        number = f"{self.sec_num}.{self.sub_num}"
        self._toc.append((2, number, title, self.page_num))

        self._need(30)
        self._skip(8)
        self.c.setFont(F_BOLD, 12)
        self.c.setFillColor(C_BLACK)
        self.c.drawString(LM, self.cy, f"{number}  {title}")
        self.cy -= 4
        self.c.setStrokeColor(C_RULE)
        self.c.setLineWidth(0.4)
        self.c.line(LM, self.cy, LM + BW * 0.5, self.cy)
        self.cy -= 11
        return self

    def subsubsection(self, title):
        self.subsub_num += 1
        number = f"{self.sec_num}.{self.sub_num}.{self.subsub_num}"
        self._toc.append((3, number, title, self.page_num))

        self._need(22)
        self._skip(6)
        self.c.setFont(F_BOLDITAL, 10.5)
        self.c.setFillColor(C_BLACK)
        self.c.drawString(LM, self.cy, f"{number}  {title}")
        self.cy -= 13
        return self

    # ── Body text ──────────────────────────────────────────────────────────────

    def para(self, text, color=C_BLACK, italic=False, bold=False):
        """Paragraph of wrapped body text with a small bottom margin."""
        font = F_BOLDITAL if (bold and italic) else (F_BOLD if bold else (F_ITALIC if italic else F_BODY))
        lines = self._wrap(text, font, self.BODY_SIZE, BW)
        self._draw_lines(lines, LM, font, self.BODY_SIZE, self.BODY_LEAD, color)
        self.cy -= 5
        return self

    def small_para(self, text, color=C_MUTED, indent=0):
        font = F_BODY
        lines = self._wrap(text, font, self.SMALL_SIZE, BW - indent)
        self._draw_lines(lines, LM + indent, font, self.SMALL_SIZE, self.SMALL_LEAD, color)
        self.cy -= 3
        return self

    # ── Lists ──────────────────────────────────────────────────────────────────

    def bullet_list(self, items, indent=16, bullet="\u2022"):
        """items: list of str or (str, color)."""
        for item in items:
            if isinstance(item, tuple):
                text, color = item
            else:
                text, color = item, C_BLACK
            lines = self._wrap(text, F_BODY, self.BODY_SIZE, BW - indent - 10)
            self._need(self.BODY_LEAD)
            self.c.setFont(F_BODY, self.BODY_SIZE)
            self.c.setFillColor(C_MUTED)
            self.c.drawString(LM + indent - 10, self.cy, bullet)
            self.c.setFillColor(color)
            self.c.drawString(LM + indent, self.cy, lines[0])
            self.cy -= self.BODY_LEAD
            for line in lines[1:]:
                self._need(self.BODY_LEAD)
                self.c.setFont(F_BODY, self.BODY_SIZE)
                self.c.setFillColor(color)
                self.c.drawString(LM + indent, self.cy, line)
                self.cy -= self.BODY_LEAD
        self.cy -= 4
        return self

    def numbered_list(self, items, indent=20, start=1):
        for i, item in enumerate(items, start):
            if isinstance(item, tuple):
                text, color = item
            else:
                text, color = item, C_BLACK
            lines = self._wrap(text, F_BODY, self.BODY_SIZE, BW - indent - 10)
            self._need(self.BODY_LEAD)
            self.c.setFont(F_BOLD, self.BODY_SIZE)
            self.c.setFillColor(C_BLUE)
            self.c.drawString(LM + indent - 16, self.cy, f"{i}.")
            self.c.setFont(F_BODY, self.BODY_SIZE)
            self.c.setFillColor(color)
            self.c.drawString(LM + indent, self.cy, lines[0])
            self.cy -= self.BODY_LEAD
            for line in lines[1:]:
                self._need(self.BODY_LEAD)
                self.c.setFont(F_BODY, self.BODY_SIZE)
                self.c.setFillColor(color)
                self.c.drawString(LM + indent, self.cy, line)
                self.cy -= self.BODY_LEAD
        self.cy -= 4
        return self

    # ── Code block ─────────────────────────────────────────────────────────────

    def code(self, lines, caption=None, lang=""):
        """Monospace code block with light-grey background."""
        inner_pad = 8
        lead = self.CODE_LEAD
        h = len(lines) * lead + inner_pad * 2 + (14 if caption else 0)
        self._need(h + 10)
        y0 = self.cy - h
        # Background
        self.c.setFillColor(C_CODE_BG)
        self.c.setStrokeColor(C_RULE)
        self.c.setLineWidth(0.5)
        self.c.rect(LM, y0, BW, h, fill=1, stroke=1)
        # Left accent
        self.c.setFillColor(C_BLUE)
        self.c.rect(LM, y0, 2.5, h, fill=1, stroke=0)
        # Caption
        iy = self.cy - inner_pad - (14 if caption else 0)
        if caption:
            self.c.setFont(F_SANS_BOLD, 8)
            self.c.setFillColor(C_MUTED)
            label = (f"Listing — {caption}" if not lang else
                     f"Listing [{lang}] — {caption}")
            self.c.drawString(LM + 8, self.cy - 11, label)
            # Thin rule under caption
            self.c.setStrokeColor(C_RULE)
            self.c.setLineWidth(0.3)
            self.c.line(LM + 2.5, self.cy - 14, LM + BW, self.cy - 14)
            iy -= 6
        for line in lines:
            self._need(lead)
            self.c.setFont(F_CODE, self.CODE_SIZE)
            self.c.setFillColor(C_CODE_FG)
            self.c.drawString(LM + 10, iy, line)
            iy -= lead
        self.cy = y0 - 8
        return self

    # ── Note / warning / tip boxes ─────────────────────────────────────────────

    def _admon(self, label, text, bg, border, label_color):
        lines = self._wrap(text, F_BODY, self.BODY_SIZE, BW - 28)
        h = len(lines) * self.BODY_LEAD + 22
        self._need(h + 8)
        y0 = self.cy - h
        self.c.setFillColor(bg)
        self.c.setStrokeColor(border)
        self.c.setLineWidth(0.8)
        self.c.rect(LM, y0, BW, h, fill=1, stroke=1)
        self.c.setFillColor(border)
        self.c.rect(LM, y0, 3.5, h, fill=1, stroke=0)
        self.c.setFont(F_SANS_BOLD, 8.5)
        self.c.setFillColor(label_color)
        self.c.drawString(LM + 10, self.cy - 12, label.upper())
        iy = self.cy - 24
        for line in lines:
            self.c.setFont(F_BODY, self.BODY_SIZE)
            self.c.setFillColor(C_BLACK)
            self.c.drawString(LM + 10, iy, line)
            iy -= self.BODY_LEAD
        self.cy = y0 - 8
        return self

    def note(self, text):    return self._admon("Note",    text, C_NOTE_BG, C_NOTE_BD, C_NOTE_BD)
    def warning(self, text): return self._admon("Warning", text, C_WARN_BG, C_WARN_BD, C_WARN_BD)
    def tip(self, text):     return self._admon("Tip",     text, C_TIP_BG,  C_TIP_BD,  C_TIP_BD)

    # ── Parameter table ────────────────────────────────────────────────────────

    def param_table(self, headers, rows, col_widths=None):
        """
        headers: list of str
        rows: list of list of str
        col_widths: list of floats summing to BW; defaults to equal widths
        """
        n = len(headers)
        cws = col_widths or [BW / n] * n
        row_h = 16
        h_hdr = 18
        total_h = h_hdr + len(rows) * row_h + 2
        self._need(total_h + 10)

        y0 = self.cy - total_h
        # Outer border
        self.c.setStrokeColor(C_RULE)
        self.c.setLineWidth(0.5)
        self.c.rect(LM, y0, BW, total_h, fill=0, stroke=1)

        # Header row
        self.c.setFillColor(C_TBL_HD)
        self.c.rect(LM, self.cy - h_hdr, BW, h_hdr, fill=1, stroke=0)
        hx = LM
        for i, (hdr, cw) in enumerate(zip(headers, cws)):
            self.c.setFont(F_SANS_BOLD, 9)
            self.c.setFillColor(C_BLACK)
            self.c.drawString(hx + 5, self.cy - 12, hdr)
            if i < n - 1:
                self.c.setStrokeColor(C_RULE)
                self.c.setLineWidth(0.3)
                self.c.line(hx + cw, self.cy - h_hdr, hx + cw, y0)
            hx += cw
        # Header bottom rule
        self.c.setStrokeColor(C_FAINT)
        self.c.setLineWidth(0.7)
        self.c.line(LM, self.cy - h_hdr, LM + BW, self.cy - h_hdr)

        ry = self.cy - h_hdr
        for ri, row in enumerate(rows):
            bg = C_TBL_ALT if ri % 2 == 1 else white
            self.c.setFillColor(bg)
            self.c.rect(LM, ry - row_h, BW, row_h, fill=1, stroke=0)
            rx = LM
            for ci, (cell, cw) in enumerate(zip(row, cws)):
                self.c.setFont(F_BODY if ci > 0 else F_CODE, 9)
                self.c.setFillColor(C_BLUE if ci == 0 else C_BLACK)
                # Truncate if too wide
                cell_str = str(cell)
                while (self.c.stringWidth(cell_str, F_BODY, 9) > cw - 10
                       and len(cell_str) > 3):
                    cell_str = cell_str[:-4] + "..."
                self.c.drawString(rx + 5, ry - 11, cell_str)
                if ci < n - 1:
                    self.c.setStrokeColor(C_RULE)
                    self.c.setLineWidth(0.3)
                    self.c.line(rx + cw, ry - row_h, rx + cw, ry)
                rx += cw
            # Row bottom rule
            self.c.setStrokeColor(C_RULE)
            self.c.setLineWidth(0.3)
            self.c.line(LM, ry - row_h, LM + BW, ry - row_h)
            ry -= row_h

        self.cy = y0 - 8
        return self

    # ── Inline helpers ─────────────────────────────────────────────────────────

    def skip(self, pts=8):
        self.cy -= pts
        return self

    def hrule(self, color=C_RULE, width=1.0):
        self._need(10)
        self.c.setStrokeColor(color)
        self.c.setLineWidth(width)
        self.c.line(LM, self.cy, PW - RM, self.cy)
        self.cy -= 8
        return self

    def caption(self, text):
        self._need(14)
        self.c.setFont(F_ITALIC, 9)
        self.c.setFillColor(C_MUTED)
        self.c.drawCentredString(PW / 2, self.cy, text)
        self.cy -= 14
        return self

    def finish(self):
        """Call after all content to write the final page footer."""
        self._draw_footer()
        self.c.save()


# ══════════════════════════════════════════════════════════════════════════════
# CONTENT
# ══════════════════════════════════════════════════════════════════════════════

def build(doc):

    # ── Section 1: Introduction ───────────────────────────────────────────────
    doc.section("Introduction")

    doc.subsection("What Is the DCKG Admin Panel?")
    doc.para(
        "The DCKG Administration Panel is a browser-based interface for managing the "
        "Dynamic Causal Knowledge Graph system. It provides real-time control over the "
        "system's research agenda, theme discovery pipeline, and core governance "
        "parameters without requiring any restart of the underlying API server."
    )
    doc.para(
        "The panel is organised into three tabs, each addressing a distinct operational "
        "concern: Brief Management, Theme Discovery, and Settings & Live Status. Changes "
        "made through the panel take effect immediately and are persisted to YAML "
        "configuration files on disk."
    )

    doc.subsection("Starting the Server")
    doc.para(
        "The admin panel is served by the DCKG FastAPI application. To start the server, "
        "run the following command from the project root directory:"
    )
    doc.code(
        ["python -m uvicorn api.main:app --host 0.0.0.0 --port 8000"],
        caption="Starting the DCKG API server", lang="shell"
    )
    doc.para(
        "Once the server is running, navigate to the following URL in any modern browser:"
    )
    doc.code(["http://localhost:8000/admin"])
    doc.tip(
        "A green pulsing dot labelled LIVE appears in the top-right corner of the "
        "header when the API is healthy and responding. If the dot is absent, check "
        "that the uvicorn process is running and that no other application is occupying "
        "port 8000."
    )

    doc.subsection("Interface Layout")
    doc.para(
        "The panel uses a fixed-height layout with three zones: a header bar at the top "
        "containing the navigation tabs and system clock, a main content area whose "
        "contents change with the active tab, and a status bar at the bottom showing the "
        "result of the last action."
    )
    doc.bullet_list([
        "Header bar (50 px):  logo, tab navigation, live indicator, UTC clock.",
        "Main content area:  three-panel horizontal layout (varies per tab).",
        "Status bar (30 px):  last action message (green = success, red = error) "
        "and system metrics (active brief count, version).",
    ])
    doc.note(
        "Status messages auto-clear after four seconds. If a message is important, "
        "note it before it disappears or consult the Live Activity Feed in Tab 3."
    )

    doc.subsection("Five-Layer Signal Filter")
    doc.para(
        "Every incoming news signal passes through five cascading filters before any "
        "causal edge is created in the graph. Understanding these layers is essential "
        "for configuring the system correctly."
    )
    doc.param_table(
        ["Layer", "Mechanism", "Cost", "Rejection rate"],
        [
            ["L1", "Ontology filter — 7 permitted edge types; any other mechanism rejected", "Free", "~90%"],
            ["L2", "Universe intersection — causal chain must reach a tradeable asset", "Free", "~5%"],
            ["L3", "Thesis brief matching — keyword pre-filter against active briefs", "Free", "~4%"],
            ["L4", "Regime-conditional attention — suppresses irrelevant edge types", "Free", "<1%"],
            ["L5", "Graph budget — max 30 active edges, min Wt = 0.015", "Free", "<1%"],
        ],
        col_widths=[24, 260, 50, 90]
    )
    doc.caption("Table 1.1 — Five-layer signal filtering architecture.")
    doc.para(
        "Only approximately 1% of all incoming signals survive all five layers and "
        "result in a graph edge update. The Claude API is only called for signals that "
        "pass Layer 3 (brief matching), making the system economically efficient at scale."
    )

    # ── Section 2: Brief Management ───────────────────────────────────────────
    doc.section("Brief Management  (Tab 1: Briefs)")

    doc.subsection("Understanding Focus Briefs")
    doc.para(
        "A Focus Brief is a structured declaration of one investable research thesis. "
        "It defines which news signals the system should pay attention to, which assets "
        "in the universe are likely affected, and the minimum evidence quality required "
        "before a signal is processed. Briefs are stored in "
        "\\texttt{config/focus\\_briefs.yaml}."
    )
    doc.para(
        "The brief filter operates as a two-stage gate around every Claude API call. "
        "In Stage 1 (pre-LLM), the raw text of an incoming article is scanned for "
        "keyword matches against all active briefs. If no brief matches, the text is "
        "silently discarded — no API call is made. In Stage 2 (post-LLM), each "
        "extracted causal claim is checked against the brief's watch\\_nodes and "
        "watch\\_edge\\_types; claims that do not match are dropped before reaching the "
        "graph."
    )
    doc.note(
        "Run 3 to 5 active briefs at any one time. More than 8 active briefs dilutes "
        "system focus and increases the risk of false positives passing the filter. "
        "Deactivate resolved theses promptly."
    )

    doc.subsection("Adding a New Brief")
    doc.para(
        "The Add New Brief form is permanently displayed in the right panel of Tab 1. "
        "Fill in the following fields and click CREATE BRIEF."
    )
    doc.numbered_list([
        ("Brief ID (required):  Must be UPPER\\_SNAKE\\_CASE with at least two characters, "
         "e.g. TARIFF\\_WAR\\_2026. The system rejects IDs containing spaces or lowercase "
         "letters, and refuses duplicate IDs across active and inactive briefs.", C_BLACK),
        ("Name (required):  A short, human-readable label that will appear on the brief "
         "card, e.g. 'Trump Tariff Escalation'.", C_BLACK),
        ("Description (optional):  Two to three sentences describing the causal mechanism "
         "and why it is investable. This is for human reference only.", C_BLACK),
        ("Watch Keywords (one per line):  Case-insensitive substrings matched against the "
         "raw text of every incoming article. Add 10 to 30 keywords. Think about how a "
         "journalist would write the story: proper nouns, technical terms, official "
         "report names, company names, and specific geographic references.", C_BLACK),
        ("Universe Targets (comma-separated):  Which assets in the DCKG tradeable "
         "universe are causally connected to this thesis. Available assets: VLO, DAL, "
         "ICE\\_GASOIL, EU\\_UTILITIES, BRENT\\_CRUDE, XLE, SPX, equity\\_index\\_short, "
         "equity\\_vol\\_long, duration\\_short.", C_BLACK),
        ("Min Novelty Score (default 0.25):  The minimum novelty score an extracted "
         "signal must achieve before it is processed. Signals that closely resemble "
         "recently processed texts receive a low novelty score and are dropped.", C_BLACK),
    ])
    doc.code(
        ["# Valid Brief IDs",
         "IRAN_WAR_SUPPLY_SHOCK",
         "PRIVATE_CREDIT_STRESS",
         "AI_DISRUPTION",
         "COPPER_CHILE_SUPPLY",
         "",
         "# Invalid Brief IDs",
         "iran war          # contains spaces",
         "IranWar           # not UPPER_SNAKE_CASE",
         "A                 # too short (minimum 2 characters)"],
        caption="Brief ID format rules", lang="yaml"
    )

    doc.subsection("Testing a Headline")
    doc.para(
        "Before ingesting live news, it is good practice to verify that your brief "
        "keywords correctly route the expected headlines. Use the Test Headline panel "
        "in the centre of Tab 1."
    )
    doc.numbered_list([
        "Paste any headline or news snippet into the large text area.",
        "Click TEST AGAINST ACTIVE BRIEFS.",
        "Read the result: PASS (green) means at least one active brief matched "
        "and the text would proceed to Claude API extraction. DROP (red) means "
        "no brief matched and the text would be silently discarded.",
    ])
    doc.para(
        "The result panel shows exactly which brief(s) matched and which specific "
        "keywords triggered the match. This test costs nothing — no API call is made."
    )
    doc.tip(
        "If an important headline is returning DROP, check whether the relevant "
        "keywords are present in the brief's watch\\_keywords list. Add missing terms "
        "and re-test. Common mistakes: acronyms without the full form (add both "
        "'CLO' and 'collateralised loan obligation'), and location variants "
        "('hormuz' and 'strait of hormuz')."
    )

    doc.subsection("Activating and Deactivating Briefs")
    doc.para(
        "The left panel of Tab 1 displays all active briefs as cards. Clicking a card "
        "expands it to reveal the first 12 watch keywords. Each card provides two "
        "action buttons:"
    )
    doc.bullet_list([
        "Deactivate:  Moves the brief to the Inactive Briefs section "
        "(collapsed by default, accessible via the toggle at the bottom of the left "
        "panel). The brief stops filtering news immediately. No configuration data is "
        "lost — the brief can be reactivated at any time.",
        "Delete:  Permanently removes the brief from focus\\_briefs.yaml. A "
        "confirmation dialog is shown. Prefer Deactivate over Delete in order to "
        "maintain an audit trail of past research theses.",
    ])
    doc.warning(
        "Deletion is irreversible. The brief's keyword list, node watch list, and "
        "universe targets are permanently removed from disk. Use Deactivate unless "
        "the brief was created in error."
    )

    doc.subsection("Quick Ingest")
    doc.para(
        "The centre panel of Tab 1 includes a Quick Ingest text area for batch "
        "processing of multiple headlines. Paste one headline per line and click "
        "INGEST & ROUTE. The system displays four statistics:"
    )
    doc.bullet_list([
        "Ingested:            total number of lines processed.",
        "Matched briefs:      texts that passed the brief filter and were sent to the Claude API.",
        "Dropped to scanner:  texts that failed the brief filter and were added to the ThemeScanner buffer.",
        "Buffer:              total number of texts currently in the ThemeScanner buffer.",
    ])
    doc.para(
        "Texts that are dropped to the scanner are not ignored. They accumulate in "
        "a rolling buffer that is analysed by the Theme Discovery engine (Tab 2) to "
        "identify emerging themes that are not yet covered by any active brief."
    )

    # ── Section 3: Theme Discovery ─────────────────────────────────────────────
    doc.section("Theme Discovery  (Tab 2: Discovery)")

    doc.subsection("Architecture Overview")
    doc.para(
        "The Theme Discovery engine is a three-tier system that analyses the texts "
        "discarded by the brief filter, looking for patterns that suggest an emerging "
        "investable thesis. The tiers are:"
    )
    doc.param_table(
        ["Tier", "Method", "Cost", "Cadence"],
        [
            ["1 — Velocity", "Keyword frequency ratio: recent 100 vs baseline 100 texts", "Free", "Daily"],
            ["2 — Semantic", "Single Claude API batch call over up to 80 dropped texts", "~$0.05", "Weekly"],
            ["3 — Orphan",   "Universe assets with >3% move and no active graph edge", "Free", "Intraday"],
        ],
        col_widths=[80, 220, 60, 68]
    )
    doc.caption("Table 3.1 — ThemeScanner detection tiers.")

    doc.subsection("Tier 1: Velocity Scan")
    doc.para(
        "The velocity scanner compares keyword and bigram frequencies in the most "
        "recent 100 texts against the prior 100 texts in the buffer. A phrase is "
        "flagged as a velocity anomaly when its normalised frequency ratio meets or "
        "exceeds 2.5 times the baseline rate."
    )
    doc.subsubsection("Running a Velocity Scan")
    doc.numbered_list([
        "Navigate to Tab 2 (Discovery).",
        "Paste news headlines into the Ingest News Batch text area (one per line).",
        "Click INGEST BATCH. The counter shows how many texts were dropped to the scanner buffer.",
        "Click RUN VELOCITY SCAN (FREE). Results appear immediately in the centre panel.",
    ])
    doc.note(
        "The velocity scan requires at least 200 texts in the buffer (100 for the "
        "recent window and 100 for the baseline). If the buffer is below this "
        "threshold, ingest more headlines before running the scan."
    )
    doc.subsubsection("Interpreting Velocity Results")
    doc.para(
        "Each velocity hit card shows: the phrase, the recent count, the baseline "
        "count, the velocity ratio, and one example headline in which the phrase "
        "appeared. Use the following guide to interpret velocity ratios:"
    )
    doc.param_table(
        ["Ratio range", "Interpretation", "Recommended action"],
        [
            [">50x",    "Breaking news. Very strong signal.", "Investigate immediately."],
            ["10-50x",  "Building theme. Strong signal.",     "Add to watchlist; consider a brief."],
            ["2.5-10x", "Early signal. Emerging pattern.",    "Monitor for several more days."],
        ],
        col_widths=[70, 230, 148]
    )
    doc.caption("Table 3.2 — Velocity ratio interpretation guide.")

    doc.subsection("Tier 2: Semantic Scan")
    doc.para(
        "The semantic scanner sends a batch of up to 80 dropped texts to the Claude "
        "API in a single call. Claude is asked to identify investable causal themes "
        "across the full batch, returning structured Candidate Brief suggestions with "
        "confidence scores."
    )
    doc.para(
        "The semantic scan catches themes that the velocity scanner misses: latent "
        "causal logic spread across articles that use different vocabulary to describe "
        "the same phenomenon. For example, 'semiconductor lead times', 'TSMC capacity "
        "constraints', and 'chip shortage' may share no common keyword but all describe "
        "the same supply-chain theme."
    )
    doc.code(
        ["# Click: RUN SEMANTIC SCAN (1 API CALL)",
         "# Cost:  approximately $0.05-0.10 per scan",
         "# Time:  10-30 seconds",
         "# Cadence: weekly is recommended"],
        caption="Semantic scan operational parameters"
    )
    doc.warning(
        "The semantic scan requires a valid Anthropic API key configured in the "
        "server environment (ANTHROPIC\\_API\\_KEY environment variable). If the key "
        "is absent, the scan will return a mock response indicating that the SDK is "
        "unavailable."
    )

    doc.subsection("Tier 3: Price Orphan Detection")
    doc.para(
        "The price orphan detector identifies assets in the DCKG tradeable universe "
        "that have experienced a large price move (absolute return of 3% or greater) "
        "but have no active causal edge in the graph pointing to them. These are "
        "themes already moving markets but currently invisible to the system."
    )
    doc.subsubsection("How to Use the Price Orphan Detector")
    doc.numbered_list([
        "Collect end-of-day returns for all universe assets.",
        "Paste the returns into the Price Orphan Detector text area in Tab 2, one per line.",
        "Click DETECT PRICE ORPHANS.",
        "For each orphaned asset, investigate today's headlines for the causal mechanism.",
        "If the mechanism is structural, add a Focus Brief targeting it.",
    ])
    doc.code(
        ["# Format: ASSET_ID,return_as_decimal (one per line)",
         "VLO,0.042",
         "DAL,-0.031",
         "XLE,0.018",
         "BRENT_CRUDE,0.055",
         "EU_UTILITIES,-0.024"],
        caption="Price orphan input format", lang="csv"
    )

    doc.subsection("Activating Candidate Briefs")
    doc.para(
        "Candidate briefs produced by either the velocity or semantic scanner appear "
        "in the right panel of Tab 2. Each card shows the candidate ID, a confidence "
        "percentage, a description of the proposed causal mechanism, and the first "
        "eight suggested watch keywords."
    )
    doc.para(
        "To activate a candidate, click ACTIVATE AS BRIEF. The system creates a new "
        "active brief using the candidate's keywords and removes the CANDIDATE\\_ "
        "prefix from the ID. Navigate to Tab 1 to add Universe Targets and refine the "
        "keyword list before the brief is used in production."
    )
    doc.param_table(
        ["Confidence", "Interpretation", "Recommended action"],
        [
            [">70%",   "Strong signal. Theme is real and building.",      "Activate immediately."],
            ["40-70%", "Moderate signal. Theme is plausible.",            "Activate; monitor closely."],
            ["<40%",   "Early noise. Insufficient evidence.",             "Wait; re-scan in 2-3 days."],
        ],
        col_widths=[60, 240, 148]
    )
    doc.caption("Table 3.3 — Candidate brief confidence thresholds.")

    doc.subsection("Recommended Daily Workflow")
    doc.param_table(
        ["Time", "Action", "Location"],
        [
            ["08:00", "Review active briefs. Deactivate resolved theses.",        "Tab 1 -> Left panel"],
            ["09:00", "Ingest morning headlines.",                                 "Tab 2 -> Ingest News Batch"],
            ["09:05", "Run Velocity Scan. Note any ratio >10x hits.",             "Tab 2 -> Velocity Scan button"],
            ["16:00", "Ingest afternoon and evening headlines.",                  "Tab 2 -> Ingest News Batch"],
            ["16:15", "Run Price Orphan Detector with EOD returns.",             "Tab 2 -> Orphan Detector"],
            ["16:30", "Check current regime and active graph edges.",             "Tab 3 -> Centre panel"],
            ["Friday","Run Semantic Scan over week's accumulated buffer.",        "Tab 2 -> Semantic Scan button"],
            ["Friday","Brief housekeeping: archive stale; refine keywords.",     "Tab 1 -> All panels"],
        ],
        col_widths=[48, 260, 140]
    )
    doc.caption("Table 3.4 — Recommended daily and weekly discovery workflow.")

    # ── Section 4: Settings & Live Status ─────────────────────────────────────
    doc.section("Settings and Live Status  (Tab 3)")

    doc.subsection("Mandate Constraints")
    doc.para(
        "The left panel of Tab 3 displays all mandate constraints read from "
        "config/mandate\\_global\\_alloc.yaml. These parameters are enforced by the "
        "SLSQP portfolio optimiser on every solve cycle."
    )
    doc.param_table(
        ["Parameter", "Default", "Unit", "Description"],
        [
            ["gross_exposure_max",       "2.0",   "x NAV", "Maximum total long + short exposure."],
            ["net_exposure_min",         "-0.20", "x NAV", "Floor on net (long minus short) exposure."],
            ["net_exposure_max",         "+1.20", "x NAV", "Ceiling on net long positioning."],
            ["single_name_long_max",     "0.15",  "x NAV", "Maximum size of any single long position."],
            ["single_name_short_max",    "-0.10", "x NAV", "Maximum size of any single short position."],
            ["sector_concentration_max", "0.35",  "x NAV", "Maximum gross exposure to any one sector."],
            ["max_positions",            "20",    "names", "Cardinality: maximum number of live positions."],
            ["turnover_budget_annual",   "3.0",   "x NAV", "Annual portfolio turnover ceiling."],
        ],
        col_widths=[120, 48, 48, 230]
    )
    doc.caption("Table 4.1 — Mandate constraints with defaults.")

    doc.subsection("Risk Parameters")
    doc.param_table(
        ["Parameter", "Default", "Description"],
        [
            ["risk_aversion", "2.0",   "Lambda in the optimiser objective. Controls return/variance trade-off. Higher = more conservative."],
            ["transaction_cost_coeff", "0.001", "Cost per unit of turnover (10 basis points per side). Penalises excessive rebalancing."],
            ["covariance_lookback_days", "60", "Rolling window length in days for estimating the asset covariance matrix Sigma."],
        ],
        col_widths=[120, 50, 278]
    )
    doc.caption("Table 4.2 — Risk parameters with defaults.")

    doc.subsubsection("Saving a Parameter Change")
    doc.numbered_list([
        "Click on the numeric input field adjacent to the parameter name.",
        "Type the new value.",
        "Click the SAVE button immediately to the right of the input field.",
        "The field briefly turns green to confirm that the value has been written to disk.",
    ])
    doc.note(
        "Parameter changes are written immediately to mandate\\_global\\_alloc.yaml. "
        "The optimiser picks up the new values on its next solve cycle. The API "
        "server does not need to be restarted."
    )

    doc.subsection("Graph Budget and Ontology (Read-Only)")
    doc.para(
        "The Graph Budget panel shows two hard limits enforced by the system in Phase 1. "
        "These values are hardcoded and will be made configurable in Phase 2."
    )
    doc.bullet_list([
        "max\\_active\\_edges = 30:  If the number of ACTIVE edges in the graph exceeds "
        "30, the edges with the lowest Wt values are pruned until the count returns to 30.",
        "min\\_wt\\_to\\_retain = 0.015:  Any edge whose computed Wt falls below this "
        "threshold is automatically pruned regardless of the total edge count.",
    ])
    doc.para(
        "The Ontology section shows the current ontology version, the number of "
        "permitted node types (4), and the number of permitted edge types (7). "
        "These values are governed artefacts — they cannot be changed through the "
        "admin panel."
    )

    doc.subsection("Decay Classes")
    doc.para(
        "The Decay Classes panel provides a visual bar chart of edge half-lives. "
        "Each decay class governs how quickly a causal edge loses weight in the "
        "absence of new confirming evidence."
    )
    doc.param_table(
        ["Decay class", "Half-life", "Applies to"],
        [
            ["LIQUIDITY_STRESS",    "7 days",      "Short-term funding and liquidity flow edges."],
            ["SUPPLY_FLOW",         "14 days",     "Physical commodity transit and flow constraints."],
            ["COST",                "45 days",     "Input cost and margin pressure edges."],
            ["POLICY",              "180 days",    "Central bank and government policy edges."],
            ["INFRASTRUCTURE_DAMAGE","1825 days (5yr)","Physical infrastructure destruction edges."],
        ],
        col_widths=[120, 90, 238]
    )
    doc.caption("Table 4.3 — Edge decay classes and half-lives.")
    doc.warning(
        "INFRASTRUCTURE\\_DAMAGE edges have a special freeze rule: a ceasefire\\_announced "
        "event freezes the decay clock (it does not reset it). The clock only resets "
        "when engineering\\_verification\\_confirmed is received. This prevents a "
        "diplomatic announcement from artificially recovering a destroyed terminal "
        "in the model."
    )

    doc.subsection("Regime Monitoring")
    doc.para(
        "The Current Regime card (centre panel, Tab 3) shows the active market regime "
        "as classified by the RegimeClassifier module. The classifier uses three "
        "economic dimensions — growth, inflation, and risk appetite — to map the "
        "current environment to one of four regimes."
    )
    doc.param_table(
        ["Regime", "Growth", "Inflation", "Risk", "Overlay instruments"],
        [
            ["GROWTH_EXPANSION",  "Positive", "Below target", "ON",  "None"],
            ["STAGFLATION_RISK",  "Negative", "Above target", "OFF", "equity\\_index\\_short (5%), equity\\_vol\\_long (2%)"],
            ["INFLATION_ONLY",    "Positive", "Above target", "ON",  "duration\\_short (3% DV01)"],
            ["RISK_OFF",          "Negative", "Below target", "OFF", "equity\\_index\\_short (3%)"],
        ],
        col_widths=[100, 55, 75, 40, 180]
    )
    doc.caption("Table 4.4 — Regime definitions and overlay instruments.")
    doc.para(
        "Reclassification requires at least two of the three dimensions to shift, "
        "confirmed by a minimum of two independent data sources. A single news "
        "signal — regardless of magnitude — cannot trigger a regime change."
    )

    doc.subsection("Active Graph Edges")
    doc.para(
        "The Active Graph Edges table (centre panel below the regime card) shows all "
        "ACTIVE edges currently in the graph, sorted by Wt in descending order. "
        "Each row displays: the source node, the target node, the abbreviated edge "
        "type, a colour-coded Wt bar, and the numeric Wt value."
    )
    doc.para(
        "The Wt value is computed as: Wt = P\\_post x M\\_adj x exp(-lambda x t) x "
        "(1 - rho\\_corr), where P\\_post is the Bayesian posterior, M\\_adj is the "
        "magnitude adjusted for confidence interval width, lambda is the decay rate "
        "for the edge's decay class, t is the time since last confirmation, and "
        "rho\\_corr is the source correlation penalty."
    )

    doc.subsection("Live Activity Feed")
    doc.para(
        "The Live Activity Feed (right panel, Tab 3) shows the last 30 events from "
        "the immutable DCKG event log, most recent first. The feed auto-refreshes "
        "every 15 seconds. Click REFRESH for an immediate update."
    )
    doc.param_table(
        ["Event type", "Colour", "Meaning"],
        [
            ["CAUSAL_EXTRACTION",           "Cyan",   "A news signal was extracted and passed all filters."],
            ["EDGE_CREATED",                "Green",  "A new causal edge was added to the graph."],
            ["EDGE_UPDATED",                "Gold",   "An existing edge received a Bayesian weight update."],
            ["REGIME_CLASSIFICATION",       "Amber",  "A regime classification result was recorded."],
            ["OPTIMIZER_SOLVE_COMPLETED",   "Purple", "The portfolio optimiser completed a solve cycle."],
            ["OPTIMIZER_SOLVE_FAILED",      "Red",    "The optimiser encountered an error during solve."],
        ],
        col_widths=[140, 55, 252]
    )
    doc.caption("Table 4.5 — Activity feed event type colour coding.")

    doc.subsection("Troubleshooting")
    doc.param_table(
        ["Symptom", "Likely cause", "Resolution"],
        [
            ["All headlines dropping",
             "No active briefs",
             "Add at least one brief in Tab 1. Test a known headline."],
            ["Velocity scan returns nothing",
             "Buffer too small (<200 texts)",
             "Ingest more headlines. Velocity needs 100 recent + 100 baseline."],
            ["Candidate confidence always <30%",
             "Too few dropped texts; theme not yet building",
             "Wait 2-3 days and re-run. Run semantic scan for smaller batches."],
            ["SAVE button has no effect",
             "Server not running or unreachable",
             "Check green LIVE dot. Restart uvicorn if needed."],
            ["Activity feed empty",
             "No events ingested yet",
             "Run the Iran case demo script: python scripts/run_iran_case.py"],
            ["Regime shows STAGFLATION_RISK always",
             "Stub classifier with hardcoded dimensions",
             "Expected in Phase 1. Phase 2 will wire real macro data feeds."],
        ],
        col_widths=[110, 130, 207]
    )
    doc.caption("Table 4.6 — Common issues and resolutions.")


# ══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

def build_admin_manual_latex_pdf(path):
    cv = canvas.Canvas(path, pagesize=A4)
    cv.setTitle("DCKG Admin Panel — User Manual")
    cv.setAuthor("DCKG System")
    cv.setSubject("Technical User Manual — Dynamic Causal Knowledge Graph Administration")

    doc = LatexDoc(cv)

    # Cover page (page 1, no running header)
    doc.cover(
        title="DCKG Administration Panel",
        subtitle="User Manual — Managing Research Themes, Discovering Emerging Signals, "
                 "and Configuring System Governance Parameters",
        version="1.0",
        date="11 April 2026",
        authors="DCKG System",
    )

    # Table of contents will be rendered after all content so we know page numbers.
    # For simplicity, render content first, then write a note.
    # Start content on page 2.
    doc._start_page()
    doc._draw_header()

    # Build all content (fills pages 2 onward)
    build(doc)

    doc.finish()
    print(f"  Saved: {path}  ({doc.page_num} pages)")


if __name__ == "__main__":
    out = r"C:\Users\H\Downloads\dckg_admin_manual_tech.pdf"
    print("Generating DCKG Admin Manual (LaTeX style)...")
    build_admin_manual_latex_pdf(out)
    print("Done.")
