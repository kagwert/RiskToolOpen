"""
Backfill demo — demonstrate point-in-time reconstruction from event log.
Per AR22b: event log must support exact point-in-time reconstruction.

Note: receipt_timestamp is stored with the simulation timestamps to allow
meaningful point-in-time filtering. In a live system this would be the
actual wall-clock time of ingest; here we simulate the Iran case timeline
from Day 0 (2026-03-01) through Day 29 (2026-03-30).
"""
import sys
import uuid
import json
import sqlite3
import tempfile
import os
from pathlib import Path
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).parent.parent))

from pillar1_perception.event_bus import EventBus, DCKGEvent, EVENT_SCHEMA_VERSION

# -----------------------------------------------------------------------
# Helper: publish a simulated event with an explicit receipt_timestamp.
# We bypass make_event's wall-clock stamping so that point-in-time
# reconstruction filters correctly against the Iran case timeline.
# -----------------------------------------------------------------------
def _publish_simulated(bus: EventBus, event_type: str, source: str,
                        payload: dict, sim_ts: str) -> str:
    """Write a DCKGEvent whose receipt_timestamp = sim_ts (not wall-clock now)."""
    evt = DCKGEvent(
        event_id=str(uuid.uuid4()),
        event_type=event_type,
        source_component=source,
        receipt_timestamp=sim_ts,
        publication_timestamp=sim_ts,
        ontology_version="1.0",
        payload=payload,
        schema_version=EVENT_SCHEMA_VERSION,
    )
    return bus.publish(evt)


def run():
    print("=" * 70)
    print("DCKG -- Point-in-Time Reconstruction Demo")
    print("=" * 70)

    _tmp_db = tempfile.mktemp(suffix=".db")
    bus = EventBus(db_path=_tmp_db)

    # Simulate events at their Iran-case-study timestamps
    sim_events = [
        ("2026-03-01T00:14:00+00:00", "CAUSAL_EXTRACTION",   "D0: Initial strike extraction"),
        ("2026-03-03T08:00:00+00:00", "EDGE_UPDATED",        "D2: AIS Bayesian update"),
        ("2026-03-08T14:30:00+00:00", "EDGE_CREATED",        "D7: Ras Tanura infrastructure damage"),
        ("2026-03-10T09:00:00+00:00", "REGIME_CLASSIFIED",   "D9: Stagflation regime classified"),
        ("2026-03-24T15:45:00+00:00", "CAUSAL_EXTRACTION",   "D23: Trump social media (narrative)"),
        ("2026-03-30T16:00:00+00:00", "ALPHA_VECTOR_PUBLISHED", "D29: Final alpha vector"),
    ]

    for ts, et, label in sim_events:
        _publish_simulated(bus, et, "demo",
                           {"label": label, "simulation_timestamp": ts}, ts)
        print(f"  Published [{ts[:10]}]: {label}")

    print(f"\nTotal events in log: {len(sim_events)}")

    # -----------------------------------------------------------------------
    # Point-in-time reconstruction at the end of Day 10 (2026-03-11).
    # Expected: 4 events visible (D0, D2, D7, D9); D23 and D29 not yet received.
    # -----------------------------------------------------------------------
    reconstruct_ts = "2026-03-11T00:00:00+00:00"
    events_at_d10 = bus.reconstruct_at(reconstruct_ts)
    event_ids_at_d10 = {e.event_id for e in events_at_d10}

    print(f"\nPoint-in-time reconstruction at end of Day 10 ({reconstruct_ts[:10]}):")
    print(f"  Events visible: {len(events_at_d10)} of {len(sim_events)} total")
    for e in events_at_d10:
        print(f"    [{e.receipt_timestamp[:10]}] {e.event_type}: {e.payload.get('label', '')}")

    # Events not yet present at the Day 10 cutoff
    all_events = bus.reconstruct_at("2099-01-01T00:00:00+00:00")
    hidden = [e for e in all_events if e.event_id not in event_ids_at_d10]
    if hidden:
        print(f"\nEvents NOT yet visible at Day 10 (future — not yet received):")
        for e in hidden:
            print(f"    [{e.receipt_timestamp[:10]}] {e.event_type}: {e.payload.get('label', '')}")

    # -----------------------------------------------------------------------
    # Immutability: attempt a DELETE — must raise OperationalError
    # -----------------------------------------------------------------------
    print("\nImmutability verification:")
    conn = sqlite3.connect(_tmp_db)
    try:
        conn.execute("DELETE FROM events WHERE row_id = (SELECT MIN(row_id) FROM events);")
        conn.commit()
        print("  DELETE: UNEXPECTED SUCCESS (immutability BROKEN)")
    except (sqlite3.OperationalError, sqlite3.IntegrityError) as ex:
        print(f"  DELETE blocked by schema trigger: CONFIRMED ({str(ex)[:60]})")
    finally:
        conn.close()

    conn2 = sqlite3.connect(_tmp_db)
    try:
        conn2.execute("UPDATE events SET event_type='HACKED' WHERE 1=1;")
        conn2.commit()
        print("  UPDATE: UNEXPECTED SUCCESS (immutability BROKEN)")
    except (sqlite3.OperationalError, sqlite3.IntegrityError) as ex:
        print(f"  UPDATE blocked by schema trigger: CONFIRMED ({str(ex)[:60]})")
    finally:
        conn2.close()

    passed = len(events_at_d10) == 4
    print(f"\nPoint-in-time reconstruction: {'PASS' if passed else 'FAIL'} "
          f"(expected 4 events at D10, got {len(events_at_d10)})")

    # Cleanup
    try:
        os.remove(_tmp_db)
    except OSError:
        pass


if __name__ == "__main__":
    run()
