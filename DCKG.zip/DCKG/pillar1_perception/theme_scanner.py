"""
ThemeScanner — detects emerging themes in news that matched no active brief.

Two-tier detection:
  Tier 1 (fast, free): keyword velocity tracking over a rolling buffer.
    - Runs every time ingest_dropped() is called.
    - Surfaces n-grams whose frequency in the recent window exceeds a threshold.
    - No API call, no ML dependencies beyond stdlib + numpy.

  Tier 2 (semantic, cheap): batched Claude API call over accumulated dropped texts.
    - Call scan_semantic() manually or on a schedule (daily).
    - Sends up to MAX_SEMANTIC_BATCH texts to Claude.
    - Returns structured candidate brief suggestions in YAML-ready format.

Integration:
    Agent A calls ingest_dropped(text) whenever a text is silently dropped by
    the brief filter (Layer 3a keyword gate). The scanner accumulates these in a
    rolling buffer and can be queried at any time.

Usage:
    scanner = ThemeScanner()
    # in agent_a:
    if not matched:
        scanner.ingest_dropped(text)
    # hourly:
    candidates = scanner.scan_velocity()
    # daily:
    candidates = scanner.scan_semantic(api_key=...)
"""
import re
import json
import math
from collections import Counter, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional, Dict, Tuple
from pathlib import Path

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

# ── Stop words (English financial + common) ────────────────────────────────────
_STOP = frozenset({
    "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "up", "about", "into", "through", "after",
    "is", "are", "was", "were", "be", "been", "being", "have", "has", "had",
    "do", "does", "did", "will", "would", "could", "should", "may", "might",
    "that", "this", "these", "those", "it", "its", "as", "if", "he", "she",
    "they", "we", "their", "said", "says", "report", "reports", "new", "year",
    "market", "markets", "global", "international", "amid", "amid", "amid",
    "amid", "amid", "amid", "amid", "amid", "amid", "amid", "amid",
    "amid", "amid", "amid", "amid", "amid", "amid", "amid", "amid",
    "per", "cent", "percent", "%", "billion", "million", "trillion",
    "quarter", "week", "month", "day", "time", "first", "second", "third",
    "over", "under", "more", "less", "higher", "lower", "rise", "fall",
    "increase", "decrease", "gain", "loss", "hit", "set", "see",
})

# ── Config ────────────────────────────────────────────────────────────────────
ROLLING_WINDOW_SIZE = 500        # max dropped texts in rolling buffer
VELOCITY_WINDOW_RECENT = 100     # compare last N vs prior N for velocity
VELOCITY_MIN_COUNT = 4           # must appear at least this many times in recent window
VELOCITY_MIN_RATIO = 2.5         # recent_freq / baseline_freq threshold
BIGRAM_MIN_COUNT = 3             # minimum co-occurrences to form a bigram candidate
MAX_SEMANTIC_BATCH = 80          # max dropped texts sent to Claude per semantic scan
MIN_TEXTS_FOR_SEMANTIC = 10      # don't bother calling Claude with fewer than this
CANDIDATE_BRIEF_TOP_N = 5        # how many candidate briefs to surface


@dataclass
class VelocityCandidate:
    """A keyword or phrase with anomalous velocity in the dropped buffer."""
    phrase: str
    recent_count: int
    baseline_count: int
    velocity_ratio: float
    example_texts: List[str] = field(default_factory=list)

    def __str__(self):
        return (f"  '{self.phrase}'  recent={self.recent_count}  "
                f"baseline={self.baseline_count}  ratio={self.velocity_ratio:.1f}x"
                + (f"\n    e.g. \"{self.example_texts[0][:100]}\"" if self.example_texts else ""))


@dataclass
class CandidateBrief:
    """
    A structured theme suggestion suitable for converting into a focus_briefs.yaml entry.
    Output by either the velocity scanner or the semantic scanner.
    """
    id: str
    name: str
    description: str
    watch_keywords: List[str]
    universe_targets: List[str]
    watch_edge_types: List[str]
    confidence: float              # 0-1: how strongly the scanner believes this is real
    source: str                    # "velocity" or "semantic"
    supporting_texts: List[str] = field(default_factory=list)

    def to_yaml_block(self) -> str:
        """Return a YAML snippet ready to paste into focus_briefs.yaml."""
        kws = "\n".join(f"      - {k}" for k in self.watch_keywords[:15])
        tgts = "\n".join(f"      - {t}" for t in self.universe_targets)
        edges = "\n".join(f"      - {e}" for e in self.watch_edge_types)
        return f"""
  # CANDIDATE BRIEF (confidence={self.confidence:.2f}, source={self.source})
  - id: {self.id}
    name: "{self.name}"
    active: false   # <-- review and set true to activate
    description: >
      {self.description}
    watch_keywords:
{kws}
    watch_nodes: []   # <-- add after first articles are processed
    watch_edge_types:
{edges}
    universe_targets:
{tgts}
    regime_relevant: []
    min_novelty_score: 0.25
    graph_priority: 99
"""


class ThemeScanner:
    """
    Detects emerging causal themes in news that matched no active brief.
    Feed dropped texts via ingest_dropped(); query with scan_velocity() or
    scan_semantic().
    """

    def __init__(self, window_size: int = ROLLING_WINDOW_SIZE):
        self._buffer: deque = deque(maxlen=window_size)   # (timestamp, text) tuples
        self._window_size = window_size

    # ── Ingestion ─────────────────────────────────────────────────────────────

    def ingest_dropped(self, text: str):
        """Call whenever a text is dropped by the brief filter (Layer 3a)."""
        ts = datetime.now(timezone.utc).isoformat()
        self._buffer.append((ts, text))

    @property
    def buffer_size(self) -> int:
        return len(self._buffer)

    # ── Tier 1: Velocity scanner ───────────────────────────────────────────────

    def scan_velocity(self) -> List[VelocityCandidate]:
        """
        Compares keyword frequency in the most recent VELOCITY_WINDOW_RECENT texts
        vs the prior baseline. Returns phrases with anomalous velocity.
        Called for free — no API.
        """
        texts = [t for _, t in self._buffer]
        if len(texts) < VELOCITY_WINDOW_RECENT * 2:
            return []

        recent_texts = texts[-VELOCITY_WINDOW_RECENT:]
        baseline_texts = texts[-VELOCITY_WINDOW_RECENT * 2: -VELOCITY_WINDOW_RECENT]

        recent_counts = self._count_phrases(recent_texts)
        baseline_counts = self._count_phrases(baseline_texts)

        # Baseline normalization: express as frequency per 100 texts
        baseline_total = max(len(baseline_texts), 1)
        recent_total = max(len(recent_texts), 1)

        candidates = []
        for phrase, r_count in recent_counts.most_common(200):
            if r_count < VELOCITY_MIN_COUNT:
                continue
            b_count = baseline_counts.get(phrase, 0)
            # Normalise both to per-100 rate
            r_rate = r_count / recent_total * 100
            b_rate = b_count / baseline_total * 100 if b_count else 0.2  # floor
            ratio = r_rate / b_rate
            if ratio >= VELOCITY_MIN_RATIO:
                examples = [t for t in recent_texts if phrase in t.lower()][:2]
                candidates.append(VelocityCandidate(
                    phrase=phrase,
                    recent_count=r_count,
                    baseline_count=b_count,
                    velocity_ratio=round(ratio, 1),
                    example_texts=examples,
                ))

        # Sort by velocity ratio, cap at 20 top candidates
        candidates.sort(key=lambda x: x.velocity_ratio, reverse=True)
        return candidates[:20]

    def _count_phrases(self, texts: List[str]) -> Counter:
        """Extract unigrams and bigrams from a list of texts."""
        counts: Counter = Counter()
        for text in texts:
            tokens = self._tokenize(text)
            # Unigrams
            for tok in tokens:
                counts[tok] += 1
            # Bigrams
            for i in range(len(tokens) - 1):
                bigram = tokens[i] + " " + tokens[i + 1]
                counts[bigram] += 1
        return counts

    def _tokenize(self, text: str) -> List[str]:
        """Lowercase, strip punctuation, remove stop words, min length 3."""
        raw = re.sub(r"[^a-z0-9\s\-]", " ", text.lower())
        tokens = raw.split()
        return [t for t in tokens if len(t) >= 3 and t not in _STOP]

    def velocity_to_candidates(
        self,
        velocity_hits: List[VelocityCandidate],
        existing_brief_keywords: Optional[List[str]] = None,
    ) -> List[CandidateBrief]:
        """
        Clusters velocity hits into candidate brief suggestions.
        Groups phrases that co-occur in the same texts into a single theme.
        Filters out phrases already covered by existing briefs.
        """
        existing_kw_lower = set(k.lower() for k in (existing_brief_keywords or []))

        # Filter out phrases already well-covered by active briefs
        novel_hits = [h for h in velocity_hits
                      if h.phrase not in existing_kw_lower and h.velocity_ratio >= VELOCITY_MIN_RATIO]

        if not novel_hits:
            return []

        # Group by co-occurrence: two phrases belong to the same theme if they
        # appear together in at least 2 of the same texts.
        texts = [t for _, t in self._buffer]
        recent_texts = texts[-VELOCITY_WINDOW_RECENT:]

        phrase_to_texts: Dict[str, set] = {}
        for hit in novel_hits:
            phrase_to_texts[hit.phrase] = set(
                i for i, t in enumerate(recent_texts) if hit.phrase in t.lower()
            )

        # Simple greedy clustering: seed cluster with highest-velocity phrase,
        # add phrases with Jaccard similarity > 0.2 to the same cluster
        used = set()
        clusters: List[List[VelocityCandidate]] = []
        for hit in novel_hits:
            if hit.phrase in used:
                continue
            cluster = [hit]
            used.add(hit.phrase)
            seed_texts = phrase_to_texts[hit.phrase]
            for other in novel_hits:
                if other.phrase in used:
                    continue
                other_texts = phrase_to_texts[other.phrase]
                if not seed_texts or not other_texts:
                    continue
                jaccard = len(seed_texts & other_texts) / len(seed_texts | other_texts)
                if jaccard >= 0.2:
                    cluster.append(other)
                    used.add(other.phrase)
            clusters.append(cluster)

        # Convert top clusters to CandidateBriefs
        candidates = []
        for cluster in clusters[:CANDIDATE_BRIEF_TOP_N]:
            top_phrase = cluster[0].phrase
            slug = re.sub(r"[^a-z0-9]+", "_", top_phrase).upper()[:30]
            brief_id = f"CANDIDATE_{slug}"
            kws = [h.phrase for h in cluster[:12]]
            confidence = min(0.9, cluster[0].velocity_ratio / 10.0)
            support_texts = cluster[0].example_texts[:3]

            candidates.append(CandidateBrief(
                id=brief_id,
                name=f"Candidate: {top_phrase.title()}",
                description=(
                    f"Emerging theme detected by velocity scanner. "
                    f"Top phrase '{top_phrase}' appeared {cluster[0].recent_count}x "
                    f"(ratio {cluster[0].velocity_ratio}x vs baseline). "
                    f"Review supporting texts to determine investability."
                ),
                watch_keywords=kws,
                universe_targets=[],     # PM must fill in
                watch_edge_types=[
                    "CONSTRAINS_SUPPLY_OF", "INCREASES_COST_OF",
                    "CAUSES_POLICY_SHIFT_IN", "ALTERS_RISK_APPETITE_FOR",
                    "DISRUPTS_INFRASTRUCTURE_OF", "CREATES_DEMAND_FOR",
                ],
                confidence=round(confidence, 2),
                source="velocity",
                supporting_texts=support_texts,
            ))

        return candidates

    # ── Tier 2: Semantic scanner (Claude API) ──────────────────────────────────

    SEMANTIC_PROMPT = """You are a causal investment research analyst. You will receive a batch of news headlines and snippets that were REJECTED by the current research agenda because they didn't match any active thesis brief.

Your job: identify emerging investable causal themes hidden in this rejected pile.

An investable causal theme must have:
1. A clear causal mechanism (X causes Y because Z)
2. A plausible link to a tradeable financial asset
3. Enough recurrence across multiple texts to suggest it's building

For each theme you find, output a JSON object with:
- id: UPPER_SNAKE_CASE identifier (max 30 chars)
- name: short human name
- description: 2-3 sentences describing the causal mechanism and why it's investable
- watch_keywords: list of 8-15 keywords/phrases that would catch this theme in future news
- universe_targets: list of asset types this theme likely affects (use generic names like
  "energy_producers", "airlines", "rates", "credit_spreads", "equity_index", "semiconductors",
  "utilities", "defence", "commodities" — do NOT fabricate specific ticker symbols)
- primary_edge_type: the most likely causal mechanism type from:
  [CONSTRAINS_SUPPLY_OF, INCREASES_COST_OF, CREATES_DEMAND_FOR, CAUSES_POLICY_SHIFT_IN,
   DISRUPTS_INFRASTRUCTURE_OF, ALTERS_RISK_APPETITE_FOR]
- confidence: 0.0-1.0 (how strongly the evidence suggests this is a real building theme)
- key_evidence: list of 1-3 text snippets from the input that most strongly support this theme

Output a JSON array. If no investable themes exist in the input, output [].
Do NOT output anything other than the JSON array."""

    def scan_semantic(
        self,
        api_key: Optional[str] = None,
        max_texts: int = MAX_SEMANTIC_BATCH,
    ) -> List[CandidateBrief]:
        """
        Send a batch of dropped texts to Claude for semantic theme extraction.
        Returns structured CandidateBrief objects.
        Costs ~1-3 Claude API calls worth of tokens per run.
        """
        texts = [t for _, t in self._buffer]
        if len(texts) < MIN_TEXTS_FOR_SEMANTIC:
            return []

        # Sample from the buffer: take recent texts, but also include some older
        # ones to catch themes that are consistently present (not just spikes)
        sample = texts[-max_texts:]

        batch_text = "\n---\n".join(
            f"[{i+1}] {t[:300]}" for i, t in enumerate(sample)
        )

        if not ANTHROPIC_AVAILABLE:
            return self._mock_semantic(sample)

        client = anthropic.Anthropic(api_key=api_key) if api_key else anthropic.Anthropic()
        try:
            response = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=3000,
                system=self.SEMANTIC_PROMPT,
                messages=[{"role": "user", "content": batch_text}],
            )
            raw = response.content[0].text.strip()
            if raw.startswith("```"):
                raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
            themes = json.loads(raw)
        except Exception:
            themes = []

        return self._themes_to_candidates(themes)

    def _themes_to_candidates(self, themes: list) -> List[CandidateBrief]:
        results = []
        for t in themes:
            if not isinstance(t, dict):
                continue
            edge_type = t.get("primary_edge_type", "CONSTRAINS_SUPPLY_OF")
            results.append(CandidateBrief(
                id=t.get("id", "CANDIDATE_UNKNOWN"),
                name=t.get("name", "Unknown Theme"),
                description=t.get("description", ""),
                watch_keywords=t.get("watch_keywords", []),
                universe_targets=t.get("universe_targets", []),
                watch_edge_types=[edge_type,
                                  "CAUSES_POLICY_SHIFT_IN",
                                  "ALTERS_RISK_APPETITE_FOR"],
                confidence=float(t.get("confidence", 0.5)),
                source="semantic",
                supporting_texts=t.get("key_evidence", []),
            ))
        results.sort(key=lambda x: x.confidence, reverse=True)
        return results

    def _mock_semantic(self, texts: List[str]) -> List[CandidateBrief]:
        """Mock response when Anthropic SDK is unavailable."""
        return [CandidateBrief(
            id="CANDIDATE_MOCK_THEME",
            name="Mock Candidate Theme",
            description="Semantic scanner requires Anthropic SDK. Install anthropic package.",
            watch_keywords=["mock", "test"],
            universe_targets=["equity_index"],
            watch_edge_types=["CONSTRAINS_SUPPLY_OF"],
            confidence=0.0,
            source="semantic",
        )]

    # ── Price orphan detection helper ─────────────────────────────────────────

    @staticmethod
    def find_price_orphans(
        universe_returns: Dict[str, float],
        active_edge_targets: List[str],
        z_score_threshold: float = 2.0,
        returns_history: Optional[Dict[str, List[float]]] = None,
    ) -> List[Tuple[str, float, str]]:
        """
        Identify universe assets with large price moves that have no active
        causal edge in the graph pointing to them.

        Args:
            universe_returns: {asset_id: today's return} e.g. {"VLO": 0.04}
            active_edge_targets: list of asset_ids that currently have at least
                one active DCKG causal edge (from graph_store.get_state_snapshot())
            z_score_threshold: flag moves beyond this many sigma
            returns_history: {asset_id: [prior returns]} for z-score calculation.
                If None, uses abs(return) > 3% as a simple threshold.

        Returns:
            List of (asset_id, return_value, reason) for orphaned movers.
        """
        orphans = []
        for asset, ret in universe_returns.items():
            if asset in active_edge_targets:
                continue  # explained by graph

            if returns_history and asset in returns_history:
                hist = returns_history[asset]
                if len(hist) < 5:
                    continue
                mean = sum(hist) / len(hist)
                var = sum((r - mean) ** 2 for r in hist) / len(hist)
                std = math.sqrt(var) if var > 0 else 0.01
                z = abs(ret - mean) / std
                if z >= z_score_threshold:
                    orphans.append((
                        asset, ret,
                        f"z={z:.1f} sigma move with no causal edge (std={std:.3f})"
                    ))
            else:
                # Simple threshold fallback
                if abs(ret) >= 0.03:
                    orphans.append((
                        asset, ret,
                        f"{ret*100:+.1f}% move with no active causal edge in graph"
                    ))

        orphans.sort(key=lambda x: abs(x[1]), reverse=True)
        return orphans
