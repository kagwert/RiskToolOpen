"""
Event bus — Phase 1 implementation using SQLite WAL.

Per AR22: append-only, never modified, redundantly stored.
Per AR63: all inter-component data flows through this bus.
Per AR64: every message carries the mandatory field set.
Per AR22b: supports point-in-time reconstruction.

Production replacement: Apache Kafka + Apache Iceberg.
Interface contract: this module exposes publish() and subscribe()
with the same signatures regardless of backend.
"""

import sqlite3
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Iterator
from dataclasses import dataclass, asdict, field

EVENT_SCHEMA_VERSION = "1.0"

EVENT_TYPES = {
    # Pillar I → II
    "CAUSAL_EXTRACTION",        # Agent extracted a causal claim from raw data
    "MARKET_DATA_UPDATE",       # Market price or spread updated
    "MACRO_RELEASE",            # Economic data release received
    "FEED_FAILURE",             # Data feed failure detected — per AR18b
    "FEED_RESTORED",            # Data feed restored

    # Pillar II internal
    "EDGE_CREATED",             # New causal edge added to graph
    "EDGE_UPDATED",             # Existing edge weight updated
    "EDGE_CONTESTED",           # Edge flagged as CONTESTED
    "EDGE_RETIRED",             # Edge weight fell below activation threshold
    "CONFLICT_DETECTED",        # Two signals in directional conflict
    "CONFLICT_RESOLVED",        # Conflict resolution produced ACTIVE or CONTESTED
    "REGIME_CLASSIFIED",        # Regime classifier produced new classification
    "REGIME_OVERLAY_ACTIVATED", # Standing overlay position activated
    "ALPHA_VECTOR_UPDATED",     # New alpha vector produced

    # Pillar II → III
    "ALPHA_VECTOR_PUBLISHED",

    # Pillar III
    "OPTIMIZER_SOLVE_STARTED",
    "OPTIMIZER_SOLVE_COMPLETED",
    "OPTIMIZER_SOLVE_FAILED",
    "PORTFOLIO_WEIGHTS_PUBLISHED",
}


@dataclass
class DCKGEvent:
    """
    Mandatory field set per AR64. Every event published to the bus must
    carry all of these fields. Downstream components may add optional fields
    but may not omit mandatory ones.
    """
    event_id: str               # UUID, immutable
    event_type: str             # Controlled vocabulary: see EVENT_TYPES above
    source_component: str       # Which pillar/agent produced this event
    receipt_timestamp: str      # ISO8601 UTC — when received by the bus
    publication_timestamp: str  # ISO8601 UTC — when the source published the data
    ontology_version: str       # Which ontology version was active at extraction time
    payload: dict               # Event-specific data
    schema_version: str = field(default=EVENT_SCHEMA_VERSION)
    correlation_id: Optional[str] = None  # Links related events


# SQL for creating the events table with NOT NULL constraints on all AR64 fields
_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS events (
    row_id               INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id             TEXT    NOT NULL UNIQUE,
    event_type           TEXT    NOT NULL,
    source_component     TEXT    NOT NULL,
    receipt_timestamp    TEXT    NOT NULL,
    publication_timestamp TEXT   NOT NULL,
    ontology_version     TEXT    NOT NULL,
    schema_version       TEXT    NOT NULL,
    correlation_id       TEXT,
    payload_json         TEXT    NOT NULL
);
"""

_CREATE_INDEXES_SQL = [
    "CREATE INDEX IF NOT EXISTS idx_events_receipt_ts ON events (receipt_timestamp);",
    "CREATE INDEX IF NOT EXISTS idx_events_event_type ON events (event_type);",
    "CREATE INDEX IF NOT EXISTS idx_events_source ON events (source_component);",
]

# Triggers that structurally enforce append-only by raising errors on any
# DELETE or UPDATE attempt. These fire at the SQLite engine level before
# any application code can intercept the operation.
_CREATE_IMMUTABILITY_TRIGGERS_SQL = [
    """
    CREATE TRIGGER IF NOT EXISTS prevent_delete_events
    BEFORE DELETE ON events
    BEGIN
        SELECT RAISE(ABORT, 'IMMUTABILITY VIOLATION: DELETE is prohibited on the events table. The event log is append-only per AR22.');
    END;
    """,
    """
    CREATE TRIGGER IF NOT EXISTS prevent_update_events
    BEFORE UPDATE ON events
    BEGIN
        SELECT RAISE(ABORT, 'IMMUTABILITY VIOLATION: UPDATE is prohibited on the events table. The event log is append-only per AR22.');
    END;
    """,
]

_INSERT_EVENT_SQL = """
INSERT INTO events (
    event_id,
    event_type,
    source_component,
    receipt_timestamp,
    publication_timestamp,
    ontology_version,
    schema_version,
    correlation_id,
    payload_json
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
"""


def _row_to_event(row: tuple) -> DCKGEvent:
    """Convert a database row tuple to a DCKGEvent dataclass."""
    (
        _row_id,
        event_id,
        event_type,
        source_component,
        receipt_timestamp,
        publication_timestamp,
        ontology_version,
        schema_version,
        correlation_id,
        payload_json,
    ) = row
    return DCKGEvent(
        event_id=event_id,
        event_type=event_type,
        source_component=source_component,
        receipt_timestamp=receipt_timestamp,
        publication_timestamp=publication_timestamp,
        ontology_version=ontology_version,
        schema_version=schema_version,
        correlation_id=correlation_id,
        payload=json.loads(payload_json),
    )


class EventBus:
    """
    SQLite-backed event bus with append-only enforcement.

    Append-only enforcement: SQLite triggers on the events table raise
    ABORT-level errors for any DELETE or UPDATE statement, making it
    structurally impossible to modify existing records — not merely
    a convention. In production (Kafka + Apache Iceberg), append-only
    is enforced at the infrastructure level; here we enforce it at the
    schema level.

    WAL mode is set on every connection for durability under concurrent
    readers. The connection is not shared across threads — callers should
    instantiate one EventBus per thread or use the module-level singleton.
    """

    def __init__(self, db_path: str = "dckg_event_log.db"):
        self.db_path = Path(db_path)
        self._init_db()

    def _init_db(self) -> None:
        """
        Initialise the SQLite database.

        Sets WAL journal mode, creates the events table with NOT NULL
        constraints on all AR64 mandatory fields, creates indexes for
        efficient timestamp and event_type queries, and installs the
        immutability triggers that prevent DELETE and UPDATE.
        """
        conn = sqlite3.connect(str(self.db_path))
        try:
            # Enable WAL mode for better concurrent read/write performance
            # and crash durability.
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA synchronous=NORMAL;")

            # Create the events table.
            conn.execute(_CREATE_TABLE_SQL)

            # Create query-performance indexes.
            for idx_sql in _CREATE_INDEXES_SQL:
                conn.execute(idx_sql)

            # Install immutability triggers. These fire at the SQLite engine
            # level — RAISE(ABORT, ...) rolls back the offending statement
            # and raises an OperationalError in Python before any row is
            # deleted or updated.
            for trigger_sql in _CREATE_IMMUTABILITY_TRIGGERS_SQL:
                conn.execute(trigger_sql)

            conn.commit()
        finally:
            conn.close()

    def publish(self, event: DCKGEvent) -> str:
        """
        Append an event to the immutable log. Returns the event_id.

        Validates all mandatory AR64 fields before writing. Raises
        ValueError immediately if any mandatory field is absent or empty,
        or if event_type is not in the controlled vocabulary.

        Never modifies existing records — append-only is a structural
        guarantee enforced by both this method and the database triggers.

        Args:
            event: A fully-populated DCKGEvent dataclass.

        Returns:
            The event_id string (UUID) of the persisted event.

        Raises:
            ValueError: If mandatory fields are missing or event_type is unknown.
            sqlite3.OperationalError: Propagated from the database on schema errors.
        """
        # Validate mandatory fields per AR64.
        mandatory_fields = [
            "event_id",
            "event_type",
            "source_component",
            "receipt_timestamp",
            "publication_timestamp",
            "ontology_version",
            "payload",
        ]
        for field_name in mandatory_fields:
            value = getattr(event, field_name, None)
            if value is None:
                raise ValueError(
                    f"Mandatory AR64 field '{field_name}' is None on event {event.event_id!r}."
                )
            if isinstance(value, str) and not value.strip():
                raise ValueError(
                    f"Mandatory AR64 field '{field_name}' is empty on event {event.event_id!r}."
                )

        # Validate event_type against controlled vocabulary.
        if event.event_type not in EVENT_TYPES:
            raise ValueError(
                f"Unknown event_type {event.event_type!r}. "
                f"Must be one of: {sorted(EVENT_TYPES)}"
            )

        payload_json = json.dumps(event.payload, separators=(",", ":"))

        conn = sqlite3.connect(str(self.db_path))
        try:
            conn.execute(
                _INSERT_EVENT_SQL,
                (
                    event.event_id,
                    event.event_type,
                    event.source_component,
                    event.receipt_timestamp,
                    event.publication_timestamp,
                    event.ontology_version,
                    event.schema_version,
                    event.correlation_id,
                    payload_json,
                ),
            )
            conn.commit()
        finally:
            conn.close()

        return event.event_id

    def subscribe(
        self,
        event_types: list,
        since_timestamp: Optional[str] = None,
    ) -> Iterator[DCKGEvent]:
        """
        Generator yielding events of the specified types in receipt_timestamp order.

        If since_timestamp is provided, replays all matching events from that
        ISO8601 UTC timestamp forward — this is the point-in-time replay
        capability required by AR22b.

        In Phase 1 this performs a one-shot query; the production replacement
        (Kafka consumer) would maintain a live cursor. The calling signature
        is identical.

        Args:
            event_types: List of event_type strings to filter on.
                         Must be a subset of EVENT_TYPES.
            since_timestamp: Optional ISO8601 UTC string. If provided, only
                             events with receipt_timestamp >= since_timestamp
                             are returned.

        Yields:
            DCKGEvent instances in ascending receipt_timestamp order.

        Raises:
            ValueError: If any member of event_types is not in the vocabulary.
        """
        for et in event_types:
            if et not in EVENT_TYPES:
                raise ValueError(
                    f"Unknown event_type {et!r} in subscription filter. "
                    f"Must be one of: {sorted(EVENT_TYPES)}"
                )

        placeholders = ",".join("?" for _ in event_types)
        params: list = list(event_types)

        if since_timestamp is not None:
            query = (
                f"SELECT row_id, event_id, event_type, source_component, "
                f"receipt_timestamp, publication_timestamp, ontology_version, "
                f"schema_version, correlation_id, payload_json "
                f"FROM events "
                f"WHERE event_type IN ({placeholders}) "
                f"AND receipt_timestamp >= ? "
                f"ORDER BY receipt_timestamp ASC, row_id ASC;"
            )
            params.append(since_timestamp)
        else:
            query = (
                f"SELECT row_id, event_id, event_type, source_component, "
                f"receipt_timestamp, publication_timestamp, ontology_version, "
                f"schema_version, correlation_id, payload_json "
                f"FROM events "
                f"WHERE event_type IN ({placeholders}) "
                f"ORDER BY receipt_timestamp ASC, row_id ASC;"
            )

        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = None  # Use plain tuples for _row_to_event
        try:
            cursor = conn.execute(query, params)
            rows = cursor.fetchall()
        finally:
            conn.close()

        for row in rows:
            yield _row_to_event(row)

    def reconstruct_at(self, timestamp: str) -> list:
        """
        Return all events that existed as of the given ISO8601 UTC timestamp.

        This is the point-in-time reconstruction capability required by AR22b.
        The result is identical to what the live system held at that moment —
        i.e. all events whose receipt_timestamp is <= timestamp, ordered by
        (receipt_timestamp ASC, row_id ASC).

        Args:
            timestamp: ISO8601 UTC string representing the point in time.

        Returns:
            List of DCKGEvent instances in insertion order up to timestamp.
        """
        query = (
            "SELECT row_id, event_id, event_type, source_component, "
            "receipt_timestamp, publication_timestamp, ontology_version, "
            "schema_version, correlation_id, payload_json "
            "FROM events "
            "WHERE receipt_timestamp <= ? "
            "ORDER BY receipt_timestamp ASC, row_id ASC;"
        )

        conn = sqlite3.connect(str(self.db_path))
        try:
            cursor = conn.execute(query, (timestamp,))
            rows = cursor.fetchall()
        finally:
            conn.close()

        return [_row_to_event(row) for row in rows]


def make_event(
    event_type: str,
    source_component: str,
    payload: dict,
    ontology_version: str = "1.0",
    correlation_id: Optional[str] = None,
    publication_timestamp: Optional[str] = None,
) -> DCKGEvent:
    """
    Convenience factory that generates a fully-populated DCKGEvent.

    Assigns a fresh UUID for event_id and sets receipt_timestamp to now (UTC).
    publication_timestamp defaults to receipt_timestamp if not provided.

    Args:
        event_type: Must be a member of EVENT_TYPES.
        source_component: Identifier of the publishing component.
        payload: Event-specific dictionary payload.
        ontology_version: Ontology version active at extraction time.
        correlation_id: Optional link to a related event chain.
        publication_timestamp: ISO8601 UTC of the original source publication;
                               defaults to the current UTC time.

    Returns:
        A fully-populated DCKGEvent ready for EventBus.publish().
    """
    now_utc = datetime.now(timezone.utc).isoformat()
    return DCKGEvent(
        event_id=str(uuid.uuid4()),
        event_type=event_type,
        source_component=source_component,
        receipt_timestamp=now_utc,
        publication_timestamp=publication_timestamp if publication_timestamp is not None else now_utc,
        ontology_version=ontology_version,
        payload=payload,
        schema_version=EVENT_SCHEMA_VERSION,
        correlation_id=correlation_id,
    )
