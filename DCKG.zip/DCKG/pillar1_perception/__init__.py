"""
Pillar I — Perception layer.

Responsible for receiving raw data feeds (newsflow, market data, macro releases,
physical observables) and publishing structured events to the DCKG event bus.

Components:
    event_bus      — SQLite WAL append-only event log (AR22, AR63, AR64)
    agent_a_newsflow — Causal extraction agent using Claude API (AR01–AR20)
"""
