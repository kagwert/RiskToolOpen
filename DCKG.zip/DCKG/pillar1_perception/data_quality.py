"""
Data quality — schema validation and feed failure detection.
Per AR18d, AR18e.
"""
from dataclasses import dataclass
from typing import List, Optional
from datetime import datetime, timezone, timedelta


REQUIRED_CAUSAL_EXTRACTION_FIELDS = [
    "source_node_type", "source_node_id", "target_node_type", "target_node_id",
    "edge_type", "p_raw", "magnitude_estimate", "magnitude_ci_width",
    "narrative_sensitive", "novelty_score", "verifiability_score",
    "publication_timestamp", "receipt_timestamp", "raw_text_excerpt", "ontology_version",
]


@dataclass
class QualityScore:
    passed: bool
    score: float           # 0.0 to 1.0
    issues: List[str]
    field_completeness: float


def validate_causal_extraction(payload: dict) -> QualityScore:
    issues: List[str] = []

    missing = [f for f in REQUIRED_CAUSAL_EXTRACTION_FIELDS if f not in payload]
    if missing:
        issues.append(f"Missing required fields: {missing}")
    completeness = 1.0 - len(missing) / len(REQUIRED_CAUSAL_EXTRACTION_FIELDS)

    if "p_raw" in payload:
        p = payload["p_raw"]
        if not (0.0 <= p <= 1.0):
            issues.append(f"p_raw out of range: {p}")

    if "novelty_score" in payload:
        n = payload["novelty_score"]
        if not (0.0 <= n <= 1.0):
            issues.append(f"novelty_score out of range: {n}")

    if "verifiability_score" in payload:
        v = payload["verifiability_score"]
        if not (0.0 <= v <= 1.0):
            issues.append(f"verifiability_score out of range: {v}")
        if v > 0 and not payload.get("source_url"):
            issues.append("verifiability_score > 0 but source_url is null")

    score = completeness * (1.0 - 0.1 * len(issues))
    return QualityScore(
        passed=len(issues) == 0,
        score=max(0.0, score),
        issues=issues,
        field_completeness=completeness,
    )


class FeedMonitor:
    """Detects feed failures per AR18b."""

    def __init__(self, max_gap_minutes: int = 30):
        self.max_gap_minutes = max_gap_minutes
        self._last_seen: dict = {}

    def record_receipt(self, feed_id: str, timestamp: Optional[str] = None):
        ts = datetime.fromisoformat(timestamp) if timestamp else datetime.now(timezone.utc)
        self._last_seen[feed_id] = ts

    def is_feed_failed(self, feed_id: str) -> bool:
        if feed_id not in self._last_seen:
            return True
        gap = datetime.now(timezone.utc) - self._last_seen[feed_id]
        return gap > timedelta(minutes=self.max_gap_minutes)

    def get_failed_feeds(self) -> List[str]:
        return [f for f in self._last_seen if self.is_feed_failed(f)]
