"""
Agent A — Newsflow causal extraction using Claude API.
Per AR24: receipt_timestamp distinct from publication_timestamp.
Per AR25: novelty_score computed before any graph update.
Per AR26: narrative_sensitive flag on every signal.
Per AR27: verifiability_score from source traceability.
Per DP14: LLM maps language to ontology — does NOT produce edge weights.
Layer 3 filter: focus_briefs.yaml keyword pre-filter (before Claude call)
  and post-extraction node/edge-type match (after Claude call).
"""
import json
import uuid
import hashlib
from datetime import datetime, timezone
from typing import Optional, List
from pathlib import Path
import sys
import yaml

# Allow import of sibling packages when this module is run directly or
# imported before the project root is on sys.path.
_project_root = Path(__file__).parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

from governance.ontology import get_ontology
from pillar1_perception.theme_scanner import ThemeScanner

_BRIEFS_PATH = Path(__file__).parent.parent / "config" / "focus_briefs.yaml"


class BriefMatcher:
    """
    Loads focus_briefs.yaml and provides two-stage Layer 3 filtering:

      1. text_matches_any_brief(text) — cheap keyword scan before any LLM call.
         Returns (matched: bool, brief_ids: list[str]).

      2. claim_matches_any_brief(claim) — post-extraction node/edge check.
         Returns True if source/target node_id or edge_type appears in any
         active brief's watch_nodes / watch_edge_types.
    """

    def __init__(self, briefs_path: Path = _BRIEFS_PATH):
        self._path = briefs_path
        self._briefs: List[dict] = []
        self._load()

    def _load(self):
        if not self._path.exists():
            self._briefs = []
            return
        with open(self._path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        self._briefs = [b for b in data.get("active_briefs", []) if b.get("active", True)]

    def reload(self):
        """Re-read briefs file from disk (call after editing focus_briefs.yaml)."""
        self._load()

    @property
    def active_brief_ids(self) -> List[str]:
        return [b["id"] for b in self._briefs]

    def text_matches_any_brief(self, text: str):
        """
        Pre-LLM keyword scan. Returns (matched: bool, matched_brief_ids: list).
        Case-insensitive substring match against watch_keywords.
        If no briefs are configured, all text passes (open mode).
        """
        if not self._briefs:
            return True, []

        text_lower = text.lower()
        matched_ids = []
        for brief in self._briefs:
            for kw in brief.get("watch_keywords", []):
                if kw.lower() in text_lower:
                    matched_ids.append(brief["id"])
                    break

        return (len(matched_ids) > 0), matched_ids

    def claim_matches_any_brief(self, claim: dict) -> bool:
        """
        Post-extraction node/edge check. Returns True if the extracted claim
        is relevant to at least one active brief.
        If no briefs are configured, all claims pass.
        """
        if not self._briefs:
            return True

        src_id = claim.get("source_node_id", "")
        tgt_id = claim.get("target_node_id", "")
        edge_type = claim.get("edge_type", "")

        for brief in self._briefs:
            watch_nodes = set(brief.get("watch_nodes", []))
            watch_edges = set(brief.get("watch_edge_types", []))
            if src_id in watch_nodes or tgt_id in watch_nodes:
                return True
            if edge_type in watch_edges and (
                tgt_id in set(brief.get("universe_targets", []))
                or src_id in watch_nodes
            ):
                return True
        return False

    def get_min_novelty(self, brief_ids: List[str]) -> float:
        """Return the minimum novelty threshold across matched briefs."""
        thresholds = [
            b.get("min_novelty_score", 0.0)
            for b in self._briefs if b["id"] in brief_ids
        ]
        return min(thresholds) if thresholds else 0.0


EXTRACTION_SYSTEM_PROMPT = """You are a causal extraction agent for a systematic investment system.
Your task is to read a news article and extract structured causal claims.

CRITICAL CONSTRAINTS:
1. You may ONLY use the following node types: {node_types}
2. You may ONLY use the following edge types: {edge_types}
3. If a causal claim does not map to any permitted edge type, you MUST output
   edge_type: "UNCLASSIFIABLE" — do not force a fit.
4. You are mapping language to a controlled vocabulary. You are NOT making
   investment decisions. Do not add edge types. Do not invent mechanisms.

For each causal claim you find, output a JSON object with these fields:
- source_node_type: one of the permitted node types
- source_node_id: a canonical string identifier for the source entity
- target_node_type: one of the permitted node types
- target_node_id: a canonical string identifier for the target entity
- edge_type: one of the permitted edge types, or UNCLASSIFIABLE
- p_raw: your estimate of P(this causal relationship is real and active), 0 to 1.
  A confirmed official announcement = 0.75-0.85. An unverified report = 0.40-0.55.
  Speculation or analysis = 0.20-0.40.
- magnitude_estimate: signed estimate of economic impact on the target.
  Positive means beneficial to target asset price/margin. Negative means harmful.
  Express as a fraction of normal: -0.3 means 30% negative impact.
- magnitude_ci_width: your 95% confidence interval width (e.g. 0.4 means +/- 0.2)
- narrative_sensitive: true if this signal could be moved by statements, sentiment,
  or narrative without physical reality changing. False if it measures physical
  reality directly.
- source_url: the URL of the source. null if not available.
- raw_text_excerpt: the exact sentence(s) that support this extraction.

Output a JSON array. If no causal claims exist, output [].
Do not output any other text."""


class AgentANewsflow:
    def __init__(self, event_bus=None, api_key: Optional[str] = None,
                 ontology_version: str = "1.0",
                 briefs_path: Optional[Path] = None):
        self.event_bus = event_bus
        self.ontology_version = ontology_version
        self._ontology = get_ontology()
        self._recent_hashes: List[str] = []  # for novelty scoring
        self._brief_matcher = BriefMatcher(
            briefs_path if briefs_path is not None else _BRIEFS_PATH
        )
        self.theme_scanner = ThemeScanner()

        if ANTHROPIC_AVAILABLE:
            self._client = (
                anthropic.Anthropic(api_key=api_key)
                if api_key
                else anthropic.Anthropic()
            )
        else:
            self._client = None

    def reload_briefs(self):
        """Re-read focus_briefs.yaml without restarting. Call after editing."""
        self._brief_matcher.reload()

    def _build_system_prompt(self) -> str:
        # OntologyValidator exposes node_type_names and edge_type_names as frozensets.
        node_types = sorted(self._ontology.node_type_names)
        edge_types = sorted(self._ontology.edge_type_names)
        return EXTRACTION_SYSTEM_PROMPT.format(
            node_types=", ".join(node_types),
            edge_types=", ".join(edge_types),
        )

    def _compute_novelty(self, text: str) -> float:
        h = hashlib.md5(text.encode()).hexdigest()[:16]
        if h in self._recent_hashes:
            return 0.0
        count_similar = sum(1 for old_h in self._recent_hashes if old_h[:4] == h[:4])
        novelty = max(0.1, 1.0 - count_similar * 0.25)
        self._recent_hashes.append(h)
        if len(self._recent_hashes) > 100:
            self._recent_hashes = self._recent_hashes[-100:]
        return novelty

    def _compute_verifiability(self, source_url: Optional[str], p_raw: float) -> float:
        if not source_url:
            return 0.0
        if "reuters.com" in source_url or "bloomberg.com" in source_url:
            return 0.85
        if "gov" in source_url or "official" in source_url.lower():
            return 0.90
        return 0.60

    def extract(
        self,
        text: str,
        source_url: Optional[str] = None,
        publication_timestamp: Optional[str] = None,
        bypass_brief_filter: bool = False,
    ) -> List[dict]:
        """
        Extract causal claims from news text.

        Layer 3 gate (focus_briefs.yaml) is applied in two stages:
          1. Pre-LLM: keyword scan — if text matches no active brief, return []
             immediately without making an API call.
          2. Post-LLM: per-claim node/edge check — claims that match no brief
             are dropped (not published to graph or event bus).

        Set bypass_brief_filter=True to skip Layer 3 (e.g. for testing or
        manual ingestion of a known-relevant article).

        Returns list of extraction dicts. UNCLASSIFIABLE claims are included
        in the return value but are NOT published to the event bus.
        """
        receipt_ts = datetime.now(timezone.utc).isoformat()
        pub_ts = publication_timestamp or receipt_ts

        # ── Layer 3a: keyword pre-filter (before any LLM call) ───────────────
        if not bypass_brief_filter:
            matched, matched_brief_ids = self._brief_matcher.text_matches_any_brief(text)
            if not matched:
                # Feed dropped text to ThemeScanner for emerging theme detection
                self.theme_scanner.ingest_dropped(text)
                return []  # silent drop — no API cost incurred
        else:
            matched_brief_ids = []

        if not self._client:
            return self._mock_extract(text, source_url, pub_ts, receipt_ts,
                                      bypass_brief_filter=bypass_brief_filter)

        system_prompt = self._build_system_prompt()
        try:
            response = self._client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=2048,
                system=system_prompt,
                messages=[{"role": "user", "content": text}],
            )
            raw = response.content[0].text.strip()
            # Strip markdown code fences if present
            if raw.startswith("```"):
                raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
            claims = json.loads(raw)
        except Exception:
            claims = []

        return self._process_claims(claims, source_url, pub_ts, receipt_ts, text,
                                    bypass_brief_filter=bypass_brief_filter)

    def _process_claims(
        self,
        claims: list,
        source_url: Optional[str],
        pub_ts: str,
        receipt_ts: str,
        text: str,
        bypass_brief_filter: bool = False,
    ) -> List[dict]:
        results = []
        for claim in claims:
            edge_type = claim.get("edge_type", "UNCLASSIFIABLE")
            # Validate against ontology; downgrade to UNCLASSIFIABLE on failure.
            if edge_type != "UNCLASSIFIABLE":
                try:
                    self._ontology.validate_edge_type(edge_type)
                except Exception:
                    edge_type = "UNCLASSIFIABLE"

            # ── Layer 3b: post-extraction brief filter ────────────────────────
            # Classifiable claims that don't match any active brief are dropped.
            if not bypass_brief_filter and edge_type != "UNCLASSIFIABLE":
                if not self._brief_matcher.claim_matches_any_brief(claim):
                    continue

            excerpt = claim.get("raw_text_excerpt", text[:200])
            novelty = self._compute_novelty(excerpt)
            p_raw = float(claim.get("p_raw", 0.5))
            src_url = claim.get("source_url") or source_url
            verifiability = self._compute_verifiability(src_url, p_raw)

            extraction = {
                "extraction_id": str(uuid.uuid4()),
                "source_node_type": claim.get("source_node_type", "GEOPOLITICAL_EVENT"),
                "source_node_id": claim.get("source_node_id", "unknown"),
                "target_node_type": claim.get("target_node_type", "TRADEABLE_ASSET"),
                "target_node_id": claim.get("target_node_id", "unknown"),
                "edge_type": edge_type,
                "p_raw": p_raw,
                "magnitude_estimate": float(claim.get("magnitude_estimate", 0.0)),
                "magnitude_ci_width": float(claim.get("magnitude_ci_width", 0.5)),
                "narrative_sensitive": bool(claim.get("narrative_sensitive", True)),
                "novelty_score": novelty,
                "verifiability_score": verifiability,
                "source_url": src_url,
                "publication_timestamp": pub_ts,
                "receipt_timestamp": receipt_ts,
                "raw_text_excerpt": excerpt,
                "ontology_version": self.ontology_version,
            }
            results.append(extraction)

            # Only publish classifiable extractions to the event bus.
            if self.event_bus and edge_type != "UNCLASSIFIABLE":
                self._publish(extraction)

        return results

    def _publish(self, extraction: dict):
        from pillar1_perception.event_bus import make_event
        evt = make_event(
            event_type="CAUSAL_EXTRACTION",
            source_component="pillar1_perception.agent_a_newsflow",
            payload=extraction,
            publication_timestamp=extraction["publication_timestamp"],
        )
        self.event_bus.publish(evt)

    def _mock_extract(
        self,
        text: str,
        source_url: Optional[str],
        pub_ts: str,
        receipt_ts: str,
        bypass_brief_filter: bool = False,
    ) -> List[dict]:
        """Fallback mock extraction when the Anthropic SDK is not available."""
        excerpt = text[:300]

        claims = []
        text_lower = text.lower()

        if "hormuz" in text_lower or "strait" in text_lower:
            claims.append({
                "source_node_type": "GEOPOLITICAL_EVENT",
                "source_node_id": "Hormuz_Closure",
                "target_node_type": "TRADEABLE_ASSET",
                "target_node_id": "ICE_GASOIL",
                "edge_type": "CONSTRAINS_SUPPLY_OF",
                "p_raw": 0.70,
                "magnitude_estimate": -0.25,
                "magnitude_ci_width": 0.30,
                "narrative_sensitive": False,
                "source_url": source_url,
                "raw_text_excerpt": excerpt,
            })

        if "ras tanura" in text_lower or "infrastructure" in text_lower:
            claims.append({
                "source_node_type": "GEOPOLITICAL_EVENT",
                "source_node_id": "Ras_Tanura_Strike",
                "target_node_type": "PHYSICAL_OBSERVABLE",
                "target_node_id": "Saudi_Refinery_Capacity",
                "edge_type": "INFRASTRUCTURE_DAMAGE_TO",
                "p_raw": 0.75,
                "magnitude_estimate": -0.40,
                "magnitude_ci_width": 0.25,
                "narrative_sensitive": False,
                "source_url": source_url,
                "raw_text_excerpt": excerpt,
            })

        return self._process_claims(claims, source_url, pub_ts, receipt_ts, text,
                                    bypass_brief_filter=bypass_brief_filter)
