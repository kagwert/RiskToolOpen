"""
Agent C — Macro sub-component extraction stub.
Per AR04, AR05. Out of scope for Phase 1.
Production: sub-component extraction from official releases.
"""
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class MacroDimension:
    dimension: str   # growth | inflation | risk_appetite
    value: str       # POSITIVE/NEGATIVE or ABOVE_TARGET/BELOW_TARGET or ON/OFF
    confidence: float
    source: str
    timestamp: str


class AgentCMacro:
    """Stub macro agent. Returns fixture-based or hardcoded regime dimensions."""

    def __init__(self):
        self._overrides: dict = {}

    def set_override(self, dimension: str, value: str, confidence: float = 0.8):
        self._overrides[dimension] = {"value": value, "confidence": confidence}

    def get_dimensions(self, timestamp: Optional[str] = None) -> List[MacroDimension]:
        from datetime import datetime, timezone
        ts = timestamp or datetime.now(timezone.utc).isoformat()
        defaults = {
            "growth": ("NEGATIVE", "stub_default"),
            "inflation": ("ABOVE_TARGET", "stub_default"),
            "risk_appetite": ("OFF", "stub_default"),
        }
        result = []
        for dim, (default_val, src) in defaults.items():
            override = self._overrides.get(dim, {})
            result.append(MacroDimension(
                dimension=dim,
                value=override.get("value", default_val),
                confidence=override.get("confidence", 0.5),
                source=src,
                timestamp=ts,
            ))
        return result
