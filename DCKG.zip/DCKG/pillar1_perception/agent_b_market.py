"""
Agent B — Market data ingestion stub.
Per AR06 through AR10. Out of scope for Phase 1 — stub with fixture loader.
Production replacement: Bloomberg/Refinitiv adapter.
Interface: identical to production component.
"""
from dataclasses import dataclass
from typing import Dict, List, Optional
from datetime import datetime, timezone
import json
from pathlib import Path


@dataclass
class MarketDataPoint:
    asset_id: str
    price: float
    volume: Optional[float]
    spread: Optional[float]
    timestamp: str
    source: str = "fixture"


class AgentBMarket:
    """Stub market data agent. Loads from fixtures."""

    def __init__(self, fixture_path: str = None):
        self.fixture_path = fixture_path
        self._data: Dict[str, List[MarketDataPoint]] = {}
        if fixture_path:
            self._load_fixtures(fixture_path)

    def _load_fixtures(self, path: str):
        with open(path) as f:
            data = json.load(f)
        for entry in data.get("market_data", []):
            asset_id = entry["asset_id"]
            if asset_id not in self._data:
                self._data[asset_id] = []
            self._data[asset_id].append(MarketDataPoint(**entry))

    def get_price(self, asset_id: str, timestamp: Optional[str] = None) -> Optional[float]:
        series = self._data.get(asset_id, [])
        if not series:
            return None
        if timestamp:
            ts = datetime.fromisoformat(timestamp)
            eligible = [d for d in series if datetime.fromisoformat(d.timestamp) <= ts]
            return eligible[-1].price if eligible else None
        return series[-1].price

    def get_returns(self, asset_id: str, lookback_days: int = 60) -> List[float]:
        """Return daily returns for covariance estimation."""
        series = self._data.get(asset_id, [])
        prices = [d.price for d in series[-lookback_days - 1:]]
        if len(prices) < 2:
            return []
        return [(prices[i] - prices[i - 1]) / prices[i - 1] for i in range(1, len(prices))]

    def get_covariance_matrix(self, asset_ids: List[str], lookback_days: int = 60):
        """
        Estimate covariance matrix from historical returns.

        Returns numpy.ndarray of shape (n, n).
        Falls back to a small diagonal matrix if price history is insufficient.
        """
        import numpy as np

        n = len(asset_ids)
        returns_matrix = []
        for asset_id in asset_ids:
            r = self.get_returns(asset_id, lookback_days)
            if not r:
                r = [0.0] * lookback_days
            r = r[-lookback_days:]
            while len(r) < lookback_days:
                r = [0.0] + r
            returns_matrix.append(r)

        R = np.array(returns_matrix)
        if n > 1:
            cov = np.cov(R)
        else:
            cov = np.array([[np.var(R[0]) if len(R[0]) > 0 else 1e-6]])
        return cov
