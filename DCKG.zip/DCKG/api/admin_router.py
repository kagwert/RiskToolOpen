"""
Admin API router for the DCKG brief-management dashboard.

Mount with:
    app.include_router(admin_router, prefix="/admin/api")

Provides CRUD management of focus_briefs.yaml, live brief-matching tests,
and ThemeScanner velocity/semantic scanning endpoints.
"""
import sys
import re
from pathlib import Path

# Ensure project root is on sys.path so sibling packages resolve.
_project_root = Path(__file__).parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))

import yaml
from typing import List, Optional, Dict

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from pillar1_perception.agent_a_newsflow import AgentANewsflow
from pillar1_perception.theme_scanner import ThemeScanner

# ── Config path ───────────────────────────────────────────────────────────────
_BRIEFS_PATH = Path(__file__).parent.parent / "config" / "focus_briefs.yaml"

# ── Module-level singletons ───────────────────────────────────────────────────
_scanner: ThemeScanner = ThemeScanner()
_agent: AgentANewsflow = AgentANewsflow()   # no event_bus, no api_key

# ── Router ────────────────────────────────────────────────────────────────────
admin_router = APIRouter()


# ── YAML helpers ──────────────────────────────────────────────────────────────

def _load_yaml() -> dict:
    """Load focus_briefs.yaml; return empty structure if file missing."""
    if not _BRIEFS_PATH.exists():
        return {"active_briefs": [], "inactive_briefs": []}
    with open(_BRIEFS_PATH, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    # Normalise missing keys
    if "active_briefs" not in data or data["active_briefs"] is None:
        data["active_briefs"] = []
    if "inactive_briefs" not in data or data["inactive_briefs"] is None:
        data["inactive_briefs"] = []
    return data


def _save_yaml(data: dict) -> None:
    """Write focus_briefs.yaml, preserving utf-8 encoding."""
    with open(_BRIEFS_PATH, "w", encoding="utf-8") as fh:
        yaml.dump(data, fh, allow_unicode=True, sort_keys=False, default_flow_style=False)


# ── Pydantic request models ───────────────────────────────────────────────────

class NewBriefRequest(BaseModel):
    id: str
    name: str
    description: str = ""
    watch_keywords: List[str] = []
    watch_nodes: List[str] = []
    watch_edge_types: List[str] = []
    universe_targets: List[str] = []
    regime_relevant: List[str] = []
    min_novelty_score: float = 0.25
    graph_priority: int = 99


class TestBriefRequest(BaseModel):
    text: str


class IngestRequest(BaseModel):
    texts: List[str]


class SemanticRequest(BaseModel):
    api_key: Optional[str] = None


# ── GET /briefs ───────────────────────────────────────────────────────────────

@admin_router.get("/briefs")
def get_briefs():
    """
    Return all briefs from focus_briefs.yaml split into active and inactive lists.
    inactive is always a list, even when the YAML stores None or [].
    """
    try:
        data = _load_yaml()
        active = data.get("active_briefs") or []
        inactive = data.get("inactive_briefs") or []
        return JSONResponse(content={"active": active, "inactive": inactive})
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── POST /briefs/{brief_id}/activate ─────────────────────────────────────────

@admin_router.post("/briefs/{brief_id}/activate")
def activate_brief(brief_id: str):
    """
    Move brief from inactive_briefs to active_briefs (or set active=True in place).
    Reloads the agent's BriefMatcher after saving.
    """
    try:
        data = _load_yaml()
        active = data.get("active_briefs") or []
        inactive = data.get("inactive_briefs") or []

        # Already in active list — just ensure active flag is set.
        for brief in active:
            if brief.get("id") == brief_id:
                brief["active"] = True
                _save_yaml(data)
                _agent.reload_briefs()
                return JSONResponse(content={"status": "activated", "id": brief_id})

        # Find in inactive list.
        found = None
        remaining_inactive = []
        for brief in inactive:
            if brief.get("id") == brief_id:
                found = brief
            else:
                remaining_inactive.append(brief)

        if found is None:
            raise HTTPException(status_code=404, detail=f"Brief '{brief_id}' not found.")

        found["active"] = True
        active.append(found)
        data["active_briefs"] = active
        data["inactive_briefs"] = remaining_inactive
        _save_yaml(data)
        _agent.reload_briefs()
        return JSONResponse(content={"status": "activated", "id": brief_id})

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── POST /briefs/{brief_id}/deactivate ───────────────────────────────────────

@admin_router.post("/briefs/{brief_id}/deactivate")
def deactivate_brief(brief_id: str):
    """
    Move brief from active_briefs to inactive_briefs.
    Reloads the agent's BriefMatcher after saving.
    """
    try:
        data = _load_yaml()
        active = data.get("active_briefs") or []
        inactive = data.get("inactive_briefs") or []

        found = None
        remaining_active = []
        for brief in active:
            if brief.get("id") == brief_id:
                found = brief
            else:
                remaining_active.append(brief)

        if found is None:
            raise HTTPException(status_code=404, detail=f"Brief '{brief_id}' not found in active briefs.")

        found["active"] = False
        inactive.append(found)
        data["active_briefs"] = remaining_active
        data["inactive_briefs"] = inactive
        _save_yaml(data)
        _agent.reload_briefs()
        return JSONResponse(content={"status": "deactivated", "id": brief_id})

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── POST /briefs ──────────────────────────────────────────────────────────────

_BRIEF_ID_RE = re.compile(r"^[A-Z][A-Z0-9_]+$")


@admin_router.post("/briefs")
def create_brief(body: NewBriefRequest):
    """
    Create a new brief and append it to active_briefs.
    Validates id format (UPPER_SNAKE_CASE) and checks for duplicate ids.
    """
    try:
        if not _BRIEF_ID_RE.match(body.id):
            raise HTTPException(
                status_code=422,
                detail=(
                    f"Brief id '{body.id}' is invalid. "
                    "Must match ^[A-Z][A-Z0-9_]+$ (UPPER_SNAKE_CASE, min 2 chars)."
                ),
            )

        data = _load_yaml()
        active = data.get("active_briefs") or []
        inactive = data.get("inactive_briefs") or []

        all_ids = {b.get("id") for b in active} | {b.get("id") for b in inactive}
        if body.id in all_ids:
            raise HTTPException(
                status_code=409,
                detail=f"Brief id '{body.id}' already exists (active or inactive).",
            )

        new_brief = {
            "id": body.id,
            "name": body.name,
            "active": True,
            "description": body.description,
            "watch_keywords": body.watch_keywords,
            "watch_nodes": body.watch_nodes,
            "watch_edge_types": body.watch_edge_types,
            "universe_targets": body.universe_targets,
            "regime_relevant": body.regime_relevant,
            "min_novelty_score": body.min_novelty_score,
            "graph_priority": body.graph_priority,
        }
        active.append(new_brief)
        data["active_briefs"] = active
        _save_yaml(data)
        _agent.reload_briefs()
        return JSONResponse(content={"status": "created", "id": body.id}, status_code=201)

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── DELETE /briefs/{brief_id} ─────────────────────────────────────────────────

@admin_router.delete("/briefs/{brief_id}")
def delete_brief(brief_id: str):
    """
    Remove a brief from both active and inactive lists.
    Reloads the agent's BriefMatcher after saving.
    """
    try:
        data = _load_yaml()
        active = data.get("active_briefs") or []
        inactive = data.get("inactive_briefs") or []

        new_active = [b for b in active if b.get("id") != brief_id]
        new_inactive = [b for b in inactive if b.get("id") != brief_id]

        removed = len(active) - len(new_active) + len(inactive) - len(new_inactive)
        if removed == 0:
            raise HTTPException(status_code=404, detail=f"Brief '{brief_id}' not found.")

        data["active_briefs"] = new_active
        data["inactive_briefs"] = new_inactive
        _save_yaml(data)
        _agent.reload_briefs()
        return JSONResponse(content={"status": "removed", "id": brief_id})

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── POST /briefs/test ─────────────────────────────────────────────────────────

@admin_router.post("/briefs/test")
def test_brief_match(body: TestBriefRequest):
    """
    Run a keyword pre-filter test against all active briefs without making
    any LLM call.  Also returns which specific keywords matched per brief.
    """
    try:
        matched, matched_brief_ids = _agent._brief_matcher.text_matches_any_brief(body.text)
        result_label = "PASS" if matched else "DROP"

        # Determine which specific keywords matched per brief
        text_lower = body.text.lower()
        matched_keywords: Dict[str, List[str]] = {}
        for brief in _agent._brief_matcher._briefs:
            brief_id = brief.get("id", "")
            if brief_id not in matched_brief_ids:
                continue
            hits = [
                kw for kw in brief.get("watch_keywords", [])
                if kw.lower() in text_lower
            ]
            matched_keywords[brief_id] = hits

        active_brief_count = len(_agent._brief_matcher.active_brief_ids)

        return JSONResponse(content={
            "result": result_label,
            "matched_brief_ids": matched_brief_ids,
            "matched_keywords": matched_keywords,
            "active_brief_count": active_brief_count,
        })

    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── GET /scanner/status ───────────────────────────────────────────────────────

@admin_router.get("/scanner/status")
def scanner_status():
    """Return the current ThemeScanner buffer size and active brief ids."""
    try:
        buffer_size = _agent.theme_scanner.buffer_size
        active_brief_ids = _agent._brief_matcher.active_brief_ids
        return JSONResponse(content={
            "buffer_size": buffer_size,
            "active_brief_ids": active_brief_ids,
        })
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── POST /scanner/ingest ──────────────────────────────────────────────────────

@admin_router.post("/scanner/ingest")
def scanner_ingest(body: IngestRequest):
    """
    Run each text through _agent.extract().  Texts that fail the keyword
    pre-filter are silently dropped by Agent A and automatically ingested
    into _agent.theme_scanner.ingest_dropped().  Returns counts of ingested
    texts, how many were dropped to the scanner, and the resulting buffer size.
    """
    try:
        ingested = 0
        dropped_to_scanner = 0

        buffer_before = _agent.theme_scanner.buffer_size

        for text in body.texts:
            # agent.extract() auto-calls theme_scanner.ingest_dropped() on drop.
            _agent.extract(text)
            ingested += 1

        buffer_after = _agent.theme_scanner.buffer_size
        dropped_to_scanner = buffer_after - buffer_before

        return JSONResponse(content={
            "ingested": ingested,
            "dropped_to_scanner": dropped_to_scanner,
            "scanner_buffer_size": buffer_after,
        })

    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── POST /scanner/velocity ────────────────────────────────────────────────────

@admin_router.post("/scanner/velocity")
def scanner_velocity():
    """
    Run Tier-1 velocity analysis over the ThemeScanner buffer and cluster
    the results into candidate brief suggestions.
    """
    try:
        hits = _agent.theme_scanner.scan_velocity()
        candidates = _agent.theme_scanner.velocity_to_candidates(hits)

        velocity_hits_out = [
            {
                "phrase": h.phrase,
                "recent_count": h.recent_count,
                "baseline_count": h.baseline_count,
                "velocity_ratio": h.velocity_ratio,
                "example": h.example_texts[0] if h.example_texts else "",
            }
            for h in hits
        ]

        candidates_out = [
            {
                "id": c.id,
                "name": c.name,
                "description": c.description,
                "watch_keywords": c.watch_keywords,
                "confidence": c.confidence,
                "source": c.source,
            }
            for c in candidates
        ]

        return JSONResponse(content={
            "velocity_hits": velocity_hits_out,
            "candidates": candidates_out,
            "buffer_size": _agent.theme_scanner.buffer_size,
        })

    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── POST /scanner/semantic ────────────────────────────────────────────────────

@admin_router.post("/scanner/semantic")
def scanner_semantic(body: SemanticRequest):
    """
    Run Tier-2 semantic analysis (Claude API call) over the ThemeScanner buffer.
    Uses the api_key from the request body if provided; otherwise falls back to
    the ANTHROPIC_API_KEY environment variable.
    """
    try:
        api_key = body.api_key if body.api_key else None
        candidates = _agent.theme_scanner.scan_semantic(api_key=api_key)

        candidates_out = [
            {
                "id": c.id,
                "name": c.name,
                "description": c.description,
                "watch_keywords": c.watch_keywords,
                "confidence": c.confidence,
                "source": c.source,
            }
            for c in candidates
        ]

        return JSONResponse(content=candidates_out)

    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── GET /governance ───────────────────────────────────────────────────────────

_MANDATE_PATH  = Path(__file__).parent.parent / "config" / "mandate_global_alloc.yaml"
_ONTOLOGY_PATH = Path(__file__).parent.parent / "config" / "ontology_v1.yaml"
_REGIMES_PATH  = Path(__file__).parent.parent / "config" / "regimes.yaml"


@admin_router.get("/governance")
def get_governance():
    """Return a summary of all governance config files for the Settings tab."""
    try:
        def _yl(p):
            with open(p, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}

        mandate  = _yl(_MANDATE_PATH)
        ontology = _yl(_ONTOLOGY_PATH)
        regimes  = _yl(_REGIMES_PATH)

        # Summarise decay classes from ontology
        decay_classes = {}
        for etype, edef in ontology.get("edge_types", {}).items():
            dc = edef.get("decay_class")
            if dc:
                decay_classes.setdefault(dc, []).append(etype)

        decay_half_lives = {}
        for dc, dcdef in ontology.get("decay_classes", {}).items():
            decay_half_lives[dc] = dcdef.get("half_life_days")

        # Regime overlays summary
        regime_summary = {}
        for rname, rdef in regimes.get("regimes", {}).items():
            overlays = rdef.get("portfolio_overlays", []) or []
            regime_summary[rname] = {
                "dimensions": rdef.get("dimensions", {}),
                "overlay_count": len(overlays),
                "overlays": [o.get("instrument") for o in overlays],
            }

        return JSONResponse(content={
            "mandate": {
                "constraints": mandate.get("constraints", {}),
                "risk_parameters": mandate.get("risk_parameters", {}),
                "sector_limits": mandate.get("sector_limits", {}),
            },
            "graph_budget": {
                "max_active_edges": 30,
                "min_wt_to_retain": 0.015,
            },
            "decay_classes": decay_half_lives,
            "edge_type_decay": decay_classes,
            "ontology": {
                "node_types": list(ontology.get("node_types", {}).keys()),
                "edge_types": list(ontology.get("edge_types", {}).keys()),
                "version": ontology.get("version", "1.0"),
            },
            "regimes": regime_summary,
            "reclassification_rules": regimes.get("reclassification_rules", {}),
        })
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


class MandatePatchRequest(BaseModel):
    section: str   # "constraints" or "risk_parameters"
    key: str
    value: float


@admin_router.patch("/governance/mandate")
def patch_mandate(body: MandatePatchRequest):
    """Update a single numeric parameter in mandate_global_alloc.yaml."""
    ALLOWED = {
        "constraints": {
            "gross_exposure_max", "net_exposure_min", "net_exposure_max",
            "single_name_long_max", "single_name_short_max",
            "sector_concentration_max", "max_positions", "turnover_budget_annual",
        },
        "risk_parameters": {
            "risk_aversion", "transaction_cost_coeff", "covariance_lookback_days",
        },
    }
    if body.section not in ALLOWED:
        raise HTTPException(status_code=422, detail=f"Unknown section '{body.section}'")
    if body.key not in ALLOWED[body.section]:
        raise HTTPException(status_code=422, detail=f"Unknown key '{body.key}' in '{body.section}'")
    try:
        with open(_MANDATE_PATH, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        data.setdefault(body.section, {})[body.key] = body.value
        with open(_MANDATE_PATH, "w", encoding="utf-8") as f:
            yaml.dump(data, f, allow_unicode=True, sort_keys=False, default_flow_style=False)
        return JSONResponse(content={"status": "updated", "section": body.section,
                                     "key": body.key, "value": body.value})
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── GET /activity ─────────────────────────────────────────────────────────────

@admin_router.get("/activity")
def get_activity():
    """
    Return live system status: recent events, active graph edges,
    portfolio weights stub, and current regime.
    """
    try:
        import time
        from pillar2_graph.graph_store import GraphStore
        from pillar2_graph.regime_classifier import RegimeClassifier, RegimeDimensions
        from pillar1_perception.event_bus import EventBus

        gs = GraphStore()
        snapshot = gs.get_state_snapshot()
        edges = snapshot.get("edges", [])

        # Recent events from event bus (last 30)
        bus = EventBus()
        recent_events = []
        try:
            all_evts = bus.reconstruct_at("2099-01-01T00:00:00+00:00")[-30:]
            for evt in reversed(all_evts):
                payload = evt.payload or {}
                recent_events.append({
                    "ts": evt.publication_timestamp,
                    "type": evt.event_type,
                    "source": evt.source_component,
                    "summary": _summarise_payload(evt.event_type, payload),
                })
        except Exception:
            pass

        # Current regime
        rc = RegimeClassifier()
        dims = RegimeDimensions(growth="NEGATIVE", inflation="ABOVE_TARGET", risk_appetite="OFF")
        result = rc.classify(dims, confirming_sources=["stub1", "stub2"])

        # Active edges sorted by Wt descending
        active_edges = []
        for e in edges:
            if e.get("status") == "ACTIVE":
                active_edges.append({
                    "source": e.get("source_node_id", ""),
                    "target": e.get("target_node_id", ""),
                    "edge_type": e.get("edge_type", ""),
                    "p_post": round(float(e.get("p_post", 0)), 3),
                    "wt": round(float(e.get("wt", 0)), 4),
                    "status": e.get("status", ""),
                    "decay_class": e.get("decay_class", ""),
                })
        active_edges.sort(key=lambda x: x["wt"], reverse=True)

        return JSONResponse(content={
            "regime": result.regime,
            "regime_confidence": round(result.confidence, 3),
            "active_edge_count": len(active_edges),
            "active_edges": active_edges[:20],
            "recent_events": recent_events,
            "brief_count": len(_agent._brief_matcher.active_brief_ids),
            "scanner_buffer": _agent.theme_scanner.buffer_size,
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        })
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


def _summarise_payload(event_type: str, payload: dict) -> str:
    """Return a one-line human summary of an event payload."""
    if event_type == "CAUSAL_EXTRACTION":
        return (f"{payload.get('source_node_id','?')} "
                f"--[{payload.get('edge_type','?')}]--> "
                f"{payload.get('target_node_id','?')}  "
                f"p={payload.get('p_raw','?')}")
    if event_type in ("EDGE_CREATED", "EDGE_UPDATED"):
        return (f"{payload.get('source_node_id','?')} "
                f"--[{payload.get('edge_type','?')}]--> "
                f"{payload.get('target_node_id','?')}")
    if event_type == "REGIME_CLASSIFICATION":
        return f"Regime -> {payload.get('regime','?')} (conf={payload.get('confidence','?')})"
    if event_type in ("OPTIMIZER_SOLVE_COMPLETED", "OPTIMIZER_SOLVE_STARTED"):
        return f"Solve {payload.get('solve_id','?')}"
    for k in ("summary", "message", "description"):
        if k in payload:
            return str(payload[k])[:80]
    return str(payload)[:80] if payload else ""
