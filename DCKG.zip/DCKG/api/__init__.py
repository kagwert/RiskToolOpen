"""
DCKG API package.

Exposes the FastAPI application for investment views and graph state queries.
"""
