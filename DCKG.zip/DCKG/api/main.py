"""
FastAPI application for DCKG views and graph state.
Per BR19, BR20: GET /views returns fully traceable investment views.
Per AR22b: GET /graph/reconstruct supports point-in-time reconstruction.
"""
import sys
from pathlib import Path
# Ensure project root is on path
sys.path.insert(0, str(Path(__file__).parent.parent))

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse, HTMLResponse
from typing import Optional
import numpy as np
from datetime import datetime, timezone

from pillar1_perception.event_bus import EventBus, make_event
from pillar2_graph.graph_store import GraphStore
from pillar2_graph.regime_classifier import RegimeClassifier, RegimeDimensions
from pillar2_graph.alpha_vector import AlphaVectorBuilder
from pillar3_execution.optimizer import PortfolioOptimizer
from pillar3_execution.universe import get_universe, get_asset_ids
from pillar3_execution.solve_logger import SolveLogger
from governance.view_dashboard import build_view_dashboard, dashboard_to_dict
from api.admin_router import admin_router

_ADMIN_HTML = Path(__file__).parent / "admin.html"

app = FastAPI(title="DCKG API", version="1.0.0",
              description="Dynamic Causal Knowledge Graph — investment views API")

app.include_router(admin_router, prefix="/admin/api")

# Module-level singletons (in production these would be injected)
_event_bus = EventBus()
_graph_store = GraphStore()
_regime_classifier = RegimeClassifier()
_alpha_builder = AlphaVectorBuilder(_regime_classifier)
_solve_logger = SolveLogger(_event_bus)
_optimizer = PortfolioOptimizer(solve_logger=_solve_logger)
_universe = get_asset_ids()


def _get_current_regime() -> tuple:
    """Return (regime_name, confidence) — stub using defaults."""
    dims = RegimeDimensions(growth="NEGATIVE", inflation="ABOVE_TARGET", risk_appetite="OFF")
    result = _regime_classifier.classify(dims, confirming_sources=["stub1", "stub2"])
    return result.regime, result.confidence


@app.get("/views")
def get_views():
    """
    Return the full view dashboard.
    Per BR19: every view traceable to source edges.
    Target response time: < 200ms.
    """
    import time
    t0 = time.time()

    regime, confidence = _get_current_regime()
    overlays = _regime_classifier.get_overlays(regime)

    edges = _graph_store.get_all_edges()
    alpha_dict = _alpha_builder.build(edges, regime, _universe)

    alpha_array = _alpha_builder.to_numpy_vector(alpha_dict, _universe)
    n = len(_universe)
    cov = np.eye(n) * 0.04  # 20% vol stub; production: rolling covariance

    sector_map = {a: get_universe()[a].sector for a in _universe if a in get_universe()}

    result = _optimizer.solve(
        alpha=alpha_array,
        cov_matrix=cov,
        universe=_universe,
        regime=regime,
        alpha_version=str(datetime.now(timezone.utc).date()),
        sector_map=sector_map,
    )

    dashboard = build_view_dashboard(
        graph_store=_graph_store,
        alpha_dict=alpha_dict,
        weights=result["weights"],
        regime=regime,
        regime_confidence=confidence,
        regime_overlays=overlays,
    )

    response_data = dashboard_to_dict(dashboard)
    elapsed_ms = (time.time() - t0) * 1000
    response_data["_response_time_ms"] = round(elapsed_ms, 1)

    return JSONResponse(content=response_data)


@app.get("/graph/state")
def get_graph_state():
    """Return full graph as node-link JSON structure."""
    snapshot = _graph_store.get_state_snapshot()
    return JSONResponse(content=snapshot)


@app.get("/graph/reconstruct")
def reconstruct_at(timestamp: str = Query(..., description="ISO8601 UTC timestamp")):
    """
    Reconstruct graph state at a given timestamp.
    Per AR22b: point-in-time reconstruction from event log.
    """
    try:
        events = _event_bus.reconstruct_at(timestamp)

        # Rebuild graph state from edge events
        edge_events = [e for e in events if e.event_type in
                       ("EDGE_CREATED", "EDGE_UPDATED", "EDGE_CONTESTED", "EDGE_RETIRED")]

        return JSONResponse(content={
            "timestamp": timestamp,
            "total_events": len(events),
            "edge_events": len(edge_events),
            "event_types": list({e.event_type for e in events}),
            "reconstruction_note": "Full graph reconstruction from event stream. Events replayed in order.",
        })
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/admin", response_class=HTMLResponse, include_in_schema=False)
def admin_dashboard():
    """Serve the theme administration dashboard."""
    return HTMLResponse(content=_ADMIN_HTML.read_text(encoding="utf-8"))


@app.get("/health")
def health():
    return {"status": "ok", "version": "1.0.0"}
