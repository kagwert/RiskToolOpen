"""
Governance layer.

Provides ontology enforcement, prediction tracking, and view dashboard
capabilities that apply system-wide across all three pillars.

Components:
    ontology          — Ontology loader and validator (AR48c, AR48d)
    prediction_tracker — IC monitoring infrastructure (AR41, AR42)
    view_dashboard    — Structured view output (BR19, BR20)
"""
