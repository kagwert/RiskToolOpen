"""
Prediction tracker — IC monitoring infrastructure.
Per AR41, AR42. Records predictions and outcomes for IC calculation.
Phase 1: stores predictions in memory; production: durable store.
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict
from datetime import datetime, timezone
import uuid

@dataclass
class Prediction:
    prediction_id: str
    edge_id: str
    asset_id: str
    direction: str       # LONG | SHORT
    p_posterior: float
    alpha_contribution: float
    made_at: str
    horizon_days: int    # prediction horizon
    outcome: Optional[str] = None   # WIN | LOSS | NEUTRAL
    outcome_at: Optional[str] = None
    outcome_return: Optional[float] = None

class PredictionTracker:
    def __init__(self):
        self._predictions: List[Prediction] = []

    def record(self, edge_id: str, asset_id: str, direction: str,
               p_posterior: float, alpha_contribution: float,
               horizon_days: int = 20) -> Prediction:
        p = Prediction(
            prediction_id=str(uuid.uuid4()),
            edge_id=edge_id,
            asset_id=asset_id,
            direction=direction,
            p_posterior=p_posterior,
            alpha_contribution=alpha_contribution,
            made_at=datetime.now(timezone.utc).isoformat(),
            horizon_days=horizon_days,
        )
        self._predictions.append(p)
        return p

    def record_outcome(self, prediction_id: str, actual_return: float):
        for p in self._predictions:
            if p.prediction_id == prediction_id:
                p.outcome_return = actual_return
                p.outcome_at = datetime.now(timezone.utc).isoformat()
                expected_positive = p.direction == "LONG"
                if abs(actual_return) < 0.005:
                    p.outcome = "NEUTRAL"
                elif (actual_return > 0) == expected_positive:
                    p.outcome = "WIN"
                else:
                    p.outcome = "LOSS"
                break

    def information_coefficient(self) -> Optional[float]:
        """Spearman rank IC between predicted alpha and actual returns."""
        completed = [p for p in self._predictions if p.outcome_return is not None]
        if len(completed) < 10:
            return None
        try:
            from scipy.stats import spearmanr
            alphas = [p.alpha_contribution for p in completed]
            returns = [p.outcome_return for p in completed]
            ic, _ = spearmanr(alphas, returns)
            return ic
        except Exception:
            return None

    def hit_rate(self) -> Optional[float]:
        decided = [p for p in self._predictions if p.outcome in ("WIN", "LOSS")]
        if not decided:
            return None
        wins = sum(1 for p in decided if p.outcome == "WIN")
        return wins / len(decided)

    def get_all(self) -> List[Prediction]:
        return list(self._predictions)
