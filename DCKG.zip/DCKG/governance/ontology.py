"""
Ontology loader and validator — per AR48c and AR48d.

The ontology is the causal vocabulary of the DCKG system. It defines:
  - Which node types are permitted (GEOPOLITICAL_EVENT, MACRO_INDICATOR, etc.)
  - Which edge types are permitted (CONSTRAINS_SUPPLY_OF, POLICY_RISK_TO, etc.)
  - Which (source_type, edge_type, target_type) triples are structurally valid
  - Decay class, half-life, likelihood ratios, and regime-conditionality for
    each edge type

AR48c: Any code that creates or modifies a graph edge must call validate_edge()
       BEFORE the graph operation executes. OntologyViolationError must be raised
       immediately on encountering an unknown or structurally invalid type — no
       graph state is written if validation fails.

AR48d: The ontology version must be recorded on every event and every edge.
       The validator is instantiated from a specific versioned YAML file so
       that the version is always known.
"""

from __future__ import annotations

import yaml
from pathlib import Path
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Exception
# ---------------------------------------------------------------------------


class OntologyViolationError(Exception):
    """
    Raised immediately when an unknown node type, unknown edge type, or
    invalid (source_type, edge_type, target_type) triple is encountered.

    Per AR48c this must be raised BEFORE any graph operation executes so
    that no invalid state is ever written to the graph.
    """


# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------


class OntologyValidator:
    """
    Validates node types, edge types, and edge triples against a loaded
    ontology YAML.

    Instantiate via the module-level load_ontology() factory rather than
    directly, to ensure the version is recorded correctly.

    All validation methods raise OntologyViolationError immediately upon
    detecting a violation — callers must not catch and suppress these.
    """

    def __init__(self, ontology_data: dict, source_path: Optional[Path] = None) -> None:
        """
        Args:
            ontology_data: Parsed YAML dictionary from ontology_v1.yaml.
            source_path: Path the ontology was loaded from (for error messages).
        """
        self._data = ontology_data
        self._source_path = source_path
        self._version: str = ontology_data.get("version", "unknown")
        self._node_types: dict = ontology_data.get("node_types", {})
        self._edge_types: dict = ontology_data.get("edge_types", {})
        self._decay_classes: dict = ontology_data.get("decay_classes", {})

        if not self._node_types:
            raise OntologyViolationError(
                f"Ontology loaded from {source_path} contains no node_types."
            )
        if not self._edge_types:
            raise OntologyViolationError(
                f"Ontology loaded from {source_path} contains no edge_types."
            )

    # ------------------------------------------------------------------
    # Public properties
    # ------------------------------------------------------------------

    @property
    def version(self) -> str:
        """The version string from the ontology YAML (e.g. '1.0')."""
        return self._version

    @property
    def node_type_names(self) -> frozenset:
        """All permitted node type names as a frozenset."""
        return frozenset(self._node_types.keys())

    @property
    def edge_type_names(self) -> frozenset:
        """All permitted edge type names as a frozenset."""
        return frozenset(self._edge_types.keys())

    # ------------------------------------------------------------------
    # Validation methods
    # ------------------------------------------------------------------

    def validate_node_type(self, node_type: str) -> None:
        """
        Raise OntologyViolationError immediately if node_type is not in the
        ontology. This check must be called before any node is created.

        Args:
            node_type: The node type string to validate.

        Raises:
            OntologyViolationError: If node_type is unknown.
        """
        if node_type not in self._node_types:
            raise OntologyViolationError(
                f"Unknown node type {node_type!r}. "
                f"Permitted node types: {sorted(self._node_types.keys())}. "
                f"Ontology version: {self._version}. "
                "No graph operation has been executed."
            )

    def validate_edge_type(self, edge_type: str) -> None:
        """
        Raise OntologyViolationError immediately if edge_type is not in the
        ontology. This check must be called before any edge is created.

        Args:
            edge_type: The edge type string to validate.

        Raises:
            OntologyViolationError: If edge_type is unknown.
        """
        if edge_type not in self._edge_types:
            raise OntologyViolationError(
                f"Unknown edge type {edge_type!r}. "
                f"Permitted edge types: {sorted(self._edge_types.keys())}. "
                f"Ontology version: {self._version}. "
                "No graph operation has been executed."
            )

    def validate_edge(
        self, source_type: str, edge_type: str, target_type: str
    ) -> None:
        """
        Validate the complete (source_type, edge_type, target_type) triple.

        Performs three checks in order, raising OntologyViolationError on the
        first failure — all checks happen before any graph operation:
          1. source_type must be a known node type.
          2. edge_type must be a known edge type.
          3. target_type must be a known node type.
          4. source_type must be in the edge's permitted_source_types.
          5. target_type must be in the edge's permitted_target_types.

        Args:
            source_type: Node type of the edge's source node.
            edge_type: The edge type.
            target_type: Node type of the edge's target node.

        Raises:
            OntologyViolationError: On any validation failure, before any
                                    graph operation is performed.
        """
        # Check 1: source node type must be known.
        self.validate_node_type(source_type)

        # Check 2: edge type must be known.
        self.validate_edge_type(edge_type)

        # Check 3: target node type must be known.
        self.validate_node_type(target_type)

        edge_def: dict = self._edge_types[edge_type]
        permitted_sources: list = edge_def.get("permitted_source_types", [])
        permitted_targets: list = edge_def.get("permitted_target_types", [])

        # Check 4: source_type must be permitted for this edge type.
        if source_type not in permitted_sources:
            raise OntologyViolationError(
                f"Edge type {edge_type!r} does not permit source node type "
                f"{source_type!r}. "
                f"Permitted source types: {permitted_sources}. "
                f"Ontology version: {self._version}. "
                "No graph operation has been executed."
            )

        # Check 5: target_type must be permitted for this edge type.
        if target_type not in permitted_targets:
            raise OntologyViolationError(
                f"Edge type {edge_type!r} does not permit target node type "
                f"{target_type!r}. "
                f"Permitted target types: {permitted_targets}. "
                f"Ontology version: {self._version}. "
                "No graph operation has been executed."
            )

    # ------------------------------------------------------------------
    # Attribute accessors
    # ------------------------------------------------------------------

    def get_decay_class(self, edge_type: str) -> str:
        """
        Return the decay class name for the given edge type.

        Args:
            edge_type: A valid edge type string.

        Returns:
            Decay class name string (e.g. 'SUPPLY_FLOW', 'INFRASTRUCTURE_DAMAGE').

        Raises:
            OntologyViolationError: If edge_type is unknown.
        """
        self.validate_edge_type(edge_type)
        return self._edge_types[edge_type]["decay_class"]

    def get_half_life(self, edge_type: str) -> int:
        """
        Return the default half-life in days for the given edge type.

        Args:
            edge_type: A valid edge type string.

        Returns:
            Integer number of days for the default half-life.

        Raises:
            OntologyViolationError: If edge_type is unknown.
        """
        self.validate_edge_type(edge_type)
        return int(self._edge_types[edge_type]["default_half_life_days"])

    def get_lr(self, edge_type: str, source_type: str) -> float:
        """
        Return the initial likelihood ratio for a given (edge_type, source_type)
        combination, as specified in initial_lr_by_source.

        Args:
            edge_type: A valid edge type string.
            source_type: The source data type key (e.g. 'primary_wire_service',
                         'satellite_imagery').

        Returns:
            Float likelihood ratio.

        Raises:
            OntologyViolationError: If edge_type is unknown.
            KeyError: If source_type is not present in initial_lr_by_source for
                      this edge type.
        """
        self.validate_edge_type(edge_type)
        lr_map: dict = self._edge_types[edge_type].get("initial_lr_by_source", {})
        if source_type not in lr_map:
            raise KeyError(
                f"Source type {source_type!r} not found in initial_lr_by_source "
                f"for edge type {edge_type!r}. "
                f"Available source types: {sorted(lr_map.keys())}."
            )
        return float(lr_map[source_type])

    def is_regime_conditional(self, edge_type: str) -> bool:
        """
        Return True if the edge type's direction depends on the current regime.

        Per the ontology, POLICY_RISK_TO edges are regime-conditional —
        their sign must be looked up from the active regime rather than
        assumed. All other edge types are unconditional.

        Args:
            edge_type: A valid edge type string.

        Returns:
            True if direction_regime_conditional is true in the ontology.

        Raises:
            OntologyViolationError: If edge_type is unknown.
        """
        self.validate_edge_type(edge_type)
        return bool(self._edge_types[edge_type].get("direction_regime_conditional", False))

    def get_edge_definition(self, edge_type: str) -> dict:
        """
        Return the full edge definition dictionary for an edge type.

        Args:
            edge_type: A valid edge type string.

        Returns:
            Dictionary with all ontology fields for the edge type.

        Raises:
            OntologyViolationError: If edge_type is unknown.
        """
        self.validate_edge_type(edge_type)
        return dict(self._edge_types[edge_type])

    def get_node_definition(self, node_type: str) -> dict:
        """
        Return the full node definition dictionary for a node type.

        Args:
            node_type: A valid node type string.

        Returns:
            Dictionary with all ontology fields for the node type.

        Raises:
            OntologyViolationError: If node_type is unknown.
        """
        self.validate_node_type(node_type)
        return dict(self._node_types[node_type])

    def get_decay_class_definition(self, decay_class: str) -> dict:
        """
        Return the full decay class definition for a decay class name.

        Args:
            decay_class: The decay class name (e.g. 'INFRASTRUCTURE_DAMAGE').

        Returns:
            Dictionary with half_life_days, clock_reset_triggers, etc.

        Raises:
            KeyError: If decay_class is not present in the ontology.
        """
        if decay_class not in self._decay_classes:
            raise KeyError(
                f"Unknown decay class {decay_class!r}. "
                f"Available classes: {sorted(self._decay_classes.keys())}."
            )
        return dict(self._decay_classes[decay_class])

    def get_permitted_source_types(self, edge_type: str) -> list:
        """
        Return the list of permitted source node types for an edge type.

        Args:
            edge_type: A valid edge type string.

        Returns:
            List of node type name strings.

        Raises:
            OntologyViolationError: If edge_type is unknown.
        """
        self.validate_edge_type(edge_type)
        return list(self._edge_types[edge_type].get("permitted_source_types", []))

    def get_permitted_target_types(self, edge_type: str) -> list:
        """
        Return the list of permitted target node types for an edge type.

        Args:
            edge_type: A valid edge type string.

        Returns:
            List of node type name strings.

        Raises:
            OntologyViolationError: If edge_type is unknown.
        """
        self.validate_edge_type(edge_type)
        return list(self._edge_types[edge_type].get("permitted_target_types", []))


# ---------------------------------------------------------------------------
# Module-level factory and singleton
# ---------------------------------------------------------------------------

_DEFAULT_ONTOLOGY_PATH = (
    Path(__file__).parent.parent / "config" / "ontology_v1.yaml"
)

_singleton: Optional[OntologyValidator] = None


def load_ontology(path: Optional[Path] = None) -> OntologyValidator:
    """
    Load and return an OntologyValidator from a YAML file.

    If path is None, the default config/ontology_v1.yaml relative to this
    package root is used. The result is NOT cached — each call parses the
    YAML fresh so that tests can load different ontology files.

    To use the module-level singleton (lazily loaded from the default path),
    call get_ontology() instead.

    Args:
        path: Optional Path to an ontology YAML file.

    Returns:
        A fully initialised OntologyValidator.

    Raises:
        FileNotFoundError: If the YAML file does not exist.
        OntologyViolationError: If the YAML is missing required sections.
    """
    resolved = Path(path) if path is not None else _DEFAULT_ONTOLOGY_PATH
    if not resolved.exists():
        raise FileNotFoundError(
            f"Ontology YAML not found at {resolved}. "
            "Check that config/ontology_v1.yaml is present in the project root."
        )
    with resolved.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    if not isinstance(data, dict):
        raise OntologyViolationError(
            f"Ontology YAML at {resolved} did not parse to a dictionary."
        )
    return OntologyValidator(ontology_data=data, source_path=resolved)


def get_ontology() -> OntologyValidator:
    """
    Return the module-level singleton OntologyValidator.

    Lazily loads from config/ontology_v1.yaml on first call.
    Subsequent calls return the cached instance without re-parsing.

    Raises:
        FileNotFoundError: If the default ontology YAML is missing.
        OntologyViolationError: If the YAML is malformed.
    """
    global _singleton
    if _singleton is None:
        _singleton = load_ontology()
    return _singleton


def reset_singleton() -> None:
    """
    Clear the cached singleton. Useful in tests that need to load a
    different ontology file.
    """
    global _singleton
    _singleton = None
