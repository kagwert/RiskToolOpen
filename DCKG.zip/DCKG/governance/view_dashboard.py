"""
View dashboard — structured human-readable investment views.
Per BR19, BR20, BR13. Every view must be fully traceable to source edges.
"""
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
import json

@dataclass
class EdgeSummary:
    edge_id: str
    edge_type: str
    wt: float
    p_posterior: float
    decay_factor: float
    t_days: float
    last_confirmed_at: str
    source_urls: List[str]
    narrative_sensitive: bool

@dataclass
class InvestmentView:
    view_id: str
    asset: str
    direction: str          # LONG | SHORT
    conviction: str         # HIGH | MEDIUM | LOW
    alpha_contribution: float
    position_weight_pct: float
    narrative_sensitive: bool
    supporting_edges: List[EdgeSummary]
    causal_chain_text: str
    created_at: str
    last_updated_at: str

@dataclass
class ViewDashboard:
    generated_at: str
    regime: str
    regime_confidence: float
    active_views: List[InvestmentView]
    contested_views: List[InvestmentView]
    conflicts: List[dict]
    regime_overlays: List[dict]

def build_view_dashboard(graph_store, alpha_dict: dict, weights: dict,
                          regime: str, regime_confidence: float,
                          regime_overlays: list) -> ViewDashboard:
    """
    Build a complete view dashboard from graph state and optimizer output.

    Per BR02: every view must be traceable to source edges.
    Per BR19: human-readable causal chain text required.
    """
    now = datetime.now(timezone.utc).isoformat()

    active_views = []
    contested_views = []

    for asset_id, weight in weights.items():
        if abs(weight) < 1e-4:
            continue

        asset_alpha = alpha_dict.get(asset_id)
        if asset_alpha is None:
            continue

        edges = graph_store.get_edges_to_asset(asset_id)
        edge_summaries = []
        for e in edges:
            if e.status == "ACTIVE":
                edge_summaries.append(EdgeSummary(
                    edge_id=e.edge_id,
                    edge_type=e.edge_type,
                    wt=e.wt,
                    p_posterior=e.p_posterior,
                    decay_factor=e.decay_factor,
                    t_days=e.decay_clock.get_t_days(),
                    last_confirmed_at=e.decay_clock.last_confirmed_at.isoformat(),
                    source_urls=e.evidence_source_urls,
                    narrative_sensitive=e.narrative_sensitive,
                ))

        direction = "LONG" if weight > 0 else "SHORT"
        abs_alpha = abs(asset_alpha.alpha)
        if abs_alpha > 0.3:
            conviction = "HIGH"
        elif abs_alpha > 0.1:
            conviction = "MEDIUM"
        else:
            conviction = "LOW"

        causal_text = _build_causal_chain_text(asset_id, edge_summaries)

        view = InvestmentView(
            view_id=f"view_{asset_id.lower()}_{now[:10]}",
            asset=asset_id,
            direction=direction,
            conviction=conviction,
            alpha_contribution=asset_alpha.alpha,
            position_weight_pct=weight * 100,
            narrative_sensitive=asset_alpha.narrative_sensitive,
            supporting_edges=edge_summaries,
            causal_chain_text=causal_text,
            created_at=now,
            last_updated_at=now,
        )

        # Check if any edge is CONTESTED
        all_asset_edges = graph_store.get_all_edges()
        contested_edges = [
            e for e in all_asset_edges
            if e.target_node_id == asset_id and e.status == "CONTESTED"
        ]
        if contested_edges:
            contested_views.append(view)
        else:
            active_views.append(view)

    return ViewDashboard(
        generated_at=now,
        regime=regime,
        regime_confidence=regime_confidence,
        active_views=active_views,
        contested_views=contested_views,
        conflicts=[],
        regime_overlays=regime_overlays,
    )


def _build_causal_chain_text(asset_id: str, edges: List[EdgeSummary]) -> str:
    if not edges:
        return f"No active causal edges for {asset_id}."
    parts = []
    for e in edges:
        mechanism_map = {
            "CONSTRAINS_SUPPLY_OF": "constrains supply of",
            "INCREASES_COST_OF": "increases cost of",
            "INFRASTRUCTURE_DAMAGE_TO": "damages infrastructure of",
            "POLICY_RISK_TO": "creates policy risk to",
            "ACCELERATES_DEMAND_FOR": "accelerates demand for",
            "LIQUIDITY_STRESS_ON": "creates liquidity stress on",
            "SUBSTITUTION_TO": "drives substitution to",
        }
        verb = mechanism_map.get(e.edge_type, "affects")
        src = e.edge_id.split("_")[0] if "_" in e.edge_id else e.edge_id
        parts.append(f"{src} {verb} {asset_id} (Wt={e.wt:.3f}, P={e.p_posterior:.2f})")
    return " → ".join(parts)


def dashboard_to_dict(dashboard: ViewDashboard) -> dict:
    def _edge_to_dict(e: EdgeSummary) -> dict:
        return {
            "edge_id": e.edge_id,
            "edge_type": e.edge_type,
            "wt": e.wt,
            "p_posterior": e.p_posterior,
            "decay_factor": e.decay_factor,
            "t_days": e.t_days,
            "last_confirmed_at": e.last_confirmed_at,
            "source_urls": e.source_urls,
            "narrative_sensitive": e.narrative_sensitive,
        }

    def _view_to_dict(v: InvestmentView) -> dict:
        return {
            "view_id": v.view_id,
            "asset": v.asset,
            "direction": v.direction,
            "conviction": v.conviction,
            "alpha_contribution": v.alpha_contribution,
            "position_weight_pct": v.position_weight_pct,
            "narrative_sensitive": v.narrative_sensitive,
            "supporting_edges": [_edge_to_dict(e) for e in v.supporting_edges],
            "causal_chain_text": v.causal_chain_text,
            "created_at": v.created_at,
            "last_updated_at": v.last_updated_at,
        }

    return {
        "generated_at": dashboard.generated_at,
        "regime": dashboard.regime,
        "regime_confidence": dashboard.regime_confidence,
        "active_views": [_view_to_dict(v) for v in dashboard.active_views],
        "contested_views": [_view_to_dict(v) for v in dashboard.contested_views],
        "conflicts": dashboard.conflicts,
        "regime_overlays": dashboard.regime_overlays,
    }
