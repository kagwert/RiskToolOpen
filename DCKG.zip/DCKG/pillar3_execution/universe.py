"""
Universe — instrument definitions linking causal nodes to tradeable assets.
Per BR22, BR23. Production replacement: vendor instrument master.
"""
from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass
class Instrument:
    asset_id: str           # canonical ID matching graph node IDs
    ticker: str             # exchange ticker
    name: str               # human-readable
    sector: str             # for sector concentration constraints
    asset_class: str        # equity | commodity | fixed_income | fx | volatility
    long_eligible: bool = True
    short_eligible: bool = True
    options_eligible: bool = False  # for Type B CONTESTED routing
    currency: str = "USD"
    exchange: str = ""


# The Phase 1 instrument universe covering the Iran case study
UNIVERSE: Dict[str, Instrument] = {
    "VLO": Instrument(
        asset_id="VLO", ticker="VLO", name="Valero Energy Corp",
        sector="energy", asset_class="equity",
        long_eligible=True, short_eligible=True, options_eligible=True
    ),
    "DAL": Instrument(
        asset_id="DAL", ticker="DAL", name="Delta Air Lines",
        sector="industrials", asset_class="equity",
        long_eligible=True, short_eligible=True, options_eligible=True
    ),
    "ICE_GASOIL": Instrument(
        asset_id="ICE_GASOIL", ticker="QS1", name="ICE Gasoil Futures",
        sector="energy", asset_class="commodity",
        long_eligible=True, short_eligible=True, options_eligible=True
    ),
    "EU_UTILITIES": Instrument(
        asset_id="EU_UTILITIES", ticker="SX6P", name="STOXX Europe 600 Utilities",
        sector="utilities", asset_class="equity",
        long_eligible=True, short_eligible=True, options_eligible=False
    ),
    "BRENT_CRUDE": Instrument(
        asset_id="BRENT_CRUDE", ticker="CO1", name="Brent Crude Futures",
        sector="energy", asset_class="commodity",
        long_eligible=True, short_eligible=True, options_eligible=True
    ),
    "XLE": Instrument(
        asset_id="XLE", ticker="XLE", name="Energy Select Sector SPDR",
        sector="energy", asset_class="equity",
        long_eligible=True, short_eligible=True, options_eligible=True
    ),
    "SPX": Instrument(
        asset_id="SPX", ticker="SPX", name="S&P 500 Index",
        sector="broad_market", asset_class="equity",
        long_eligible=True, short_eligible=True, options_eligible=True
    ),
    "equity_index_short": Instrument(
        asset_id="equity_index_short", ticker="SH", name="ProShares Short S&P500",
        sector="broad_market", asset_class="equity",
        long_eligible=True, short_eligible=False, options_eligible=False
    ),
    "equity_vol_long": Instrument(
        asset_id="equity_vol_long", ticker="VXX", name="iPath Series B S&P 500 VIX",
        sector="broad_market", asset_class="volatility",
        long_eligible=True, short_eligible=False, options_eligible=False
    ),
    "duration_short": Instrument(
        asset_id="duration_short", ticker="TBF", name="ProShares Short 20+ Year Treasury",
        sector="fixed_income", asset_class="fixed_income",
        long_eligible=True, short_eligible=False, options_eligible=False
    ),
}


def get_universe() -> Dict[str, Instrument]:
    return UNIVERSE


def get_asset_ids() -> List[str]:
    return list(UNIVERSE.keys())


def get_instrument(asset_id: str) -> Optional[Instrument]:
    return UNIVERSE.get(asset_id)


def get_sector(asset_id: str) -> str:
    inst = UNIVERSE.get(asset_id)
    return inst.sector if inst else "unknown"
