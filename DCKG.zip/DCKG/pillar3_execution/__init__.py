"""
Pillar III — Execution layer.

Responsible for constructing a risk-adjusted portfolio from the alpha vector
produced by Pillar II and the mandate constraints in config/mandate_global_alloc.yaml.

Components:
    universe       — Instrument definitions mapping causal node IDs to tradeable assets
    optimizer      — SLSQP portfolio optimizer (Phase 1; production: Gurobi MIQP)
    solve_logger   — Audit log for every optimizer run (AR62)
"""
