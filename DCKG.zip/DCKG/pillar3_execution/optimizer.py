"""
Portfolio optimizer — SLSQP phase 1 implementation.
Per AR59, AR60. Production replacement: Gurobi MIQP.
Per AR62: every solve logged via SolveLogger.

KNOWN LIMITATION (Phase 1): Cardinality constraint uses two-stage approximation.
The production Gurobi implementation solves the true MIQP.
"""
import numpy as np
from scipy.optimize import minimize, Bounds
from typing import Dict, List, Optional
from pathlib import Path
import time
import yaml


class PortfolioOptimizer:
    def __init__(self, mandate_config_path: str = None, solve_logger=None):
        if mandate_config_path is None:
            mandate_config_path = str(
                Path(__file__).parent.parent / "config" / "mandate_global_alloc.yaml"
            )
        with open(mandate_config_path) as f:
            self.mandate = yaml.safe_load(f)
        self.solve_logger = solve_logger
        self._version = "1.0"

    def solve(
        self,
        alpha: np.ndarray,
        cov_matrix: np.ndarray,
        universe: List[str],
        prior_weights: Optional[Dict[str, float]] = None,
        regime: str = "UNKNOWN",
        alpha_version: str = "unknown",
        sector_map: Optional[Dict[str, str]] = None,
    ) -> Dict:
        """
        Solve portfolio optimization.

        Returns dict with: weights (dict), objective_value, solve_status,
        binding_constraints, solve_time_ms, cardinality_approximated, notes.

        Two-stage cardinality approximation:
        1. Solve full problem without cardinality constraint.
        2. Trim to top K positions by |weight|.
        3. Re-solve with only those K assets (others forced to zero via bounds).
        """
        n = len(universe)
        if prior_weights is None:
            prior_weights = {a: 0.0 for a in universe}
        w_prior = np.array([prior_weights.get(a, 0.0) for a in universe])

        params = self.mandate
        risk_aversion = params["risk_parameters"]["risk_aversion"]
        tc_coeff = params["risk_parameters"]["transaction_cost_coeff"]
        gross_max = params["constraints"]["gross_exposure_max"]
        net_min = params["constraints"]["net_exposure_min"]
        net_max = params["constraints"]["net_exposure_max"]
        long_max = params["constraints"]["single_name_long_max"]
        short_max = params["constraints"]["single_name_short_max"]  # negative
        k = params["constraints"]["max_positions"]
        sector_concentration_max = params["constraints"].get("sector_concentration_max", 0.35)

        record = None
        if self.solve_logger:
            # Rough constraint count: net bounds (2) + gross (1) + per-name (2*n) + sectors
            n_sectors = len(set(sector_map.values())) if sector_map else 0
            record = self.solve_logger.start_solve(
                alpha_vector_version=alpha_version,
                mandate_version=self._version,
                regime=regime,
                n_assets=n,
                n_constraints=3 + 2 * n + n_sectors,
            )

        t0 = time.time()

        # ------------------------------------------------------------------
        # Build sector index map once (used in constraints closure below)
        # ------------------------------------------------------------------
        sector_indices: Dict[str, List[int]] = {}
        if sector_map:
            for i, asset in enumerate(universe):
                s = sector_map.get(asset, "unknown")
                sector_indices.setdefault(s, []).append(i)

        # ------------------------------------------------------------------
        # Objective and gradient
        # ------------------------------------------------------------------
        def objective(w: np.ndarray) -> float:
            # Minimise the negative of: w^T mu - (lambda/2) w^T Sigma w - c ||Δw||_1
            delta = w - w_prior
            port_return = float(w @ alpha)
            port_variance = float(w @ cov_matrix @ w)
            port_tc = tc_coeff * float(np.sum(np.abs(delta)))
            return -(port_return - (risk_aversion / 2.0) * port_variance - port_tc)

        def objective_grad(w: np.ndarray) -> np.ndarray:
            delta = w - w_prior
            sign_delta = np.sign(delta)
            # Gradient of the negative objective
            grad = -(alpha - risk_aversion * cov_matrix @ w - tc_coeff * sign_delta)
            return grad

        # ------------------------------------------------------------------
        # Per-name bounds
        # ------------------------------------------------------------------
        bounds = Bounds(lb=np.full(n, short_max), ub=np.full(n, long_max))

        # ------------------------------------------------------------------
        # Constraints
        # ------------------------------------------------------------------
        constraints = []

        # Net exposure: sum(w) >= net_min
        constraints.append({
            "type": "ineq",
            "fun": lambda w: float(w.sum()) - net_min,
            "jac": lambda w: np.ones(n),
        })
        # Net exposure: sum(w) <= net_max
        constraints.append({
            "type": "ineq",
            "fun": lambda w: net_max - float(w.sum()),
            "jac": lambda w: -np.ones(n),
        })
        # Gross exposure: sum(|w|) <= gross_max
        constraints.append({
            "type": "ineq",
            "fun": lambda w: gross_max - float(np.sum(np.abs(w))),
        })

        # Sector concentration constraints
        for sector, indices in sector_indices.items():
            idx_arr = np.array(indices)
            constraints.append({
                "type": "ineq",
                "fun": lambda w, idx=idx_arr: sector_concentration_max - float(np.sum(np.abs(w[idx]))),
            })

        # ------------------------------------------------------------------
        # Stage 1: solve without cardinality
        # ------------------------------------------------------------------
        w0 = np.zeros(n)
        result = minimize(
            objective, w0, jac=objective_grad,
            method="SLSQP", bounds=bounds, constraints=constraints,
            options={"maxiter": 1000, "ftol": 1e-9},
        )

        # SLSQP status=0 means success; status=9 means iteration limit but
        # still a usable point; status=1 is occasionally returned on success
        # by some scipy builds.
        solver_ok = result.success or result.status in (0, 1, 9)

        if not solver_ok:
            solve_time = (time.time() - t0) * 1000.0
            if self.solve_logger and record:
                self.solve_logger.fail_solve(record, result.message)
            return {
                "weights": {},
                "objective_value": None,
                "solve_status": "failed",
                "binding_constraints": [],
                "solve_time_ms": solve_time,
                "cardinality_approximated": True,
                "notes": f"SLSQP stage-1 failed: {result.message}",
            }

        w_stage1 = result.x.copy()

        # ------------------------------------------------------------------
        # Stage 2 & 3: cardinality trim + re-solve
        # ------------------------------------------------------------------
        cardinality_approximated = n > k
        if cardinality_approximated:
            abs_weights = np.abs(w_stage1)
            top_k_indices = np.argsort(abs_weights)[-k:]
            mask = np.zeros(n, dtype=bool)
            mask[top_k_indices] = True

            # Force non-selected assets to zero via tight bounds
            lb2 = np.where(mask, short_max, 0.0)
            ub2 = np.where(mask, long_max, 0.0)
            bounds2 = Bounds(lb=lb2, ub=ub2)

            result2 = minimize(
                objective, w_stage1 * mask, jac=objective_grad,
                method="SLSQP", bounds=bounds2, constraints=constraints,
                options={"maxiter": 1000, "ftol": 1e-9},
            )
            if result2.success or result2.status in (0, 1, 9):
                w_final = result2.x.copy()
            else:
                # Fall back to stage-1 solution trimmed to K
                w_final = w_stage1 * mask
        else:
            w_final = w_stage1

        # Zero out numerically negligible weights
        w_final[np.abs(w_final) < 1e-4] = 0.0

        solve_time = (time.time() - t0) * 1000.0
        obj_val = -float(objective(w_final))

        # ------------------------------------------------------------------
        # Identify binding constraints (weights at their bounds)
        # ------------------------------------------------------------------
        binding: List[str] = []
        for i, asset in enumerate(universe):
            if abs(w_final[i] - long_max) < 1e-4:
                binding.append(f"{asset}_long_max")
            elif abs(w_final[i] - short_max) < 1e-4:
                binding.append(f"{asset}_short_max")

        weights_dict = {
            universe[i]: float(w_final[i])
            for i in range(n)
            if abs(w_final[i]) > 1e-4
        }

        if self.solve_logger and record:
            self.solve_logger.complete_solve(
                record, weights_dict, prior_weights, obj_val, solve_time, binding
            )

        notes = (
            "Phase 1: cardinality approximated by two-stage SLSQP"
            if cardinality_approximated
            else ""
        )
        return {
            "weights": weights_dict,
            "objective_value": obj_val,
            "solve_status": "optimal",
            "binding_constraints": binding,
            "solve_time_ms": solve_time,
            "cardinality_approximated": cardinality_approximated,
            "notes": notes,
        }
