"""
Solve logger — audit log for every optimizer run.
Per AR62: every solve logged with alpha version, constraints, timing, binding constraints.
"""
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
import uuid


@dataclass
class SolveRecord:
    solve_id: str
    started_at: str
    completed_at: Optional[str]
    alpha_vector_version: str
    mandate_version: str
    regime: str
    objective_value: Optional[float]
    solve_status: str          # optimal | infeasible | timeout | failed
    solve_time_ms: Optional[float]
    n_assets: int
    n_constraints: int
    binding_constraints: List[str]
    cardinality_approximated: bool  # True if two-stage SLSQP used (Phase 1 limitation)
    weights: Optional[Dict[str, float]]  # asset_id -> weight
    prior_weights: Optional[Dict[str, float]]
    turnover: Optional[float]
    notes: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class SolveLogger:
    def __init__(self, event_bus=None):
        self.event_bus = event_bus
        self._records: List[SolveRecord] = []

    def start_solve(self, alpha_vector_version: str, mandate_version: str,
                    regime: str, n_assets: int, n_constraints: int) -> SolveRecord:
        record = SolveRecord(
            solve_id=str(uuid.uuid4()),
            started_at=datetime.now(timezone.utc).isoformat(),
            completed_at=None,
            alpha_vector_version=alpha_vector_version,
            mandate_version=mandate_version,
            regime=regime,
            objective_value=None,
            solve_status="running",
            solve_time_ms=None,
            n_assets=n_assets,
            n_constraints=n_constraints,
            binding_constraints=[],
            cardinality_approximated=True,  # Always True in Phase 1
            weights=None,
            prior_weights=None,
            turnover=None,
        )
        self._records.append(record)
        if self.event_bus:
            self._publish_event("OPTIMIZER_SOLVE_STARTED", record)
        return record

    def complete_solve(self, record: SolveRecord, weights: Dict[str, float],
                       prior_weights: Dict[str, float], objective_value: float,
                       solve_time_ms: float, binding_constraints: List[str]) -> SolveRecord:
        record.completed_at = datetime.now(timezone.utc).isoformat()
        record.weights = weights
        record.prior_weights = prior_weights
        record.objective_value = objective_value
        record.solve_time_ms = solve_time_ms
        record.binding_constraints = binding_constraints
        record.solve_status = "optimal"
        turnover = sum(
            abs(weights.get(k, 0) - prior_weights.get(k, 0))
            for k in set(weights) | set(prior_weights)
        )
        record.turnover = turnover
        if self.event_bus:
            self._publish_event("OPTIMIZER_SOLVE_COMPLETED", record)
        return record

    def fail_solve(self, record: SolveRecord, reason: str) -> SolveRecord:
        record.completed_at = datetime.now(timezone.utc).isoformat()
        record.solve_status = "failed"
        record.notes = reason
        if self.event_bus:
            self._publish_event("OPTIMIZER_SOLVE_FAILED", record)
        return record

    def _publish_event(self, event_type: str, record: SolveRecord):
        from pillar1_perception.event_bus import make_event
        evt = make_event(
            event_type=event_type,
            source_component="pillar3_execution.optimizer",
            payload=record.to_dict(),
        )
        self.event_bus.publish(evt)

    def get_all_records(self) -> List[SolveRecord]:
        return list(self._records)

    def get_latest(self) -> Optional[SolveRecord]:
        return self._records[-1] if self._records else None
