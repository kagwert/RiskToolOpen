# DCKG — Claude Code Implementation Prompt
## Dynamic Causal Knowledge Graph · Basic Implementation
### Reference: DCKG Business and Architecture Requirements v2.0

---

## CONTEXT AND OBJECTIVE

You are implementing a **basic but architecturally correct** version of the Dynamic Causal Knowledge Graph (DCKG) — a systematic investment framework that translates raw news and market data into causal signals driving a portfolio optimizer. This is a Phase 1 build as defined in **Section 10.1** of the Requirements document, scoped as a fully runnable research prototype.

The purpose is not to build the production system. The purpose is to build something that:
- Instantiates the correct three-pillar architecture (**AR53**)
- Enforces the causal ontology discipline from day one (**AR48, AR48b**)
- Produces a correctly structured immutable event log (**AR22**)
- Generates auditable edge weights using the exact Bayesian formula (**BR02**)
- Applies temporal decay correctly (**DP04, DP05**)
- Classifies regime before signing any edge (**DP08**)
- Produces human-readable investment views traceable to sources (**BR01, BR02**)

Everything built here should be **replaceable** at each component boundary without touching adjacent components (**AR53**). Do not make architectural shortcuts that couple the pillars.

---

## TECHNOLOGY STACK

```
Language:       Python 3.11+
Graph store:    NetworkX (in-process, replaces Neo4j for Phase 1)
Event log:      SQLite with append-only WAL mode (replaces Kafka+Iceberg)
LLM extraction: Anthropic Claude API (claude-sonnet-4-6)
Data feeds:     NewsAPI or mock fixtures (see Data section)
Optimizer:      scipy.optimize with SLSQP (replaces Gurobi for Phase 1)
Config:         YAML files — one per ontology version, one per mandate
Testing:        pytest with fixtures covering the Iran case study
Interface:      FastAPI for the view dashboard endpoint + CLI runner
```

Stub any component that requires paid vendor access. Every stub must implement the same interface as the production component so it can be swapped without code changes elsewhere (**AR53**).

---

## REPOSITORY STRUCTURE

```
dckg/
├── README.md
├── requirements.txt
├── config/
│   ├── ontology_v1.yaml          # The causal vocabulary — AR48, AR48b
│   ├── mandate_global_alloc.yaml # Mandate constraints — BR06
│   └── regimes.yaml              # Regime state space and overlay rules — AR58b
├── pillar1_perception/
│   ├── __init__.py
│   ├── event_bus.py              # SQLite event log — AR22, AR63, AR64
│   ├── agent_a_newsflow.py       # LLM causal extraction — AR24, AR25, AR26, AR27
│   ├── agent_b_market.py         # Market data ingestion — AR06 through AR10
│   ├── agent_c_macro.py          # Macro sub-component extraction — AR04, AR05
│   └── data_quality.py           # Schema validation, quality scoring — AR18d, AR18e
├── pillar2_graph/
│   ├── __init__.py
│   ├── graph_store.py            # NetworkX DAG, edge CRUD — AR54, AR55, AR56
│   ├── bayesian_update.py        # Edge weight formula — the mathematical core
│   ├── decay.py                  # Decay classes and clock logic — DP04, DP05
│   ├── conflict_resolution.py    # CONTESTED classification — AR57, AR61, AR61b
│   ├── regime_classifier.py      # Independent regime classification — AR58, AR58b
│   └── alpha_vector.py           # Alpha construction from graph — BR01
├── pillar3_execution/
│   ├── __init__.py
│   ├── optimizer.py              # SLSQP optimizer — AR59, AR60
│   ├── universe.py               # Instrument mapping — BR22, BR23
│   └── solve_logger.py           # Solve audit log — AR62
├── governance/
│   ├── ontology.py               # Ontology loader and validator — AR48c, AR48d
│   ├── prediction_tracker.py     # IC monitoring infrastructure — AR41, AR42
│   └── view_dashboard.py         # Structured view output — BR19, BR20
├── api/
│   └── main.py                   # FastAPI endpoints for views and graph state
├── tests/
│   ├── fixtures/
│   │   ├── iran_newsflow.json    # Labelled Iran case study extractions
│   │   └── iran_market_data.json # Iran case market data fixtures
│   ├── test_ontology.py
│   ├── test_bayesian_update.py
│   ├── test_decay.py
│   ├── test_conflict_resolution.py
│   ├── test_regime_classifier.py
│   ├── test_optimizer.py
│   └── test_iran_case.py         # End-to-end Iran case study validation
└── scripts/
    ├── run_iran_case.py           # Reproduce Day 0–29 Iran case from fixtures
    └── backfill_demo.py           # Demonstrate point-in-time reconstruction
```

---

## PART 1: THE CAUSAL ONTOLOGY

### `config/ontology_v1.yaml`

This file is the causal vocabulary of the entire system. Per **AR48** and **AR48b**, every entry must be fully documented. This is not configuration — it is the formal specification of what the system can observe and reason about. The file must be treated as a governed artefact: no code may introduce a new node type or edge type that is not present in this file.

Implement the following initial ontology (**AR48f** specifies a maximum of 8 edge types at initial deployment):

```yaml
version: "1.0"
approved_by: "MVC"
effective_date: "2026-04-08"

node_types:
  GEOPOLITICAL_EVENT:
    definition: "A discrete event involving state or non-state actors with direct
      physical or policy consequences. Distinguished from MACRO_INDICATOR by being
      event-driven rather than periodic. Examples: military strike, sanctions
      announcement, treaty. Counter-example: opinion poll, diplomatic meeting
      without outcome."
    permitted_edge_origins: [CONSTRAINS_SUPPLY_OF, INCREASES_COST_OF,
                             INFRASTRUCTURE_DAMAGE_TO, POLICY_RISK_TO]
    permitted_edge_targets: []

  MACRO_INDICATOR:
    definition: "A periodically published economic measurement. Must be associated
      with a specific release schedule and issuing authority. Examples: CPI, PMI,
      NFP, GDP. Counter-example: analyst estimate, social media sentiment."
    permitted_edge_origins: [POLICY_RISK_TO, INCREASES_COST_OF]
    permitted_edge_targets: []

  PHYSICAL_OBSERVABLE:
    definition: "A directly measurable physical quantity independent of market
      pricing. Examples: AIS vessel count, pipeline throughput, storage inventory
      level, port congestion. Counter-example: futures price, implied volatility."
    permitted_edge_origins: [CONSTRAINS_SUPPLY_OF, INFRASTRUCTURE_DAMAGE_TO]
    permitted_edge_targets: []

  TRADEABLE_ASSET:
    definition: "A financial instrument or asset class that can be directly or
      indirectly held in the portfolio. Examples: equity sector index, commodity
      futures, government bond, options contract. Counter-example: concept node,
      intermediate economic variable."
    permitted_edge_origins: []
    permitted_edge_targets: [CONSTRAINS_SUPPLY_OF, INCREASES_COST_OF,
                              INFRASTRUCTURE_DAMAGE_TO, POLICY_RISK_TO,
                              ACCELERATES_DEMAND_FOR, LIQUIDITY_STRESS_ON,
                              SUBSTITUTION_TO]

edge_types:
  CONSTRAINS_SUPPLY_OF:
    mechanism: "Source reduces the quantity of target available to end consumers
      through a physical restriction on production, transportation, or access.
      The mechanism must be traceable to a specific physical pathway, not merely
      price correlation."
    permitted_source_types: [GEOPOLITICAL_EVENT, PHYSICAL_OBSERVABLE]
    permitted_target_types: [TRADEABLE_ASSET, PHYSICAL_OBSERVABLE]
    direction: NEGATIVE_TO_TARGET_PRICE  # supply constraint → price increase
    direction_regime_conditional: false
    decay_class: SUPPLY_FLOW
    default_half_life_days: 14
    boundary_conditions:
      - "Does not apply when supply constraint is fully offset by inventory releases"
      - "Direction reverses if target asset benefits from supply tightness (e.g. refiners)"
    initial_lr_by_source:
      primary_wire_service: 4.5
      ais_vessel_tracking: 8.0
      official_government_statement: 6.0
      social_media: 1.2
    historical_episodes:
      - "1990 Gulf War — Kuwait invasion constrains Gulf crude supply"
      - "2022 Russia-Ukraine — pipeline gas supply constraint to Europe"

  INCREASES_COST_OF:
    mechanism: "Source raises the input costs faced by target asset producers or
      operators, compressing margins without necessarily constraining output volume.
      Distinguished from CONSTRAINS_SUPPLY_OF by operating through cost, not volume."
    permitted_source_types: [GEOPOLITICAL_EVENT, MACRO_INDICATOR, PHYSICAL_OBSERVABLE]
    permitted_target_types: [TRADEABLE_ASSET]
    direction: NEGATIVE_TO_MARGINS
    direction_regime_conditional: false
    decay_class: COST
    default_half_life_days: 45
    boundary_conditions:
      - "Does not apply when target can pass through cost increases to customers"
      - "Magnitude conditioned on hedging coverage of target sector"
    initial_lr_by_source:
      primary_wire_service: 3.5
      macro_release: 4.0
      physical_observable: 6.0
    historical_episodes:
      - "2022 energy shock — natural gas cost increase to European manufacturers"
      - "2008 oil spike — jet fuel cost shock to airlines"

  INFRASTRUCTURE_DAMAGE_TO:
    mechanism: "Source causes physical damage to infrastructure whose repair or
      replacement requires years, not weeks. Distinguished by decay class:
      INFRASTRUCTURE_DAMAGE uses half-life of years. Decay clock does NOT reset
      on ceasefire — only on confirmed engineering repair."
    permitted_source_types: [GEOPOLITICAL_EVENT]
    permitted_target_types: [PHYSICAL_OBSERVABLE, TRADEABLE_ASSET]
    direction: NEGATIVE_TO_CAPACITY
    direction_regime_conditional: false
    decay_class: INFRASTRUCTURE_DAMAGE
    default_half_life_days: 1825  # 5 years
    boundary_conditions:
      - "Decay clock resets ONLY on engineering_verification_confirmed flag"
      - "Ceasefire, diplomatic agreement, and political statements do NOT reset clock"
      - "Half-life must be set from engineering repair estimates, not market signal"
    initial_lr_by_source:
      primary_wire_service: 5.0
      satellite_imagery: 9.0
      engineering_assessment: 9.5
    historical_episodes:
      - "1991 Gulf War — Kuwaiti oil field damage required years of repair"
      - "2006 Lebanon war — infrastructure damage persisted beyond ceasefire"

  POLICY_RISK_TO:
    mechanism: "Source creates meaningful probability of a policy change that would
      materially alter the investment environment for target. Policy risk is narrative-
      sensitive: can be moved by statements alone."
    permitted_source_types: [GEOPOLITICAL_EVENT, MACRO_INDICATOR]
    permitted_target_types: [TRADEABLE_ASSET]
    direction: REGIME_CONDITIONAL  # must be looked up in regime table
    direction_regime_conditional: true
    decay_class: POLICY
    default_half_life_days: 180
    boundary_conditions:
      - "Direction depends entirely on current regime — never sign without regime lookup"
      - "Policy risk to rates: sign depends on inflation vs growth regime"
    initial_lr_by_source:
      central_bank_statement: 6.5
      government_press_release: 5.0
      primary_wire_service: 3.0
    historical_episodes:
      - "2022 Fed pivot — inflation regime drives rate-hike policy risk"
      - "2020 pandemic — emergency policy risk to all rate-sensitive assets"

  ACCELERATES_DEMAND_FOR:
    mechanism: "Source increases end-user demand for target through a named
      substitution or necessity pathway."
    permitted_source_types: [GEOPOLITICAL_EVENT, MACRO_INDICATOR]
    permitted_target_types: [TRADEABLE_ASSET]
    direction: POSITIVE_TO_TARGET_PRICE
    direction_regime_conditional: false
    decay_class: SUPPLY_FLOW
    default_half_life_days: 14
    boundary_conditions:
      - "Does not apply when demand increase is temporary and non-structural"
    initial_lr_by_source:
      primary_wire_service: 3.0
      macro_release: 3.5
    historical_episodes:
      - "2022 Russia-Ukraine — coal demand acceleration as gas substitute in Europe"
      - "1973 oil crisis — nuclear energy demand acceleration"

  LIQUIDITY_STRESS_ON:
    mechanism: "Source increases credit spreads or reduces market liquidity for
      target, raising funding costs or impairing price discovery. Distinct from
      INCREASES_COST_OF which operates through operating costs."
    permitted_source_types: [GEOPOLITICAL_EVENT, MACRO_INDICATOR]
    permitted_target_types: [TRADEABLE_ASSET]
    direction: NEGATIVE_TO_TARGET_PRICE
    direction_regime_conditional: false
    decay_class: LIQUIDITY_STRESS
    default_half_life_days: 7
    boundary_conditions:
      - "Does not apply in QE environments where central bank backstops credit"
    initial_lr_by_source:
      credit_spread_data: 7.0
      primary_wire_service: 2.5
    historical_episodes:
      - "2008 GFC — credit liquidity stress on financials"
      - "2020 March — liquidity stress across all risk assets"

  SUBSTITUTION_TO:
    mechanism: "Source causes market participants to shift demand from one asset
      to target as a direct substitute, creating a positive causal link where
      neither node would otherwise be connected."
    permitted_source_types: [GEOPOLITICAL_EVENT, PHYSICAL_OBSERVABLE]
    permitted_target_types: [TRADEABLE_ASSET]
    direction: POSITIVE_TO_TARGET_PRICE
    direction_regime_conditional: false
    decay_class: SUPPLY_FLOW
    default_half_life_days: 14
    boundary_conditions:
      - "Substitution must be technically feasible within the timeframe claimed"
    initial_lr_by_source:
      primary_wire_service: 2.5
      physical_observable: 5.0
    historical_episodes:
      - "2022 — European coal as substitute for Russian gas"
      - "2021 — LNG as substitute for pipeline gas in Asia"

decay_classes:
  LIQUIDITY_STRESS:
    half_life_days: 7
    clock_reset_triggers: [new_confirming_wire, physical_observable_confirmation]
    clock_freeze_triggers: [feed_failure]
    notes: "Fastest-decaying class. Market stress normalises quickly when source resolves."

  SUPPLY_FLOW:
    half_life_days: 14
    clock_reset_triggers: [ais_confirmation, physical_flow_data, exchange_data]
    clock_freeze_triggers: [feed_failure]
    notes: "Physical flow disruptions typically resolve within weeks to months."

  COST:
    half_life_days: 45
    clock_reset_triggers: [macro_release_confirmation, earnings_confirmation]
    clock_freeze_triggers: [feed_failure]
    notes: "Cost pressures persist longer than flow disruptions but ultimately adjust."

  POLICY:
    half_life_days: 180
    clock_reset_triggers: [central_bank_decision, government_announcement]
    clock_freeze_triggers: [feed_failure]
    notes: "Policy environments change slowly. Risk persists until explicit policy decision."

  INFRASTRUCTURE_DAMAGE:
    half_life_days: 1825
    clock_reset_triggers: [engineering_verification_confirmed]
    clock_freeze_triggers: [feed_failure, ceasefire_announced, diplomatic_agreement]
    notes: >
      CRITICAL: ceasefire_announced and diplomatic_agreement are FREEZE triggers,
      not reset triggers. Infrastructure damage persists through political events.
      Clock resets ONLY when physical engineering repair is independently verified.
      This is a hard constraint — no exception is permitted.
```

### `config/regimes.yaml`

Per **AR58**, **AR58b**, and **AR58c**, the regime classifier must operate independently of the graph, and each regime must specify standing portfolio overlays that activate deterministically on regime entry and exit deterministically on regime exit.

```yaml
version: "1.0"

regimes:
  GROWTH_EXPANSION:
    dimensions: {growth: POSITIVE, inflation: BELOW_TARGET, risk_appetite: ON}
    edge_sign_multipliers:
      POLICY_RISK_TO_rates: +1.0    # rate risk positive to duration
      POLICY_RISK_TO_equities: +1.0  # policy risk positive to equity beta
    portfolio_overlays: []

  STAGFLATION_RISK:
    dimensions: {growth: NEGATIVE, inflation: ABOVE_TARGET, risk_appetite: OFF}
    edge_sign_multipliers:
      POLICY_RISK_TO_rates: -1.0    # CB constrained — rate cuts off table
      POLICY_RISK_TO_equities: -1.0  # stagflation negative for equities
    portfolio_overlays:
      - instrument: "equity_index_short"
        sizing: "5pct_delta_NAV"
        exit_trigger: "regime_reclassification"
        exit_mechanism: "deterministic_immediate"
      - instrument: "equity_vol_long"
        sizing: "2pct_vega_NAV"
        exit_trigger: "regime_reclassification"
        exit_mechanism: "deterministic_immediate"
    notes: >
      Overlay positions are properties of the regime, not of any causal edge.
      They must be generated automatically on regime entry without requiring
      a causal chain to produce them. They exit deterministically on
      reclassification — no discretion is permitted.

  INFLATION_ONLY:
    dimensions: {growth: POSITIVE, inflation: ABOVE_TARGET, risk_appetite: ON}
    edge_sign_multipliers:
      POLICY_RISK_TO_rates: -0.8
      POLICY_RISK_TO_equities: -0.3
    portfolio_overlays:
      - instrument: "duration_short"
        sizing: "3pct_DV01_NAV"
        exit_trigger: "regime_reclassification"
        exit_mechanism: "deterministic_5day_reduction"

  RISK_OFF:
    dimensions: {growth: NEGATIVE, inflation: BELOW_TARGET, risk_appetite: OFF}
    edge_sign_multipliers:
      POLICY_RISK_TO_rates: +1.0
      POLICY_RISK_TO_equities: -1.0
    portfolio_overlays:
      - instrument: "equity_index_short"
        sizing: "3pct_delta_NAV"
        exit_trigger: "regime_reclassification"
        exit_mechanism: "deterministic_immediate"

reclassification_rules:
  minimum_dimensions_to_reclassify: 2
  confirmation_required: true
  confirmation_sources_minimum: 2
  freeze_contested_edges_during_transition: true
  notes: >
    Regime reclassification requires 2 of 3 dimensions to shift AND confirmation
    from at least 2 independent data sources. A single signal — including a
    ceasefire announcement, a single CPI print, or a prediction market move —
    is insufficient to trigger reclassification. During transition, all edges
    with regime_multiplier != 1.0 are frozen to CONTESTED status.
```

---

## PART 2: THE EVENT BUS AND IMMUTABLE LOG

### `pillar1_perception/event_bus.py`

Per **AR22**, **AR63**, and **AR64**, every inter-component message must pass through a single durable event bus. In this Phase 1 implementation the bus is SQLite in WAL mode. The schema must support full replay from any timestamp (**AR22b**). The implementation must make it impossible to update or delete existing records — append-only is a structural constraint, not a convention.

Every message must carry the mandatory fields specified in **AR64**:

```python
"""
Event bus — Phase 1 implementation using SQLite WAL.

Per AR22: append-only, never modified, redundantly stored.
Per AR63: all inter-component data flows through this bus.
Per AR64: every message carries the mandatory field set.
Per AR22b: supports point-in-time reconstruction.

Production replacement: Apache Kafka + Apache Iceberg.
Interface contract: this module exposes publish() and subscribe()
with the same signatures regardless of backend.
"""

import sqlite3, json, uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Any
from dataclasses import dataclass, asdict

EVENT_SCHEMA_VERSION = "1.0"

@dataclass
class DCKGEvent:
    """
    Mandatory field set per AR64. Every event published to the bus must
    carry all of these fields. Downstream components may add optional fields
    but may not omit mandatory ones.
    """
    event_id: str              # UUID, immutable
    event_type: str            # Controlled vocabulary: see EVENT_TYPES below
    source_component: str      # Which pillar/agent produced this event
    receipt_timestamp: str     # ISO8601 UTC — when received by the bus
    publication_timestamp: str # ISO8601 UTC — when the source published the data
    ontology_version: str      # Which ontology version was active at extraction time
    payload: dict              # Event-specific data
    schema_version: str = EVENT_SCHEMA_VERSION
    correlation_id: Optional[str] = None  # Links related events


# Controlled vocabulary for event_type — per AR64
EVENT_TYPES = {
    # Pillar I → II
    "CAUSAL_EXTRACTION",      # Agent extracted a causal claim from raw data
    "MARKET_DATA_UPDATE",     # Market price or spread updated
    "MACRO_RELEASE",          # Economic data release received
    "FEED_FAILURE",           # Data feed failure detected — per AR18b
    "FEED_RESTORED",          # Data feed restored

    # Pillar II internal
    "EDGE_CREATED",           # New causal edge added to graph
    "EDGE_UPDATED",           # Existing edge weight updated
    "EDGE_CONTESTED",         # Edge flagged as CONTESTED
    "EDGE_RETIRED",           # Edge weight fell below activation threshold
    "CONFLICT_DETECTED",      # Two signals in directional conflict
    "CONFLICT_RESOLVED",      # Conflict resolution produced ACTIVE or CONTESTED
    "REGIME_CLASSIFIED",      # Regime classifier produced new classification
    "REGIME_OVERLAY_ACTIVATED",  # Standing overlay position activated
    "ALPHA_VECTOR_UPDATED",   # New alpha vector produced

    # Pillar II → III
    "ALPHA_VECTOR_PUBLISHED",

    # Pillar III
    "OPTIMIZER_SOLVE_STARTED",
    "OPTIMIZER_SOLVE_COMPLETED",
    "OPTIMIZER_SOLVE_FAILED",
    "PORTFOLIO_WEIGHTS_PUBLISHED",
}


class EventBus:
    """
    SQLite-backed event bus with append-only enforcement.
    
    Append-only enforcement: the connection is opened without DELETE or UPDATE
    permissions by intercepting those statements. In production (Kafka+Iceberg),
    append-only is enforced at the infrastructure level. Here we enforce it
    in the application layer.
    """

    def __init__(self, db_path: str = "dckg_event_log.db"):
        self.db_path = Path(db_path)
        self._init_db()

    def _init_db(self):
        # Implement with WAL mode for durability
        # Schema: events table with NOT NULL constraints on all AR64 fields
        # Trigger: BEFORE DELETE and BEFORE UPDATE raise exceptions
        # Index: on receipt_timestamp, event_type, source_component
        ...

    def publish(self, event: DCKGEvent) -> str:
        """
        Append an event to the log. Returns event_id.
        Never modifies existing records.
        Raises ValueError if any mandatory field is missing.
        Raises ValueError if event_type is not in controlled vocabulary.
        """
        ...

    def subscribe(self, event_types: list[str], since_timestamp: Optional[str] = None):
        """
        Generator yielding events of specified types.
        If since_timestamp provided, replays from that point — enables AR22b.
        """
        ...

    def reconstruct_at(self, timestamp: str) -> list[DCKGEvent]:
        """
        Return all events that existed as of timestamp.
        This is the point-in-time reconstruction capability required by AR22b.
        Must produce identical results to what the live system held at that moment.
        """
        ...
```

---

## PART 3: CAUSAL EXTRACTION AGENT

### `pillar1_perception/agent_a_newsflow.py`

This is the LLM-powered agent. Per **AR24**, **AR25**, **AR26**, **AR27**, the agent must:
- Assign a receipt timestamp distinct from the publication timestamp
- Compute a novelty score before updating any edge
- Classify every signal as narrative-sensitive or narrative-insensitive
- Assign a verifiability score based on source traceability

**Critical architectural constraint:** The LLM may only map text to the existing ontology vocabulary. It must not invent new node types or edge types. The extraction prompt must explicitly constrain the LLM's output to the permitted types in `ontology_v1.yaml`. Per **DP14**, the LLM initialises priors but never updates live edge weights directly — it produces structured extraction events, and the graph layer applies the Bayesian update.

The extraction prompt must instruct the LLM to:
1. Identify causal claims in the text
2. Map source and target to permitted node types
3. Map the relationship to a permitted edge type — or declare `UNCLASSIFIABLE` if none fits
4. Assign an initial probability based on source reliability
5. Classify the signal as narrative-sensitive or narrative-insensitive
6. Extract the source URL and publication timestamp
7. Assign a novelty score based on similarity to recently processed signals

```python
"""
Agent A — Newsflow causal extraction.

Per AR24: assigns receipt_timestamp at ingest, distinct from publication_timestamp.
Per AR25: computes novelty_score before any graph update.
Per AR26: classifies narrative_sensitive flag on every signal.
Per AR27: assigns verifiability_score from source traceability.
Per DP14: LLM maps language to ontology — it does not produce edge weights.

Output schema (what this agent publishes to the event bus):
{
  "event_type": "CAUSAL_EXTRACTION",
  "source_node_type": str,       # from ontology node_types
  "source_node_id": str,         # canonical identifier
  "target_node_type": str,       # from ontology node_types
  "target_node_id": str,         # canonical identifier
  "edge_type": str,              # from ontology edge_types — or UNCLASSIFIABLE
  "p_raw": float,                # initial probability estimate [0,1]
  "magnitude_estimate": float,   # signed economic impact estimate
  "magnitude_ci_width": float,   # 95% confidence interval width
  "narrative_sensitive": bool,   # AR26
  "novelty_score": float,        # AR25 — 0.0 = duplicate, 1.0 = fully novel
  "verifiability_score": float,  # AR27 — 0.0 = unverifiable, 1.0 = primary source
  "source_url": str,             # must be present and non-null for verifiability > 0
  "publication_timestamp": str,  # from the source
  "receipt_timestamp": str,      # when this agent received the raw text
  "raw_text_excerpt": str,       # the exact text that supported this extraction
  "ontology_version": str        # which ontology was active at extraction time
}
"""

EXTRACTION_SYSTEM_PROMPT = """
You are a causal extraction agent for a systematic investment system.
Your task is to read a news article and extract structured causal claims.

CRITICAL CONSTRAINTS:
1. You may ONLY use the following node types: {node_types}
2. You may ONLY use the following edge types: {edge_types}
3. If a causal claim does not map to any permitted edge type, you MUST output
   edge_type: "UNCLASSIFIABLE" — do not force a fit.
4. You are mapping language to a controlled vocabulary. You are NOT making
   investment decisions. Do not add edge types. Do not invent mechanisms.

For each causal claim you find, output a JSON object with these fields:
- source_node_type: one of the permitted node types
- source_node_id: a canonical string identifier for the source entity
- target_node_type: one of the permitted node types  
- target_node_id: a canonical string identifier for the target entity
- edge_type: one of the permitted edge types, or UNCLASSIFIABLE
- p_raw: your estimate of P(this causal relationship is real and active), 0 to 1.
  Base this on: source reliability, specificity of the claim, language certainty.
  A confirmed official announcement = 0.75–0.85.
  An unverified report = 0.40–0.55.
  Speculation or analysis = 0.20–0.40.
- magnitude_estimate: signed estimate of economic impact on the target.
  Positive means beneficial to target asset price/margin. Negative means harmful.
  Express as a fraction of normal: -0.3 means 30% negative impact.
- magnitude_ci_width: your 95% confidence interval width (e.g. 0.4 means +/- 0.2)
- narrative_sensitive: true if this signal could be moved by statements, sentiment,
  or narrative without physical reality changing. False if it measures physical
  reality directly (e.g. AIS vessel data, inventory levels, physical prices).
- source_url: the URL of the source. null if not available.
- raw_text_excerpt: the exact sentence(s) that support this extraction.

Output a JSON array. If no causal claims exist, output [].
Do not output any other text.
"""
```

---

## PART 4: THE BAYESIAN EDGE WEIGHT FORMULA

### `pillar2_graph/bayesian_update.py`

This is the mathematical core of the system. Implement the exact formula from the Requirements document with no approximations.

**The edge weight formula (from Section 3.2 of the Combined Reference):**

```
Wt = P_post × M × exp(−λ · t) × (1 − ρ_corr)
```

Where:
- `P_post` = Bayesian posterior probability after updating on new evidence
- `M` = signed magnitude estimate with confidence interval adjustment: `M_base × (1 − CI_width/2)`
- `exp(−λ · t)` = temporal decay factor where λ = ln(2) / half_life_days and t = days since `last_confirmed_at`
- `ρ_corr` = correlation penalty between evidence sources: prevents double-counting

**The Bayesian update:**
```
P_post = (LR × P_prior) / (LR × P_prior + (1 − P_prior))
```

Where LR = likelihood ratio for the evidence source type (from ontology).

**Per DP05:** `t` is measured from `last_confirmed_at`, not from edge creation date. When a new confirming signal arrives, `last_confirmed_at` is reset to the current timestamp and the decay clock restarts from zero.

**Per AR18b:** When a feed failure is detected, the decay clock is **frozen** — `t` stops incrementing. Decaying on missing data would incorrectly treat feed failure as signal absence.

**Per AR57:** When signals conflict, run the three-stage conflict resolution protocol:
1. Check if signals address the same causal mechanism (if not, no conflict)
2. Apply adversarial scoring: each signal scores the other's evidence quality
3. If score difference > threshold → ACTIVE for the stronger signal; if too close → CONTESTED

```python
"""
Bayesian edge weight calculation.

All formula implementations must match the specification exactly.
Do not approximate. Do not simplify. If the formula produces unexpected
results, fix the inputs — do not adjust the formula.

Per DP04: decay constants are calibrated to economic half-life, not arbitrary.
Per DP05: t measured from last_confirmed_at — resets on confirmation.
Per AR18b: decay clock frozen during feed failures.
Per AR57: conflict resolution is deterministic, bounded, and logged.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
import math
from typing import Optional

@dataclass 
class EdgeState:
    """
    Complete state of a causal graph edge.
    Per AR55: every edge must carry all of these fields.
    """
    # Identity
    edge_id: str
    source_node_id: str
    target_node_id: str
    edge_type: str                    # from ontology
    ontology_version: str

    # Probabilistic state
    p_prior: float                    # before current update
    p_posterior: float                # after current update
    likelihood_ratio: float           # LR used in last update

    # Magnitude
    magnitude_base: float             # signed economic impact
    magnitude_ci_width: float         # 95% CI width
    magnitude_adjusted: float         # = magnitude_base * (1 - ci_width/2)

    # Temporal
    created_at: str                   # ISO8601 UTC
    last_confirmed_at: str            # ISO8601 UTC — decay clock base
    decay_class: str                  # from ontology
    half_life_days: float             # from ontology decay class
    clock_frozen: bool = False        # True during feed failure per AR18b

    # Correlation
    rho_corr: float = 0.0             # correlation penalty across evidence sources

    # Classification
    narrative_sensitive: bool = True
    status: str = "ACTIVE"            # ACTIVE | CONTESTED | RETIRED
    contested_type: Optional[str] = None  # Type A | Type B — per AR61, AR61b

    # Evidence trail
    evidence_source_urls: list[str] = field(default_factory=list)
    extraction_event_ids: list[str] = field(default_factory=list)

    @property
    def t_days(self) -> float:
        """Days since last_confirmed_at. Frozen if clock_frozen."""
        if self.clock_frozen:
            return self._frozen_t
        now = datetime.now(timezone.utc)
        confirmed = datetime.fromisoformat(self.last_confirmed_at)
        return (now - confirmed).total_seconds() / 86400.0

    @property
    def decay_factor(self) -> float:
        """exp(−λ·t) where λ = ln(2) / half_life_days"""
        lambda_ = math.log(2) / self.half_life_days
        return math.exp(-lambda_ * self.t_days)

    @property
    def wt(self) -> float:
        """
        The edge weight: Wt = P_post × M_adj × decay × (1 − ρ)
        This is the value that enters the alpha vector.
        """
        return (
            self.p_posterior
            * self.magnitude_adjusted
            * self.decay_factor
            * (1.0 - self.rho_corr)
        )


def bayesian_update(p_prior: float, likelihood_ratio: float) -> float:
    """
    P_post = (LR × P_prior) / (LR × P_prior + (1 − P_prior))
    
    Returns the posterior probability after observing evidence with
    the given likelihood ratio. LR > 1 means evidence is more likely
    under H1 (relationship is real) than H0 (relationship is not real).
    """
    numerator = likelihood_ratio * p_prior
    return numerator / (numerator + (1.0 - p_prior))


def compute_correlation_penalty(evidence_source_types: list[str]) -> float:
    """
    Per (1 − ρ_corr): compute the correlation penalty across evidence sources.
    Sources that measure the same underlying phenomenon should not be treated
    as independent confirmation. Example: two wire services reporting the same
    Reuters story carry high correlation. AIS data and a wire report carry low
    correlation — genuinely independent.

    Returns ρ_corr in [0, 1]. A value of 0 means fully independent sources.
    A value of 0.8 means 80% of the evidence is correlated and only 20%
    is genuinely independent information.
    """
    # Implement correlation matrix between source type pairs
    # Wire services: ρ ≈ 0.75 with each other (same news, different outlets)
    # AIS + wire: ρ ≈ 0.15 (independent physical measurement)
    # Macro release + wire: ρ ≈ 0.40 (macro data drives the wire story)
    ...
```

---

## PART 5: THE OPTIMIZER

### `pillar3_execution/optimizer.py`

Per **AR59** and **AR60**, the optimizer must solve for all positions simultaneously and transaction costs must be an explicit term in the objective. Use scipy SLSQP for Phase 1. The interface must accept the same inputs that a production Gurobi solver would accept.

**The objective function:**
```
maximize: w^T μ_adj − (λ/2) w^T Σ w − c‖Δw‖₁
```

Where:
- `μ_adj` = alpha vector from Pillar II
- `Σ` = covariance matrix (use rolling 60-day returns for Phase 1)
- `λ` = risk aversion parameter (from mandate config)
- `c` = transaction cost coefficient
- `Δw` = w − w_prior (turnover)

Cardinality constraint `‖w‖₀ ≤ K` cannot be solved directly by SLSQP. Implement a two-stage approach: solve without cardinality, then trim to K largest positions and re-solve. Flag this as a known limitation — the production Gurobi implementation solves the true MIQP.

Per **AR62**: every solve must be logged to the event bus with the full alpha vector version, constraint set, solve status, solve time, objective value, and the binding constraints.

---

## PART 6: TESTS — THE IRAN CASE STUDY

### `tests/test_iran_case.py`

The Iran case study is the primary validation fixture for the entire system. Implement end-to-end tests that reproduce the key system behaviours from Day 0 to Day 29 of the Iran conflict case.

**Required test cases:**

```python
"""
Iran case study validation tests.
These tests use labelled fixtures from tests/fixtures/iran_newsflow.json
and iran_market_data.json to validate that the system produces the
correct outputs at key moments in the case.

Per AR37: before deployment, positive IC must be demonstrated on held-out data.
Per AR39: event log replay must produce identical signals to live computation.
These tests are the automated verification of those requirements.
"""

class TestIranCaseStudy:

    def test_d0_novel_event_detection(self):
        """
        Day 0 00:14 UTC: US-Israel strikes confirmed via Reuters.
        The system must classify this as NOVEL (novelty_score > 0.8).
        The system must extract CONSTRAINS_SUPPLY_OF edge from
        Hormuz_Closure → Gulf_Refined_Products within 30 seconds of ingestion.
        The initial P_raw must be between 0.55 and 0.80 for a primary wire source.
        """
        ...

    def test_d2_ais_bayesian_update(self):
        """
        Day 2: AIS data shows zero tankers transiting.
        AIS has LR = 8.0 (from ontology).
        Starting from P_prior = 0.68, the update must produce:
        P_post = (8.0 × 0.68) / (8.0 × 0.68 + 0.32) = 0.944
        This must be computed exactly — not approximately.
        """
        p_prior = 0.68
        lr = 8.0
        p_post = bayesian_update(p_prior, lr)
        assert abs(p_post - 0.944) < 0.001

    def test_d7_infrastructure_edge_decay_class(self):
        """
        Day 7: Ras Tanura drone strike creates INFRASTRUCTURE_DAMAGE_TO edge.
        The edge must receive decay_class = INFRASTRUCTURE_DAMAGE.
        The half-life must be 1825 days (5 years), not the supply flow 14 days.
        The decay factor at t=22 days must be exp(-ln(2)/1825 * 22) ≈ 0.9917.
        """
        ...

    def test_d23_trump_post_no_action(self):
        """
        Day 23: Trump Truth Social post drives Brent paper -11%.
        The system must:
        1. Classify the post as narrative_sensitive = True
        2. Assign novelty_score < 0.3 (4th similar pattern)
        3. NOT update the CONSTRAINS_SUPPLY_OF edges (physical, narrative-insensitive)
        4. NOT update the gasoil or jet crack edges (physical)
        5. The Brent CONTESTED edge may receive a small update (it IS narrative-sensitive)
        Physical edges must not move on narrative signals. This is DP07.
        """
        ...

    def test_infrastructure_edge_immune_to_ceasefire(self):
        """
        Day 40: Ceasefire announced.
        The Ras Laffan INFRASTRUCTURE_DAMAGE_TO edge must NOT reset its decay clock.
        The ontology specifies ceasefire_announced as a FREEZE trigger, not a reset trigger.
        The decay factor must continue from where it was before the ceasefire.
        This is the hardest invariant to maintain and the most important.
        """
        ...

    def test_contested_type_b_options_routing(self):
        """
        Brent paper meets Type B CONTESTED criteria per AR61b:
        - Active CONTESTED flag
        - Both modal outcomes have P > 0.25
        - Bimodal distribution (ceasefire ~$75, escalation $130+)
        - Resolution timeline exists (Polymarket)
        - Spread > $30 between modes
        The system must route this to options expression, not linear weight reduction.
        """
        ...

    def test_stagflation_regime_overlays_activate(self):
        """
        Day 9: STAGFLATION_RISK regime confirmed.
        Per AR58b and AR58c: overlay positions must activate immediately.
        The event log must contain REGIME_OVERLAY_ACTIVATED events for:
        - equity_index_short at 5% delta NAV
        - equity_vol_long at 2% vega NAV
        These must appear WITHOUT any causal chain producing them.
        They are properties of the regime, not of any edge.
        """
        ...

    def test_point_in_time_reconstruction(self):
        """
        Per AR22b: the event log must support exact point-in-time reconstruction.
        Run the Iran case to Day 15. Record the graph state.
        Reconstruct the graph state at Day 10 from the event log.
        The reconstructed state at Day 10 must not include any events from Day 11-15.
        The reconstructed state must be identical to what the live system held at Day 10.
        """
        ...
```

---

## PART 7: VIEW DASHBOARD

### `governance/view_dashboard.py` and `api/main.py`

Per **BR19**, **BR20**, and **BR13**, the system must produce a human-readable structured view dashboard. Every view must be fully traceable to its source edges and evidence (**BR02**).

Implement a FastAPI endpoint at `GET /views` that returns:

```json
{
  "generated_at": "2026-03-29T17:30:00Z",
  "regime": "STAGFLATION_RISK",
  "regime_confidence": 0.84,
  "active_views": [
    {
      "view_id": "view_vlo_long_2026-03-01",
      "asset": "VLO",
      "direction": "LONG",
      "conviction": "HIGH",
      "alpha_contribution": 0.341,
      "position_weight_pct": 9.0,
      "narrative_sensitive": false,
      "supporting_edges": [
        {
          "edge_id": "edge_hormuz_gasoil_crack",
          "edge_type": "CONSTRAINS_SUPPLY_OF",
          "wt": 0.063,
          "p_posterior": 0.944,
          "decay_factor": 0.835,
          "t_days": 15.0,
          "last_confirmed_at": "2026-03-15T14:00:00Z",
          "source_urls": ["https://ceraweek.com/..."]
        }
      ],
      "causal_chain_text": "Hormuz closure constrains Gulf refined products → gasoil crack widens → refiner margins expand → VLO earnings uplift",
      "created_at": "2026-03-01T07:30:00Z",
      "last_updated_at": "2026-03-29T17:30:00Z"
    }
  ],
  "contested_views": [...],
  "conflicts": [...],
  "regime_overlays": [...]
}
```

Also implement `GET /graph/state` returning the full NetworkX graph as a JSON node-link structure, and `GET /graph/reconstruct?timestamp=ISO8601` for point-in-time reconstruction.

---

## IMPLEMENTATION SEQUENCE

Follow the build sequence from **Section 10.1** of the Requirements document:

**Week 1–2:**
1. Implement `event_bus.py` with SQLite WAL. Write `test_event_bus.py` — verify append-only, verify replay, verify point-in-time reconstruction.
2. Implement `ontology.py` loader. Write `test_ontology.py` — verify that code attempting to use an undefined edge type raises `OntologyViolationError`.
3. Implement `decay.py` with all five decay classes. Write `test_decay.py` — verify the infrastructure freeze-on-ceasefire invariant with a direct unit test.

**Week 3–4:**
4. Implement `agent_a_newsflow.py` using the Claude API. Write `test_iran_case.py::test_d0_novel_event_detection` using the fixture. Do not proceed until hallucination rate on the fixture set is below 5%.
5. Implement `bayesian_update.py`. Write `test_iran_case.py::test_d2_ais_bayesian_update` — this test must pass exactly, not approximately.
6. Implement `graph_store.py` and `conflict_resolution.py`. Write the CONTESTED tests.

**Week 5–6:**
7. Implement `regime_classifier.py`. Write `test_iran_case.py::test_stagflation_regime_overlays_activate`. The regime classifier must be independent of the graph store — validate this with an isolation test.
8. Implement `alpha_vector.py` and `optimizer.py`. Write the optimizer tests.
9. Implement the view dashboard and FastAPI endpoints.
10. Run `test_iran_case.py::test_point_in_time_reconstruction`. This is the system integration test.

---

## WHAT NOT TO BUILD

The following are explicitly out of scope for this Phase 1 implementation. Do not build them, and do not make architectural decisions that would complicate their future addition:

- **Agent B (market data):** Stub with a fixture loader. The interface must accept the same schema as real market data.
- **Agent C (macro sub-components):** Stub. The sub-component extraction logic is the most complex part of Agent C and requires a dedicated implementation sprint.
- **Agent D (game theory):** Stub. The game tree computation is a separate module.
- **Agent E (positioning and flow):** Stub with CFTC fixture data.
- **Multi-tier storage:** Use SQLite for all storage. Design the interfaces so that Tier 1 (Neo4j), Tier 2 (Iceberg), and Tier 3 (object storage) can be swapped in without changing Pillar II or III code.
- **Production LR calibration:** Use the initial LR values from the ontology. The calibration cycle requires live prediction-outcome data and cannot be implemented until the system has been running for several months.
- **MIQP cardinality:** Use the two-stage approximation described above. Note the limitation explicitly in the solver log.
- **Vendor data feeds:** All external data ingestion uses fixtures or free-tier APIs. The ingestion adapter interfaces must be identical to what the production feeds would use.

---

## DEFINITION OF DONE

The Phase 1 implementation is complete when:

1. `pytest tests/` passes with zero failures including `test_iran_case.py`
2. `test_d2_ais_bayesian_update` produces P_post = 0.944 exactly (within 0.001)
3. `test_infrastructure_edge_immune_to_ceasefire` passes — the Ras Laffan edge does not reset on a ceasefire event
4. `test_point_in_time_reconstruction` passes — the Day 10 graph state reconstructed from the event log is identical to the live Day 10 state
5. `test_stagflation_regime_overlays_activate` passes — overlays appear without a causal chain
6. `GET /views` returns a fully traceable response in < 200ms
7. Attempting to use an edge type not in `ontology_v1.yaml` raises `OntologyViolationError` before any graph operation executes
8. The event log contains zero DELETE or UPDATE statements — verified by a schema-level trigger test
9. Running `scripts/run_iran_case.py` produces the Day 29 portfolio (VLO 9%, DAL short 12%, ICE gasoil crack 6%, EU utilities 14%) within ±2% of each weight

These tests are the automated implementation of the pre-deployment validation gates in **Section 6.2 (AR37–AR40)** of the Requirements document, adapted for the Phase 1 scope.
