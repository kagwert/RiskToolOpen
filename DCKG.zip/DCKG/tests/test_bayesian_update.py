"""
Tests for Bayesian edge weight calculation.
Per DP04, DP05, AR18b.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import math
from datetime import datetime, timezone, timedelta

from pillar2_graph.bayesian_update import (
    bayesian_update, compute_magnitude_adjusted, compute_correlation_penalty,
    EdgeState
)
from pillar2_graph.decay import DecayClock


class TestBayesianUpdateFormula:
    def test_d2_ais_exact(self):
        """The critical test: P_post = 0.944 from p_prior=0.68, LR=8.0."""
        p_prior = 0.68
        lr = 8.0
        p_post = bayesian_update(p_prior, lr)
        assert abs(p_post - 0.944) < 0.001

    def test_high_lr_raises_probability(self):
        p_post = bayesian_update(0.5, 10.0)
        assert p_post > 0.9

    def test_lr_one_no_update(self):
        """LR=1 means no new information; posterior equals prior."""
        p_prior = 0.6
        p_post = bayesian_update(p_prior, 1.0)
        assert abs(p_post - p_prior) < 0.001

    def test_low_lr_lowers_probability(self):
        """LR < 1 means evidence against the hypothesis."""
        p_post = bayesian_update(0.6, 0.2)
        assert p_post < 0.6

    def test_formula_structure(self):
        """Verify formula: (LR * P) / (LR * P + (1-P))"""
        p, lr = 0.4, 5.0
        expected = (lr * p) / (lr * p + (1 - p))
        assert abs(bayesian_update(p, lr) - expected) < 1e-10


class TestMagnitudeAdjustment:
    def test_ci_width_reduces_magnitude(self):
        """M_adj = M_base * (1 - ci_width/2)"""
        m_adj = compute_magnitude_adjusted(-0.30, 0.40)
        expected = -0.30 * (1 - 0.40 / 2)
        assert abs(m_adj - expected) < 1e-10

    def test_zero_ci_width_no_adjustment(self):
        m_adj = compute_magnitude_adjusted(-0.25, 0.0)
        assert abs(m_adj - (-0.25)) < 1e-10

    def test_positive_magnitude_adjusted(self):
        m_adj = compute_magnitude_adjusted(0.15, 0.20)
        assert m_adj > 0
        assert m_adj < 0.15


class TestCorrelationPenalty:
    def test_single_source_no_penalty(self):
        rho = compute_correlation_penalty(["primary_wire_service"])
        assert rho == 0.0

    def test_two_wire_services_high_correlation(self):
        rho = compute_correlation_penalty(["primary_wire_service", "primary_wire_service"])
        assert rho > 0.5

    def test_ais_plus_wire_low_correlation(self):
        rho = compute_correlation_penalty(["primary_wire_service", "ais_vessel_tracking"])
        assert rho < 0.3

    def test_empty_sources_no_penalty(self):
        rho = compute_correlation_penalty([])
        assert rho == 0.0


class TestEdgeStateWt:
    def test_wt_formula(self):
        """Wt = P_post * M_adj * decay * (1 - rho)"""
        clock = DecayClock(
            decay_class="SUPPLY_FLOW",
            last_confirmed_at=datetime.now(timezone.utc),
            created_at=datetime.now(timezone.utc),
        )
        edge = EdgeState(
            edge_id="e1",
            source_node_id="src",
            target_node_id="tgt",
            edge_type="CONSTRAINS_SUPPLY_OF",
            ontology_version="1.0",
            p_prior=0.5,
            p_posterior=0.8,
            likelihood_ratio=4.0,
            magnitude_base=-0.3,
            magnitude_ci_width=0.2,
            magnitude_adjusted=-0.3 * (1 - 0.2/2),
            decay_clock=clock,
            rho_corr=0.0,
        )
        # At t=0, decay=1.0, rho=0.0
        expected_wt = 0.8 * (-0.3 * 0.9) * 1.0 * 1.0
        assert abs(edge.wt - expected_wt) < 0.001

    def test_wt_negative_for_supply_constraint(self):
        """Supply constraints on non-refiner assets should produce negative Wt."""
        clock = DecayClock(
            decay_class="SUPPLY_FLOW",
            last_confirmed_at=datetime.now(timezone.utc),
            created_at=datetime.now(timezone.utc),
        )
        edge = EdgeState(
            edge_id="e2",
            source_node_id="src",
            target_node_id="tgt",
            edge_type="CONSTRAINS_SUPPLY_OF",
            ontology_version="1.0",
            p_prior=0.5,
            p_posterior=0.7,
            likelihood_ratio=4.5,
            magnitude_base=-0.20,
            magnitude_ci_width=0.30,
            magnitude_adjusted=compute_magnitude_adjusted(-0.20, 0.30),
            decay_clock=clock,
            rho_corr=0.0,
        )
        assert edge.wt < 0
