import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import json
from datetime import datetime, timezone, timedelta

from pillar1_perception.event_bus import EventBus, make_event
from pillar2_graph.graph_store import GraphStore
from pillar2_graph.regime_classifier import RegimeClassifier, RegimeDimensions
from pillar2_graph.alpha_vector import AlphaVectorBuilder
from pillar3_execution.optimizer import PortfolioOptimizer
from pillar3_execution.universe import get_asset_ids

FIXTURES_DIR = Path(__file__).parent / "fixtures"

@pytest.fixture
def event_bus(tmp_path):
    """Fresh event bus backed by a temp SQLite file."""
    db = tmp_path / "test_events.db"
    return EventBus(db_path=str(db))

@pytest.fixture
def graph_store():
    return GraphStore()

@pytest.fixture
def regime_classifier():
    return RegimeClassifier()

@pytest.fixture
def optimizer():
    return PortfolioOptimizer()

@pytest.fixture
def universe():
    return get_asset_ids()

@pytest.fixture
def iran_newsflow():
    with open(FIXTURES_DIR / "iran_newsflow.json") as f:
        return json.load(f)

@pytest.fixture
def iran_market_data():
    with open(FIXTURES_DIR / "iran_market_data.json") as f:
        return json.load(f)
