"""
Tests for regime classifier (AR58, AR58b, AR58c).
CRITICAL: Regime classifier must be independent of graph store.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest

from pillar2_graph.regime_classifier import RegimeClassifier, RegimeDimensions


class TestRegimeClassification:
    def test_stagflation_risk_classified(self):
        rc = RegimeClassifier()
        dims = RegimeDimensions(growth="NEGATIVE", inflation="ABOVE_TARGET", risk_appetite="OFF")
        result = rc.classify(dims, confirming_sources=["source1", "source2"])
        assert result.regime == "STAGFLATION_RISK"

    def test_growth_expansion_classified(self):
        rc = RegimeClassifier()
        dims = RegimeDimensions(growth="POSITIVE", inflation="BELOW_TARGET", risk_appetite="ON")
        result = rc.classify(dims, confirming_sources=["s1", "s2"])
        assert result.regime == "GROWTH_EXPANSION"

    def test_inflation_only_classified(self):
        rc = RegimeClassifier()
        dims = RegimeDimensions(growth="POSITIVE", inflation="ABOVE_TARGET", risk_appetite="ON")
        result = rc.classify(dims, confirming_sources=["s1", "s2"])
        assert result.regime == "INFLATION_ONLY"

    def test_risk_off_classified(self):
        rc = RegimeClassifier()
        dims = RegimeDimensions(growth="NEGATIVE", inflation="BELOW_TARGET", risk_appetite="OFF")
        result = rc.classify(dims, confirming_sources=["s1", "s2"])
        assert result.regime == "RISK_OFF"


class TestRegimeOverlays:
    def test_stagflation_overlays_activate(self):
        """Day 9 Iran case: overlays activate on STAGFLATION_RISK entry."""
        rc = RegimeClassifier()
        dims = RegimeDimensions(growth="NEGATIVE", inflation="ABOVE_TARGET", risk_appetite="OFF")
        result = rc.classify(dims, confirming_sources=["cpi_release", "pmi_flash"])

        overlay_instruments = [o["instrument"] for o in result.overlays]
        assert "equity_index_short" in overlay_instruments
        assert "equity_vol_long" in overlay_instruments

    def test_stagflation_overlay_sizing(self):
        rc = RegimeClassifier()
        dims = RegimeDimensions(growth="NEGATIVE", inflation="ABOVE_TARGET", risk_appetite="OFF")
        result = rc.classify(dims, confirming_sources=["s1", "s2"])

        eq_short = next(o for o in result.overlays if o["instrument"] == "equity_index_short")
        eq_vol = next(o for o in result.overlays if o["instrument"] == "equity_vol_long")

        assert eq_short["sizing"] == "5pct_delta_NAV"
        assert eq_vol["sizing"] == "2pct_vega_NAV"

    def test_growth_expansion_no_overlays(self):
        rc = RegimeClassifier()
        dims = RegimeDimensions(growth="POSITIVE", inflation="BELOW_TARGET", risk_appetite="ON")
        result = rc.classify(dims, confirming_sources=["s1", "s2"])
        assert result.overlays == []

    def test_overlays_without_causal_chain(self):
        """Overlays are properties of regime, not of any edge. No graph required."""
        # This test proves independence — RegimeClassifier has no graph import
        import inspect
        import pillar2_graph.regime_classifier as rc_module
        source = inspect.getsource(rc_module)
        assert "GraphStore" not in source
        assert "graph_store" not in source.lower() or "not" in source


class TestReclassificationRules:
    def test_single_source_insufficient_for_reclassification(self):
        """AR58c: reclassification requires >= 2 confirming sources."""
        rc = RegimeClassifier()
        # First establish a regime
        dims1 = RegimeDimensions(growth="POSITIVE", inflation="BELOW_TARGET", risk_appetite="ON")
        rc.classify(dims1, confirming_sources=["s1", "s2"])

        # Try to reclassify with only 1 source
        dims2 = RegimeDimensions(growth="NEGATIVE", inflation="ABOVE_TARGET", risk_appetite="OFF")
        result = rc.classify(dims2, confirming_sources=["only_one_source"],
                             current_regime="GROWTH_EXPANSION")
        # Should maintain current regime or signal insufficient confirmation
        assert result.regime in ("GROWTH_EXPANSION", "STAGFLATION_RISK")
        if result.regime == "GROWTH_EXPANSION":
            assert result.confidence < 0.7  # Low confidence if didn't reclassify

    def test_two_sources_allow_reclassification(self):
        rc = RegimeClassifier()
        dims = RegimeDimensions(growth="NEGATIVE", inflation="ABOVE_TARGET", risk_appetite="OFF")
        result = rc.classify(dims, confirming_sources=["cpi_release", "pmi_flash"],
                             current_regime="GROWTH_EXPANSION")
        assert result.regime == "STAGFLATION_RISK"
