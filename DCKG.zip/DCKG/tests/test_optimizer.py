"""
Tests for portfolio optimizer (AR59, AR60, AR62).
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import numpy as np

from pillar3_execution.optimizer import PortfolioOptimizer
from pillar3_execution.universe import get_asset_ids


@pytest.fixture
def optimizer():
    return PortfolioOptimizer()

@pytest.fixture
def simple_universe():
    return ["VLO", "DAL", "ICE_GASOIL", "EU_UTILITIES"]


class TestOptimizerSolve:
    def test_solve_returns_weights(self, optimizer, simple_universe):
        n = len(simple_universe)
        alpha = np.array([0.2, -0.1, 0.15, 0.12])
        cov = np.eye(n) * 0.04
        result = optimizer.solve(alpha, cov, simple_universe)
        assert result["solve_status"] in ("optimal", "failed")
        if result["solve_status"] == "optimal":
            assert isinstance(result["weights"], dict)

    def test_weights_sum_within_net_exposure_bounds(self, optimizer, simple_universe):
        n = len(simple_universe)
        alpha = np.array([0.3, -0.2, 0.2, 0.15])
        cov = np.eye(n) * 0.04
        result = optimizer.solve(alpha, cov, simple_universe)
        if result["solve_status"] == "optimal":
            weights = result["weights"]
            net = sum(weights.values())
            assert -0.25 <= net <= 1.25  # within mandate bounds (with tolerance)

    def test_no_position_exceeds_long_max(self, optimizer, simple_universe):
        n = len(simple_universe)
        alpha = np.array([1.0, 1.0, 1.0, 1.0])  # very strong alpha
        cov = np.eye(n) * 0.04
        result = optimizer.solve(alpha, cov, simple_universe)
        if result["solve_status"] == "optimal":
            for w in result["weights"].values():
                assert w <= 0.15 + 1e-4  # mandate long max

    def test_no_position_exceeds_short_max(self, optimizer, simple_universe):
        n = len(simple_universe)
        alpha = np.array([-1.0, -1.0, -1.0, -1.0])  # very negative alpha
        cov = np.eye(n) * 0.04
        result = optimizer.solve(alpha, cov, simple_universe)
        if result["solve_status"] == "optimal":
            for w in result["weights"].values():
                assert w >= -0.10 - 1e-4  # mandate short max

    def test_solve_time_logged(self, optimizer, simple_universe):
        n = len(simple_universe)
        alpha = np.array([0.1, -0.05, 0.08, 0.06])
        cov = np.eye(n) * 0.04
        result = optimizer.solve(alpha, cov, simple_universe)
        assert result["solve_time_ms"] is not None
        assert result["solve_time_ms"] >= 0

    def test_positive_alpha_produces_long(self, optimizer):
        universe = ["VLO"]
        alpha = np.array([0.5])
        cov = np.array([[0.04]])
        result = optimizer.solve(alpha, cov, universe)
        if result["solve_status"] == "optimal":
            w = result["weights"].get("VLO", 0.0)
            assert w > 0

    def test_negative_alpha_produces_short(self, optimizer):
        universe = ["DAL"]
        alpha = np.array([-0.5])
        cov = np.array([[0.04]])
        result = optimizer.solve(alpha, cov, universe)
        if result["solve_status"] == "optimal":
            w = result["weights"].get("DAL", 0.0)
            assert w < 0

    def test_cardinality_approximation_flag(self, optimizer):
        full_universe = get_asset_ids()
        n = len(full_universe)
        alpha = np.random.randn(n) * 0.1
        cov = np.eye(n) * 0.04
        result = optimizer.solve(alpha, cov, full_universe)
        # With 10 assets and max_positions=20, no trimming needed
        assert "cardinality_approximated" in result

    def test_transaction_costs_reduce_turnover(self, optimizer, simple_universe):
        n = len(simple_universe)
        alpha = np.array([0.1, -0.05, 0.08, 0.04])
        cov = np.eye(n) * 0.04
        prior = {"VLO": 0.08, "DAL": -0.04, "ICE_GASOIL": 0.06, "EU_UTILITIES": 0.03}
        result = optimizer.solve(alpha, cov, simple_universe, prior_weights=prior)
        if result["solve_status"] == "optimal":
            assert result["weights"] is not None
