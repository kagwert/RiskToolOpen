"""
Iran case study end-to-end validation tests.
Per AR37, AR39. These tests use labelled fixtures.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import json
import math
from datetime import datetime, timezone, timedelta

from pillar1_perception.event_bus import EventBus, make_event
from pillar2_graph.graph_store import GraphStore
from pillar2_graph.bayesian_update import bayesian_update, EdgeState, compute_magnitude_adjusted
from pillar2_graph.decay import DecayClock
from pillar2_graph.regime_classifier import RegimeClassifier, RegimeDimensions
from pillar2_graph.alpha_vector import AlphaVectorBuilder
from pillar3_execution.optimizer import PortfolioOptimizer
from pillar3_execution.universe import get_asset_ids

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture
def iran_fixtures():
    with open(FIXTURES_DIR / "iran_newsflow.json") as f:
        return json.load(f)


@pytest.fixture
def fresh_system(tmp_path):
    bus = EventBus(db_path=str(tmp_path / "iran_test.db"))
    graph = GraphStore()
    rc = RegimeClassifier()
    return bus, graph, rc


class TestIranCaseStudy:

    def test_d0_novel_event_detection(self, iran_fixtures):
        """Day 0: Strike classified as novel, CONSTRAINS_SUPPLY_OF extracted."""
        from pillar1_perception.agent_a_newsflow import AgentANewsflow
        agent = AgentANewsflow()

        d0_event = next(e for e in iran_fixtures["events"] if e["event_label"] == "D0_INITIAL_STRIKE")
        extractions = agent._mock_extract(
            d0_event["raw_text"],
            source_url=d0_event["source_url"],
            pub_ts="2026-03-01T00:14:00Z",
            receipt_ts="2026-03-01T00:14:05Z",
        )

        # Must find at least one CONSTRAINS_SUPPLY_OF
        supply_constraints = [e for e in extractions if e["edge_type"] == "CONSTRAINS_SUPPLY_OF"]
        assert len(supply_constraints) >= 1

        # p_raw must be in expected range
        for ext in supply_constraints:
            p = ext["p_raw"]
            d0_expected = d0_event["expected_extractions"][0]
            assert d0_expected["p_raw_min"] <= p <= d0_expected["p_raw_max"]

    def test_d2_ais_bayesian_update(self):
        """
        Day 2: AIS data shows zero tankers.
        LR = 8.0, P_prior = 0.68 -> P_post must be 0.944 +/- 0.001.
        This is the critical numerical test.
        """
        p_prior = 0.68
        lr = 8.0
        p_post = bayesian_update(p_prior, lr)
        assert abs(p_post - 0.944) < 0.001, f"P_post={p_post:.6f}, expected 0.944"

    def test_d7_infrastructure_edge_decay_class(self, fresh_system):
        """Day 7: Ras Tanura strike creates INFRASTRUCTURE_DAMAGE_TO with 1825-day half-life."""
        bus, graph, rc = fresh_system

        graph.add_node("Ras_Tanura_Strike", "GEOPOLITICAL_EVENT")
        graph.add_node("Saudi_Refinery_Capacity", "PHYSICAL_OBSERVABLE")

        edge = graph.add_edge(
            source_node_id="Ras_Tanura_Strike",
            target_node_id="Saudi_Refinery_Capacity",
            edge_type="INFRASTRUCTURE_DAMAGE_TO",
            p_prior=0.50, likelihood_ratio=5.0,
            magnitude_base=-0.40, magnitude_ci_width=0.25,
            narrative_sensitive=False,
        )

        assert edge.decay_clock.decay_class == "INFRASTRUCTURE_DAMAGE"
        assert edge.decay_clock.get_t_days() < 0.01  # just created

        # At t=22 days, decay factor should be ~0.9917
        old_clock = DecayClock(
            decay_class="INFRASTRUCTURE_DAMAGE",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=22),
            created_at=datetime.now(timezone.utc) - timedelta(days=22),
        )
        expected = math.exp(-math.log(2) / 1825 * 22)
        assert abs(old_clock.get_decay_factor() - expected) < 0.001
        assert expected > 0.99

    def test_d23_trump_post_no_action(self, fresh_system):
        """
        Day 23: Trump Truth Social post must NOT update physical edges.
        Per DP07: narrative signals cannot update narrative_sensitive=False edges.
        """
        bus, graph, rc = fresh_system

        graph.add_node("US_Israel_Iran_Strike", "GEOPOLITICAL_EVENT")
        graph.add_node("ICE_GASOIL", "TRADEABLE_ASSET")

        # Create a physical edge (narrative_sensitive=False)
        physical_edge = graph.add_edge(
            source_node_id="US_Israel_Iran_Strike",
            target_node_id="ICE_GASOIL",
            edge_type="CONSTRAINS_SUPPLY_OF",
            p_prior=0.68, likelihood_ratio=8.0,
            magnitude_base=-0.25, magnitude_ci_width=0.30,
            narrative_sensitive=False,
        )

        p_before = physical_edge.p_posterior

        # Trump post: narrative_sensitive=True signal should NOT update physical edges
        from pillar1_perception.agent_a_newsflow import AgentANewsflow
        agent = AgentANewsflow()
        trump_text = "Great progress on Iran peace deal. Huge ceasefire coming very soon. Oil prices will come down."
        extractions = agent._mock_extract(trump_text, source_url="https://truthsocial.com/trump",
                                           pub_ts="2026-03-24T15:45:00Z",
                                           receipt_ts="2026-03-24T15:45:05Z")

        # Any narrative extraction should be narrative_sensitive=True
        for ext in extractions:
            if ext.get("narrative_sensitive") is False:
                # Physical edges should not be updated by narrative signals
                pass

        # The physical edge p_posterior should not have changed
        current_edge = graph.get_edge(physical_edge.edge_id)
        assert current_edge.p_posterior == p_before

    def test_infrastructure_edge_immune_to_ceasefire(self, fresh_system):
        """
        Day 40: Ceasefire announced.
        Infrastructure edge clock must FREEZE, not RESET.
        This is the most important invariant in the system.
        """
        bus, graph, rc = fresh_system

        graph.add_node("Ras_Tanura_Strike", "GEOPOLITICAL_EVENT")
        graph.add_node("Saudi_Refinery_Capacity", "PHYSICAL_OBSERVABLE")

        # Create edge and manually age it to 15 days
        edge = graph.add_edge(
            source_node_id="Ras_Tanura_Strike",
            target_node_id="Saudi_Refinery_Capacity",
            edge_type="INFRASTRUCTURE_DAMAGE_TO",
            p_prior=0.50, likelihood_ratio=5.0,
            magnitude_base=-0.40, magnitude_ci_width=0.25,
            narrative_sensitive=False,
        )

        # Age the clock artificially
        edge.decay_clock.last_confirmed_at = datetime.now(timezone.utc) - timedelta(days=15)
        t_before_ceasefire = edge.decay_clock.get_t_days()
        assert t_before_ceasefire > 14

        # Ceasefire: must FREEZE (not reset)
        graph.freeze_edge_clock(edge.edge_id, "ceasefire_announced")

        updated_edge = graph.get_edge(edge.edge_id)

        # Clock must be frozen
        assert updated_edge.decay_clock.frozen is True

        # t must NOT have reset to 0
        t_after_ceasefire = updated_edge.decay_clock.get_t_days()
        assert t_after_ceasefire > 14, f"t was {t_after_ceasefire:.2f} -- should be > 14 days (not reset)"

        # decay factor should be well above 0.5 (we're only 15 days into a 1825-day half-life)
        assert updated_edge.decay_clock.get_decay_factor() > 0.99

    def test_stagflation_regime_overlays_activate(self, fresh_system, iran_fixtures):
        """
        Day 9: STAGFLATION_RISK regime confirmed.
        Overlays must activate WITHOUT any causal chain producing them.
        """
        bus, graph, rc = fresh_system

        d9_event = next(e for e in iran_fixtures["events"] if e["event_label"] == "D9_STAGFLATION_REGIME")
        rt = d9_event["regime_trigger"]

        dims = RegimeDimensions(**rt["dimensions"])
        result = rc.classify(dims, confirming_sources=rt["confirming_sources"])

        assert result.regime == "STAGFLATION_RISK"

        overlay_instruments = [o["instrument"] for o in result.overlays]
        for expected_overlay in rt["expected_overlays"]:
            assert expected_overlay["instrument"] in overlay_instruments, \
                f"Expected overlay {expected_overlay['instrument']} not found"

        # Publish overlay events to bus
        for overlay in result.overlays:
            evt = make_event(
                event_type="REGIME_OVERLAY_ACTIVATED",
                source_component="regime_classifier",
                payload={"regime": result.regime, "overlay": overlay},
            )
            bus.publish(evt)

        # Verify overlays are in the event log
        overlay_events = list(bus.subscribe(["REGIME_OVERLAY_ACTIVATED"]))
        assert len(overlay_events) == len(result.overlays)

    def test_point_in_time_reconstruction(self, tmp_path):
        """
        Per AR22b: event log must support exact point-in-time reconstruction.
        Events published after cutoff must not appear in reconstruction.
        """
        import time
        bus = EventBus(db_path=str(tmp_path / "pit_test.db"))

        # Publish 4 events before cutoff (simulating Days 0-10)
        for i in range(4):
            evt = make_event("EDGE_CREATED", "test", {"day": i})
            bus.publish(evt)

        time.sleep(0.05)
        cutoff = datetime.now(timezone.utc).isoformat()
        time.sleep(0.05)

        # Publish 2 events after cutoff (Days 11-15)
        for i in range(4, 6):
            evt = make_event("REGIME_CLASSIFIED", "test", {"day": i})
            bus.publish(evt)

        # Reconstruct at cutoff
        events_at_cutoff = bus.reconstruct_at(cutoff)

        assert len(events_at_cutoff) == 4, f"Expected 4 events, got {len(events_at_cutoff)}"
        assert all(e.event_type == "EDGE_CREATED" for e in events_at_cutoff)

        # Total events should be 6
        all_events = bus.reconstruct_at("2099-01-01T00:00:00+00:00")
        assert len(all_events) == 6

    def test_contested_type_b_options_routing(self, fresh_system):
        """
        Brent paper with bimodal distribution should be classified CONTESTED Type B.
        Criteria: both P > 0.25, bimodal spread > $30, polymarket exists.
        """
        from pillar2_graph.conflict_resolution import resolve_conflict

        clock = DecayClock(
            decay_class="SUPPLY_FLOW",
            last_confirmed_at=datetime.now(timezone.utc),
            created_at=datetime.now(timezone.utc),
        )

        edge_ceasefire = EdgeState(
            edge_id="brent_ceasefire",
            source_node_id="Ceasefire_Signal",
            target_node_id="BRENT_CRUDE",
            edge_type="CONSTRAINS_SUPPLY_OF",
            ontology_version="1.0",
            p_prior=0.45,
            p_posterior=0.55,
            likelihood_ratio=3.0,
            magnitude_base=-0.30,  # ceasefire: oil goes down
            magnitude_ci_width=0.4,
            magnitude_adjusted=compute_magnitude_adjusted(-0.30, 0.4),
            decay_clock=clock,
            rho_corr=0.0,
            narrative_sensitive=True,
        )

        clock2 = DecayClock(
            decay_class="SUPPLY_FLOW",
            last_confirmed_at=datetime.now(timezone.utc),
            created_at=datetime.now(timezone.utc),
        )

        edge_escalation = EdgeState(
            edge_id="brent_escalation",
            source_node_id="Escalation_Signal",
            target_node_id="BRENT_CRUDE",
            edge_type="CONSTRAINS_SUPPLY_OF",
            ontology_version="1.0",
            p_prior=0.45,
            p_posterior=0.50,
            likelihood_ratio=3.0,
            magnitude_base=0.45,   # escalation: oil goes way up
            magnitude_ci_width=0.4,
            magnitude_adjusted=compute_magnitude_adjusted(0.45, 0.4),
            decay_clock=clock2,
            rho_corr=0.0,
            narrative_sensitive=False,
        )

        result = resolve_conflict(
            edge_ceasefire, edge_escalation,
            polymarket_resolution_exists=True,
            bimodal_spread=55.0  # $75 vs $130+
        )

        assert result.outcome == "CONTESTED_B", \
            f"Expected CONTESTED_B, got {result.outcome}"
