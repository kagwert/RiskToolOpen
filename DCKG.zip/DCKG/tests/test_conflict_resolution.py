"""
Tests for conflict resolution (AR57, AR61, AR61b).
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from datetime import datetime, timezone

from pillar2_graph.conflict_resolution import resolve_conflict, score_evidence_quality
from pillar2_graph.bayesian_update import EdgeState, compute_magnitude_adjusted
from pillar2_graph.decay import DecayClock


def make_edge(edge_id, edge_type, p_posterior, magnitude_base, narrative_sensitive,
              status="ACTIVE", rho_corr=0.0):
    clock = DecayClock(
        decay_class="SUPPLY_FLOW",
        last_confirmed_at=datetime.now(timezone.utc),
        created_at=datetime.now(timezone.utc),
    )
    return EdgeState(
        edge_id=edge_id,
        source_node_id="src",
        target_node_id="tgt",
        edge_type=edge_type,
        ontology_version="1.0",
        p_prior=0.5,
        p_posterior=p_posterior,
        likelihood_ratio=4.0,
        magnitude_base=magnitude_base,
        magnitude_ci_width=0.2,
        magnitude_adjusted=compute_magnitude_adjusted(magnitude_base, 0.2),
        decay_clock=clock,
        rho_corr=rho_corr,
        narrative_sensitive=narrative_sensitive,
        status=status,
    )


class TestConflictResolution:
    def test_different_targets_no_conflict(self):
        edge_a = make_edge("e1", "CONSTRAINS_SUPPLY_OF", 0.8, -0.3, False)
        edge_b = make_edge("e2", "ACCELERATES_DEMAND_FOR", 0.6, 0.2, True)
        edge_b.target_node_id = "different_target"
        result = resolve_conflict(edge_a, edge_b)
        assert result.outcome == "NO_CONFLICT"

    def test_strong_evidence_wins(self):
        edge_a = make_edge("e1", "CONSTRAINS_SUPPLY_OF", 0.95, -0.3, False)
        edge_b = make_edge("e2", "CONSTRAINS_SUPPLY_OF", 0.40, 0.1, True)
        result = resolve_conflict(edge_a, edge_b)
        assert result.outcome == "ACTIVE"
        assert result.winning_edge_id == "e1"

    def test_close_scores_produce_contested_a(self):
        """When evidence quality is too close to call, result is CONTESTED Type A."""
        edge_a = make_edge("e1", "CONSTRAINS_SUPPLY_OF", 0.70, -0.3, True)
        edge_b = make_edge("e2", "CONSTRAINS_SUPPLY_OF", 0.68, 0.2, True)
        result = resolve_conflict(edge_a, edge_b)
        assert result.outcome in ("CONTESTED_A", "ACTIVE")

    def test_contested_type_b_bimodal_routing(self):
        """Type B: both P > 0.25, bimodal spread > 30, polymarket exists."""
        edge_a = make_edge("e1", "CONSTRAINS_SUPPLY_OF", 0.60, -0.3, False)
        edge_b = make_edge("e2", "CONSTRAINS_SUPPLY_OF", 0.55, 0.2, False)
        result = resolve_conflict(
            edge_a, edge_b,
            polymarket_resolution_exists=True,
            bimodal_spread=35.0
        )
        assert result.outcome == "CONTESTED_B"

    def test_evidence_quality_score_range(self):
        edge = make_edge("e1", "CONSTRAINS_SUPPLY_OF", 0.9, -0.3, False)
        score = score_evidence_quality(edge)
        assert 0.0 <= score <= 1.0

    def test_hard_evidence_scores_higher_than_narrative(self):
        hard = make_edge("e1", "CONSTRAINS_SUPPLY_OF", 0.8, -0.3, False)
        soft = make_edge("e2", "CONSTRAINS_SUPPLY_OF", 0.8, -0.3, True)
        assert score_evidence_quality(hard) > score_evidence_quality(soft)
