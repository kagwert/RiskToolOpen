"""
Tests for decay clock logic.
Per DP04: decay constants calibrated to economic half-life.
Per DP05: t measured from last_confirmed_at.
Per AR18b: freeze on feed failure.
CRITICAL: Infrastructure damage clock FREEZES on ceasefire, does NOT reset.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import math
from datetime import datetime, timezone, timedelta

from pillar2_graph.decay import DecayClock, DECAY_CLASSES, get_half_life


class TestDecayFormula:
    def test_half_life_formula(self):
        """At t=half_life, decay factor should be exactly 0.5."""
        clock = DecayClock(
            decay_class="SUPPLY_FLOW",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=14),
            created_at=datetime.now(timezone.utc) - timedelta(days=14),
        )
        factor = clock.get_decay_factor()
        assert abs(factor - 0.5) < 0.01

    def test_zero_time_decay_factor_is_one(self):
        clock = DecayClock(
            decay_class="SUPPLY_FLOW",
            last_confirmed_at=datetime.now(timezone.utc),
            created_at=datetime.now(timezone.utc),
        )
        factor = clock.get_decay_factor()
        assert abs(factor - 1.0) < 0.01

    def test_infrastructure_damage_slow_decay(self):
        """1825-day half-life: at t=22 days, factor ≈ 0.9917."""
        clock = DecayClock(
            decay_class="INFRASTRUCTURE_DAMAGE",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=22),
            created_at=datetime.now(timezone.utc) - timedelta(days=22),
        )
        factor = clock.get_decay_factor()
        expected = math.exp(-math.log(2) / 1825 * 22)
        assert abs(factor - expected) < 0.001

    def test_liquidity_stress_fast_decay(self):
        """7-day half-life: at t=7 days, factor ≈ 0.5."""
        clock = DecayClock(
            decay_class="LIQUIDITY_STRESS",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=7),
            created_at=datetime.now(timezone.utc) - timedelta(days=7),
        )
        factor = clock.get_decay_factor()
        assert abs(factor - 0.5) < 0.02


class TestClockReset:
    def test_reset_restarts_t_from_zero(self):
        clock = DecayClock(
            decay_class="SUPPLY_FLOW",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=10),
            created_at=datetime.now(timezone.utc) - timedelta(days=10),
        )
        assert clock.get_t_days() > 9
        clock.reset()
        assert clock.get_t_days() < 0.01

    def test_reset_unfreezes_clock(self):
        clock = DecayClock(
            decay_class="SUPPLY_FLOW",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=5),
            created_at=datetime.now(timezone.utc) - timedelta(days=5),
        )
        clock.freeze()
        assert clock.frozen is True
        clock.reset()
        assert clock.frozen is False


class TestClockFreeze:
    def test_freeze_stops_t_incrementing(self):
        clock = DecayClock(
            decay_class="SUPPLY_FLOW",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=5),
            created_at=datetime.now(timezone.utc) - timedelta(days=5),
        )
        t_before = clock.get_t_days()
        clock.freeze()
        assert clock.frozen is True
        assert clock.frozen_t_days is not None
        # t should not change after freeze
        t_after = clock.get_t_days()
        assert abs(t_after - t_before) < 0.01

    def test_feed_failure_freezes_all_classes(self):
        for decay_class in DECAY_CLASSES:
            clock = DecayClock(
                decay_class=decay_class,
                last_confirmed_at=datetime.now(timezone.utc),
                created_at=datetime.now(timezone.utc),
            )
            result = clock.process_trigger("feed_failure")
            assert result == "frozen", f"feed_failure should freeze {decay_class}"
            assert clock.frozen is True


class TestInfrastructureCeasefireCritical:
    """
    The most important test in the system.
    INFRASTRUCTURE_DAMAGE ceasefire must FREEZE, not RESET.
    """

    def test_ceasefire_freezes_infrastructure_clock(self):
        clock = DecayClock(
            decay_class="INFRASTRUCTURE_DAMAGE",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=15),
            created_at=datetime.now(timezone.utc) - timedelta(days=15),
        )
        t_before_ceasefire = clock.get_t_days()
        assert t_before_ceasefire > 14

        result = clock.process_trigger("ceasefire_announced")

        assert result == "frozen", "ceasefire_announced must FREEZE, not reset"
        assert clock.frozen is True
        assert clock.frozen_t_days is not None
        assert clock.frozen_t_days > 14, "t must not have reset to 0"

    def test_diplomatic_agreement_freezes_infrastructure_clock(self):
        clock = DecayClock(
            decay_class="INFRASTRUCTURE_DAMAGE",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=10),
            created_at=datetime.now(timezone.utc) - timedelta(days=10),
        )
        result = clock.process_trigger("diplomatic_agreement")
        assert result == "frozen"
        assert clock.frozen is True
        assert clock.frozen_t_days > 9

    def test_only_engineering_verification_resets_infrastructure(self):
        clock = DecayClock(
            decay_class="INFRASTRUCTURE_DAMAGE",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=20),
            created_at=datetime.now(timezone.utc) - timedelta(days=20),
        )
        result = clock.process_trigger("engineering_verification_confirmed")
        assert result == "reset"
        assert clock.frozen is False
        assert clock.get_t_days() < 0.01

    def test_ceasefire_does_not_affect_supply_flow_clock(self):
        """Only INFRASTRUCTURE_DAMAGE has ceasefire as a freeze trigger."""
        clock = DecayClock(
            decay_class="SUPPLY_FLOW",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=5),
            created_at=datetime.now(timezone.utc) - timedelta(days=5),
        )
        result = clock.process_trigger("ceasefire_announced")
        assert result == "no_action", "ceasefire should not affect SUPPLY_FLOW clocks"
        assert clock.frozen is False

    def test_infrastructure_frozen_clock_value_preserved(self):
        """After freeze, t must remain at the frozen value, not at 0."""
        clock = DecayClock(
            decay_class="INFRASTRUCTURE_DAMAGE",
            last_confirmed_at=datetime.now(timezone.utc) - timedelta(days=40),
            created_at=datetime.now(timezone.utc) - timedelta(days=40),
        )
        t_at_ceasefire = clock.get_t_days()
        clock.process_trigger("ceasefire_announced")

        # t should equal the frozen value
        t_after = clock.get_t_days()
        assert abs(t_after - t_at_ceasefire) < 0.1

        # decay factor should match the frozen t
        expected_factor = math.exp(-math.log(2) / 1825 * t_at_ceasefire)
        assert abs(clock.get_decay_factor() - expected_factor) < 0.001
