"""
Tests for the event bus (append-only SQLite log).
Per AR22: append-only enforcement.
Per AR22b: point-in-time reconstruction.
Per AR64: mandatory field validation.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import sqlite3
from datetime import datetime, timezone, timedelta

from pillar1_perception.event_bus import EventBus, DCKGEvent, EVENT_TYPES, make_event


class TestAppendOnly:
    def test_publish_returns_event_id(self, event_bus):
        evt = make_event("CAUSAL_EXTRACTION", "test", {"data": "x"})
        event_id = event_bus.publish(evt)
        assert event_id is not None
        assert len(event_id) > 0

    def test_delete_raises_error(self, event_bus):
        evt = make_event("CAUSAL_EXTRACTION", "test", {"data": "x"})
        event_bus.publish(evt)
        # Direct DELETE must be blocked by trigger
        with pytest.raises(Exception):
            conn = sqlite3.connect(str(event_bus.db_path))
            conn.execute("DELETE FROM events WHERE 1=1")
            conn.commit()
            conn.close()

    def test_update_raises_error(self, event_bus):
        evt = make_event("CAUSAL_EXTRACTION", "test", {"data": "x"})
        event_bus.publish(evt)
        with pytest.raises(Exception):
            conn = sqlite3.connect(str(event_bus.db_path))
            conn.execute("UPDATE events SET source_component='hacked' WHERE 1=1")
            conn.commit()
            conn.close()

    def test_multiple_events_accumulate(self, event_bus):
        for i in range(5):
            evt = make_event("EDGE_CREATED", "test", {"i": i})
            event_bus.publish(evt)
        all_events = list(event_bus.subscribe(["EDGE_CREATED"]))
        assert len(all_events) == 5

    def test_invalid_event_type_rejected(self, event_bus):
        with pytest.raises(ValueError):
            evt = make_event("INVALID_TYPE_XYZ", "test", {})
            event_bus.publish(evt)

    def test_missing_mandatory_field_rejected(self, event_bus):
        evt = DCKGEvent(
            event_id="abc",
            event_type="CAUSAL_EXTRACTION",
            source_component="",  # empty - should fail
            receipt_timestamp="",
            publication_timestamp="",
            ontology_version="1.0",
            payload={},
        )
        with pytest.raises((ValueError, Exception)):
            event_bus.publish(evt)


class TestSubscribeAndReplay:
    def test_subscribe_returns_matching_events(self, event_bus):
        make_and_publish(event_bus, "EDGE_CREATED")
        make_and_publish(event_bus, "REGIME_CLASSIFIED")
        make_and_publish(event_bus, "EDGE_CREATED")

        events = list(event_bus.subscribe(["EDGE_CREATED"]))
        assert len(events) == 2
        assert all(e.event_type == "EDGE_CREATED" for e in events)

    def test_subscribe_multiple_types(self, event_bus):
        make_and_publish(event_bus, "EDGE_CREATED")
        make_and_publish(event_bus, "EDGE_UPDATED")
        make_and_publish(event_bus, "REGIME_CLASSIFIED")

        events = list(event_bus.subscribe(["EDGE_CREATED", "EDGE_UPDATED"]))
        assert len(events) == 2

    def test_subscribe_empty_bus_returns_nothing(self, event_bus):
        events = list(event_bus.subscribe(["EDGE_CREATED"]))
        assert events == []

    def test_subscribe_since_timestamp_replays(self, event_bus, tmp_path):
        # Create a bus with real timestamps
        bus = EventBus(db_path=str(tmp_path / "replay.db"))

        import time
        t_before = datetime.now(timezone.utc).isoformat()
        time.sleep(0.01)
        make_and_publish(bus, "EDGE_CREATED")
        make_and_publish(bus, "EDGE_UPDATED")
        time.sleep(0.01)
        t_after = datetime.now(timezone.utc).isoformat()
        make_and_publish(bus, "EDGE_RETIRED")

        events = list(bus.subscribe(["EDGE_CREATED", "EDGE_UPDATED", "EDGE_RETIRED"], since_timestamp=t_after))
        assert len(events) == 1
        assert events[0].event_type == "EDGE_RETIRED"


class TestPointInTimeReconstruction:
    def test_reconstruct_at_returns_subset(self, tmp_path):
        bus = EventBus(db_path=str(tmp_path / "pit.db"))

        import time
        make_and_publish(bus, "CAUSAL_EXTRACTION")
        make_and_publish(bus, "EDGE_CREATED")
        time.sleep(0.05)
        cutoff = datetime.now(timezone.utc).isoformat()
        time.sleep(0.05)
        make_and_publish(bus, "REGIME_CLASSIFIED")
        make_and_publish(bus, "PORTFOLIO_WEIGHTS_PUBLISHED")

        events = bus.reconstruct_at(cutoff)
        assert len(events) == 2
        assert all(e.event_type in ("CAUSAL_EXTRACTION", "EDGE_CREATED") for e in events)

    def test_reconstruct_future_returns_all(self, event_bus):
        make_and_publish(event_bus, "EDGE_CREATED")
        make_and_publish(event_bus, "EDGE_UPDATED")
        events = event_bus.reconstruct_at("2099-01-01T00:00:00+00:00")
        assert len(events) == 2

    def test_reconstruct_past_returns_empty(self, event_bus):
        make_and_publish(event_bus, "EDGE_CREATED")
        events = event_bus.reconstruct_at("2000-01-01T00:00:00+00:00")
        assert len(events) == 0


def make_and_publish(bus, event_type):
    evt = make_event(event_type, "test_component", {"test": True})
    bus.publish(evt)
    return evt
