"""
Tests for ontology loader and validator.
Per AR48c: code must not use undefined edge/node types.
Per AR48d: OntologyViolationError raised BEFORE any graph operation.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from governance.ontology import OntologyViolationError, get_ontology, load_ontology, reset_singleton


@pytest.fixture(autouse=True)
def reset_ontology():
    reset_singleton()
    yield
    reset_singleton()


class TestOntologyLoading:
    def test_loads_node_types(self):
        ont = get_ontology()
        assert "GEOPOLITICAL_EVENT" in ont.node_type_names
        assert "MACRO_INDICATOR" in ont.node_type_names
        assert "PHYSICAL_OBSERVABLE" in ont.node_type_names
        assert "TRADEABLE_ASSET" in ont.node_type_names

    def test_loads_edge_types(self):
        ont = get_ontology()
        assert "CONSTRAINS_SUPPLY_OF" in ont.edge_type_names
        assert "INFRASTRUCTURE_DAMAGE_TO" in ont.edge_type_names
        assert "POLICY_RISK_TO" in ont.edge_type_names
        assert len(ont.edge_type_names) <= 8  # AR48f: max 8 at initial deployment

    def test_loads_decay_classes(self):
        ont = get_ontology()
        half_life = ont.get_half_life("CONSTRAINS_SUPPLY_OF")
        assert half_life == 14

    def test_infrastructure_damage_half_life(self):
        ont = get_ontology()
        half_life = ont.get_half_life("INFRASTRUCTURE_DAMAGE_TO")
        assert half_life == 1825

    def test_policy_risk_is_regime_conditional(self):
        ont = get_ontology()
        assert ont.is_regime_conditional("POLICY_RISK_TO") is True

    def test_constrains_supply_not_regime_conditional(self):
        ont = get_ontology()
        assert ont.is_regime_conditional("CONSTRAINS_SUPPLY_OF") is False


class TestViolationErrors:
    def test_unknown_edge_type_raises(self):
        ont = get_ontology()
        with pytest.raises(OntologyViolationError):
            ont.validate_edge_type("MADE_UP_EDGE")

    def test_unknown_node_type_raises(self):
        ont = get_ontology()
        with pytest.raises(OntologyViolationError):
            ont.validate_node_type("MADE_UP_NODE")

    def test_invalid_edge_triple_raises(self):
        ont = get_ontology()
        # TRADEABLE_ASSET cannot be source of CONSTRAINS_SUPPLY_OF
        with pytest.raises(OntologyViolationError):
            ont.validate_edge("TRADEABLE_ASSET", "CONSTRAINS_SUPPLY_OF", "TRADEABLE_ASSET")

    def test_valid_edge_triple_passes(self):
        ont = get_ontology()
        # Should NOT raise
        ont.validate_edge("GEOPOLITICAL_EVENT", "CONSTRAINS_SUPPLY_OF", "TRADEABLE_ASSET")

    def test_valid_infrastructure_damage(self):
        ont = get_ontology()
        ont.validate_edge("GEOPOLITICAL_EVENT", "INFRASTRUCTURE_DAMAGE_TO", "PHYSICAL_OBSERVABLE")

    def test_graph_store_rejects_invalid_edge_type(self):
        """OntologyViolationError must be raised BEFORE any graph operation."""
        from pillar2_graph.graph_store import GraphStore
        g = GraphStore()
        g.add_node("A", "GEOPOLITICAL_EVENT")
        g.add_node("B", "TRADEABLE_ASSET")
        with pytest.raises(OntologyViolationError):
            g.add_edge("A", "B", "FAKE_EDGE_TYPE", 0.5, 4.0, -0.2, 0.3)
        # Graph must not have been modified
        assert len(g.get_all_edges()) == 0
