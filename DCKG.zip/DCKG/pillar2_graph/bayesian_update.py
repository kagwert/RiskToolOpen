"""
Bayesian edge weight calculation.
Per DP04, DP05, AR18b, AR57.
"""
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional
from .decay import DecayClock, DECAY_CLASSES


@dataclass
class EdgeState:
    # Identity
    edge_id: str
    source_node_id: str
    target_node_id: str
    edge_type: str
    ontology_version: str

    # Probabilistic
    p_prior: float
    p_posterior: float
    likelihood_ratio: float

    # Magnitude
    magnitude_base: float
    magnitude_ci_width: float
    magnitude_adjusted: float  # = magnitude_base * (1 - ci_width/2)

    # Temporal - use DecayClock
    decay_clock: DecayClock

    # Correlation
    rho_corr: float = 0.0

    # Classification
    narrative_sensitive: bool = True
    status: str = "ACTIVE"  # ACTIVE | CONTESTED | RETIRED
    contested_type: Optional[str] = None  # Type A | Type B

    # Evidence
    evidence_source_urls: list = field(default_factory=list)
    extraction_event_ids: list = field(default_factory=list)

    @property
    def decay_factor(self) -> float:
        return self.decay_clock.get_decay_factor()

    @property
    def wt(self) -> float:
        """Wt = P_post × M_adj × decay × (1 − ρ_corr)"""
        return self.p_posterior * self.magnitude_adjusted * self.decay_factor * (1.0 - self.rho_corr)


def bayesian_update(p_prior: float, likelihood_ratio: float) -> float:
    """P_post = (LR × P_prior) / (LR × P_prior + (1 − P_prior))"""
    numerator = likelihood_ratio * p_prior
    return numerator / (numerator + (1.0 - p_prior))


def compute_magnitude_adjusted(magnitude_base: float, ci_width: float) -> float:
    """M_adj = M_base × (1 − CI_width/2)"""
    return magnitude_base * (1.0 - ci_width / 2.0)


# Correlation matrix between source types.
# Wire services are correlated; AIS + wire are not.
SOURCE_CORRELATION_MATRIX = {
    ("primary_wire_service", "primary_wire_service"): 0.75,
    ("primary_wire_service", "social_media"): 0.50,
    ("primary_wire_service", "ais_vessel_tracking"): 0.15,
    ("primary_wire_service", "macro_release"): 0.40,
    ("primary_wire_service", "satellite_imagery"): 0.10,
    ("primary_wire_service", "engineering_assessment"): 0.10,
    ("primary_wire_service", "official_government_statement"): 0.30,
    ("ais_vessel_tracking", "ais_vessel_tracking"): 0.20,
    ("ais_vessel_tracking", "physical_observable"): 0.30,
    ("satellite_imagery", "satellite_imagery"): 0.20,
    ("macro_release", "macro_release"): 0.60,
    ("social_media", "social_media"): 0.80,
}


def compute_correlation_penalty(evidence_source_types: list) -> float:
    """
    Returns rho_corr in [0, 1].
    0 = fully independent, 0.8 = 80% correlated.
    If only one source type, return 0.0.
    If multiple, return the max pairwise correlation found.
    """
    if len(evidence_source_types) <= 1:
        return 0.0
    max_corr = 0.0
    for i, a in enumerate(evidence_source_types):
        for b in evidence_source_types[i + 1:]:
            # Try canonical (sorted) key first, then both orderings
            key = (min(a, b), max(a, b))
            corr = SOURCE_CORRELATION_MATRIX.get(key, 0.0)
            if corr == 0.0:
                corr = SOURCE_CORRELATION_MATRIX.get((a, b), 0.0)
            if corr == 0.0:
                corr = SOURCE_CORRELATION_MATRIX.get((b, a), 0.0)
            max_corr = max(max_corr, corr)
    return max_corr
