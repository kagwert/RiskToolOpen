"""
Conflict resolution for contradicting causal signals.
Per AR57: three-stage protocol.
Per AR61: CONTESTED Type A = evidence too close to call.
Per AR61b: CONTESTED Type B = bimodal distribution, route to options.
"""
from dataclasses import dataclass
from typing import Optional, Tuple
from .bayesian_update import EdgeState

ADVERSARIAL_SCORE_THRESHOLD = 0.15  # If score diff < threshold, CONTESTED
BIMODAL_SPREAD_THRESHOLD = 30.0      # Per AR61b: spread > 30 required for Type B
CONTESTED_B_MIN_POSTERIOR = 0.25     # Per AR61b: both P > 0.25


@dataclass
class ConflictResolutionResult:
    outcome: str  # ACTIVE | CONTESTED_A | CONTESTED_B | NO_CONFLICT
    winning_edge_id: Optional[str]
    losing_edge_id: Optional[str]
    score_a: float
    score_b: float
    reason: str
    bimodal_spread: Optional[float] = None  # For Type B


def resolve_conflict(
    edge_a: EdgeState,
    edge_b: EdgeState,
    polymarket_resolution_exists: bool = False,
    bimodal_spread: Optional[float] = None,
) -> ConflictResolutionResult:
    """
    Three-stage conflict resolution:
    Stage 1: Do they address the same mechanism? If not, no conflict.
    Stage 2: Adversarial scoring — each scores the other's evidence.
    Stage 3: Score diff > threshold → ACTIVE for stronger; else → CONTESTED.

    CONTESTED Type B criteria per AR61b:
    - Both P > 0.25
    - Bimodal distribution (spread > 30)
    - Resolution timeline exists (polymarket)

    Returns ConflictResolutionResult.
    """
    # Stage 1: Same mechanism check.
    # Two edges conflict only if they target the same asset via the same edge type.
    if edge_a.edge_type != edge_b.edge_type:
        return ConflictResolutionResult(
            outcome="NO_CONFLICT",
            winning_edge_id=None,
            losing_edge_id=None,
            score_a=score_evidence_quality(edge_a),
            score_b=score_evidence_quality(edge_b),
            reason=(
                f"Edge types differ ({edge_a.edge_type!r} vs {edge_b.edge_type!r}): "
                "different mechanisms, no structural conflict."
            ),
            bimodal_spread=bimodal_spread,
        )

    if edge_a.target_node_id != edge_b.target_node_id:
        return ConflictResolutionResult(
            outcome="NO_CONFLICT",
            winning_edge_id=None,
            losing_edge_id=None,
            score_a=score_evidence_quality(edge_a),
            score_b=score_evidence_quality(edge_b),
            reason=(
                f"Target nodes differ ({edge_a.target_node_id!r} vs "
                f"{edge_b.target_node_id!r}): edges affect different assets."
            ),
            bimodal_spread=bimodal_spread,
        )

    # Stage 2: Adversarial scoring.
    score_a = score_evidence_quality(edge_a)
    score_b = score_evidence_quality(edge_b)
    score_diff = abs(score_a - score_b)

    # Stage 3: Determine outcome.

    # Check for Type B (bimodal) conditions per AR61b before checking score diff.
    # Type B requires: both P > 0.25, bimodal spread > 30, polymarket resolution exists.
    if (
        polymarket_resolution_exists
        and bimodal_spread is not None
        and bimodal_spread > BIMODAL_SPREAD_THRESHOLD
        and edge_a.p_posterior > CONTESTED_B_MIN_POSTERIOR
        and edge_b.p_posterior > CONTESTED_B_MIN_POSTERIOR
    ):
        return ConflictResolutionResult(
            outcome="CONTESTED_B",
            winning_edge_id=None,
            losing_edge_id=None,
            score_a=score_a,
            score_b=score_b,
            reason=(
                f"Type B contested: bimodal distribution (spread={bimodal_spread:.1f} > "
                f"{BIMODAL_SPREAD_THRESHOLD}), both posteriors above threshold "
                f"(A={edge_a.p_posterior:.3f}, B={edge_b.p_posterior:.3f}), "
                "resolution timeline exists. Route to options desk."
            ),
            bimodal_spread=bimodal_spread,
        )

    # Type A check: score diff below threshold — too close to call.
    if score_diff < ADVERSARIAL_SCORE_THRESHOLD:
        return ConflictResolutionResult(
            outcome="CONTESTED_A",
            winning_edge_id=None,
            losing_edge_id=None,
            score_a=score_a,
            score_b=score_b,
            reason=(
                f"Type A contested: adversarial score difference {score_diff:.4f} "
                f"< threshold {ADVERSARIAL_SCORE_THRESHOLD}. Evidence too close to call."
            ),
            bimodal_spread=bimodal_spread,
        )

    # Clear winner — stronger evidence edge becomes ACTIVE.
    if score_a >= score_b:
        return ConflictResolutionResult(
            outcome="ACTIVE",
            winning_edge_id=edge_a.edge_id,
            losing_edge_id=edge_b.edge_id,
            score_a=score_a,
            score_b=score_b,
            reason=(
                f"Edge A wins: adversarial score {score_a:.4f} vs {score_b:.4f} "
                f"(diff={score_diff:.4f} > threshold={ADVERSARIAL_SCORE_THRESHOLD})."
            ),
            bimodal_spread=bimodal_spread,
        )
    else:
        return ConflictResolutionResult(
            outcome="ACTIVE",
            winning_edge_id=edge_b.edge_id,
            losing_edge_id=edge_a.edge_id,
            score_a=score_a,
            score_b=score_b,
            reason=(
                f"Edge B wins: adversarial score {score_b:.4f} vs {score_a:.4f} "
                f"(diff={score_diff:.4f} > threshold={ADVERSARIAL_SCORE_THRESHOLD})."
            ),
            bimodal_spread=bimodal_spread,
        )


def score_evidence_quality(edge: EdgeState) -> float:
    """
    Score evidence quality 0.0-1.0 based on:
    - p_posterior (higher = stronger evidence)
    - rho_corr (lower correlation = more independent evidence)
    - narrative_sensitive (False = harder evidence = higher score)
    - decay factor (less decayed = fresher evidence)

    Scoring weights chosen to reflect the relative importance of each dimension:
    - Posterior probability: 40% — primary signal strength
    - Independence (1 - rho_corr): 20% — correlated sources inflate confidence
    - Evidence hardness (!narrative_sensitive): 20% — hard evidence > narrative
    - Freshness (decay factor): 20% — stale evidence should carry less weight

    Result is always in [0.0, 1.0].
    """
    # Posterior contribution: maps [0, 1] → [0, 0.40]
    posterior_score = edge.p_posterior * 0.40

    # Independence contribution: lower correlation → higher score.
    # Maps [0, 1] rho_corr → [0.20, 0.0]
    independence_score = (1.0 - edge.rho_corr) * 0.20

    # Evidence hardness: non-narrative (hard) evidence scores full marks.
    hardness_score = 0.20 if not edge.narrative_sensitive else 0.0

    # Freshness: fully fresh decay_factor=1.0 scores 0.20; fully decayed scores 0.0.
    freshness_score = edge.decay_factor * 0.20

    return posterior_score + independence_score + hardness_score + freshness_score
