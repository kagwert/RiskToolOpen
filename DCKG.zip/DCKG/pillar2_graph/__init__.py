"""
Pillar 2 — Causal Graph Layer.

Implements the probabilistic causal knowledge graph (DCKG) with:
- Temporal decay calibrated to economic half-life (DP04, DP05)
- Bayesian edge weight updates from extraction events (AR18b)
- NetworkX DAG with ontology-validated CRUD operations (AR54–AR56)
- Three-stage conflict resolution (AR57, AR61, AR61b)
- Independent macro regime classifier with deterministic overlays (AR58–AR58c)
- Alpha vector construction fully traceable to source evidence (BR01)
"""
