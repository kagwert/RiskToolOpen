"""
Graph store — NetworkX DAG with causal edge CRUD.
Per AR54, AR55, AR56.
Production replacement: Neo4j.
"""
import networkx as nx
from typing import Optional, Dict, List
from datetime import datetime, timezone
import uuid
try:
    from ..governance.ontology import get_ontology, OntologyViolationError
except (ImportError, ValueError):
    from governance.ontology import get_ontology, OntologyViolationError
from .bayesian_update import EdgeState, bayesian_update, compute_magnitude_adjusted
from .decay import DecayClock, DECAY_CLASSES


class GraphStore:
    """
    In-process NetworkX DiGraph storing causal edges.
    All edges are EdgeState objects.
    All operations validate against the ontology before executing.
    """

    def __init__(self, ontology_version: str = "1.0"):
        self.graph = nx.DiGraph()
        self.ontology_version = ontology_version
        self._ontology = get_ontology()
        self._edges: Dict[str, EdgeState] = {}  # edge_id -> EdgeState

    def add_node(self, node_id: str, node_type: str, metadata: dict = None) -> None:
        """Add a node, validating node_type against ontology."""
        self._ontology.validate_node_type(node_type)
        attrs = {"node_type": node_type}
        if metadata:
            attrs.update(metadata)
        self.graph.add_node(node_id, **attrs)

    def add_edge(
        self,
        source_node_id: str,
        target_node_id: str,
        edge_type: str,
        p_prior: float,
        likelihood_ratio: float,
        magnitude_base: float,
        magnitude_ci_width: float,
        narrative_sensitive: bool = True,
        source_url: str = None,
        extraction_event_id: str = None,
    ) -> EdgeState:
        """
        Add a causal edge. Validates against ontology first.
        Raises OntologyViolationError immediately if edge_type invalid.
        Returns the created EdgeState.
        """
        # Validate edge_type against ontology before any graph mutation.
        self._ontology.validate_edge_type(edge_type)

        # Validate node types if the nodes already exist in the graph.
        source_attrs = self.graph.nodes.get(source_node_id, {})
        target_attrs = self.graph.nodes.get(target_node_id, {})
        source_type = source_attrs.get("node_type")
        target_type = target_attrs.get("node_type")

        if source_type is not None and target_type is not None:
            self._ontology.validate_edge(source_type, edge_type, target_type)

        # Compute derived values.
        p_posterior = bayesian_update(p_prior, likelihood_ratio)
        magnitude_adjusted = compute_magnitude_adjusted(magnitude_base, magnitude_ci_width)

        # Determine decay class from ontology.
        decay_class = self._ontology.get_decay_class(edge_type)

        # Build the decay clock.
        now = datetime.now(timezone.utc)
        decay_clock = DecayClock(
            decay_class=decay_class,
            last_confirmed_at=now,
            created_at=now,
        )

        edge_id = str(uuid.uuid4())

        edge_state = EdgeState(
            edge_id=edge_id,
            source_node_id=source_node_id,
            target_node_id=target_node_id,
            edge_type=edge_type,
            ontology_version=self.ontology_version,
            p_prior=p_prior,
            p_posterior=p_posterior,
            likelihood_ratio=likelihood_ratio,
            magnitude_base=magnitude_base,
            magnitude_ci_width=magnitude_ci_width,
            magnitude_adjusted=magnitude_adjusted,
            decay_clock=decay_clock,
            narrative_sensitive=narrative_sensitive,
            status="ACTIVE",
            evidence_source_urls=[source_url] if source_url else [],
            extraction_event_ids=[extraction_event_id] if extraction_event_id else [],
        )

        self._edges[edge_id] = edge_state

        # Add nodes if they don't exist yet (without type — caller should use add_node for typed nodes).
        if source_node_id not in self.graph:
            self.graph.add_node(source_node_id)
        if target_node_id not in self.graph:
            self.graph.add_node(target_node_id)

        self.graph.add_edge(source_node_id, target_node_id, edge_id=edge_id)

        return edge_state

    def update_edge(
        self,
        edge_id: str,
        new_likelihood_ratio: float,
        source_url: str = None,
        extraction_event_id: str = None,
    ) -> EdgeState:
        """
        Update an existing edge with new evidence.
        Applies Bayesian update: new p_posterior from current p_posterior as new p_prior.
        Resets decay clock (last_confirmed_at = now).
        """
        edge = self._get_edge_or_raise(edge_id)

        # Use current p_posterior as the new p_prior for sequential Bayesian updating.
        new_p_prior = edge.p_posterior
        new_p_posterior = bayesian_update(new_p_prior, new_likelihood_ratio)

        edge.p_prior = new_p_prior
        edge.p_posterior = new_p_posterior
        edge.likelihood_ratio = new_likelihood_ratio

        # Reset decay clock on new confirming evidence.
        edge.decay_clock.reset()

        if source_url:
            edge.evidence_source_urls.append(source_url)
        if extraction_event_id:
            edge.extraction_event_ids.append(extraction_event_id)

        return edge

    def get_edge(self, edge_id: str) -> Optional[EdgeState]:
        return self._edges.get(edge_id)

    def get_edges_to_asset(self, asset_node_id: str) -> List[EdgeState]:
        """Return all ACTIVE edges pointing to given asset node."""
        result = []
        for predecessor in self.graph.predecessors(asset_node_id):
            edge_data = self.graph.get_edge_data(predecessor, asset_node_id)
            if edge_data:
                eid = edge_data.get("edge_id")
                if eid and eid in self._edges:
                    edge = self._edges[eid]
                    if edge.status == "ACTIVE":
                        result.append(edge)
        return result

    def get_all_edges(self) -> List[EdgeState]:
        return list(self._edges.values())

    def retire_edge(self, edge_id: str, reason: str = "") -> EdgeState:
        """Set edge status to RETIRED."""
        edge = self._get_edge_or_raise(edge_id)
        edge.status = "RETIRED"
        return edge

    def contest_edge(self, edge_id: str, contested_type: str) -> EdgeState:
        """Set edge status to CONTESTED with given type (A or B)."""
        edge = self._get_edge_or_raise(edge_id)
        edge.status = "CONTESTED"
        edge.contested_type = contested_type
        return edge

    def freeze_edge_clock(self, edge_id: str, trigger: str) -> EdgeState:
        """Freeze decay clock for edge due to trigger (e.g. feed_failure, ceasefire_announced)."""
        edge = self._get_edge_or_raise(edge_id)
        edge.decay_clock.process_trigger(trigger)
        return edge

    def reset_edge_clock(self, edge_id: str, trigger: str) -> EdgeState:
        """Reset decay clock for edge due to trigger (e.g. engineering_verification_confirmed)."""
        edge = self._get_edge_or_raise(edge_id)
        edge.decay_clock.process_trigger(trigger)
        return edge

    def get_state_snapshot(self) -> dict:
        """Return a JSON-serializable snapshot of all nodes and edges."""
        nodes = []
        for node_id, attrs in self.graph.nodes(data=True):
            nodes.append({"node_id": node_id, **attrs})

        edges = []
        for edge_id, edge in self._edges.items():
            clock = edge.decay_clock
            edges.append({
                "edge_id": edge.edge_id,
                "source_node_id": edge.source_node_id,
                "target_node_id": edge.target_node_id,
                "edge_type": edge.edge_type,
                "ontology_version": edge.ontology_version,
                "p_prior": edge.p_prior,
                "p_posterior": edge.p_posterior,
                "likelihood_ratio": edge.likelihood_ratio,
                "magnitude_base": edge.magnitude_base,
                "magnitude_ci_width": edge.magnitude_ci_width,
                "magnitude_adjusted": edge.magnitude_adjusted,
                "decay_class": clock.decay_class,
                "last_confirmed_at": clock.last_confirmed_at.isoformat(),
                "created_at": clock.created_at.isoformat(),
                "frozen": clock.frozen,
                "frozen_t_days": clock.frozen_t_days,
                "decay_factor": edge.decay_factor,
                "wt": edge.wt,
                "rho_corr": edge.rho_corr,
                "narrative_sensitive": edge.narrative_sensitive,
                "status": edge.status,
                "contested_type": edge.contested_type,
                "evidence_source_urls": edge.evidence_source_urls,
                "extraction_event_ids": edge.extraction_event_ids,
            })

        return {"nodes": nodes, "edges": edges}

    def _get_edge_or_raise(self, edge_id: str) -> EdgeState:
        edge = self._edges.get(edge_id)
        if edge is None:
            raise KeyError(f"Edge {edge_id!r} not found in graph store.")
        return edge
