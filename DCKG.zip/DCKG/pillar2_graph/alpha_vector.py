"""
Alpha vector construction from causal graph edges.
Per BR01: alpha must be fully traceable to source edges and evidence.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from datetime import datetime, timezone
from .bayesian_update import EdgeState
from .regime_classifier import RegimeClassifier, RegimeDimensions


@dataclass
class AlphaContribution:
    edge_id: str
    edge_type: str
    wt: float
    regime_multiplier: float
    adjusted_wt: float  # wt * regime_multiplier
    source_urls: List[str]


@dataclass
class AssetAlpha:
    asset_id: str
    alpha: float  # sum of adjusted edge weights
    contributions: List[AlphaContribution]
    narrative_sensitive: bool  # True if ANY contributing edge is narrative-sensitive
    computed_at: str


class AlphaVectorBuilder:
    """
    Aggregates edge weights into per-asset alpha signals.
    Applies regime sign multipliers for POLICY_RISK_TO edges.
    """

    def __init__(self, regime_classifier: RegimeClassifier):
        self.regime_classifier = regime_classifier

    def build(
        self,
        edges: List[EdgeState],
        current_regime: str,
        universe: List[str],
    ) -> Dict[str, AssetAlpha]:
        """
        Build alpha vector from active edges.
        - Only include ACTIVE edges (not CONTESTED, not RETIRED)
        - Apply regime multipliers for regime-conditional edge types
        - Aggregate by target asset
        - Return dict: asset_id -> AssetAlpha
        """
        now_iso = datetime.now(timezone.utc).isoformat()

        # Accumulate contributions per asset.
        # Only universe assets are included in the output.
        universe_set = set(universe)

        # asset_id -> list of AlphaContribution
        contributions_by_asset: Dict[str, List[AlphaContribution]] = {
            asset_id: [] for asset_id in universe
        }

        for edge in edges:
            # Skip non-ACTIVE edges.
            if edge.status != "ACTIVE":
                continue

            target = edge.target_node_id
            if target not in universe_set:
                continue

            # Compute regime multiplier.
            # Per AR58b, POLICY_RISK_TO edges are regime-conditional.
            if self.regime_classifier is not None:
                regime_multiplier = self.regime_classifier.get_edge_sign_multiplier(
                    current_regime, edge.edge_type
                )
            else:
                regime_multiplier = 1.0

            wt = edge.wt
            adjusted_wt = wt * regime_multiplier

            contribution = AlphaContribution(
                edge_id=edge.edge_id,
                edge_type=edge.edge_type,
                wt=wt,
                regime_multiplier=regime_multiplier,
                adjusted_wt=adjusted_wt,
                source_urls=list(edge.evidence_source_urls),
            )
            contributions_by_asset[target].append(contribution)

        # Assemble AssetAlpha objects for all universe assets.
        result: Dict[str, AssetAlpha] = {}
        for asset_id in universe:
            contribs = contributions_by_asset[asset_id]
            alpha_sum = sum(c.adjusted_wt for c in contribs)
            # narrative_sensitive = True if ANY contributing edge is narrative-sensitive.
            is_narrative = any(c for c in contribs if _is_narrative(edges, c.edge_id))

            result[asset_id] = AssetAlpha(
                asset_id=asset_id,
                alpha=alpha_sum,
                contributions=contribs,
                narrative_sensitive=is_narrative,
                computed_at=now_iso,
            )

        return result

    def to_numpy_vector(
        self,
        alpha_dict: Dict[str, AssetAlpha],
        universe: List[str],
    ):
        """Return alpha as numpy array aligned to universe order."""
        try:
            import numpy as np
        except ImportError as exc:
            raise ImportError(
                "numpy is required for to_numpy_vector. "
                "Install it with: pip install numpy"
            ) from exc

        values = []
        for asset_id in universe:
            asset_alpha = alpha_dict.get(asset_id)
            values.append(asset_alpha.alpha if asset_alpha is not None else 0.0)
        return np.array(values, dtype=float)


def _is_narrative(edges: List[EdgeState], edge_id: str) -> bool:
    """Helper: look up narrative_sensitive for an edge by id."""
    for e in edges:
        if e.edge_id == edge_id:
            return e.narrative_sensitive
    return True  # Conservative default: treat unknown edges as narrative-sensitive.
