"""
Regime classifier — independent of the causal graph per AR58.
Per AR58b: overlays activate deterministically on regime entry.
Per AR58c: reclassification requires 2 of 3 dimensions AND 2 independent sources.
"""
import yaml
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional, List, Dict
from datetime import datetime, timezone

# Default path to the regimes configuration file.
_DEFAULT_REGIMES_PATH = (
    Path(__file__).parent.parent / "config" / "regimes.yaml"
)


@dataclass
class RegimeDimensions:
    """The three dimensions that determine regime."""
    growth: str          # POSITIVE | NEGATIVE
    inflation: str       # ABOVE_TARGET | BELOW_TARGET
    risk_appetite: str   # ON | OFF


@dataclass
class RegimeClassification:
    regime: str
    confidence: float
    dimensions: RegimeDimensions
    classified_at: str          # ISO8601
    confirming_sources: List[str]  # Must have >= 2 for reclassification
    overlays: List[dict]        # Standing overlay positions


@dataclass
class OverlayPosition:
    instrument: str
    sizing: str
    exit_trigger: str
    exit_mechanism: str
    activated_at: str
    regime: str


class RegimeClassifier:
    """
    Classifies macro regime from three dimensions.
    Independent of the causal graph.
    """

    def __init__(self, config_path: str = None):
        path = Path(config_path) if config_path else _DEFAULT_REGIMES_PATH
        if not path.exists():
            raise FileNotFoundError(
                f"Regimes YAML not found at {path}. "
                "Check that config/regimes.yaml is present in the project root."
            )
        with path.open("r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
        self._data = data
        self._regimes: dict = data.get("regimes", {})
        self._rules: dict = data.get("reclassification_rules", {})
        self._min_sources: int = int(
            self._rules.get("confirmation_sources_minimum", 2)
        )
        self._min_dimensions: int = int(
            self._rules.get("minimum_dimensions_to_reclassify", 2)
        )

    def classify(
        self,
        dimensions: RegimeDimensions,
        confirming_sources: List[str],
        current_regime: Optional[str] = None,
    ) -> RegimeClassification:
        """
        Classify regime from dimensions.
        Per AR58c: reclassification requires 2+ confirming sources.
        If reclassification is triggered, overlays activate immediately.
        """
        candidate_regime = self._match_regime(dimensions)
        now_iso = datetime.now(timezone.utc).isoformat()

        # If there is no current regime, this is initial classification — no
        # minimum-source requirement for first classification.
        if current_regime is None:
            confidence = 1.0 if len(confirming_sources) >= self._min_sources else 0.7
            overlays = self.get_overlays(candidate_regime)
            return RegimeClassification(
                regime=candidate_regime,
                confidence=confidence,
                dimensions=dimensions,
                classified_at=now_iso,
                confirming_sources=confirming_sources,
                overlays=overlays,
            )

        # If the candidate is the same as the current regime, return as confirmed.
        if candidate_regime == current_regime:
            return RegimeClassification(
                regime=current_regime,
                confidence=1.0,
                dimensions=dimensions,
                classified_at=now_iso,
                confirming_sources=confirming_sources,
                overlays=self.get_overlays(current_regime),
            )

        # Reclassification attempt: requires minimum confirming sources per AR58c.
        if len(confirming_sources) < self._min_sources:
            # Insufficient sources — stay in current regime.
            return RegimeClassification(
                regime=current_regime,
                confidence=0.5,
                dimensions=dimensions,
                classified_at=now_iso,
                confirming_sources=confirming_sources,
                overlays=self.get_overlays(current_regime),
            )

        # Check how many dimensions have shifted from the current regime.
        current_dims = self._get_regime_dimensions(current_regime)
        shifted_count = 0
        if current_dims is not None:
            if dimensions.growth != current_dims.growth:
                shifted_count += 1
            if dimensions.inflation != current_dims.inflation:
                shifted_count += 1
            if dimensions.risk_appetite != current_dims.risk_appetite:
                shifted_count += 1

        if shifted_count < self._min_dimensions:
            # Not enough dimensions have shifted — stay in current regime.
            return RegimeClassification(
                regime=current_regime,
                confidence=0.6,
                dimensions=dimensions,
                classified_at=now_iso,
                confirming_sources=confirming_sources,
                overlays=self.get_overlays(current_regime),
            )

        # Reclassification confirmed: activate overlays for new regime immediately.
        new_overlays = self.get_overlays(candidate_regime)
        return RegimeClassification(
            regime=candidate_regime,
            confidence=1.0,
            dimensions=dimensions,
            classified_at=now_iso,
            confirming_sources=confirming_sources,
            overlays=new_overlays,
        )

    def get_overlays(self, regime: str) -> List[dict]:
        """Return overlay positions for a regime."""
        regime_def = self._regimes.get(regime, {})
        return list(regime_def.get("portfolio_overlays", []))

    def get_edge_sign_multiplier(self, regime: str, edge_type: str) -> float:
        """Get sign multiplier for an edge type in a given regime."""
        regime_def = self._regimes.get(regime, {})
        multipliers = regime_def.get("edge_sign_multipliers", {})
        # Try exact key first (e.g. "POLICY_RISK_TO_rates"),
        # then the bare edge_type (e.g. "POLICY_RISK_TO").
        if edge_type in multipliers:
            return float(multipliers[edge_type])
        # Look for any key that starts with the edge_type prefix.
        for key, val in multipliers.items():
            if key.startswith(edge_type):
                return float(val)
        # Default: no sign adjustment.
        return 1.0

    def _match_regime(self, dimensions: RegimeDimensions) -> str:
        """Match dimensions to regime name.

        The regimes YAML stores risk_appetite as YAML booleans (True/False) because
        YAML interprets unquoted ON/OFF as boolean values. This method normalises
        both the YAML-loaded values and the caller's string values before comparison.
        """
        target_growth = dimensions.growth
        target_inflation = dimensions.inflation
        target_risk = dimensions.risk_appetite

        for regime_name, regime_def in self._regimes.items():
            dims = regime_def.get("dimensions", {})
            yaml_growth = dims.get("growth")
            yaml_inflation = dims.get("inflation")
            yaml_risk = dims.get("risk_appetite")

            # Normalise risk_appetite: YAML True -> "ON", False -> "OFF"
            if yaml_risk is True:
                yaml_risk = "ON"
            elif yaml_risk is False:
                yaml_risk = "OFF"

            if (
                yaml_growth == target_growth
                and yaml_inflation == target_inflation
                and yaml_risk == target_risk
            ):
                return regime_name
        # Fallback: return UNKNOWN if no match.
        return "UNKNOWN"

    def _get_regime_dimensions(self, regime: str) -> Optional[RegimeDimensions]:
        """Return RegimeDimensions for a named regime, or None if unknown.

        Normalises YAML boolean risk_appetite values (True->ON, False->OFF).
        """
        regime_def = self._regimes.get(regime)
        if regime_def is None:
            return None
        dims = regime_def.get("dimensions", {})
        risk = dims.get("risk_appetite", "")
        if risk is True:
            risk = "ON"
        elif risk is False:
            risk = "OFF"
        return RegimeDimensions(
            growth=dims.get("growth", ""),
            inflation=dims.get("inflation", ""),
            risk_appetite=risk,
        )
