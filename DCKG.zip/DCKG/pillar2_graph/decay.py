"""
Temporal decay implementation.
Per DP04: decay constants calibrated to economic half-life.
Per DP05: t measured from last_confirmed_at — resets on confirmation.
Per AR18b: decay clock frozen during feed failures.

CRITICAL: For INFRASTRUCTURE_DAMAGE, ceasefire events FREEZE the clock (do not reset).
"""
import math
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Optional

DECAY_CLASSES = {
    "LIQUIDITY_STRESS": {
        "half_life_days": 7,
        "clock_reset_triggers": ["new_confirming_wire", "physical_observable_confirmation"],
        "clock_freeze_triggers": ["feed_failure"],
    },
    "SUPPLY_FLOW": {
        "half_life_days": 14,
        "clock_reset_triggers": ["ais_confirmation", "physical_flow_data", "exchange_data"],
        "clock_freeze_triggers": ["feed_failure"],
    },
    "COST": {
        "half_life_days": 45,
        "clock_reset_triggers": ["macro_release_confirmation", "earnings_confirmation"],
        "clock_freeze_triggers": ["feed_failure"],
    },
    "POLICY": {
        "half_life_days": 180,
        "clock_reset_triggers": ["central_bank_decision", "government_announcement"],
        "clock_freeze_triggers": ["feed_failure"],
    },
    "INFRASTRUCTURE_DAMAGE": {
        "half_life_days": 1825,
        "clock_reset_triggers": ["engineering_verification_confirmed"],
        "clock_freeze_triggers": ["feed_failure", "ceasefire_announced", "diplomatic_agreement"],
    },
}


@dataclass
class DecayClock:
    decay_class: str
    last_confirmed_at: datetime   # base for t calculation
    created_at: datetime
    frozen: bool = False
    frozen_t_days: Optional[float] = None  # t value when frozen

    def get_t_days(self, now: Optional[datetime] = None) -> float:
        """Days since last_confirmed_at. Returns frozen_t_days if clock is frozen."""
        if self.frozen and self.frozen_t_days is not None:
            return self.frozen_t_days
        if now is None:
            now = datetime.now(timezone.utc)
        # Ensure both are timezone-aware for subtraction
        lca = self.last_confirmed_at
        if lca.tzinfo is None:
            lca = lca.replace(tzinfo=timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        delta = now - lca
        return delta.total_seconds() / 86400.0

    def get_decay_factor(self, now: Optional[datetime] = None) -> float:
        """exp(-lambda * t) where lambda = ln(2) / half_life_days"""
        config = DECAY_CLASSES.get(self.decay_class)
        if config is None:
            raise ValueError(f"Unknown decay class: {self.decay_class!r}")
        half_life = config["half_life_days"]
        lam = math.log(2) / half_life
        t = self.get_t_days(now=now)
        return math.exp(-lam * t)

    def freeze(self, now: Optional[datetime] = None) -> None:
        """Freeze the clock at current t. Does NOT reset t."""
        if self.frozen:
            # Already frozen — do nothing; preserves the t value from the original freeze
            return
        current_t = self.get_t_days(now=now)
        self.frozen = True
        self.frozen_t_days = current_t

    def reset(self, now: Optional[datetime] = None) -> None:
        """Reset the clock: last_confirmed_at = now, frozen = False, t = 0."""
        if now is None:
            now = datetime.now(timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        self.last_confirmed_at = now
        self.frozen = False
        self.frozen_t_days = None

    def process_trigger(self, trigger: str, now: Optional[datetime] = None) -> str:
        """
        Process a clock trigger event. Returns 'frozen', 'reset', or 'no_action'.

        For INFRASTRUCTURE_DAMAGE: freeze on ceasefire/diplomatic, reset only on
        engineering_verification_confirmed.
        For all classes: freeze on feed_failure.
        For all classes: reset on their class-specific reset triggers.

        The precedence for INFRASTRUCTURE_DAMAGE is:
        1. Check freeze triggers first (includes ceasefire_announced, diplomatic_agreement,
           feed_failure) — if trigger matches, FREEZE (not reset).
        2. Check reset triggers (only engineering_verification_confirmed) — RESET.
        3. Otherwise no_action.

        For all other decay classes:
        1. Check reset triggers first — if match, RESET.
        2. Check freeze triggers (feed_failure) — if match, FREEZE.
        3. Otherwise no_action.
        """
        config = DECAY_CLASSES.get(self.decay_class)
        if config is None:
            raise ValueError(f"Unknown decay class: {self.decay_class!r}")

        reset_triggers = config["clock_reset_triggers"]
        freeze_triggers = config["clock_freeze_triggers"]

        if self.decay_class == "INFRASTRUCTURE_DAMAGE":
            # CRITICAL: for INFRASTRUCTURE_DAMAGE, freeze triggers take priority.
            # ceasefire_announced and diplomatic_agreement are FREEZE triggers only.
            # The clock only RESETS on engineering_verification_confirmed.
            if trigger in freeze_triggers:
                self.freeze(now=now)
                return "frozen"
            if trigger in reset_triggers:
                self.reset(now=now)
                return "reset"
            return "no_action"
        else:
            # All other classes: reset triggers take priority over freeze triggers.
            if trigger in reset_triggers:
                self.reset(now=now)
                return "reset"
            if trigger in freeze_triggers:
                self.freeze(now=now)
                return "frozen"
            return "no_action"


def get_half_life(decay_class: str) -> float:
    """Return half_life_days for given decay class."""
    config = DECAY_CLASSES.get(decay_class)
    if config is None:
        raise ValueError(f"Unknown decay class: {decay_class!r}")
    return float(config["half_life_days"])
